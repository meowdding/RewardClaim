package net.ornithemc.osl.registries.api.registry.sync;

import net.minecraft.unmapped.C_02814799;

/**
 * An {@linkplain IdMapper} implementation for {@linkplain C_02814799}s
 * where IDs are used as keys to the map. The values are moved from the old key
 * (the old ID) to the new key (the new ID) within the same map. {@code null} is
 * used as the default or "empty" value.
 */
public class Id2ObjectBiMapMapper implements IdMapper {

	public static Id2ObjectBiMapMapper of(C_02814799<?> registry) {
		return new Id2ObjectBiMapMapper(registry);
	}

	private final C_02814799<Object> registry;
	private final C_02814799<Object> backup;

	private boolean applied;

	@SuppressWarnings("unchecked")
	private Id2ObjectBiMapMapper(C_02814799<?> registry) {
		this.registry = (C_02814799<Object>) registry;
		this.backup = new C_02814799<>(registry.m_03214275());
	}

	/*
	 * unlike Registry, Id2ObjectBiMap allows duplicate values
	 * thus iterating over all values will not give you all id-value pairs!
	 */

	@Override
	public void apply(RegistryMappings mappings) {
		this.backup.osl$registries$clear();

		for (int id : this.registry.osl$registries$idSet()) {
			this.backup.m_52504356(this.registry.m_91732132(id), id);
		}

		this.registry.osl$registries$clear();

		for (int oldId : this.backup.osl$registries$idSet()) {
			Object value = this.backup.m_91732132(oldId);
			int newId = mappings.remap(oldId);

			if (newId >= 0) {
				this.registry.m_52504356(value, newId);
			}
		}

		this.applied = true;
	}

	@Override
	public void undo(RegistryMappings mappings) {
		if (this.applied) {
			this.registry.osl$registries$clear();

			for (int id : this.backup.osl$registries$idSet()) {
				this.registry.m_52504356(this.backup.m_91732132(id), id);
			}
		}

		this.applied = false;
	}
}

package net.ornithemc.osl.registries.impl.mixin.common;

import net.minecraft.util.registry.DefaultedIdRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(DefaultedIdRegistry.class)
public interface DefaultedIdRegistryAccess {

	@Accessor("defaultKey")
	Object accessDefaultKey();

}

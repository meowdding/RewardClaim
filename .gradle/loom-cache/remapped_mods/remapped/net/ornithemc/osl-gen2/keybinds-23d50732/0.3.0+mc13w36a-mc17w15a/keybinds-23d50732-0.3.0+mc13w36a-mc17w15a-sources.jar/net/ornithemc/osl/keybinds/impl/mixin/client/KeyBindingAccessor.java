package net.ornithemc.osl.keybinds.impl.mixin.client;

import java.util.Set;
import net.minecraft.client.options.KeyBinding;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(KeyBinding.class)
public interface KeyBindingAccessor {

	@Accessor("CATEGORIES")
	static Set<String> accessCategories() {
		throw new UnsupportedOperationException();
	}
}

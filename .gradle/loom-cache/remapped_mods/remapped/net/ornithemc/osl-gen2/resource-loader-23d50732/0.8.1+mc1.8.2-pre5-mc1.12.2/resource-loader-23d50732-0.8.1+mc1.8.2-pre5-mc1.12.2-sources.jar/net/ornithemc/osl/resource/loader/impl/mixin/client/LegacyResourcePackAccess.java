package net.ornithemc.osl.resource.loader.impl.mixin.client;

import net.minecraft.client.resource.pack.ResourcePack;
import net.minecraft.unmapped.C_55632762;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

// only exists in 15w31a+
@Mixin(C_55632762.class)
public interface LegacyResourcePackAccess {

	@Accessor("pack")
	ResourcePack accessPack();

}

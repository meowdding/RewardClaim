/*
 * Original file can be found at
 * https://github.com/FabricMC/fabric-api/blob/1.14/fabric-resource-loader-v0/src/main/java/net/fabricmc/fabric/impl/resource/loader/DeferredInputStream.java
 * 
 * Modifications by OrnitheMC:
 * - remove unused constructor and method
 * - replace Minecraft class reference with OSL equivalent
 * - update formatting to match the rest of the project
 */
/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.ornithemc.osl.resource.loader.impl.resource;

import java.io.IOException;
import java.io.InputStream;

import net.ornithemc.osl.core.api.util.Unit;

/**
 * InputStream deferring to a separate I/O thread to work around
 * Thread.interrupt()-related issues in NIO.
 */
class DeferredInputStream extends InputStream {

	private final InputStream stream;

	DeferredInputStream(InputStream stream) throws IOException {
		if (stream == null) {
			throw new IOException("Something happened while trying to create an InputStream!");
		}

		this.stream = stream;
	}

	@Override
	public int available() throws IOException {
		return DeferredNioExecutionHandler.submit(this.stream::available);
	}

	@Override
	public boolean markSupported() {
		return this.stream.markSupported();
	}

	@Override
	public void mark(int readLimit) {
		this.stream.mark(readLimit);
	}

	@Override
	public void reset() throws IOException {
		DeferredNioExecutionHandler.submit(() -> {
			this.stream.reset();
			return Unit.INSTANCE;
		});
	}

	@Override
	public long skip(long n) throws IOException {
		return DeferredNioExecutionHandler.submit(() -> this.stream.skip(n));
	}

	@Override
	public int read() throws IOException {
		return DeferredNioExecutionHandler.submit(this.stream::read);
	}

	@Override
	public int read(byte[] b) throws IOException {
		return DeferredNioExecutionHandler.submit(() -> this.stream.read(b));
	}

	@Override
	public int read(byte[] b, int offset, int length) throws IOException {
		return DeferredNioExecutionHandler.submit(() -> this.stream.read(b, offset, length));
	}

	@Override
	public void close() throws IOException {
		DeferredNioExecutionHandler.submit(() -> {
			this.stream.close();
			return Unit.INSTANCE;
		});
	}
}

package net.ornithemc.osl.text.api;

import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;

public class TextColor {

	private static final Map<Formatting, TextColor> BY_FORMATTING = new EnumMap<>(Formatting.class);

	public static final TextColor BLACK = new TextColor(Formatting.BLACK);
	public static final TextColor DARK_BLUE = new TextColor(Formatting.DARK_BLUE);
	public static final TextColor DARK_GREEN = new TextColor(Formatting.DARK_GREEN);
	public static final TextColor DARK_AQUA = new TextColor(Formatting.DARK_AQUA);
	public static final TextColor DARK_RED = new TextColor(Formatting.DARK_RED);
	public static final TextColor DARK_PURPLE = new TextColor(Formatting.DARK_PURPLE);
	public static final TextColor GOLD = new TextColor(Formatting.GOLD);
	public static final TextColor GRAY = new TextColor(Formatting.GRAY);
	public static final TextColor DARK_GRAY = new TextColor(Formatting.DARK_GRAY);
	public static final TextColor BLUE = new TextColor(Formatting.BLUE);
	public static final TextColor GREEN = new TextColor(Formatting.GREEN);
	public static final TextColor AQUA = new TextColor(Formatting.AQUA);
	public static final TextColor RED = new TextColor(Formatting.RED);
	public static final TextColor LIGHT_PURPLE = new TextColor(Formatting.LIGHT_PURPLE);
	public static final TextColor YELLOW = new TextColor(Formatting.YELLOW);
	public static final TextColor WHITE = new TextColor(Formatting.WHITE);

	public static final char CUSTOM_COLOR_PREFIX = '#';

	private final Formatting formatting;
	private final int color;

	private TextColor(Formatting formatting) {
		BY_FORMATTING.put(formatting, this);

		this.formatting = formatting;
		this.color = formatting.color;
	}

	private TextColor(int color) {
		this.formatting = null;
		this.color = color;
	}

	public int getColor() {
		return this.color;
	}

	public boolean isFormatting() {
		return this.formatting != null;
	}

	public Formatting getFormatting() {
		return this.formatting;
	}

	public String serialize() {
		if (this.isFormatting()) {
			return this.formatting.name().toLowerCase(Locale.ROOT); 
		} else {
			return CUSTOM_COLOR_PREFIX + Integer.toHexString(this.color);
		}
	}

	public static TextColor of(int color) {
		return new TextColor(color);
	}

	public static TextColor fromFormatting(Formatting formatting) {
		if (formatting.isColor()) {
			TextColor color = BY_FORMATTING.get(formatting);

			if (color != null) {
				return color;
			}

			throw new IllegalStateException("could not resolve text color " + formatting.name());
		} else {
			return null;
		}
	}

	public static TextColor deserialize(String s) {
		if (s.startsWith(String.valueOf(CUSTOM_COLOR_PREFIX))) {
			try {
				int color = Integer.parseInt(s.substring(1), 16);
				return TextColor.of(color);
			} catch (NumberFormatException e) {
				return null;
			}
		} else {
			Formatting formatting = Formatting.valueOf(s.toUpperCase(Locale.ROOT));
			return formatting == null ? null : BY_FORMATTING.get(formatting);
		}
	}
}

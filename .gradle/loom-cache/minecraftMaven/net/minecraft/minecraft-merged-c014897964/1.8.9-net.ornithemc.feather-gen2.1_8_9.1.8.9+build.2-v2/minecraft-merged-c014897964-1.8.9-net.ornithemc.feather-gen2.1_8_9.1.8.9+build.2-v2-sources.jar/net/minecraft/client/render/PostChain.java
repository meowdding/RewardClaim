package net.minecraft.client.render;

import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.pipeline.RenderTarget;
import net.minecraft.client.render.shaders.Uniform;
import net.minecraft.client.render.texture.Texture;
import net.minecraft.client.render.texture.TextureManager;
import net.minecraft.client.resource.Resource;
import net.minecraft.client.resource.manager.ResourceManager;
import net.minecraft.resource.Identifier;
import net.minecraft.server.ChainedJsonException;
import net.minecraft.util.JsonUtils;
import org.apache.commons.io.IOUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Matrix4f;

@Environment(EnvType.CLIENT)
public class PostChain {
	private RenderTarget screenTarget;
	private ResourceManager resourceManager;
	private String name;
	private final List<PostPass> passes = Lists.newArrayList();
	private final Map<String, RenderTarget> customRenderTargets = Maps.newHashMap();
	private final List<RenderTarget> fullSizedTargets = Lists.newArrayList();
	private Matrix4f shaderOrthoMatrix;
	private int screenWidth;
	private int screenHeight;
	private float time;
	private float lastStamp;

	public PostChain(TextureManager textureManager, ResourceManager resourceManager, RenderTarget screenTarget, Identifier id) throws IOException, JsonSyntaxException {
		this.resourceManager = resourceManager;
		this.screenTarget = screenTarget;
		this.time = 0.0F;
		this.lastStamp = 0.0F;
		this.screenWidth = screenTarget.viewWidth;
		this.screenHeight = screenTarget.viewHeight;
		this.name = id.toString();
		this.updateOrthoMatrix();
		this.load(textureManager, id);
	}

	public void load(TextureManager textureManager, Identifier id) throws IOException, JsonSyntaxException {
		JsonParser jsonParser = new JsonParser();
		InputStream inputStream = null;

		try {
			Resource resource = this.resourceManager.getResource(id);
			inputStream = resource.asStream();
			JsonObject jsonObject = jsonParser.parse(IOUtils.toString(inputStream, Charsets.UTF_8)).getAsJsonObject();
			if (JsonUtils.hasJsonArray(jsonObject, "targets")) {
				JsonArray jsonArray = jsonObject.getAsJsonArray("targets");
				int i = 0;

				for (JsonElement jsonElement : jsonArray) {
					try {
						this.parseTargetNode(jsonElement);
					} catch (Exception exception) {
						ChainedJsonException chainedJsonException = ChainedJsonException.forException(exception);
						chainedJsonException.prependJsonKey("targets[" + i + "]");
						throw chainedJsonException;
					}

					i++;
				}
			}

			if (JsonUtils.hasJsonArray(jsonObject, "passes")) {
				JsonArray jsonArray = jsonObject.getAsJsonArray("passes");
				int i = 0;

				for (JsonElement jsonElement : jsonArray) {
					try {
						this.parsePassNode(textureManager, jsonElement);
					} catch (Exception exception) {
						ChainedJsonException chainedJsonException = ChainedJsonException.forException(exception);
						chainedJsonException.prependJsonKey("passes[" + i + "]");
						throw chainedJsonException;
					}

					i++;
				}
			}
		} catch (Exception exception2) {
			ChainedJsonException chainedJsonException2 = ChainedJsonException.forException(exception2);
			chainedJsonException2.setFileNameAndFlush(id.getPath());
			throw chainedJsonException2;
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void parseTargetNode(JsonElement json) throws ChainedJsonException {
		if (JsonUtils.isString(json)) {
			this.addTempTarget(json.getAsString(), this.screenWidth, this.screenHeight);
		} else {
			JsonObject jsonObject = JsonUtils.asJsonObject(json, "target");
			String string = JsonUtils.getString(jsonObject, "name");
			int i = JsonUtils.getIntegerOrDefault(jsonObject, "width", this.screenWidth);
			int j = JsonUtils.getIntegerOrDefault(jsonObject, "height", this.screenHeight);
			if (this.customRenderTargets.containsKey(string)) {
				throw new ChainedJsonException(string + " is already defined");
			}

			this.addTempTarget(string, i, j);
		}
	}

	private void parsePassNode(TextureManager textureManager, JsonElement json) throws IOException {
		JsonObject jsonObject = JsonUtils.asJsonObject(json, "pass");
		String string = JsonUtils.getString(jsonObject, "name");
		String string2 = JsonUtils.getString(jsonObject, "intarget");
		String string3 = JsonUtils.getString(jsonObject, "outtarget");
		RenderTarget renderTarget = this.getRenderTarget(string2);
		RenderTarget renderTarget2 = this.getRenderTarget(string3);
		if (renderTarget == null) {
			throw new ChainedJsonException("Input target '" + string2 + "' does not exist");
		}

		if (renderTarget2 == null) {
			throw new ChainedJsonException("Output target '" + string3 + "' does not exist");
		}

		PostPass postPass = this.addPass(string, renderTarget, renderTarget2);
		JsonArray jsonArray = JsonUtils.getJsonArrayOrDefault(jsonObject, "auxtargets", null);
		if (jsonArray != null) {
			int i = 0;

			for (JsonElement jsonElement : jsonArray) {
				try {
					JsonObject jsonObject2 = JsonUtils.asJsonObject(jsonElement, "auxtarget");
					String string4 = JsonUtils.getString(jsonObject2, "name");
					String string5 = JsonUtils.getString(jsonObject2, "id");
					RenderTarget renderTarget3 = this.getRenderTarget(string5);
					if (renderTarget3 == null) {
						Identifier identifier = new Identifier("textures/effect/" + string5 + ".png");

						try {
							this.resourceManager.getResource(identifier);
						} catch (FileNotFoundException fileNotFoundException) {
							throw new ChainedJsonException("Render target or texture '" + string5 + "' does not exist");
						}

						textureManager.bind(identifier);
						Texture texture = textureManager.get(identifier);
						int j = JsonUtils.getInteger(jsonObject2, "width");
						int k = JsonUtils.getInteger(jsonObject2, "height");
						boolean bl = JsonUtils.getBoolean(jsonObject2, "bilinear");
						if (bl) {
							GL11.glTexParameteri(3553, 10241, 9729);
							GL11.glTexParameteri(3553, 10240, 9729);
						} else {
							GL11.glTexParameteri(3553, 10241, 9728);
							GL11.glTexParameteri(3553, 10240, 9728);
						}

						postPass.addAuxAsset(string4, texture.getGlId(), j, k);
					} else {
						postPass.addAuxAsset(string4, renderTarget3, renderTarget3.width, renderTarget3.height);
					}
				} catch (Exception exception) {
					ChainedJsonException chainedJsonException = ChainedJsonException.forException(exception);
					chainedJsonException.prependJsonKey("auxtargets[" + i + "]");
					throw chainedJsonException;
				}

				i++;
			}
		}

		JsonArray jsonArray2 = JsonUtils.getJsonArrayOrDefault(jsonObject, "uniforms", null);
		if (jsonArray2 != null) {
			int l = 0;

			for (JsonElement jsonElement2 : jsonArray2) {
				try {
					this.parseUniformNode(jsonElement2);
				} catch (Exception exception2) {
					ChainedJsonException chainedJsonException2 = ChainedJsonException.forException(exception2);
					chainedJsonException2.prependJsonKey("uniforms[" + l + "]");
					throw chainedJsonException2;
				}

				l++;
			}
		}
	}

	private void parseUniformNode(JsonElement json) throws ChainedJsonException {
		JsonObject jsonObject = JsonUtils.asJsonObject(json, "uniform");
		String string = JsonUtils.getString(jsonObject, "name");
		Uniform uniform = this.passes.get(this.passes.size() - 1).getEffect().getUniform(string);
		if (uniform == null) {
			throw new ChainedJsonException("Uniform '" + string + "' does not exist");
		}

		float[] fs = new float[4];
		int i = 0;

		for (JsonElement jsonElement : JsonUtils.getJsonArray(jsonObject, "values")) {
			try {
				fs[i] = JsonUtils.asFloat(jsonElement, "value");
			} catch (Exception exception) {
				ChainedJsonException chainedJsonException = ChainedJsonException.forException(exception);
				chainedJsonException.prependJsonKey("values[" + i + "]");
				throw chainedJsonException;
			}

			i++;
		}

		switch (i) {
			case 0:
			default:
				break;
			case 1:
				uniform.set(fs[0]);
				break;
			case 2:
				uniform.set(fs[0], fs[1]);
				break;
			case 3:
				uniform.set(fs[0], fs[1], fs[2]);
				break;
			case 4:
				uniform.set(fs[0], fs[1], fs[2], fs[3]);
		}
	}

	public RenderTarget getTempTarget(String name) {
		return this.customRenderTargets.get(name);
	}

	public void addTempTarget(String name, int width, int height) {
		RenderTarget renderTarget = new RenderTarget(width, height, true);
		renderTarget.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
		this.customRenderTargets.put(name, renderTarget);
		if (width == this.screenWidth && height == this.screenHeight) {
			this.fullSizedTargets.add(renderTarget);
		}
	}

	public void close() {
		for (RenderTarget renderTarget : this.customRenderTargets.values()) {
			renderTarget.destroyBuffers();
		}

		for (PostPass postPass : this.passes) {
			postPass.close();
		}

		this.passes.clear();
	}

	public PostPass addPass(String name, RenderTarget inTarget, RenderTarget outTarget) throws IOException {
		PostPass postPass = new PostPass(this.resourceManager, name, inTarget, outTarget);
		this.passes.add(this.passes.size(), postPass);
		return postPass;
	}

	private void updateOrthoMatrix() {
		this.shaderOrthoMatrix = new Matrix4f();
		this.shaderOrthoMatrix.setIdentity();
		this.shaderOrthoMatrix.m00 = 2.0F / this.screenTarget.width;
		this.shaderOrthoMatrix.m11 = 2.0F / -this.screenTarget.height;
		this.shaderOrthoMatrix.m22 = -0.0020001999F;
		this.shaderOrthoMatrix.m33 = 1.0F;
		this.shaderOrthoMatrix.m03 = -1.0F;
		this.shaderOrthoMatrix.m13 = 1.0F;
		this.shaderOrthoMatrix.m23 = -1.0001999F;
	}

	public void resize(int width, int height) {
		this.screenWidth = this.screenTarget.width;
		this.screenHeight = this.screenTarget.height;
		this.updateOrthoMatrix();

		for (PostPass postPass : this.passes) {
			postPass.setOrthoMatrix(this.shaderOrthoMatrix);
		}

		for (RenderTarget renderTarget : this.fullSizedTargets) {
			renderTarget.resize(width, height);
		}
	}

	public void process(float tickDelta) {
		if (tickDelta < this.lastStamp) {
			this.time = this.time + (1.0F - this.lastStamp);
			this.time += tickDelta;
		} else {
			this.time = this.time + (tickDelta - this.lastStamp);
		}

		this.lastStamp = tickDelta;

		while (this.time > 20.0F) {
			this.time -= 20.0F;
		}

		for (PostPass postPass : this.passes) {
			postPass.process(this.time / 20.0F);
		}
	}

	public final String getName() {
		return this.name;
	}

	private RenderTarget getRenderTarget(String name) {
		if (name == null) {
			return null;
		} else {
			return name.equals("minecraft:main") ? this.screenTarget : this.customRenderTargets.get(name);
		}
	}
}

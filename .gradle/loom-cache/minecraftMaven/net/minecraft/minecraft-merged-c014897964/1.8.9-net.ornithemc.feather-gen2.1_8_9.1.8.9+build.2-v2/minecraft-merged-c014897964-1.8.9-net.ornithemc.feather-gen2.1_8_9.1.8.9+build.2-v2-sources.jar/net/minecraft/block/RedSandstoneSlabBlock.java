package net.minecraft.block;

import java.util.List;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.block.state.property.EnumProperty;
import net.minecraft.block.state.property.Property;
import net.minecraft.block.state.property.StringSerializable;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.locale.I18n;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public abstract class RedSandstoneSlabBlock extends SlabBlock {
	public static final BooleanProperty SEAMLESS = BooleanProperty.of("seamless");
	public static final EnumProperty<RedSandstoneSlabBlock.Variant> VARIANT = EnumProperty.of("variant", RedSandstoneSlabBlock.Variant.class);

	public RedSandstoneSlabBlock() {
		super(Material.STONE);
		BlockState blockState = this.stateDefinition.any();
		if (this.isDouble()) {
			blockState = blockState.set(SEAMLESS, false);
		} else {
			blockState = blockState.set(HALF, SlabBlock.Half.BOTTOM);
		}

		this.setDefaultState(blockState.set(VARIANT, RedSandstoneSlabBlock.Variant.RED_SANDSTONE));
		this.setCreativeModeTab(CreativeModeTab.BUILDING_BLOCKS);
	}

	@Override
	public String getName() {
		return I18n.translate(this.getTranslationKey() + ".red_sandstone.name");
	}

	@Override
	public Item getDropItem(BlockState state, Random random, int fortuneLevel) {
		return Item.byBlock(Blocks.RED_SANDSTONE_SLAB);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public Item getPickItem(World world, BlockPos pos) {
		return Item.byBlock(Blocks.RED_SANDSTONE_SLAB);
	}

	@Override
	public String getName(int variant) {
		return super.getTranslationKey() + "." + RedSandstoneSlabBlock.Variant.byId(variant).getKey();
	}

	@Override
	public Property<?> getVariantProperty() {
		return VARIANT;
	}

	@Override
	public Object getVariant(ItemStack item) {
		return RedSandstoneSlabBlock.Variant.byId(item.getMetadata() & 7);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public void addToCreativeMenu(Item item, CreativeModeTab tab, List<ItemStack> inventory) {
		if (item != Item.byBlock(Blocks.DOUBLE_RED_SANDSTONE_SLAB)) {
			for (RedSandstoneSlabBlock.Variant variant : RedSandstoneSlabBlock.Variant.values()) {
				inventory.add(new ItemStack(item, 1, variant.getId()));
			}
		}
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		BlockState blockState = this.defaultState().set(VARIANT, RedSandstoneSlabBlock.Variant.byId(metadata & 7));
		if (this.isDouble()) {
			blockState = blockState.set(SEAMLESS, (metadata & 8) != 0);
		} else {
			blockState = blockState.set(HALF, (metadata & 8) == 0 ? SlabBlock.Half.BOTTOM : SlabBlock.Half.TOP);
		}

		return blockState;
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		int i = 0;
		i |= state.get(VARIANT).getId();
		if (this.isDouble()) {
			if (state.get(SEAMLESS)) {
				i |= 8;
			}
		} else if (state.get(HALF) == SlabBlock.Half.TOP) {
			i |= 8;
		}

		return i;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return this.isDouble() ? new StateDefinition(this, SEAMLESS, VARIANT) : new StateDefinition(this, HALF, VARIANT);
	}

	@Override
	public MapColor getMapColor(BlockState state) {
		return state.get(VARIANT).getColor();
	}

	@Override
	public int getDropItemMetadata(BlockState state) {
		return state.get(VARIANT).getId();
	}

	public enum Variant implements StringSerializable {
		RED_SANDSTONE(0, "red_sandstone", SandBlock.Variant.RED_SAND.getColor());

		private static final RedSandstoneSlabBlock.Variant[] BY_ID = new RedSandstoneSlabBlock.Variant[values().length];
		private final int id;
		private final String name;
		private final MapColor color;

		Variant(int id, String name, MapColor color) {
			this.id = id;
			this.name = name;
			this.color = color;
		}

		public int getId() {
			return this.id;
		}

		public MapColor getColor() {
			return this.color;
		}

		@Override
		public String toString() {
			return this.name;
		}

		public static RedSandstoneSlabBlock.Variant byId(int id) {
			if (id < 0 || id >= BY_ID.length) {
				id = 0;
			}

			return BY_ID[id];
		}

		@Override
		public String getSerializedName() {
			return this.name;
		}

		public String getKey() {
			return this.name;
		}

		static {
			for (RedSandstoneSlabBlock.Variant variant : values()) {
				BY_ID[variant.getId()] = variant;
			}
		}
	}
}

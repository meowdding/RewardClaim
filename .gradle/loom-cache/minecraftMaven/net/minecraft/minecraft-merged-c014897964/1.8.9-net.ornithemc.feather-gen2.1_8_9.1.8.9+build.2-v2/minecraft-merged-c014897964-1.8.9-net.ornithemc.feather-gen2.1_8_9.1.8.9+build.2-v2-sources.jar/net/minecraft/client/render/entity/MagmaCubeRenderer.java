package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.model.entity.MagmaCubeModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.monster.MagmaCubeEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class MagmaCubeRenderer extends MobRenderer<MagmaCubeEntity> {
	private static final Identifier MAGMA_CUBE_LOCATION = new Identifier("textures/entity/slime/magmacube.png");

	public MagmaCubeRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher, new MagmaCubeModel(), 0.25F);
	}

	protected Identifier getTextureLocation(MagmaCubeEntity entity) {
		return MAGMA_CUBE_LOCATION;
	}

	protected void applyScale(MagmaCubeEntity entity, float scale) {
		int i = entity.getSize();
		float f = (entity.lastStretch + (entity.stretch - entity.lastStretch) * scale) / (i * 0.5F + 1.0F);
		float g = 1.0F / (f + 1.0F);
		float h = i;
		GlStateManager.scalef(g * h, 1.0F / g * h, g * h);
	}
}

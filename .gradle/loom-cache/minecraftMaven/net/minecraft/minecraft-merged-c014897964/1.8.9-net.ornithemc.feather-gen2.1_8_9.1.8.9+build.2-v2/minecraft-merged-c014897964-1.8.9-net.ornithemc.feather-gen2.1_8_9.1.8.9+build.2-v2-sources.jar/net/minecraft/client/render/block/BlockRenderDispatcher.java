package net.minecraft.client.render.block;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.options.GameOptions;
import net.minecraft.client.render.model.block.BakedModel;
import net.minecraft.client.render.model.block.BasicBakedModel;
import net.minecraft.client.render.model.block.WeightedBakedModel;
import net.minecraft.client.render.texture.TextureAtlasSprite;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.client.resource.manager.ResourceManager;
import net.minecraft.client.resource.manager.ResourceReloadListener;
import net.minecraft.client.resource.model.BlockModelShaper;
import net.minecraft.util.crash.CrashException;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.WorldView;
import net.minecraft.world.gen.WorldGeneratorType;

@Environment(EnvType.CLIENT)
public class BlockRenderDispatcher implements ResourceReloadListener {
	private BlockModelShaper modelShaper;
	private final GameOptions options;
	private final BlockModelRenderer modelRenderer = new BlockModelRenderer();
	private final AnimatedBlockEntityRenderer blockEntityRenderer = new AnimatedBlockEntityRenderer();
	private final LiquidRenderer liquidRenderer = new LiquidRenderer();

	public BlockRenderDispatcher(BlockModelShaper modelShaper, GameOptions options) {
		this.modelShaper = modelShaper;
		this.options = options;
	}

	public BlockModelShaper getModelShaper() {
		return this.modelShaper;
	}

	public void renderMiningProgress(BlockState state, BlockPos pos, TextureAtlasSprite sprite, WorldView world) {
		Block block = state.getBlock();
		int i = block.getRenderType();
		if (i == 3) {
			state = block.resolveVirtualProperties(state, world, pos);
			BakedModel bakedModel = this.modelShaper.getModel(state);
			BakedModel bakedModel2 = new BasicBakedModel.Builder(bakedModel, sprite).build();
			this.modelRenderer.render(world, bakedModel2, state, pos, Tesselator.getInstance().getBuffer());
		}
	}

	public boolean render(BlockState state, BlockPos pos, WorldView world, BufferBuilder bufferBuilder) {
		try {
			int i = state.getBlock().getRenderType();
			if (i == -1) {
				return false;
			}

			switch (i) {
				case 1:
					return this.liquidRenderer.render(world, state, pos, bufferBuilder);
				case 2:
					return false;
				case 3:
					BakedModel bakedModel = this.getModel(state, world, pos);
					return this.modelRenderer.render(world, bakedModel, state, pos, bufferBuilder);
				default:
					return false;
			}
		} catch (Throwable throwable) {
			CrashReport crashReport = CrashReport.of(throwable, "Tesselating block in world");
			CrashReportCategory crashReportCategory = crashReport.addCategory("Block being tesselated");
			CrashReportCategory.addBlockDetails(crashReportCategory, pos, state.getBlock(), state.getBlock().getMetadataFromState(state));
			throw new CrashException(crashReport);
		}
	}

	public BlockModelRenderer getModelRenderer() {
		return this.modelRenderer;
	}

	private BakedModel getModel(BlockState state, BlockPos pos) {
		BakedModel bakedModel = this.modelShaper.getModel(state);
		if (pos != null && this.options.allowBlockAlternatives && bakedModel instanceof WeightedBakedModel) {
			bakedModel = ((WeightedBakedModel)bakedModel).pick(MathHelper.hashCode(pos));
		}

		return bakedModel;
	}

	public BakedModel getModel(BlockState state, WorldView world, BlockPos pos) {
		Block block = state.getBlock();
		if (world.getGeneratorType() != WorldGeneratorType.DEBUG_ALL_BLOCK_STATES) {
			try {
				state = block.resolveVirtualProperties(state, world, pos);
			} catch (Exception var6) {
			}
		}

		BakedModel bakedModel = this.modelShaper.getModel(state);
		if (pos != null && this.options.allowBlockAlternatives && bakedModel instanceof WeightedBakedModel) {
			bakedModel = ((WeightedBakedModel)bakedModel).pick(MathHelper.hashCode(pos));
		}

		return bakedModel;
	}

	public void renderAsItem(BlockState state, float brightness) {
		int i = state.getBlock().getRenderType();
		if (i != -1) {
			switch (i) {
				case 1:
				default:
					break;
				case 2:
					this.blockEntityRenderer.render(state.getBlock(), brightness);
					break;
				case 3:
					BakedModel bakedModel = this.getModel(state, null);
					this.modelRenderer.render(bakedModel, state, brightness, true);
			}
		}
	}

	public boolean isItem3d(Block block, int metadata) {
		if (block == null) {
			return false;
		}

		int i = block.getRenderType();
		return i == 3 ? false : i == 2;
	}

	@Override
	public void reload(ResourceManager resourceManager) {
		this.liquidRenderer.reload();
	}
}

package net.minecraft.client.render.block.entity;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.client.render.TextRenderUtils;
import net.minecraft.client.render.TextRenderer;
import net.minecraft.client.render.model.block.entity.SignModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.resource.Identifier;
import net.minecraft.text.Text;
import org.lwjgl.opengl.GL11;

@Environment(EnvType.CLIENT)
public class SignRenderer extends BlockEntityRenderer<SignBlockEntity> {
	private static final Identifier BACKGROUND_LOCATION = new Identifier("textures/entity/sign.png");
	private final SignModel model = new SignModel();

	public void render(SignBlockEntity blockEntity, double dx, double dy, double dz, float tickDelta, int blockMiningProgress) {
		Block block = blockEntity.getBlock();
		GlStateManager.pushMatrix();
		float f = 0.6666667F;
		if (block == Blocks.STANDING_SIGN) {
			GlStateManager.translatef((float)dx + 0.5F, (float)dy + 0.75F * f, (float)dz + 0.5F);
			float g = blockEntity.getBlockMetadata() * 360 / 16.0F;
			GlStateManager.rotatef(-g, 0.0F, 1.0F, 0.0F);
			this.model.pole.visible = true;
		} else {
			int i = blockEntity.getBlockMetadata();
			float h = 0.0F;
			if (i == 2) {
				h = 180.0F;
			}

			if (i == 4) {
				h = 90.0F;
			}

			if (i == 5) {
				h = -90.0F;
			}

			GlStateManager.translatef((float)dx + 0.5F, (float)dy + 0.75F * f, (float)dz + 0.5F);
			GlStateManager.rotatef(-h, 0.0F, 1.0F, 0.0F);
			GlStateManager.translatef(0.0F, -0.3125F, -0.4375F);
			this.model.pole.visible = false;
		}

		if (blockMiningProgress >= 0) {
			this.bindTexture(MINING_PROGRESS_LOCATIONS[blockMiningProgress]);
			GlStateManager.matrixMode(5890);
			GlStateManager.pushMatrix();
			GlStateManager.scalef(4.0F, 2.0F, 1.0F);
			GlStateManager.translatef(0.0625F, 0.0625F, 0.0625F);
			GlStateManager.matrixMode(5888);
		} else {
			this.bindTexture(BACKGROUND_LOCATION);
		}

		GlStateManager.enableRescaleNormal();
		GlStateManager.pushMatrix();
		GlStateManager.scalef(f, -f, -f);
		this.model.render();
		GlStateManager.popMatrix();
		TextRenderer textRenderer = this.getTextRenderer();
		float h = 0.015625F * f;
		GlStateManager.translatef(0.0F, 0.5F * f, 0.07F * f);
		GlStateManager.scalef(h, -h, h);
		GL11.glNormal3f(0.0F, 0.0F, -1.0F * h);
		GlStateManager.depthMask(false);
		int j = 0;
		if (blockMiningProgress < 0) {
			for (int k = 0; k < blockEntity.lines.length; k++) {
				if (blockEntity.lines[k] != null) {
					Text text = blockEntity.lines[k];
					List<Text> list = TextRenderUtils.wrapText(text, 90, textRenderer, false, true);
					String string = list != null && list.size() > 0 ? list.get(0).getFormattedString() : "";
					if (k == blockEntity.currentRow) {
						string = "> " + string + " <";
						textRenderer.draw(string, -textRenderer.getWidth(string) / 2, k * 10 - blockEntity.lines.length * 5, j);
					} else {
						textRenderer.draw(string, -textRenderer.getWidth(string) / 2, k * 10 - blockEntity.lines.length * 5, j);
					}
				}
			}
		}

		GlStateManager.depthMask(true);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.popMatrix();
		if (blockMiningProgress >= 0) {
			GlStateManager.matrixMode(5890);
			GlStateManager.popMatrix();
			GlStateManager.matrixMode(5888);
		}
	}
}

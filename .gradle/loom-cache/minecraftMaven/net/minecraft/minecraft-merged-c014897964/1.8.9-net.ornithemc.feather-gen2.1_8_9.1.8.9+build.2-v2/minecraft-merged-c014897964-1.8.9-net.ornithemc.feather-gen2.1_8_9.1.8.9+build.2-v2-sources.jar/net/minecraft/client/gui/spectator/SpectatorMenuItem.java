package net.minecraft.client.gui.spectator;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public interface SpectatorMenuItem {
	void select(SpectatorMenu hud);

	Text getDisplayName();

	void render(float tickDelta, int slot);

	boolean isEnabled();
}

package net.minecraft.client.render.block.entity;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BannerBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.model.block.entity.BannerModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.texture.LayeredColorMaskTexture;
import net.minecraft.item.DyeColor;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class BannerRenderer extends BlockEntityRenderer<BannerBlockEntity> {
	private static final Map<String, BannerRenderer.CachedTexture> TEXTURE_CACHE = Maps.newHashMap();
	private static final Identifier BASE_TEXTURE = new Identifier("textures/entity/banner_base.png");
	private BannerModel model = new BannerModel();

	public void render(BannerBlockEntity blockEntity, double dx, double dy, double dz, float tickDelta, int blockMiningProgress) {
		boolean bl = blockEntity.getWorld() != null;
		boolean bl2 = !bl || blockEntity.getBlock() == Blocks.STANDING_BANNER;
		int i = bl ? blockEntity.getBlockMetadata() : 0;
		long l = bl ? blockEntity.getWorld().getTime() : 0L;
		GlStateManager.pushMatrix();
		float f = 0.6666667F;
		if (bl2) {
			GlStateManager.translatef((float)dx + 0.5F, (float)dy + 0.75F * f, (float)dz + 0.5F);
			float g = i * 360 / 16.0F;
			GlStateManager.rotatef(-g, 0.0F, 1.0F, 0.0F);
			this.model.pole.visible = true;
		} else {
			int j = i;
			float h = 0.0F;
			if (j == 2) {
				h = 180.0F;
			}

			if (j == 4) {
				h = 90.0F;
			}

			if (j == 5) {
				h = -90.0F;
			}

			GlStateManager.translatef((float)dx + 0.5F, (float)dy - 0.25F * f, (float)dz + 0.5F);
			GlStateManager.rotatef(-h, 0.0F, 1.0F, 0.0F);
			GlStateManager.translatef(0.0F, -0.3125F, -0.4375F);
			this.model.pole.visible = false;
		}

		BlockPos blockPos = blockEntity.getPos();
		float h = blockPos.getX() * 7 + blockPos.getY() * 9 + blockPos.getZ() * 13 + (float)l + tickDelta;
		this.model.flag.rotationX = (-0.0125F + 0.01F * MathHelper.cos(h * (float) Math.PI * 0.02F)) * (float) Math.PI;
		GlStateManager.enableRescaleNormal();
		Identifier identifier = this.getTexture(blockEntity);
		if (identifier != null) {
			this.bindTexture(identifier);
			GlStateManager.pushMatrix();
			GlStateManager.scalef(f, -f, -f);
			this.model.render();
			GlStateManager.popMatrix();
		}

		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.popMatrix();
	}

	private Identifier getTexture(BannerBlockEntity banner) {
		String string = banner.getTexture();
		if (string.isEmpty()) {
			return null;
		}

		BannerRenderer.CachedTexture cachedTexture = TEXTURE_CACHE.get(string);
		if (cachedTexture == null) {
			if (TEXTURE_CACHE.size() >= 256) {
				long l = System.currentTimeMillis();
				Iterator<String> iterator = TEXTURE_CACHE.keySet().iterator();

				while (iterator.hasNext()) {
					String string2 = iterator.next();
					BannerRenderer.CachedTexture cachedTexture2 = TEXTURE_CACHE.get(string2);
					if (l - cachedTexture2.cachedTime > 60000L) {
						Minecraft.getInstance().getTextureManager().close(cachedTexture2.texture);
						iterator.remove();
					}
				}

				if (TEXTURE_CACHE.size() >= 256) {
					return null;
				}
			}

			List<BannerBlockEntity.Pattern> list = banner.getPatterns();
			List<DyeColor> list2 = banner.getColors();
			List<String> list3 = Lists.newArrayList();

			for (BannerBlockEntity.Pattern pattern : list) {
				list3.add("textures/entity/banner/" + pattern.getKey() + ".png");
			}

			cachedTexture = new BannerRenderer.CachedTexture();
			cachedTexture.texture = new Identifier(string);
			Minecraft.getInstance().getTextureManager().register(cachedTexture.texture, new LayeredColorMaskTexture(BASE_TEXTURE, list3, list2));
			TEXTURE_CACHE.put(string, cachedTexture);
		}

		cachedTexture.cachedTime = System.currentTimeMillis();
		return cachedTexture.texture;
	}

	@Environment(EnvType.CLIENT)
	static class CachedTexture {
		public long cachedTime;
		public Identifier texture;

		private CachedTexture() {
		}
	}
}

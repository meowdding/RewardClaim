package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.entity.living.player.ClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerRenderer;
import net.minecraft.client.render.platform.GlStateManager;

@Environment(EnvType.CLIENT)
public class Deadmau5Layer implements EntityRenderLayer<ClientPlayerEntity> {
	private final PlayerRenderer parent;

	public Deadmau5Layer(PlayerRenderer parent) {
		this.parent = parent;
	}

	public void render(
		ClientPlayerEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale
	) {
		if (entity.getName().equals("deadmau5") && entity.hasSkinTexture() && !entity.isInvisible()) {
			this.parent.bindTexture(entity.getSkinTextureLocation());

			for (int i = 0; i < 2; i++) {
				float f = entity.lastYaw + (entity.yaw - entity.lastYaw) * tickDelta - (entity.lastBodyYaw + (entity.bodyYaw - entity.lastBodyYaw) * tickDelta);
				float g = entity.lastPitch + (entity.pitch - entity.lastPitch) * tickDelta;
				GlStateManager.pushMatrix();
				GlStateManager.rotatef(f, 0.0F, 1.0F, 0.0F);
				GlStateManager.rotatef(g, 1.0F, 0.0F, 0.0F);
				GlStateManager.translatef(0.375F * (i * 2 - 1), 0.0F, 0.0F);
				GlStateManager.translatef(0.0F, -0.375F, 0.0F);
				GlStateManager.rotatef(-g, 1.0F, 0.0F, 0.0F);
				GlStateManager.rotatef(-f, 0.0F, 1.0F, 0.0F);
				float h = 1.3333334F;
				GlStateManager.scalef(h, h, h);
				this.parent.getModel().renderEars(0.0625F);
				GlStateManager.popMatrix();
			}
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return true;
	}
}

package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;

@Environment(EnvType.CLIENT)
public class ArrowRenderer extends EntityRenderer<ArrowEntity> {
	private static final Identifier ARROW_LOCATION = new Identifier("textures/entity/arrow.png");

	public ArrowRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
	}

	public void render(ArrowEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		this.bindTexture(entity);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.pushMatrix();
		GlStateManager.translatef((float)dx, (float)dy, (float)dz);
		GlStateManager.rotatef(entity.lastYaw + (entity.yaw - entity.lastYaw) * tickDelta - 90.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(entity.lastPitch + (entity.pitch - entity.lastPitch) * tickDelta, 0.0F, 0.0F, 1.0F);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		int i = 0;
		float f = 0.0F;
		float g = 0.5F;
		float h = (0 + i * 10) / 32.0F;
		float j = (5 + i * 10) / 32.0F;
		float k = 0.0F;
		float l = 0.15625F;
		float m = (5 + i * 10) / 32.0F;
		float n = (10 + i * 10) / 32.0F;
		float o = 0.05625F;
		GlStateManager.enableRescaleNormal();
		float p = entity.shake - tickDelta;
		if (p > 0.0F) {
			float q = -MathHelper.sin(p * 3.0F) * p;
			GlStateManager.rotatef(q, 0.0F, 0.0F, 1.0F);
		}

		GlStateManager.rotatef(45.0F, 1.0F, 0.0F, 0.0F);
		GlStateManager.scalef(o, o, o);
		GlStateManager.translatef(-4.0F, 0.0F, 0.0F);
		GL11.glNormal3f(o, 0.0F, 0.0F);
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
		bufferBuilder.vertex(-7.0, -2.0, -2.0).texture(k, m).nextVertex();
		bufferBuilder.vertex(-7.0, -2.0, 2.0).texture(l, m).nextVertex();
		bufferBuilder.vertex(-7.0, 2.0, 2.0).texture(l, n).nextVertex();
		bufferBuilder.vertex(-7.0, 2.0, -2.0).texture(k, n).nextVertex();
		tesselator.end();
		GL11.glNormal3f(-o, 0.0F, 0.0F);
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
		bufferBuilder.vertex(-7.0, 2.0, -2.0).texture(k, m).nextVertex();
		bufferBuilder.vertex(-7.0, 2.0, 2.0).texture(l, m).nextVertex();
		bufferBuilder.vertex(-7.0, -2.0, 2.0).texture(l, n).nextVertex();
		bufferBuilder.vertex(-7.0, -2.0, -2.0).texture(k, n).nextVertex();
		tesselator.end();

		for (int r = 0; r < 4; r++) {
			GlStateManager.rotatef(90.0F, 1.0F, 0.0F, 0.0F);
			GL11.glNormal3f(0.0F, 0.0F, o);
			bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
			bufferBuilder.vertex(-8.0, -2.0, 0.0).texture(f, h).nextVertex();
			bufferBuilder.vertex(8.0, -2.0, 0.0).texture(g, h).nextVertex();
			bufferBuilder.vertex(8.0, 2.0, 0.0).texture(g, j).nextVertex();
			bufferBuilder.vertex(-8.0, 2.0, 0.0).texture(f, j).nextVertex();
			tesselator.end();
		}

		GlStateManager.disableRescaleNormal();
		GlStateManager.popMatrix();
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(ArrowEntity entity) {
		return ARROW_LOCATION;
	}
}

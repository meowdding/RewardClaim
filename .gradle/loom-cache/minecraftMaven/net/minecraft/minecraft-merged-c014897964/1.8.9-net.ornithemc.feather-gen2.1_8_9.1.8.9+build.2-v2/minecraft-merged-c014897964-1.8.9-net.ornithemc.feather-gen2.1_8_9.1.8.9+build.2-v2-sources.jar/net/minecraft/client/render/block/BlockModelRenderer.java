package net.minecraft.client.render.block;

import java.util.BitSet;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.model.block.BakedModel;
import net.minecraft.client.render.model.block.BakedQuad;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.texture.TextureUtil;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.util.crash.CrashException;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.WorldView;

@Environment(EnvType.CLIENT)
public class BlockModelRenderer {
	public boolean render(WorldView world, BakedModel model, BlockState state, BlockPos pos, BufferBuilder bufferBuilder) {
		Block block = state.getBlock();
		block.updateShape(world, pos);
		return this.render(world, model, state, pos, bufferBuilder, true);
	}

	public boolean render(WorldView world, BakedModel model, BlockState state, BlockPos pos, BufferBuilder bufferBuilder, boolean checkShouldRenderFace) {
		boolean bl = Minecraft.isAmbientOcclusionEnabled() && state.getBlock().getLight() == 0 && model.useAmbientOcclusion();

		try {
			Block block = state.getBlock();
			return bl
				? this.tesselateWithAmbientOcclusion(world, model, block, pos, bufferBuilder, checkShouldRenderFace)
				: this.tesselateWithoutAmbientOcclusion(world, model, block, pos, bufferBuilder, checkShouldRenderFace);
		} catch (Throwable throwable) {
			CrashReport crashReport = CrashReport.of(throwable, "Tesselating block model");
			CrashReportCategory crashReportCategory = crashReport.addCategory("Block model being tesselated");
			CrashReportCategory.addBlockDetails(crashReportCategory, pos, state);
			crashReportCategory.add("Using AO", bl);
			throw new CrashException(crashReport);
		}
	}

	public boolean tesselateWithAmbientOcclusion(
		WorldView world, BakedModel model, Block block, BlockPos pos, BufferBuilder bufferBuilder, boolean checkShouldRenderFace
	) {
		boolean bl = false;
		float[] fs = new float[Direction.values().length * 2];
		BitSet bitSet = new BitSet(3);
		BlockModelRenderer.AmbientOcclusionFace ambientOcclusionFace = new BlockModelRenderer.AmbientOcclusionFace();

		for (Direction direction : Direction.values()) {
			List<BakedQuad> list = model.getQuads(direction);
			if (!list.isEmpty()) {
				BlockPos blockPos = pos.offset(direction);
				if (!checkShouldRenderFace || block.shouldRenderFace(world, blockPos, direction)) {
					this.tesselateFaceWithAmbientOcclusion(world, block, pos, bufferBuilder, list, fs, bitSet, ambientOcclusionFace);
					bl = true;
				}
			}
		}

		List<BakedQuad> list2 = model.getQuads();
		if (list2.size() > 0) {
			this.tesselateFaceWithAmbientOcclusion(world, block, pos, bufferBuilder, list2, fs, bitSet, ambientOcclusionFace);
			bl = true;
		}

		return bl;
	}

	public boolean tesselateWithoutAmbientOcclusion(
		WorldView world, BakedModel model, Block block, BlockPos pos, BufferBuilder bufferBuilder, boolean checkShouldRenderFace
	) {
		boolean bl = false;
		BitSet bitSet = new BitSet(3);

		for (Direction direction : Direction.values()) {
			List<BakedQuad> list = model.getQuads(direction);
			if (!list.isEmpty()) {
				BlockPos blockPos = pos.offset(direction);
				if (!checkShouldRenderFace || block.shouldRenderFace(world, blockPos, direction)) {
					int k = block.getLightColor(world, blockPos);
					this.tesselateFaceWithoutAmbientOcclusion(world, block, pos, direction, k, false, bufferBuilder, list, bitSet);
					bl = true;
				}
			}
		}

		List<BakedQuad> list2 = model.getQuads();
		if (list2.size() > 0) {
			this.tesselateFaceWithoutAmbientOcclusion(world, block, pos, null, -1, true, bufferBuilder, list2, bitSet);
			bl = true;
		}

		return bl;
	}

	private void tesselateFaceWithAmbientOcclusion(
		WorldView world,
		Block block,
		BlockPos pos,
		BufferBuilder bufferBuilder,
		List<BakedQuad> quads,
		float[] faceShape,
		BitSet shapeState,
		BlockModelRenderer.AmbientOcclusionFace face
	) {
		double d = pos.getX();
		double e = pos.getY();
		double f = pos.getZ();
		Block.OffsetType offsetType = block.getOffsetType();
		if (offsetType != Block.OffsetType.NONE) {
			long l = MathHelper.hashCode(pos);
			d += ((float)(l >> 16 & 15L) / 15.0F - 0.5) * 0.5;
			f += ((float)(l >> 24 & 15L) / 15.0F - 0.5) * 0.5;
			if (offsetType == Block.OffsetType.XYZ) {
				e += ((float)(l >> 20 & 15L) / 15.0F - 1.0) * 0.2;
			}
		}

		for (BakedQuad bakedQuad : quads) {
			this.computeFaceShape(block, bakedQuad.getVertices(), bakedQuad.getFace(), faceShape, shapeState);
			face.compute(world, block, pos, bakedQuad.getFace(), faceShape, shapeState);
			bufferBuilder.vertices(bakedQuad.getVertices());
			bufferBuilder.lightColor(face.lightMap[0], face.lightMap[1], face.lightMap[2], face.lightMap[3]);
			if (bakedQuad.hasTint()) {
				int i = block.getColorTint(world, pos, bakedQuad.getTintIndex());
				if (GameRenderer.anaglyphEnabled) {
					i = TextureUtil.getAnaglyphColor(i);
				}

				float g = (i >> 16 & 0xFF) / 255.0F;
				float h = (i >> 8 & 0xFF) / 255.0F;
				float j = (i & 0xFF) / 255.0F;
				bufferBuilder.multiplyColor(face.brightness[0] * g, face.brightness[0] * h, face.brightness[0] * j, 4);
				bufferBuilder.multiplyColor(face.brightness[1] * g, face.brightness[1] * h, face.brightness[1] * j, 3);
				bufferBuilder.multiplyColor(face.brightness[2] * g, face.brightness[2] * h, face.brightness[2] * j, 2);
				bufferBuilder.multiplyColor(face.brightness[3] * g, face.brightness[3] * h, face.brightness[3] * j, 1);
			} else {
				bufferBuilder.multiplyColor(face.brightness[0], face.brightness[0], face.brightness[0], 4);
				bufferBuilder.multiplyColor(face.brightness[1], face.brightness[1], face.brightness[1], 3);
				bufferBuilder.multiplyColor(face.brightness[2], face.brightness[2], face.brightness[2], 2);
				bufferBuilder.multiplyColor(face.brightness[3], face.brightness[3], face.brightness[3], 1);
			}

			bufferBuilder.postPosition(d, e, f);
		}
	}

	private void computeFaceShape(Block block, int[] vertices, Direction face, float[] faceShape, BitSet shapeState) {
		float f = 32.0F;
		float g = 32.0F;
		float h = 32.0F;
		float i = -32.0F;
		float j = -32.0F;
		float k = -32.0F;

		for (int l = 0; l < 4; l++) {
			float m = Float.intBitsToFloat(vertices[l * 7]);
			float n = Float.intBitsToFloat(vertices[l * 7 + 1]);
			float o = Float.intBitsToFloat(vertices[l * 7 + 2]);
			f = Math.min(f, m);
			g = Math.min(g, n);
			h = Math.min(h, o);
			i = Math.max(i, m);
			j = Math.max(j, n);
			k = Math.max(k, o);
		}

		if (faceShape != null) {
			faceShape[Direction.WEST.getId()] = f;
			faceShape[Direction.EAST.getId()] = i;
			faceShape[Direction.DOWN.getId()] = g;
			faceShape[Direction.UP.getId()] = j;
			faceShape[Direction.NORTH.getId()] = h;
			faceShape[Direction.SOUTH.getId()] = k;
			faceShape[Direction.WEST.getId() + Direction.values().length] = 1.0F - f;
			faceShape[Direction.EAST.getId() + Direction.values().length] = 1.0F - i;
			faceShape[Direction.DOWN.getId() + Direction.values().length] = 1.0F - g;
			faceShape[Direction.UP.getId() + Direction.values().length] = 1.0F - j;
			faceShape[Direction.NORTH.getId() + Direction.values().length] = 1.0F - h;
			faceShape[Direction.SOUTH.getId() + Direction.values().length] = 1.0F - k;
		}

		float p = 1.0E-4F;
		float m = 0.9999F;
		switch (face) {
			case DOWN:
				shapeState.set(1, f >= 1.0E-4F || h >= 1.0E-4F || i <= 0.9999F || k <= 0.9999F);
				shapeState.set(0, (g < 1.0E-4F || block.isCube()) && g == j);
				break;
			case UP:
				shapeState.set(1, f >= 1.0E-4F || h >= 1.0E-4F || i <= 0.9999F || k <= 0.9999F);
				shapeState.set(0, (j > 0.9999F || block.isCube()) && g == j);
				break;
			case NORTH:
				shapeState.set(1, f >= 1.0E-4F || g >= 1.0E-4F || i <= 0.9999F || j <= 0.9999F);
				shapeState.set(0, (h < 1.0E-4F || block.isCube()) && h == k);
				break;
			case SOUTH:
				shapeState.set(1, f >= 1.0E-4F || g >= 1.0E-4F || i <= 0.9999F || j <= 0.9999F);
				shapeState.set(0, (k > 0.9999F || block.isCube()) && h == k);
				break;
			case WEST:
				shapeState.set(1, g >= 1.0E-4F || h >= 1.0E-4F || j <= 0.9999F || k <= 0.9999F);
				shapeState.set(0, (f < 1.0E-4F || block.isCube()) && f == i);
				break;
			case EAST:
				shapeState.set(1, g >= 1.0E-4F || h >= 1.0E-4F || j <= 0.9999F || k <= 0.9999F);
				shapeState.set(0, (i > 0.9999F || block.isCube()) && f == i);
		}
	}

	private void tesselateFaceWithoutAmbientOcclusion(
		WorldView world,
		Block block,
		BlockPos pos,
		Direction face,
		int lightColor,
		boolean computeShape,
		BufferBuilder bufferBuilder,
		List<BakedQuad> quads,
		BitSet shapeState
	) {
		double d = pos.getX();
		double e = pos.getY();
		double f = pos.getZ();
		Block.OffsetType offsetType = block.getOffsetType();
		if (offsetType != Block.OffsetType.NONE) {
			int i = pos.getX();
			int j = pos.getZ();
			long l = i * 3129871 ^ j * 116129781L;
			l = l * l * 42317861L + l * 11L;
			d += ((float)(l >> 16 & 15L) / 15.0F - 0.5) * 0.5;
			f += ((float)(l >> 24 & 15L) / 15.0F - 0.5) * 0.5;
			if (offsetType == Block.OffsetType.XYZ) {
				e += ((float)(l >> 20 & 15L) / 15.0F - 1.0) * 0.2;
			}
		}

		for (BakedQuad bakedQuad : quads) {
			if (computeShape) {
				this.computeFaceShape(block, bakedQuad.getVertices(), bakedQuad.getFace(), null, shapeState);
				lightColor = shapeState.get(0) ? block.getLightColor(world, pos.offset(bakedQuad.getFace())) : block.getLightColor(world, pos);
			}

			bufferBuilder.vertices(bakedQuad.getVertices());
			bufferBuilder.lightColor(lightColor, lightColor, lightColor, lightColor);
			if (bakedQuad.hasTint()) {
				int k = block.getColorTint(world, pos, bakedQuad.getTintIndex());
				if (GameRenderer.anaglyphEnabled) {
					k = TextureUtil.getAnaglyphColor(k);
				}

				float g = (k >> 16 & 0xFF) / 255.0F;
				float h = (k >> 8 & 0xFF) / 255.0F;
				float m = (k & 0xFF) / 255.0F;
				bufferBuilder.multiplyColor(g, h, m, 4);
				bufferBuilder.multiplyColor(g, h, m, 3);
				bufferBuilder.multiplyColor(g, h, m, 2);
				bufferBuilder.multiplyColor(g, h, m, 1);
			}

			bufferBuilder.postPosition(d, e, f);
		}
	}

	public void render(BakedModel model, float brightness, float r, float g, float b) {
		for (Direction direction : Direction.values()) {
			this.renderQuads(brightness, r, g, b, model.getQuads(direction));
		}

		this.renderQuads(brightness, r, g, b, model.getQuads());
	}

	public void render(BakedModel model, BlockState state, float brightness, boolean skipColor) {
		Block block = state.getBlock();
		block.resetShape();
		GlStateManager.rotatef(90.0F, 0.0F, 1.0F, 0.0F);
		int i = block.getColor(block.getStateForItemModel(state));
		if (GameRenderer.anaglyphEnabled) {
			i = TextureUtil.getAnaglyphColor(i);
		}

		float f = (i >> 16 & 0xFF) / 255.0F;
		float g = (i >> 8 & 0xFF) / 255.0F;
		float h = (i & 0xFF) / 255.0F;
		if (!skipColor) {
			GlStateManager.color4f(brightness, brightness, brightness, 1.0F);
		}

		this.render(model, brightness, f, g, h);
	}

	private void renderQuads(float brightness, float r, float g, float b, List<BakedQuad> quads) {
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();

		for (BakedQuad bakedQuad : quads) {
			bufferBuilder.begin(7, DefaultVertexFormat.BLOCK_NORMALS);
			bufferBuilder.vertices(bakedQuad.getVertices());
			if (bakedQuad.hasTint()) {
				bufferBuilder.setQuadColor(r * brightness, g * brightness, b * brightness);
			} else {
				bufferBuilder.setQuadColor(brightness, brightness, brightness);
			}

			Vec3i vec3i = bakedQuad.getFace().getNormal();
			bufferBuilder.postNormal(vec3i.getX(), vec3i.getY(), vec3i.getZ());
			tesselator.end();
		}
	}

	@Environment(EnvType.CLIENT)
	public enum AdjacencyData {
		DOWN(
			new Direction[]{Direction.WEST, Direction.EAST, Direction.NORTH, Direction.SOUTH},
			0.5F,
			false,
			new BlockModelRenderer.SizeData[0],
			new BlockModelRenderer.SizeData[0],
			new BlockModelRenderer.SizeData[0],
			new BlockModelRenderer.SizeData[0]
		),
		UP(
			new Direction[]{Direction.EAST, Direction.WEST, Direction.NORTH, Direction.SOUTH},
			1.0F,
			false,
			new BlockModelRenderer.SizeData[0],
			new BlockModelRenderer.SizeData[0],
			new BlockModelRenderer.SizeData[0],
			new BlockModelRenderer.SizeData[0]
		),
		NORTH(
			new Direction[]{Direction.UP, Direction.DOWN, Direction.EAST, Direction.WEST},
			0.8F,
			true,
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.FLIP_WEST,
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.WEST,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.WEST,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.FLIP_WEST
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.FLIP_EAST,
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.EAST,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.EAST,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.FLIP_EAST
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.FLIP_EAST,
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.EAST,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.EAST,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.FLIP_EAST
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.FLIP_WEST,
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.WEST,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.WEST,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.FLIP_WEST
			}
		),
		SOUTH(
			new Direction[]{Direction.WEST, Direction.EAST, Direction.DOWN, Direction.UP},
			0.8F,
			true,
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.FLIP_WEST,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.FLIP_WEST,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.WEST,
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.WEST
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.FLIP_WEST,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.FLIP_WEST,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.WEST,
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.WEST
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.FLIP_EAST,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.FLIP_EAST,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.EAST,
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.EAST
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.FLIP_EAST,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.FLIP_EAST,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.EAST,
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.EAST
			}
		),
		WEST(
			new Direction[]{Direction.UP, Direction.DOWN, Direction.NORTH, Direction.SOUTH},
			0.6F,
			true,
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.SOUTH,
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.FLIP_SOUTH,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.FLIP_SOUTH,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.SOUTH
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.NORTH,
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.FLIP_NORTH,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.FLIP_NORTH,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.NORTH
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.NORTH,
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.FLIP_NORTH,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.FLIP_NORTH,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.NORTH
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.SOUTH,
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.FLIP_SOUTH,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.FLIP_SOUTH,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.SOUTH
			}
		),
		EAST(
			new Direction[]{Direction.DOWN, Direction.UP, Direction.NORTH, Direction.SOUTH},
			0.6F,
			true,
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.SOUTH,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.FLIP_SOUTH,
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.FLIP_SOUTH,
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.SOUTH
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.NORTH,
				BlockModelRenderer.SizeData.FLIP_DOWN,
				BlockModelRenderer.SizeData.FLIP_NORTH,
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.FLIP_NORTH,
				BlockModelRenderer.SizeData.DOWN,
				BlockModelRenderer.SizeData.NORTH
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.NORTH,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.FLIP_NORTH,
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.FLIP_NORTH,
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.NORTH
			},
			new BlockModelRenderer.SizeData[]{
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.SOUTH,
				BlockModelRenderer.SizeData.FLIP_UP,
				BlockModelRenderer.SizeData.FLIP_SOUTH,
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.FLIP_SOUTH,
				BlockModelRenderer.SizeData.UP,
				BlockModelRenderer.SizeData.SOUTH
			}
		);

		protected final Direction[] corners;
		protected final float weight;
		protected final boolean nonCubicWeight;
		protected final BlockModelRenderer.SizeData[] vertex1Weights;
		protected final BlockModelRenderer.SizeData[] vertex2Weights;
		protected final BlockModelRenderer.SizeData[] vertex3Weights;
		protected final BlockModelRenderer.SizeData[] vertex4Weights;
		private static final BlockModelRenderer.AdjacencyData[] ALL = new BlockModelRenderer.AdjacencyData[6];

		AdjacencyData(
			Direction[] corners,
			float weight,
			boolean nonCubicWeight,
			BlockModelRenderer.SizeData[] vertex1Weights,
			BlockModelRenderer.SizeData[] vertex2Weights,
			BlockModelRenderer.SizeData[] vertex3Weights,
			BlockModelRenderer.SizeData[] vertex4Weights
		) {
			this.corners = corners;
			this.weight = weight;
			this.nonCubicWeight = nonCubicWeight;
			this.vertex1Weights = vertex1Weights;
			this.vertex2Weights = vertex2Weights;
			this.vertex3Weights = vertex3Weights;
			this.vertex4Weights = vertex4Weights;
		}

		public static BlockModelRenderer.AdjacencyData byDirection(Direction dir) {
			return ALL[dir.getId()];
		}

		static {
			ALL[Direction.DOWN.getId()] = DOWN;
			ALL[Direction.UP.getId()] = UP;
			ALL[Direction.NORTH.getId()] = NORTH;
			ALL[Direction.SOUTH.getId()] = SOUTH;
			ALL[Direction.WEST.getId()] = WEST;
			ALL[Direction.EAST.getId()] = EAST;
		}
	}

	@Environment(EnvType.CLIENT)
	class AmbientOcclusionFace {
		private final float[] brightness = new float[4];
		private final int[] lightMap = new int[4];

		public AmbientOcclusionFace() {
		}

		public void compute(WorldView world, Block block, BlockPos pos, Direction face, float[] faceShape, BitSet shapeState) {
			BlockPos blockPos = shapeState.get(0) ? pos.offset(face) : pos;
			BlockModelRenderer.AdjacencyData adjacencyData = BlockModelRenderer.AdjacencyData.byDirection(face);
			BlockPos blockPos2 = blockPos.offset(adjacencyData.corners[0]);
			BlockPos blockPos3 = blockPos.offset(adjacencyData.corners[1]);
			BlockPos blockPos4 = blockPos.offset(adjacencyData.corners[2]);
			BlockPos blockPos5 = blockPos.offset(adjacencyData.corners[3]);
			int i = block.getLightColor(world, blockPos2);
			int j = block.getLightColor(world, blockPos3);
			int k = block.getLightColor(world, blockPos4);
			int l = block.getLightColor(world, blockPos5);
			float f = world.getBlockState(blockPos2).getBlock().getAmbientOcclusionLight();
			float g = world.getBlockState(blockPos3).getBlock().getAmbientOcclusionLight();
			float h = world.getBlockState(blockPos4).getBlock().getAmbientOcclusionLight();
			float m = world.getBlockState(blockPos5).getBlock().getAmbientOcclusionLight();
			boolean bl = world.getBlockState(blockPos2.offset(face)).getBlock().isTranslucent();
			boolean bl2 = world.getBlockState(blockPos3.offset(face)).getBlock().isTranslucent();
			boolean bl3 = world.getBlockState(blockPos4.offset(face)).getBlock().isTranslucent();
			boolean bl4 = world.getBlockState(blockPos5.offset(face)).getBlock().isTranslucent();
			float n;
			int o;
			if (!bl3 && !bl) {
				n = f;
				o = i;
			} else {
				BlockPos blockPos6 = blockPos2.offset(adjacencyData.corners[2]);
				n = world.getBlockState(blockPos6).getBlock().getAmbientOcclusionLight();
				o = block.getLightColor(world, blockPos6);
			}

			float p;
			int q;
			if (!bl4 && !bl) {
				p = f;
				q = i;
			} else {
				BlockPos blockPos6 = blockPos2.offset(adjacencyData.corners[3]);
				p = world.getBlockState(blockPos6).getBlock().getAmbientOcclusionLight();
				q = block.getLightColor(world, blockPos6);
			}

			float r;
			int s;
			if (!bl3 && !bl2) {
				r = g;
				s = j;
			} else {
				BlockPos blockPos6 = blockPos3.offset(adjacencyData.corners[2]);
				r = world.getBlockState(blockPos6).getBlock().getAmbientOcclusionLight();
				s = block.getLightColor(world, blockPos6);
			}

			float t;
			int u;
			if (!bl4 && !bl2) {
				t = g;
				u = j;
			} else {
				BlockPos blockPos6 = blockPos3.offset(adjacencyData.corners[3]);
				t = world.getBlockState(blockPos6).getBlock().getAmbientOcclusionLight();
				u = block.getLightColor(world, blockPos6);
			}

			int v = block.getLightColor(world, pos);
			if (shapeState.get(0) || !world.getBlockState(pos.offset(face)).getBlock().isSolidRender()) {
				v = block.getLightColor(world, pos.offset(face));
			}

			float w = shapeState.get(0)
				? world.getBlockState(blockPos).getBlock().getAmbientOcclusionLight()
				: world.getBlockState(pos).getBlock().getAmbientOcclusionLight();
			BlockModelRenderer.AmbientVertexRemap ambientVertexRemap = BlockModelRenderer.AmbientVertexRemap.byDirection(face);
			if (shapeState.get(1) && adjacencyData.nonCubicWeight) {
				float x = (m + f + p + w) * 0.25F;
				float y = (h + f + n + w) * 0.25F;
				float z = (h + g + r + w) * 0.25F;
				float aa = (m + g + t + w) * 0.25F;
				float ab = faceShape[adjacencyData.vertex1Weights[0].shape] * faceShape[adjacencyData.vertex1Weights[1].shape];
				float ac = faceShape[adjacencyData.vertex1Weights[2].shape] * faceShape[adjacencyData.vertex1Weights[3].shape];
				float ad = faceShape[adjacencyData.vertex1Weights[4].shape] * faceShape[adjacencyData.vertex1Weights[5].shape];
				float ae = faceShape[adjacencyData.vertex1Weights[6].shape] * faceShape[adjacencyData.vertex1Weights[7].shape];
				float af = faceShape[adjacencyData.vertex2Weights[0].shape] * faceShape[adjacencyData.vertex2Weights[1].shape];
				float ag = faceShape[adjacencyData.vertex2Weights[2].shape] * faceShape[adjacencyData.vertex2Weights[3].shape];
				float ah = faceShape[adjacencyData.vertex2Weights[4].shape] * faceShape[adjacencyData.vertex2Weights[5].shape];
				float ai = faceShape[adjacencyData.vertex2Weights[6].shape] * faceShape[adjacencyData.vertex2Weights[7].shape];
				float aj = faceShape[adjacencyData.vertex3Weights[0].shape] * faceShape[adjacencyData.vertex3Weights[1].shape];
				float ak = faceShape[adjacencyData.vertex3Weights[2].shape] * faceShape[adjacencyData.vertex3Weights[3].shape];
				float al = faceShape[adjacencyData.vertex3Weights[4].shape] * faceShape[adjacencyData.vertex3Weights[5].shape];
				float am = faceShape[adjacencyData.vertex3Weights[6].shape] * faceShape[adjacencyData.vertex3Weights[7].shape];
				float an = faceShape[adjacencyData.vertex4Weights[0].shape] * faceShape[adjacencyData.vertex4Weights[1].shape];
				float ao = faceShape[adjacencyData.vertex4Weights[2].shape] * faceShape[adjacencyData.vertex4Weights[3].shape];
				float ap = faceShape[adjacencyData.vertex4Weights[4].shape] * faceShape[adjacencyData.vertex4Weights[5].shape];
				float aq = faceShape[adjacencyData.vertex4Weights[6].shape] * faceShape[adjacencyData.vertex4Weights[7].shape];
				this.brightness[ambientVertexRemap.vertex1] = x * ab + y * ac + z * ad + aa * ae;
				this.brightness[ambientVertexRemap.vertex2] = x * af + y * ag + z * ah + aa * ai;
				this.brightness[ambientVertexRemap.vertex3] = x * aj + y * ak + z * al + aa * am;
				this.brightness[ambientVertexRemap.vertex4] = x * an + y * ao + z * ap + aa * aq;
				int ar = this.blend(l, i, q, v);
				int as = this.blend(k, i, o, v);
				int at = this.blend(k, j, s, v);
				int au = this.blend(l, j, u, v);
				this.lightMap[ambientVertexRemap.vertex1] = this.blend(ar, as, at, au, ab, ac, ad, ae);
				this.lightMap[ambientVertexRemap.vertex2] = this.blend(ar, as, at, au, af, ag, ah, ai);
				this.lightMap[ambientVertexRemap.vertex3] = this.blend(ar, as, at, au, aj, ak, al, am);
				this.lightMap[ambientVertexRemap.vertex4] = this.blend(ar, as, at, au, an, ao, ap, aq);
			} else {
				float x = (m + f + p + w) * 0.25F;
				float y = (h + f + n + w) * 0.25F;
				float z = (h + g + r + w) * 0.25F;
				float aa = (m + g + t + w) * 0.25F;
				this.lightMap[ambientVertexRemap.vertex1] = this.blend(l, i, q, v);
				this.lightMap[ambientVertexRemap.vertex2] = this.blend(k, i, o, v);
				this.lightMap[ambientVertexRemap.vertex3] = this.blend(k, j, s, v);
				this.lightMap[ambientVertexRemap.vertex4] = this.blend(l, j, u, v);
				this.brightness[ambientVertexRemap.vertex1] = x;
				this.brightness[ambientVertexRemap.vertex2] = y;
				this.brightness[ambientVertexRemap.vertex3] = z;
				this.brightness[ambientVertexRemap.vertex4] = aa;
			}
		}

		private int blend(int i, int j, int k, int l) {
			if (i == 0) {
				i = l;
			}

			if (j == 0) {
				j = l;
			}

			if (k == 0) {
				k = l;
			}

			return i + j + k + l >> 2 & 16711935;
		}

		private int blend(int i, int j, int k, int l, float f, float g, float h, float m) {
			int n = (int)((i >> 16 & 0xFF) * f + (j >> 16 & 0xFF) * g + (k >> 16 & 0xFF) * h + (l >> 16 & 0xFF) * m) & 0xFF;
			int o = (int)((i & 0xFF) * f + (j & 0xFF) * g + (k & 0xFF) * h + (l & 0xFF) * m) & 0xFF;
			return n << 16 | o;
		}
	}

	@Environment(EnvType.CLIENT)
	enum AmbientVertexRemap {
		DOWN(0, 1, 2, 3),
		UP(2, 3, 0, 1),
		NORTH(3, 0, 1, 2),
		SOUTH(0, 1, 2, 3),
		WEST(3, 0, 1, 2),
		EAST(1, 2, 3, 0);

		private final int vertex1;
		private final int vertex2;
		private final int vertex3;
		private final int vertex4;
		private static final BlockModelRenderer.AmbientVertexRemap[] ALL = new BlockModelRenderer.AmbientVertexRemap[6];

		AmbientVertexRemap(int vertex1, int vertex2, int vertex3, int vertex4) {
			this.vertex1 = vertex1;
			this.vertex2 = vertex2;
			this.vertex3 = vertex3;
			this.vertex4 = vertex4;
		}

		public static BlockModelRenderer.AmbientVertexRemap byDirection(Direction dir) {
			return ALL[dir.getId()];
		}

		static {
			ALL[Direction.DOWN.getId()] = DOWN;
			ALL[Direction.UP.getId()] = UP;
			ALL[Direction.NORTH.getId()] = NORTH;
			ALL[Direction.SOUTH.getId()] = SOUTH;
			ALL[Direction.WEST.getId()] = WEST;
			ALL[Direction.EAST.getId()] = EAST;
		}
	}

	@Environment(EnvType.CLIENT)
	public enum SizeData {
		DOWN(Direction.DOWN, false),
		UP(Direction.UP, false),
		NORTH(Direction.NORTH, false),
		SOUTH(Direction.SOUTH, false),
		WEST(Direction.WEST, false),
		EAST(Direction.EAST, false),
		FLIP_DOWN(Direction.DOWN, true),
		FLIP_UP(Direction.UP, true),
		FLIP_NORTH(Direction.NORTH, true),
		FLIP_SOUTH(Direction.SOUTH, true),
		FLIP_WEST(Direction.WEST, true),
		FLIP_EAST(Direction.EAST, true);

		protected final int shape;

		SizeData(Direction dir, boolean flip) {
			this.shape = dir.getId() + (flip ? Direction.values().length : 0);
		}
	}
}

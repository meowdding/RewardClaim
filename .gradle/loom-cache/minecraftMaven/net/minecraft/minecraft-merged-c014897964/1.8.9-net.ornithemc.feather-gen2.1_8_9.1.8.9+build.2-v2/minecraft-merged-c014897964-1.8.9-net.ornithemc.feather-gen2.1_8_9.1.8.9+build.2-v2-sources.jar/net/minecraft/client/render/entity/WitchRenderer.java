package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.layer.WitchItemInHandLayer;
import net.minecraft.client.render.model.entity.WitchModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.monster.WitchEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class WitchRenderer extends MobRenderer<WitchEntity> {
	private static final Identifier WITCH_LOCATION = new Identifier("textures/entity/witch.png");

	public WitchRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher, new WitchModel(0.0F), 0.5F);
		this.addLayer(new WitchItemInHandLayer(this));
	}

	public void render(WitchEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		((WitchModel)this.model).itemInHand = entity.getDisplayItemInHand() != null;
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(WitchEntity entity) {
		return WITCH_LOCATION;
	}

	@Override
	public void glTranslate() {
		GlStateManager.translatef(0.0F, 0.1875F, 0.0F);
	}

	protected void applyScale(WitchEntity entity, float scale) {
		float f = 0.9375F;
		GlStateManager.scalef(f, f, f);
	}
}

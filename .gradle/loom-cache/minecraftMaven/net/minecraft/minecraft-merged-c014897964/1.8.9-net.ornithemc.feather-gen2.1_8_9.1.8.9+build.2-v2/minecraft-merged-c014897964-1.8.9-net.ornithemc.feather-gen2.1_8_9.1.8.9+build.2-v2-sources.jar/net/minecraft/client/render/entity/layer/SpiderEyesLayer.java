package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.SpiderRenderer;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.monster.SpiderEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class SpiderEyesLayer implements EntityRenderLayer<SpiderEntity> {
	private static final Identifier SPIDER_EYES_LOCATION = new Identifier("textures/entity/spider_eyes.png");
	private final SpiderRenderer parent;

	public SpiderEyesLayer(SpiderRenderer parent) {
		this.parent = parent;
	}

	public void render(SpiderEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale) {
		this.parent.bindTexture(SPIDER_EYES_LOCATION);
		GlStateManager.enableBlend();
		GlStateManager.disableAlphaTest();
		GlStateManager.blendFunc(1, 1);
		if (entity.isInvisible()) {
			GlStateManager.depthMask(false);
		} else {
			GlStateManager.depthMask(true);
		}

		int i = 61680;
		int j = i % 65536;
		int k = i / 65536;
		GLX.multiTexCoord2f(GLX.GL_TEXTURE1, j / 1.0F, k / 1.0F);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.parent.getModel().render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
		i = entity.getLightLevel(tickDelta);
		j = i % 65536;
		k = i / 65536;
		GLX.multiTexCoord2f(GLX.GL_TEXTURE1, j / 1.0F, k / 1.0F);
		this.parent.setLightColor(entity, tickDelta);
		GlStateManager.disableBlend();
		GlStateManager.enableAlphaTest();
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

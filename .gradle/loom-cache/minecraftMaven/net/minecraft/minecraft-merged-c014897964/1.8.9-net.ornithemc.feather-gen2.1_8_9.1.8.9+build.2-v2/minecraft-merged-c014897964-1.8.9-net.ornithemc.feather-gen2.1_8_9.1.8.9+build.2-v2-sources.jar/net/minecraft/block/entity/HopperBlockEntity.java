package net.minecraft.block.entity;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.HopperBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityFilter;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.entity.living.player.PlayerInventory;
import net.minecraft.inventory.Hopper;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SidedInventory;
import net.minecraft.inventory.menu.HopperMenu;
import net.minecraft.inventory.menu.InventoryMenu;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.util.Tickable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.ornithemc.feather.constants.NbtTypes;

public class HopperBlockEntity extends InventoryBlockEntity implements Hopper, Tickable {
	private ItemStack[] inventory = new ItemStack[5];
	private String customName;
	private int transferCooldown = -1;

	@Override
	public void readNbt(NbtCompound nbt) {
		super.readNbt(nbt);
		NbtList nbtList = nbt.getList("Items", NbtTypes.COMPOUND);
		this.inventory = new ItemStack[this.getSize()];
		if (nbt.contains("CustomName", NbtTypes.STRING)) {
			this.customName = nbt.getString("CustomName");
		}

		this.transferCooldown = nbt.getInt("TransferCooldown");

		for (int i = 0; i < nbtList.size(); i++) {
			NbtCompound nbtCompound = nbtList.getCompound(i);
			int j = nbtCompound.getByte("Slot");
			if (j >= 0 && j < this.inventory.length) {
				this.inventory[j] = ItemStack.fromNbt(nbtCompound);
			}
		}
	}

	@Override
	public void writeNbt(NbtCompound nbt) {
		super.writeNbt(nbt);
		NbtList nbtList = new NbtList();

		for (int i = 0; i < this.inventory.length; i++) {
			if (this.inventory[i] != null) {
				NbtCompound nbtCompound = new NbtCompound();
				nbtCompound.putByte("Slot", (byte)i);
				this.inventory[i].writeNbt(nbtCompound);
				nbtList.addElement(nbtCompound);
			}
		}

		nbt.put("Items", nbtList);
		nbt.putInt("TransferCooldown", this.transferCooldown);
		if (this.hasCustomName()) {
			nbt.putString("CustomName", this.customName);
		}
	}

	@Override
	public void markDirty() {
		super.markDirty();
	}

	@Override
	public int getSize() {
		return this.inventory.length;
	}

	@Override
	public ItemStack getItem(int slot) {
		return this.inventory[slot];
	}

	@Override
	public ItemStack removeItem(int slot, int amount) {
		if (this.inventory[slot] != null) {
			if (this.inventory[slot].size <= amount) {
				ItemStack itemStack = this.inventory[slot];
				this.inventory[slot] = null;
				return itemStack;
			}

			ItemStack itemStack = this.inventory[slot].split(amount);
			if (this.inventory[slot].size == 0) {
				this.inventory[slot] = null;
			}

			return itemStack;
		} else {
			return null;
		}
	}

	@Override
	public ItemStack removeItemQuietly(int slot) {
		if (this.inventory[slot] != null) {
			ItemStack itemStack = this.inventory[slot];
			this.inventory[slot] = null;
			return itemStack;
		} else {
			return null;
		}
	}

	@Override
	public void setItem(int slot, ItemStack item) {
		this.inventory[slot] = item;
		if (item != null && item.size > this.getMaxStackSize()) {
			item.size = this.getMaxStackSize();
		}
	}

	@Override
	public String getName() {
		return this.hasCustomName() ? this.customName : "container.hopper";
	}

	@Override
	public boolean hasCustomName() {
		return this.customName != null && this.customName.length() > 0;
	}

	public void setCustomName(String name) {
		this.customName = name;
	}

	@Override
	public int getMaxStackSize() {
		return 64;
	}

	@Override
	public boolean isValid(PlayerEntity player) {
		return this.world.getBlockEntity(this.pos) != this
			? false
			: !(player.squaredDistanceTo(this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5) > 64.0);
	}

	@Override
	public void onOpen(PlayerEntity player) {
	}

	@Override
	public void onClose(PlayerEntity player) {
	}

	@Override
	public boolean isItemAllowed(int slot, ItemStack item) {
		return true;
	}

	@Override
	public void tick() {
		if (this.world != null && !this.world.isClient) {
			this.transferCooldown--;
			if (!this.isOnCooldown()) {
				this.setCooldown(0);
				this.transferItems();
			}
		}
	}

	public boolean transferItems() {
		if (this.world != null && !this.world.isClient) {
			if (!this.isOnCooldown() && HopperBlock.isEnabled(this.getBlockMetadata())) {
				boolean bl = false;
				if (!this.isInventoryEmpty()) {
					bl = this.pushItem();
				}

				if (!this.isFull()) {
					bl = pullItem(this) || bl;
				}

				if (bl) {
					this.setCooldown(8);
					this.markDirty();
					return true;
				}
			}

			return false;
		} else {
			return false;
		}
	}

	private boolean isInventoryEmpty() {
		for (ItemStack itemStack : this.inventory) {
			if (itemStack != null) {
				return false;
			}
		}

		return true;
	}

	private boolean isFull() {
		for (ItemStack itemStack : this.inventory) {
			if (itemStack == null || itemStack.size != itemStack.getMaxSize()) {
				return false;
			}
		}

		return true;
	}

	private boolean pushItem() {
		Inventory inventory = this.getTargetInventory();
		if (inventory == null) {
			return false;
		}

		Direction direction = HopperBlock.getFacing(this.getBlockMetadata()).getOpposite();
		if (this.isFullInventory(inventory, direction)) {
			return false;
		}

		for (int i = 0; i < this.getSize(); i++) {
			if (this.getItem(i) != null) {
				ItemStack itemStack = this.getItem(i).copy();
				ItemStack itemStack2 = pushItem(inventory, this.removeItem(i, 1), direction);
				if (itemStack2 == null || itemStack2.size == 0) {
					inventory.markDirty();
					return true;
				}

				this.setItem(i, itemStack);
			}
		}

		return false;
	}

	private boolean isFullInventory(Inventory inventory, Direction side) {
		if (inventory instanceof SidedInventory) {
			SidedInventory sidedInventory = (SidedInventory)inventory;
			int[] is = sidedInventory.getSlots(side);

			for (int i = 0; i < is.length; i++) {
				ItemStack itemStack = sidedInventory.getItem(is[i]);
				if (itemStack == null || itemStack.size != itemStack.getMaxSize()) {
					return false;
				}
			}
		} else {
			int j = inventory.getSize();

			for (int k = 0; k < j; k++) {
				ItemStack itemStack2 = inventory.getItem(k);
				if (itemStack2 == null || itemStack2.size != itemStack2.getMaxSize()) {
					return false;
				}
			}
		}

		return true;
	}

	private static boolean isEmptyInventory(Inventory inventory, Direction side) {
		if (inventory instanceof SidedInventory) {
			SidedInventory sidedInventory = (SidedInventory)inventory;
			int[] is = sidedInventory.getSlots(side);

			for (int i = 0; i < is.length; i++) {
				if (sidedInventory.getItem(is[i]) != null) {
					return false;
				}
			}
		} else {
			int j = inventory.getSize();

			for (int k = 0; k < j; k++) {
				if (inventory.getItem(k) != null) {
					return false;
				}
			}
		}

		return true;
	}

	public static boolean pullItem(Hopper hopper) {
		Inventory inventory = getInventoryAbove(hopper);
		if (inventory != null) {
			Direction direction = Direction.DOWN;
			if (isEmptyInventory(inventory, direction)) {
				return false;
			}

			if (inventory instanceof SidedInventory) {
				SidedInventory sidedInventory = (SidedInventory)inventory;
				int[] is = sidedInventory.getSlots(direction);

				for (int i = 0; i < is.length; i++) {
					if (pullItems(hopper, inventory, is[i], direction)) {
						return true;
					}
				}
			} else {
				int j = inventory.getSize();

				for (int k = 0; k < j; k++) {
					if (pullItems(hopper, inventory, k, direction)) {
						return true;
					}
				}
			}
		} else {
			for (ItemEntity itemEntity : getItem(hopper.getWorld(), hopper.getX(), hopper.getY() + 1.0, hopper.getZ())) {
				if (pickUpItem(hopper, itemEntity)) {
					return true;
				}
			}
		}

		return false;
	}

	private static boolean pullItems(Hopper hopper, Inventory inventory, int slot, Direction side) {
		ItemStack itemStack = inventory.getItem(slot);
		if (itemStack != null && canPullItem(inventory, itemStack, slot, side)) {
			ItemStack itemStack2 = itemStack.copy();
			ItemStack itemStack3 = pushItem(hopper, inventory.removeItem(slot, 1), null);
			if (itemStack3 == null || itemStack3.size == 0) {
				inventory.markDirty();
				return true;
			}

			inventory.setItem(slot, itemStack2);
		}

		return false;
	}

	public static boolean pickUpItem(Inventory inventory, ItemEntity item) {
		boolean bl = false;
		if (item == null) {
			return false;
		}

		ItemStack itemStack = item.getItem().copy();
		ItemStack itemStack2 = pushItem(inventory, itemStack, null);
		if (itemStack2 != null && itemStack2.size != 0) {
			item.setItem(itemStack2);
		} else {
			bl = true;
			item.remove();
		}

		return bl;
	}

	public static ItemStack pushItem(Inventory inventory, ItemStack item, Direction side) {
		if (inventory instanceof SidedInventory && side != null) {
			SidedInventory sidedInventory = (SidedInventory)inventory;
			int[] is = sidedInventory.getSlots(side);

			for (int i = 0; i < is.length && item != null && item.size > 0; i++) {
				item = pushItem(inventory, item, is[i], side);
			}
		} else {
			int j = inventory.getSize();

			for (int k = 0; k < j && item != null && item.size > 0; k++) {
				item = pushItem(inventory, item, k, side);
			}
		}

		if (item != null && item.size == 0) {
			item = null;
		}

		return item;
	}

	private static boolean canPushItem(Inventory inventory, ItemStack item, int slot, Direction side) {
		return !inventory.isItemAllowed(slot, item) ? false : !(inventory instanceof SidedInventory) || ((SidedInventory)inventory).canPushItem(slot, item, side);
	}

	private static boolean canPullItem(Inventory inventory, ItemStack item, int slot, Direction side) {
		return !(inventory instanceof SidedInventory) || ((SidedInventory)inventory).canPullItem(slot, item, side);
	}

	private static ItemStack pushItem(Inventory inventory, ItemStack item, int slot, Direction side) {
		ItemStack itemStack = inventory.getItem(slot);
		if (canPushItem(inventory, item, slot, side)) {
			boolean bl = false;
			if (itemStack == null) {
				inventory.setItem(slot, item);
				item = null;
				bl = true;
			} else if (canMergeItems(itemStack, item)) {
				int i = item.getMaxSize() - itemStack.size;
				int j = Math.min(item.size, i);
				item.size -= j;
				itemStack.size += j;
				bl = j > 0;
			}

			if (bl) {
				if (inventory instanceof HopperBlockEntity) {
					HopperBlockEntity hopperBlockEntity = (HopperBlockEntity)inventory;
					if (hopperBlockEntity.canTransferNextTick()) {
						hopperBlockEntity.setCooldown(8);
					}

					inventory.markDirty();
				}

				inventory.markDirty();
			}
		}

		return item;
	}

	/**
	 * Return the inventory of the block this hopper is pointing into.
	 */
	private Inventory getTargetInventory() {
		Direction direction = HopperBlock.getFacing(this.getBlockMetadata());
		return getInventoryAt(
			this.getWorld(), this.pos.getX() + direction.getOffsetX(), this.pos.getY() + direction.getOffsetY(), this.pos.getZ() + direction.getOffsetZ()
		);
	}

	public static Inventory getInventoryAbove(Hopper hopper) {
		return getInventoryAt(hopper.getWorld(), hopper.getX(), hopper.getY() + 1.0, hopper.getZ());
	}

	public static List<ItemEntity> getItem(World world, double x, double y, double z) {
		return world.getEntitiesOfType(ItemEntity.class, new Box(x - 0.5, y - 0.5, z - 0.5, x + 0.5, y + 0.5, z + 0.5), EntityFilter.ALIVE);
	}

	public static Inventory getInventoryAt(World world, double x, double y, double z) {
		Inventory inventory = null;
		int i = MathHelper.floor(x);
		int j = MathHelper.floor(y);
		int k = MathHelper.floor(z);
		BlockPos blockPos = new BlockPos(i, j, k);
		Block block = world.getBlockState(blockPos).getBlock();
		if (block.hasBlockEntity()) {
			BlockEntity blockEntity = world.getBlockEntity(blockPos);
			if (blockEntity instanceof Inventory) {
				inventory = (Inventory)blockEntity;
				if (inventory instanceof ChestBlockEntity && block instanceof ChestBlock) {
					inventory = ((ChestBlock)block).getInventory(world, blockPos);
				}
			}
		}

		if (inventory == null) {
			List<Entity> list = world.getEntities(null, new Box(x - 0.5, y - 0.5, z - 0.5, x + 0.5, y + 0.5, z + 0.5), EntityFilter.INVENTORY);
			if (list.size() > 0) {
				inventory = (Inventory)list.get(world.random.nextInt(list.size()));
			}
		}

		return inventory;
	}

	private static boolean canMergeItems(ItemStack item1, ItemStack item2) {
		if (item1.getItem() != item2.getItem()) {
			return false;
		} else if (item1.getMetadata() != item2.getMetadata()) {
			return false;
		} else {
			return item1.size > item1.getMaxSize() ? false : ItemStack.matchesNbt(item1, item2);
		}
	}

	@Override
	public double getX() {
		return this.pos.getX() + 0.5;
	}

	@Override
	public double getY() {
		return this.pos.getY() + 0.5;
	}

	@Override
	public double getZ() {
		return this.pos.getZ() + 0.5;
	}

	public void setCooldown(int cooldown) {
		this.transferCooldown = cooldown;
	}

	public boolean isOnCooldown() {
		return this.transferCooldown > 0;
	}

	public boolean canTransferNextTick() {
		return this.transferCooldown <= 1;
	}

	@Override
	public String getMenuType() {
		return "minecraft:hopper";
	}

	@Override
	public InventoryMenu createMenu(PlayerInventory playerInventory, PlayerEntity player) {
		return new HopperMenu(playerInventory, this, player);
	}

	@Override
	public int getData(int id) {
		return 0;
	}

	@Override
	public void setData(int id, int value) {
	}

	@Override
	public int getDataSize() {
		return 0;
	}

	@Override
	public void clear() {
		for (int i = 0; i < this.inventory.length; i++) {
			this.inventory[i] = null;
		}
	}
}

package net.minecraft.block;

import com.google.common.base.Predicate;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.block.state.property.EnumProperty;
import net.minecraft.block.state.property.Property;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.ornithemc.feather.constants.SetBlockFlags;

public class PoweredRailBlock extends AbstractRailBlock {
	public static final EnumProperty<AbstractRailBlock.Shape> SHAPE = EnumProperty.of(
		"shape",
		AbstractRailBlock.Shape.class,
		new Predicate<AbstractRailBlock.Shape>() {
			public boolean apply(AbstractRailBlock.Shape shape) {
				return shape != AbstractRailBlock.Shape.NORTH_EAST
					&& shape != AbstractRailBlock.Shape.NORTH_WEST
					&& shape != AbstractRailBlock.Shape.SOUTH_EAST
					&& shape != AbstractRailBlock.Shape.SOUTH_WEST;
			}
		}
	);
	public static final BooleanProperty POWERED = BooleanProperty.of("powered");

	protected PoweredRailBlock() {
		super(true);
		this.setDefaultState(this.stateDefinition.any().set(SHAPE, AbstractRailBlock.Shape.NORTH_SOUTH).set(POWERED, false));
	}

	protected boolean isPoweredByConnectedRails(World world, BlockPos pos, BlockState state, boolean forward, int depth) {
		if (depth >= 8) {
			return false;
		}

		int i = pos.getX();
		int j = pos.getY();
		int k = pos.getZ();
		boolean bl = true;
		AbstractRailBlock.Shape shape = state.get(SHAPE);
		switch (shape) {
			case NORTH_SOUTH:
				if (forward) {
					k++;
				} else {
					k--;
				}
				break;
			case EAST_WEST:
				if (forward) {
					i--;
				} else {
					i++;
				}
				break;
			case ASCENDING_EAST:
				if (forward) {
					i--;
				} else {
					i++;
					j++;
					bl = false;
				}

				shape = AbstractRailBlock.Shape.EAST_WEST;
				break;
			case ASCENDING_WEST:
				if (forward) {
					i--;
					j++;
					bl = false;
				} else {
					i++;
				}

				shape = AbstractRailBlock.Shape.EAST_WEST;
				break;
			case ASCENDING_NORTH:
				if (forward) {
					k++;
				} else {
					k--;
					j++;
					bl = false;
				}

				shape = AbstractRailBlock.Shape.NORTH_SOUTH;
				break;
			case ASCENDING_SOUTH:
				if (forward) {
					k++;
					j++;
					bl = false;
				} else {
					k--;
				}

				shape = AbstractRailBlock.Shape.NORTH_SOUTH;
		}

		return this.isPoweredByRail(world, new BlockPos(i, j, k), forward, depth, shape)
			? true
			: bl && this.isPoweredByRail(world, new BlockPos(i, j - 1, k), forward, depth, shape);
	}

	protected boolean isPoweredByRail(World world, BlockPos pos, boolean forward, int depth, AbstractRailBlock.Shape shape) {
		BlockState blockState = world.getBlockState(pos);
		if (blockState.getBlock() != this) {
			return false;
		}

		AbstractRailBlock.Shape shape2 = blockState.get(SHAPE);
		if (shape != AbstractRailBlock.Shape.EAST_WEST
			|| shape2 != AbstractRailBlock.Shape.NORTH_SOUTH && shape2 != AbstractRailBlock.Shape.ASCENDING_NORTH && shape2 != AbstractRailBlock.Shape.ASCENDING_SOUTH) {
			if (shape != AbstractRailBlock.Shape.NORTH_SOUTH
				|| shape2 != AbstractRailBlock.Shape.EAST_WEST && shape2 != AbstractRailBlock.Shape.ASCENDING_EAST && shape2 != AbstractRailBlock.Shape.ASCENDING_WEST) {
				if (!blockState.get(POWERED)) {
					return false;
				} else {
					return world.hasNeighborSignal(pos) ? true : this.isPoweredByConnectedRails(world, pos, blockState, forward, depth + 1);
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	@Override
	protected void updateState(World world, BlockPos pos, BlockState state, Block neighborBlock) {
		boolean bl = state.get(POWERED);
		boolean bl2 = world.hasNeighborSignal(pos)
			|| this.isPoweredByConnectedRails(world, pos, state, true, 0)
			|| this.isPoweredByConnectedRails(world, pos, state, false, 0);
		if (bl2 != bl) {
			world.setBlockState(pos, state.set(POWERED, bl2), SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
			world.updateNeighbors(pos.down(), this);
			if (state.get(SHAPE).isAscending()) {
				world.updateNeighbors(pos.up(), this);
			}
		}
	}

	@Override
	public Property<AbstractRailBlock.Shape> getShapeProperty() {
		return SHAPE;
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		return this.defaultState().set(SHAPE, AbstractRailBlock.Shape.byId(metadata & 7)).set(POWERED, (metadata & 8) > 0);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		int i = 0;
		i |= state.get(SHAPE).getId();
		if (state.get(POWERED)) {
			i |= 8;
		}

		return i;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, SHAPE, POWERED);
	}
}

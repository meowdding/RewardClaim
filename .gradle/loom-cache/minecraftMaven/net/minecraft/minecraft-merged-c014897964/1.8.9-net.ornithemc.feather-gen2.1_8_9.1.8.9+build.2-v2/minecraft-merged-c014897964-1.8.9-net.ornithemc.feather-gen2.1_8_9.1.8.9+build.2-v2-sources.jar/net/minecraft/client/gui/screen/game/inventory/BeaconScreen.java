package net.minecraft.client.gui.screen.game.inventory;

import io.netty.buffer.Unpooled;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.entity.living.effect.StatusEffect;
import net.minecraft.entity.living.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.menu.BeaconMenu;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.c2s.play.CustomPayloadC2SPacket;
import net.minecraft.resource.Identifier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Environment(EnvType.CLIENT)
public class BeaconScreen extends InventoryMenuScreen {
	private static final Logger LOGGER = LogManager.getLogger();
	private static final Identifier MENU_LOCATION = new Identifier("textures/gui/container/beacon.png");
	private Inventory inventory;
	private BeaconScreen.DoneButtonWidget doneButton;
	private boolean acceptsPayment;

	public BeaconScreen(PlayerInventory playerInventory, Inventory inventory) {
		super(new BeaconMenu(playerInventory, inventory));
		this.inventory = inventory;
		this.backgroundWidth = 230;
		this.backgroundHeight = 219;
	}

	@Override
	public void init() {
		super.init();
		this.buttons.add(this.doneButton = new BeaconScreen.DoneButtonWidget(-1, this.x + 164, this.y + 107));
		this.buttons.add(new BeaconScreen.CancelButtonWidget(-2, this.x + 190, this.y + 107));
		this.acceptsPayment = true;
		this.doneButton.active = false;
	}

	@Override
	public void tick() {
		super.tick();
		int i = this.inventory.getData(0);
		int j = this.inventory.getData(1);
		int k = this.inventory.getData(2);
		if (this.acceptsPayment && i >= 0) {
			this.acceptsPayment = false;

			for (int l = 0; l <= 2; l++) {
				int m = BeaconBlockEntity.EFFECTS[l].length;
				int n = m * 22 + (m - 1) * 2;

				for (int o = 0; o < m; o++) {
					int p = BeaconBlockEntity.EFFECTS[l][o].id;
					BeaconScreen.EffectButtonWidget effectButtonWidget = new BeaconScreen.EffectButtonWidget(
						l << 8 | p, this.x + 76 + o * 24 - n / 2, this.y + 22 + l * 25, p, l
					);
					this.buttons.add(effectButtonWidget);
					if (l >= i) {
						effectButtonWidget.active = false;
					} else if (p == j) {
						effectButtonWidget.setDisabled(true);
					}
				}
			}

			int l = 3;
			int m = BeaconBlockEntity.EFFECTS[l].length + 1;
			int n = m * 22 + (m - 1) * 2;

			for (int o = 0; o < m - 1; o++) {
				int p = BeaconBlockEntity.EFFECTS[l][o].id;
				BeaconScreen.EffectButtonWidget effectButtonWidget = new BeaconScreen.EffectButtonWidget(l << 8 | p, this.x + 167 + o * 24 - n / 2, this.y + 47, p, l);
				this.buttons.add(effectButtonWidget);
				if (l >= i) {
					effectButtonWidget.active = false;
				} else if (p == k) {
					effectButtonWidget.setDisabled(true);
				}
			}

			if (j > 0) {
				BeaconScreen.EffectButtonWidget effectButtonWidget2 = new BeaconScreen.EffectButtonWidget(
					l << 8 | j, this.x + 167 + (m - 1) * 24 - n / 2, this.y + 47, j, l
				);
				this.buttons.add(effectButtonWidget2);
				if (l >= i) {
					effectButtonWidget2.active = false;
				} else if (j == k) {
					effectButtonWidget2.setDisabled(true);
				}
			}
		}

		this.doneButton.active = this.inventory.getItem(0) != null && j > 0;
	}

	@Override
	protected void buttonClicked(ButtonWidget button) {
		if (button.id == -2) {
			this.minecraft.openScreen(null);
		} else if (button.id == -1) {
			String string = "MC|Beacon";
			PacketByteBuf packetByteBuf = new PacketByteBuf(Unpooled.buffer());
			packetByteBuf.writeInt(this.inventory.getData(1));
			packetByteBuf.writeInt(this.inventory.getData(2));
			this.minecraft.getNetworkHandler().sendPacket(new CustomPayloadC2SPacket(string, packetByteBuf));
			this.minecraft.openScreen(null);
		} else if (button instanceof BeaconScreen.EffectButtonWidget) {
			if (((BeaconScreen.EffectButtonWidget)button).isDisabled()) {
				return;
			}

			int i = button.id;
			int j = i & 0xFF;
			int k = i >> 8;
			if (k < 3) {
				this.inventory.setData(1, j);
			} else {
				this.inventory.setData(2, j);
			}

			this.buttons.clear();
			this.init();
			this.tick();
		}
	}

	@Override
	protected void renderLabels(int mouseX, int mouseY) {
		Lighting.turnOff();
		this.drawCenteredString(this.textRenderer, I18n.translate("tile.beacon.primary"), 62, 10, 14737632);
		this.drawCenteredString(this.textRenderer, I18n.translate("tile.beacon.secondary"), 169, 10, 14737632);

		for (ButtonWidget buttonWidget : this.buttons) {
			if (buttonWidget.isHovered()) {
				buttonWidget.renderTooltip(mouseX - this.x, mouseY - this.y);
				break;
			}
		}

		Lighting.turnOnGui();
	}

	@Override
	protected void renderMenuBackground(float tickDelta, int mouseX, int mouseY) {
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.minecraft.getTextureManager().bind(MENU_LOCATION);
		int i = (this.width - this.backgroundWidth) / 2;
		int j = (this.height - this.backgroundHeight) / 2;
		this.drawTexture(i, j, 0, 0, this.backgroundWidth, this.backgroundHeight);
		this.itemRenderer.zOffset = 100.0F;
		this.itemRenderer.renderGuiItem(new ItemStack(Items.EMERALD), i + 42, j + 109);
		this.itemRenderer.renderGuiItem(new ItemStack(Items.DIAMOND), i + 42 + 22, j + 109);
		this.itemRenderer.renderGuiItem(new ItemStack(Items.GOLD_INGOT), i + 42 + 44, j + 109);
		this.itemRenderer.renderGuiItem(new ItemStack(Items.IRON_INGOT), i + 42 + 66, j + 109);
		this.itemRenderer.zOffset = 0.0F;
	}

	@Environment(EnvType.CLIENT)
	static class BeaconButtonWidget extends ButtonWidget {
		/**
		 * The texture of the button inside the beacon GUI
		 */
		private final Identifier textureLocation;
		private final int u;
		private final int v;
		/**
		 * If clicking the button is disabled (button becomes unclickable and grayed out).
		 */
		private boolean disabled;

		protected BeaconButtonWidget(int id, int x, int y, Identifier textureLocation, int u, int v) {
			super(id, x, y, 22, 22, "");
			this.textureLocation = textureLocation;
			this.u = u;
			this.v = v;
		}

		@Override
		public void render(Minecraft minecraft, int mouseX, int mouseY) {
			if (this.visible) {
				minecraft.getTextureManager().bind(BeaconScreen.MENU_LOCATION);
				GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
				this.hovered = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;
				int i = 219;
				int j = 0;
				if (!this.active) {
					j += this.width * 2;
				} else if (this.disabled) {
					j += this.width * 1;
				} else if (this.hovered) {
					j += this.width * 3;
				}

				this.drawTexture(this.x, this.y, j, i, this.width, this.height);
				if (!BeaconScreen.MENU_LOCATION.equals(this.textureLocation)) {
					minecraft.getTextureManager().bind(this.textureLocation);
				}

				this.drawTexture(this.x + 2, this.y + 2, this.u, this.v, 18, 18);
			}
		}

		public boolean isDisabled() {
			return this.disabled;
		}

		public void setDisabled(boolean disabled) {
			this.disabled = disabled;
		}
	}

	@Environment(EnvType.CLIENT)
	class CancelButtonWidget extends BeaconScreen.BeaconButtonWidget {
		public CancelButtonWidget(int id, int x, int y) {
			super(id, x, y, BeaconScreen.MENU_LOCATION, 112, 220);
		}

		@Override
		public void renderTooltip(int mouseX, int mouseY) {
			BeaconScreen.this.renderTooltip(I18n.translate("gui.cancel"), mouseX, mouseY);
		}
	}

	@Environment(EnvType.CLIENT)
	class DoneButtonWidget extends BeaconScreen.BeaconButtonWidget {
		public DoneButtonWidget(int id, int x, int y) {
			super(id, x, y, BeaconScreen.MENU_LOCATION, 90, 220);
		}

		@Override
		public void renderTooltip(int mouseX, int mouseY) {
			BeaconScreen.this.renderTooltip(I18n.translate("gui.done"), mouseX, mouseY);
		}
	}

	@Environment(EnvType.CLIENT)
	class EffectButtonWidget extends BeaconScreen.BeaconButtonWidget {
		private final int effectId;
		private final int effectStrength;

		public EffectButtonWidget(int x, int y, int id, int effectId, int effectStrength) {
			super(
				x,
				y,
				id,
				InventoryMenuScreen.MENU_LOCATION,
				0 + StatusEffect.BY_ID[effectId].getIconIndex() % 8 * 18,
				198 + StatusEffect.BY_ID[effectId].getIconIndex() / 8 * 18
			);
			this.effectId = effectId;
			this.effectStrength = effectStrength;
		}

		@Override
		public void renderTooltip(int mouseX, int mouseY) {
			String string = I18n.translate(StatusEffect.BY_ID[this.effectId].getTranslationKey());
			if (this.effectStrength >= 3 && this.effectId != StatusEffect.REGENERATION.id) {
				string = string + " II";
			}

			BeaconScreen.this.renderTooltip(string, mouseX, mouseY);
		}
	}
}

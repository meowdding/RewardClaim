package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.model.entity.GhastModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.monster.GhastEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class GhastRenderer extends MobRenderer<GhastEntity> {
	private static final Identifier GHAST_LOCATION = new Identifier("textures/entity/ghast/ghast.png");
	private static final Identifier GHAST_SHOOTING_LOCATION = new Identifier("textures/entity/ghast/ghast_shooting.png");

	public GhastRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher, new GhastModel(), 0.5F);
	}

	protected Identifier getTextureLocation(GhastEntity entity) {
		return entity.isCharging() ? GHAST_SHOOTING_LOCATION : GHAST_LOCATION;
	}

	protected void applyScale(GhastEntity entity, float scale) {
		float f = 1.0F;
		float g = (8.0F + f) / 2.0F;
		float h = (8.0F + 1.0F / f) / 2.0F;
		GlStateManager.scalef(h, g, h);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
	}
}

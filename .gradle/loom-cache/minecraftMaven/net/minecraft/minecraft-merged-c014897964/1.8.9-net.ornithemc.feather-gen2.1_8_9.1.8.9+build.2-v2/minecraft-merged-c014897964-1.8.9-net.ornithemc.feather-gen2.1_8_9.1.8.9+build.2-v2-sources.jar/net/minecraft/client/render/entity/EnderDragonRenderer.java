package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.BossBar;
import net.minecraft.client.render.entity.layer.EnderDragonDeathLayer;
import net.minecraft.client.render.entity.layer.EnderDragonEyesLayer;
import net.minecraft.client.render.model.entity.EnderDragonModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.living.mob.monster.boss.EnderDragonEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class EnderDragonRenderer extends MobRenderer<EnderDragonEntity> {
	private static final Identifier ENDER_CRYSTAL_BEAM_LOCATION = new Identifier("textures/entity/endercrystal/endercrystal_beam.png");
	private static final Identifier DRAGON_EXPLODING_LOCATION = new Identifier("textures/entity/enderdragon/dragon_exploding.png");
	private static final Identifier DRAGON_LOCATION = new Identifier("textures/entity/enderdragon/dragon.png");
	protected EnderDragonModel model = (EnderDragonModel)this.model;

	public EnderDragonRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher, new EnderDragonModel(0.0F), 0.5F);
		this.addLayer(new EnderDragonEyesLayer(this));
		this.addLayer(new EnderDragonDeathLayer());
	}

	protected void applyRotation(EnderDragonEntity entity, float bob, float bodyYaw, float tickDelta) {
		float f = (float)entity.getSegmentProperties(7, tickDelta)[0];
		float g = (float)(entity.getSegmentProperties(5, tickDelta)[1] - entity.getSegmentProperties(10, tickDelta)[1]);
		GlStateManager.rotatef(-f, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(g * 10.0F, 1.0F, 0.0F, 0.0F);
		GlStateManager.translatef(0.0F, 0.0F, 1.0F);
		if (entity.deathTicks > 0) {
			float h = (entity.deathTicks + tickDelta - 1.0F) / 20.0F * 1.6F;
			h = MathHelper.sqrt(h);
			if (h > 1.0F) {
				h = 1.0F;
			}

			GlStateManager.rotatef(h * this.getDeathYaw(entity), 0.0F, 0.0F, 1.0F);
		}
	}

	protected void renderModel(EnderDragonEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float bob, float yaw, float pitch, float scale) {
		if (entity.ticksSinceDeath > 0) {
			float f = entity.ticksSinceDeath / 200.0F;
			GlStateManager.depthFunc(515);
			GlStateManager.enableAlphaTest();
			GlStateManager.alphaFunc(516, f);
			this.bindTexture(DRAGON_EXPLODING_LOCATION);
			this.model.render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
			GlStateManager.alphaFunc(516, 0.1F);
			GlStateManager.depthFunc(514);
		}

		this.bindTexture(entity);
		this.model.render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
		if (entity.damagedTimer > 0) {
			GlStateManager.depthFunc(514);
			GlStateManager.disableTexture();
			GlStateManager.enableBlend();
			GlStateManager.blendFunc(770, 771);
			GlStateManager.color4f(1.0F, 0.0F, 0.0F, 0.5F);
			this.model.render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
			GlStateManager.enableTexture();
			GlStateManager.disableBlend();
			GlStateManager.depthFunc(515);
		}
	}

	public void render(EnderDragonEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		BossBar.update(entity, false);
		super.render(entity, dx, dy, dz, yaw, tickDelta);
		if (entity.connectedCrystal != null) {
			this.renderCrystalBeam(entity, dx, dy, dz, tickDelta);
		}
	}

	protected void renderCrystalBeam(EnderDragonEntity dragon, double dx, double dy, double dz, float tickDelta) {
		float f = dragon.connectedCrystal.renderTicks + tickDelta;
		float g = MathHelper.sin(f * 0.2F) / 2.0F + 0.5F;
		g = (g * g + g) * 0.2F;
		float h = (float)(dragon.connectedCrystal.x - dragon.x - (dragon.lastX - dragon.x) * (1.0F - tickDelta));
		float i = (float)(g + dragon.connectedCrystal.y - 1.0 - dragon.y - (dragon.lastY - dragon.y) * (1.0F - tickDelta));
		float j = (float)(dragon.connectedCrystal.z - dragon.z - (dragon.lastZ - dragon.z) * (1.0F - tickDelta));
		float k = MathHelper.sqrt(h * h + j * j);
		float l = MathHelper.sqrt(h * h + i * i + j * j);
		GlStateManager.pushMatrix();
		GlStateManager.translatef((float)dx, (float)dy + 2.0F, (float)dz);
		GlStateManager.rotatef((float)(-Math.atan2(j, h)) * 180.0F / (float) Math.PI - 90.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef((float)(-Math.atan2(k, i)) * 180.0F / (float) Math.PI - 90.0F, 1.0F, 0.0F, 0.0F);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		Lighting.turnOff();
		GlStateManager.disableCull();
		this.bindTexture(ENDER_CRYSTAL_BEAM_LOCATION);
		GlStateManager.shadeModel(7425);
		float m = 0.0F - (dragon.ticks + tickDelta) * 0.01F;
		float n = MathHelper.sqrt(h * h + i * i + j * j) / 32.0F - (dragon.ticks + tickDelta) * 0.01F;
		bufferBuilder.begin(5, DefaultVertexFormat.POSITION_TEX_COLOR);
		int o = 8;

		for (int p = 0; p <= 8; p++) {
			float q = MathHelper.sin(p % 8 * (float) Math.PI * 2.0F / 8.0F) * 0.75F;
			float r = MathHelper.cos(p % 8 * (float) Math.PI * 2.0F / 8.0F) * 0.75F;
			float s = p % 8 * 1.0F / 8.0F;
			bufferBuilder.vertex(q * 0.2F, r * 0.2F, 0.0).texture(s, n).color(0, 0, 0, 255).nextVertex();
			bufferBuilder.vertex(q, r, l).texture(s, m).color(255, 255, 255, 255).nextVertex();
		}

		tesselator.end();
		GlStateManager.enableCull();
		GlStateManager.shadeModel(7424);
		Lighting.turnOn();
		GlStateManager.popMatrix();
	}

	protected Identifier getTextureLocation(EnderDragonEntity entity) {
		return DRAGON_LOCATION;
	}
}

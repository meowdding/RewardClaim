package net.minecraft.client.entity.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.world.World;

@Environment(EnvType.CLIENT)
public class BarrierParticle extends Particle {
	protected BarrierParticle(World world, double x, double y, double z, Item item) {
		super(world, x, y, z, 0.0, 0.0, 0.0);
		this.setTexture(Minecraft.getInstance().getItemRenderer().getModelShaper().getParticleIcon(item));
		this.red = this.green = this.blue = 1.0F;
		this.velocityX = this.velocityY = this.velocityZ = 0.0;
		this.gravity = 0.0F;
		this.lifetime = 80;
	}

	@Override
	public int getAtlasType() {
		return 1;
	}

	@Override
	public void render(BufferBuilder bufferBuilder, Entity camera, float tickDelta, float dx, float dy, float dz, float forwards, float sideways) {
		float f = this.sprite.getUMin();
		float g = this.sprite.getUMax();
		float h = this.sprite.getVMin();
		float i = this.sprite.getVMax();
		float j = 0.5F;
		float k = (float)(this.lastX + (this.x - this.lastX) * tickDelta - cameraX);
		float l = (float)(this.lastY + (this.y - this.lastY) * tickDelta - cameraY);
		float m = (float)(this.lastZ + (this.z - this.lastZ) * tickDelta - cameraZ);
		int n = this.getLightLevel(tickDelta);
		int o = n >> 16 & 65535;
		int p = n & 65535;
		bufferBuilder.vertex(k - dx * 0.5F - forwards * 0.5F, l - dy * 0.5F, m - dz * 0.5F - sideways * 0.5F)
			.texture(g, i)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
		bufferBuilder.vertex(k - dx * 0.5F + forwards * 0.5F, l + dy * 0.5F, m - dz * 0.5F + sideways * 0.5F)
			.texture(g, h)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
		bufferBuilder.vertex(k + dx * 0.5F + forwards * 0.5F, l + dy * 0.5F, m + dz * 0.5F + sideways * 0.5F)
			.texture(f, h)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
		bufferBuilder.vertex(k + dx * 0.5F - forwards * 0.5F, l - dy * 0.5F, m + dz * 0.5F - sideways * 0.5F)
			.texture(f, i)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
	}

	@Environment(EnvType.CLIENT)
	public static class Factory implements ParticleFactory {
		@Override
		public Particle create(int type, World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, int... parameters) {
			return new BarrierParticle(world, x, y, z, Item.byBlock(Blocks.BARRIER));
		}
	}
}

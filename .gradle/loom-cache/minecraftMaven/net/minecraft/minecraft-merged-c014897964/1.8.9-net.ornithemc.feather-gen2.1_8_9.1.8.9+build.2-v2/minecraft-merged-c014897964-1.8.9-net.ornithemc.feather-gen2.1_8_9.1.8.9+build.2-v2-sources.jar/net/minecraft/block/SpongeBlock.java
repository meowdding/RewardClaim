package net.minecraft.block;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.entity.particle.ParticleType;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.locale.I18n;
import net.minecraft.util.Pair;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.ornithemc.feather.constants.SetBlockFlags;

public class SpongeBlock extends Block {
	public static final BooleanProperty WET = BooleanProperty.of("wet");

	protected SpongeBlock() {
		super(Material.SPONGE);
		this.setDefaultState(this.stateDefinition.any().set(WET, false));
		this.setCreativeModeTab(CreativeModeTab.BUILDING_BLOCKS);
	}

	@Override
	public String getName() {
		return I18n.translate(this.getTranslationKey() + ".dry.name");
	}

	@Override
	public int getDropItemMetadata(BlockState state) {
		return state.get(WET) ? 1 : 0;
	}

	@Override
	public void onAdded(World world, BlockPos pos, BlockState state) {
		this.getWet(world, pos, state);
	}

	@Override
	public void neighborChanged(World world, BlockPos pos, BlockState state, Block neighborBlock) {
		this.getWet(world, pos, state);
		super.neighborChanged(world, pos, state, neighborBlock);
	}

	protected void getWet(World world, BlockPos pos, BlockState state) {
		if (!state.get(WET) && this.removeWater(world, pos)) {
			world.setBlockState(pos, state.set(WET, true), SetBlockFlags.NOTIFY_LISTENERS);
			world.doEvent(2001, pos, Block.getId(Blocks.WATER));
		}
	}

	private boolean removeWater(World world, BlockPos pos) {
		Queue<Pair<BlockPos, Integer>> queue = Lists.newLinkedList();
		ArrayList<BlockPos> arrayList = Lists.newArrayList();
		queue.add(new Pair<>(pos, 0));
		int i = 0;

		while (!queue.isEmpty()) {
			Pair<BlockPos, Integer> pair = queue.poll();
			BlockPos blockPos = pair.getLeft();
			int j = pair.getRight();

			for (Direction direction : Direction.values()) {
				BlockPos blockPos2 = blockPos.offset(direction);
				if (world.getBlockState(blockPos2).getBlock().getMaterial() == Material.WATER) {
					world.setBlockState(blockPos2, Blocks.AIR.defaultState(), SetBlockFlags.NOTIFY_LISTENERS);
					arrayList.add(blockPos2);
					i++;
					if (j < 6) {
						queue.add(new Pair<>(blockPos2, j + 1));
					}
				}
			}

			if (i > 64) {
				break;
			}
		}

		for (BlockPos blockPos : arrayList) {
			world.updateNeighbors(blockPos, Blocks.AIR);
		}

		return i > 0;
	}

	@Environment(EnvType.CLIENT)
	@Override
	public void addToCreativeMenu(Item item, CreativeModeTab tab, List<ItemStack> inventory) {
		inventory.add(new ItemStack(item, 1, 0));
		inventory.add(new ItemStack(item, 1, 1));
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		return this.defaultState().set(WET, (metadata & 1) == 1);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		return state.get(WET) ? 1 : 0;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, WET);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public void randomDisplayTick(World world, BlockPos pos, BlockState state, Random random) {
		if (state.get(WET)) {
			Direction direction = Direction.pick(random);
			if (direction != Direction.UP && !World.hasSolidTop(world, pos.offset(direction))) {
				double d = pos.getX();
				double e = pos.getY();
				double f = pos.getZ();
				if (direction == Direction.DOWN) {
					e -= 0.05;
					d += random.nextDouble();
					f += random.nextDouble();
				} else {
					e += random.nextDouble() * 0.8;
					if (direction.getAxis() == Direction.Axis.X) {
						f += random.nextDouble();
						if (direction == Direction.EAST) {
							d += 1.1;
						} else {
							d += 0.05;
						}
					} else {
						d += random.nextDouble();
						if (direction == Direction.SOUTH) {
							f += 1.1;
						} else {
							f += 0.05;
						}
					}
				}

				world.addParticle(ParticleType.DRIP_WATER, d, e, f, 0.0, 0.0, 0.0);
			}
		}
	}
}

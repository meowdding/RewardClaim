package net.minecraft.client.network.handler;

import com.google.common.collect.Maps;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BannerBlockEntity;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.CommandBlockBlockEntity;
import net.minecraft.block.entity.FlowerPotBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.client.ClientPlayerInteractionManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.living.player.LocalClientPlayerEntity;
import net.minecraft.client.entity.living.player.RemoteClientPlayerEntity;
import net.minecraft.client.entity.particle.EntityPickupParticle;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.ConfirmationListener;
import net.minecraft.client.gui.screen.CreditsScreen;
import net.minecraft.client.gui.screen.DemoScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.game.BookEditScreen;
import net.minecraft.client.gui.screen.game.ChatScreen;
import net.minecraft.client.gui.screen.game.inventory.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.game.inventory.VillagerScreen;
import net.minecraft.client.gui.screen.menu.StatsListener;
import net.minecraft.client.gui.screen.menu.TitleScreen;
import net.minecraft.client.gui.screen.menu.multiplayer.DisconnectedScreen;
import net.minecraft.client.gui.screen.menu.multiplayer.DownloadingTerrainScreen;
import net.minecraft.client.gui.screen.menu.multiplayer.MultiplayerScreen;
import net.minecraft.client.network.PlayerInfo;
import net.minecraft.client.options.GameOptions;
import net.minecraft.client.options.ServerList;
import net.minecraft.client.options.ServerListEntry;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.sound.instance.GuardianAttackSoundInstance;
import net.minecraft.client.twitch.AchievementMetadata;
import net.minecraft.client.twitch.PlayerCombatMetadata;
import net.minecraft.client.twitch.PlayerDeathMetadata;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.world.villager.trade.ClientTrader;
import net.minecraft.entity.EnderCrystalEntity;
import net.minecraft.entity.EnderEyeEntity;
import net.minecraft.entity.Entities;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.FireworksEntity;
import net.minecraft.entity.FishingBobberEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.PrimedTntEntity;
import net.minecraft.entity.data.SyncedData;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.decoration.LeadKnotEntity;
import net.minecraft.entity.decoration.PaintingEntity;
import net.minecraft.entity.global.LightningBoltEntity;
import net.minecraft.entity.living.ArmorStandEntity;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.attribute.AbstractEntityAttributeContainer;
import net.minecraft.entity.living.attribute.AttributeModifier;
import net.minecraft.entity.living.attribute.EntityAttributeInstance;
import net.minecraft.entity.living.attribute.RangedEntityAttribute;
import net.minecraft.entity.living.effect.StatusEffectInstance;
import net.minecraft.entity.living.mob.MobEntity;
import net.minecraft.entity.living.mob.monster.GuardianEntity;
import net.minecraft.entity.living.mob.passive.animal.HorseBaseEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.entity.living.player.PlayerInventory;
import net.minecraft.entity.particle.ParticleType;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.EggEntity;
import net.minecraft.entity.projectile.EnderPearlEntity;
import net.minecraft.entity.projectile.ExperienceBottleEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.entity.projectile.PotionEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.entity.projectile.SnowballEntity;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.entity.vehicle.MinecartEntity;
import net.minecraft.inventory.AnimalInventory;
import net.minecraft.inventory.MenuInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.inventory.menu.EmptyMenuProvider;
import net.minecraft.inventory.menu.InventoryMenu;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.FilledMapItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.PacketUtils;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.CustomPayloadC2SPacket;
import net.minecraft.network.packet.c2s.play.InventoryMenuConfirmC2SPacket;
import net.minecraft.network.packet.c2s.play.KeepAliveC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.ResourcePackC2SPacket;
import net.minecraft.network.packet.s2c.play.AddEntityS2CPacket;
import net.minecraft.network.packet.s2c.play.AddExperienceOrbS2CPacket;
import net.minecraft.network.packet.s2c.play.AddGlobalEntityS2CPacket;
import net.minecraft.network.packet.s2c.play.AddMobS2CPacket;
import net.minecraft.network.packet.s2c.play.AddPaintingS2CPacket;
import net.minecraft.network.packet.s2c.play.AddPlayerS2CPacket;
import net.minecraft.network.packet.s2c.play.AttachEntityS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockEventS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockMiningProgressS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.BlocksUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.CameraS2CPacket;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.CloseInventoryMenuS2CPacket;
import net.minecraft.network.packet.s2c.play.CommandSuggestionsS2CPacket;
import net.minecraft.network.packet.s2c.play.CompressionThresholdS2CPacket;
import net.minecraft.network.packet.s2c.play.CustomPayloadS2CPacket;
import net.minecraft.network.packet.s2c.play.DifficultyS2CPacket;
import net.minecraft.network.packet.s2c.play.DisconnectS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityAnimationS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityAttributesS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityDataS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityEquipmentS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityEventS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityHeadAnglesS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityMoveS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityPickupS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityRemoveStatusEffectS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusEffectS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitySyncS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityTeleportS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.GameEventS2CPacket;
import net.minecraft.network.packet.s2c.play.InventoryMenuConfirmS2CPacket;
import net.minecraft.network.packet.s2c.play.InventoryMenuContentS2CPacket;
import net.minecraft.network.packet.s2c.play.InventoryMenuDataS2CPacket;
import net.minecraft.network.packet.s2c.play.InventoryMenuSlotContentS2CPacket;
import net.minecraft.network.packet.s2c.play.KeepAliveS2CPacket;
import net.minecraft.network.packet.s2c.play.LoginS2CPacket;
import net.minecraft.network.packet.s2c.play.MapDataS2CPacket;
import net.minecraft.network.packet.s2c.play.OpenInventoryMenuS2CPacket;
import net.minecraft.network.packet.s2c.play.OpenSignEditorS2CPacket;
import net.minecraft.network.packet.s2c.play.ParticleS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerAbilitiesS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerCombatS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerHealthS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerInfoS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerMoveS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerSleepS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerXpS2CPacket;
import net.minecraft.network.packet.s2c.play.RemoveEntitiesS2CPacket;
import net.minecraft.network.packet.s2c.play.ResourcePackS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardDisplayS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardObjectiveS2CPacket;
import net.minecraft.network.packet.s2c.play.ScoreboardScoreS2CPacket;
import net.minecraft.network.packet.s2c.play.SelectSlotS2CPacket;
import net.minecraft.network.packet.s2c.play.SignUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.SoundEventS2CPacket;
import net.minecraft.network.packet.s2c.play.SpawnPointS2CPacket;
import net.minecraft.network.packet.s2c.play.StatsS2CPacket;
import net.minecraft.network.packet.s2c.play.TabListS2CPacket;
import net.minecraft.network.packet.s2c.play.TeamS2CPacket;
import net.minecraft.network.packet.s2c.play.TitlesS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldBorderS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldChunkS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldChunksS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldEventS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldTimeS2CPacket;
import net.minecraft.realms.DisconnectedRealmsScreen;
import net.minecraft.realms.RealmsScreenProxy;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.ScoreboardScore;
import net.minecraft.scoreboard.criterion.ScoreboardCriterion;
import net.minecraft.scoreboard.team.AbstractTeam;
import net.minecraft.scoreboard.team.Team;
import net.minecraft.stat.Stat;
import net.minecraft.stat.achievement.AchievementStat;
import net.minecraft.stat.achievement.Achievements;
import net.minecraft.text.Formatting;
import net.minecraft.text.LiteralText;
import net.minecraft.text.StringUtils;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.dimension.OverworldDimension;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.map.SavedMapData;
import net.minecraft.world.village.trade.TradeOffers;
import net.minecraft.world.village.trade.Trader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Environment(EnvType.CLIENT)
public class ClientPlayNetworkHandler implements ClientPlayPacketHandler {
	private static final Logger LOGGER = LogManager.getLogger();
	private final Connection connection;
	private final GameProfile profile;
	private final Screen callbackScreen;
	private Minecraft minecraft;
	private ClientWorld world;
	private boolean started;
	private final Map<UUID, PlayerInfo> onlinePlayers = Maps.newHashMap();
	public int maxPlayerCount = 20;
	private boolean hasAchievements = false;
	private final Random random = new Random();

	public ClientPlayNetworkHandler(Minecraft minecraft, Screen callbackScreen, Connection connection, GameProfile profile) {
		this.minecraft = minecraft;
		this.callbackScreen = callbackScreen;
		this.connection = connection;
		this.profile = profile;
	}

	public void closeWorld() {
		this.world = null;
	}

	@Override
	public void handleLogin(LoginS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		this.minecraft.interactionManager = new ClientPlayerInteractionManager(this.minecraft, this);
		this.world = new ClientWorld(
			this,
			new WorldSettings(0L, packet.getGameMode(), false, packet.getHardcore(), packet.getGeneratorType()),
			packet.getDimension(),
			packet.getDifficulty(),
			this.minecraft.profiler
		);
		this.minecraft.options.difficulty = packet.getDifficulty();
		this.minecraft.setWorld(this.world);
		this.minecraft.player.dimension = packet.getDimension();
		this.minecraft.openScreen(new DownloadingTerrainScreen(this));
		this.minecraft.player.setNetworkId(packet.getEntityId());
		this.maxPlayerCount = packet.getMaxPlayerCount();
		this.minecraft.player.setReducedDebugInfo(packet.getReducedDebugInfo());
		this.minecraft.interactionManager.setGameMode(packet.getGameMode());
		this.minecraft.options.syncClientSettings();
		this.connection.send(new CustomPayloadC2SPacket("MC|Brand", new PacketByteBuf(Unpooled.buffer()).writeString(ClientBrandRetriever.getClientModName())));
	}

	@Override
	public void handleAddEntity(AddEntityS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		double d = packet.getX() / 32.0;
		double e = packet.getY() / 32.0;
		double f = packet.getZ() / 32.0;
		Entity entity = null;
		if (packet.getType() == 10) {
			entity = MinecartEntity.create(this.world, d, e, f, MinecartEntity.Type.byIndex(packet.getData()));
		} else if (packet.getType() == 90) {
			Entity entity2 = this.world.getEntity(packet.getData());
			if (entity2 instanceof PlayerEntity) {
				entity = new FishingBobberEntity(this.world, d, e, f, (PlayerEntity)entity2);
			}

			packet.setData(0);
		} else if (packet.getType() == 60) {
			entity = new ArrowEntity(this.world, d, e, f);
		} else if (packet.getType() == 61) {
			entity = new SnowballEntity(this.world, d, e, f);
		} else if (packet.getType() == 71) {
			entity = new ItemFrameEntity(
				this.world, new BlockPos(MathHelper.floor(d), MathHelper.floor(e), MathHelper.floor(f)), Direction.byIdHorizontal(packet.getData())
			);
			packet.setData(0);
		} else if (packet.getType() == 77) {
			entity = new LeadKnotEntity(this.world, new BlockPos(MathHelper.floor(d), MathHelper.floor(e), MathHelper.floor(f)));
			packet.setData(0);
		} else if (packet.getType() == 65) {
			entity = new EnderPearlEntity(this.world, d, e, f);
		} else if (packet.getType() == 72) {
			entity = new EnderEyeEntity(this.world, d, e, f);
		} else if (packet.getType() == 76) {
			entity = new FireworksEntity(this.world, d, e, f, null);
		} else if (packet.getType() == 63) {
			entity = new FireballEntity(this.world, d, e, f, packet.getVelocityX() / 8000.0, packet.getVelocityY() / 8000.0, packet.getVelocityZ() / 8000.0);
			packet.setData(0);
		} else if (packet.getType() == 64) {
			entity = new SmallFireballEntity(this.world, d, e, f, packet.getVelocityX() / 8000.0, packet.getVelocityY() / 8000.0, packet.getVelocityZ() / 8000.0);
			packet.setData(0);
		} else if (packet.getType() == 66) {
			entity = new WitherSkullEntity(this.world, d, e, f, packet.getVelocityX() / 8000.0, packet.getVelocityY() / 8000.0, packet.getVelocityZ() / 8000.0);
			packet.setData(0);
		} else if (packet.getType() == 62) {
			entity = new EggEntity(this.world, d, e, f);
		} else if (packet.getType() == 73) {
			entity = new PotionEntity(this.world, d, e, f, packet.getData());
			packet.setData(0);
		} else if (packet.getType() == 75) {
			entity = new ExperienceBottleEntity(this.world, d, e, f);
			packet.setData(0);
		} else if (packet.getType() == 1) {
			entity = new BoatEntity(this.world, d, e, f);
		} else if (packet.getType() == 50) {
			entity = new PrimedTntEntity(this.world, d, e, f, null);
		} else if (packet.getType() == 78) {
			entity = new ArmorStandEntity(this.world, d, e, f);
		} else if (packet.getType() == 51) {
			entity = new EnderCrystalEntity(this.world, d, e, f);
		} else if (packet.getType() == 2) {
			entity = new ItemEntity(this.world, d, e, f);
		} else if (packet.getType() == 70) {
			entity = new FallingBlockEntity(this.world, d, e, f, Block.deserialize(packet.getData() & 65535));
			packet.setData(0);
		}

		if (entity != null) {
			entity.lastKnownX = packet.getX();
			entity.lastKnownY = packet.getY();
			entity.lastKnownZ = packet.getZ();
			entity.pitch = packet.getPitch() * 360 / 256.0F;
			entity.yaw = packet.getYaw() * 360 / 256.0F;
			Entity[] entitys = entity.getParts();
			if (entitys != null) {
				int i = packet.getId() - entity.getNetworkId();

				for (int j = 0; j < entitys.length; j++) {
					entitys[j].setNetworkId(entitys[j].getNetworkId() + i);
				}
			}

			entity.setNetworkId(packet.getId());
			this.world.forceEntity(packet.getId(), entity);
			if (packet.getData() > 0) {
				if (packet.getType() == 60) {
					Entity entity3 = this.world.getEntity(packet.getData());
					if (entity3 instanceof LivingEntity && entity instanceof ArrowEntity) {
						((ArrowEntity)entity).shooter = entity3;
					}
				}

				entity.lerpVelocity(packet.getVelocityX() / 8000.0, packet.getVelocityY() / 8000.0, packet.getVelocityZ() / 8000.0);
			}
		}
	}

	@Override
	public void handleAddExperienceOrb(AddExperienceOrbS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = new ExperienceOrbEntity(this.world, packet.getX() / 32.0, packet.getY() / 32.0, packet.getZ() / 32.0, packet.getXp());
		entity.lastKnownX = packet.getX();
		entity.lastKnownY = packet.getY();
		entity.lastKnownZ = packet.getZ();
		entity.yaw = 0.0F;
		entity.pitch = 0.0F;
		entity.setNetworkId(packet.getId());
		this.world.forceEntity(packet.getId(), entity);
	}

	@Override
	public void handleAddGlobalEntity(AddGlobalEntityS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		double d = packet.getX() / 32.0;
		double e = packet.getY() / 32.0;
		double f = packet.getZ() / 32.0;
		Entity entity = null;
		if (packet.getType() == 1) {
			entity = new LightningBoltEntity(this.world, d, e, f);
		}

		if (entity != null) {
			entity.lastKnownX = packet.getX();
			entity.lastKnownY = packet.getY();
			entity.lastKnownZ = packet.getZ();
			entity.yaw = 0.0F;
			entity.pitch = 0.0F;
			entity.setNetworkId(packet.getId());
			this.world.addGlobalEntity(entity);
		}
	}

	@Override
	public void handleAddPainting(AddPaintingS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		PaintingEntity paintingEntity = new PaintingEntity(this.world, packet.getPos(), packet.getFacing(), packet.getMotive());
		this.world.forceEntity(packet.getId(), paintingEntity);
	}

	@Override
	public void handleEntityVelocity(EntityVelocityS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = this.world.getEntity(packet.getId());
		if (entity != null) {
			entity.lerpVelocity(packet.getVelocityX() / 8000.0, packet.getVelocityY() / 8000.0, packet.getVelocityZ() / 8000.0);
		}
	}

	@Override
	public void handleEntityData(EntityDataS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = this.world.getEntity(packet.getId());
		if (entity != null && packet.getDataEntries() != null) {
			entity.getSyncedData().update(packet.getDataEntries());
		}
	}

	@Override
	public void handleAddPlayer(AddPlayerS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		double d = packet.getX() / 32.0;
		double e = packet.getY() / 32.0;
		double f = packet.getZ() / 32.0;
		float g = packet.getYaw() * 360 / 256.0F;
		float h = packet.getPitch() * 360 / 256.0F;
		RemoteClientPlayerEntity remoteClientPlayerEntity = new RemoteClientPlayerEntity(this.minecraft.world, this.getOnlinePlayer(packet.getUuid()).getProfile());
		remoteClientPlayerEntity.lastX = remoteClientPlayerEntity.prevX = remoteClientPlayerEntity.lastKnownX = packet.getX();
		remoteClientPlayerEntity.lastY = remoteClientPlayerEntity.prevY = remoteClientPlayerEntity.lastKnownY = packet.getY();
		remoteClientPlayerEntity.lastZ = remoteClientPlayerEntity.prevZ = remoteClientPlayerEntity.lastKnownZ = packet.getZ();
		int i = packet.getItemInHand();
		if (i == 0) {
			remoteClientPlayerEntity.inventory.items[remoteClientPlayerEntity.inventory.selectedSlot] = null;
		} else {
			remoteClientPlayerEntity.inventory.items[remoteClientPlayerEntity.inventory.selectedSlot] = new ItemStack(Item.byId(i), 1, 0);
		}

		remoteClientPlayerEntity.updatePositionAndAngles(d, e, f, g, h);
		this.world.forceEntity(packet.getId(), remoteClientPlayerEntity);
		List<SyncedData.Entry> list = packet.getDataEntries();
		if (list != null) {
			remoteClientPlayerEntity.getSyncedData().update(list);
		}
	}

	@Override
	public void handleEntityTeleport(EntityTeleportS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = this.world.getEntity(packet.getId());
		if (entity != null) {
			entity.lastKnownX = packet.getX();
			entity.lastKnownY = packet.getY();
			entity.lastKnownZ = packet.getZ();
			double d = entity.lastKnownX / 32.0;
			double e = entity.lastKnownY / 32.0;
			double f = entity.lastKnownZ / 32.0;
			float g = packet.getYaw() * 360 / 256.0F;
			float h = packet.getPitch() * 360 / 256.0F;
			if (!(Math.abs(entity.x - d) >= 0.03125) && !(Math.abs(entity.y - e) >= 0.015625) && !(Math.abs(entity.z - f) >= 0.03125)) {
				entity.lerpPositionAndAngles(entity.x, entity.y, entity.z, g, h, 3, true);
			} else {
				entity.lerpPositionAndAngles(d, e, f, g, h, 3, true);
			}

			entity.onGround = packet.getOnGround();
		}
	}

	@Override
	public void handleSelectSlot(SelectSlotS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		if (packet.getSlot() >= 0 && packet.getSlot() < PlayerInventory.getHotbarSize()) {
			this.minecraft.player.inventory.selectedSlot = packet.getSlot();
		}
	}

	@Override
	public void handleEntityMove(EntityMoveS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = packet.getEntity(this.world);
		if (entity != null) {
			entity.lastKnownX = entity.lastKnownX + packet.getDx();
			entity.lastKnownY = entity.lastKnownY + packet.getDy();
			entity.lastKnownZ = entity.lastKnownZ + packet.getDz();
			double d = entity.lastKnownX / 32.0;
			double e = entity.lastKnownY / 32.0;
			double f = entity.lastKnownZ / 32.0;
			float g = packet.hasAngles() ? packet.getYaw() * 360 / 256.0F : entity.yaw;
			float h = packet.hasAngles() ? packet.getPitch() * 360 / 256.0F : entity.pitch;
			entity.lerpPositionAndAngles(d, e, f, g, h, 3, false);
			entity.onGround = packet.getOnGround();
		}
	}

	@Override
	public void handleEntityHeadAngles(EntityHeadAnglesS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = packet.getEntity(this.world);
		if (entity != null) {
			float f = packet.getHeadYaw() * 360 / 256.0F;
			entity.setHeadYaw(f);
		}
	}

	@Override
	public void handleRemoveEntities(RemoveEntitiesS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);

		for (int i = 0; i < packet.getIds().length; i++) {
			this.world.removeEntity(packet.getIds()[i]);
		}
	}

	@Override
	public void handlePlayerMove(PlayerMoveS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		PlayerEntity playerEntity = this.minecraft.player;
		double d = packet.getX();
		double e = packet.getY();
		double f = packet.getZ();
		float g = packet.getYaw();
		float h = packet.getPitch();
		if (packet.getRelativeArgs().contains(PlayerMoveS2CPacket.Argument.X)) {
			d += playerEntity.x;
		} else {
			playerEntity.velocityX = 0.0;
		}

		if (packet.getRelativeArgs().contains(PlayerMoveS2CPacket.Argument.Y)) {
			e += playerEntity.y;
		} else {
			playerEntity.velocityY = 0.0;
		}

		if (packet.getRelativeArgs().contains(PlayerMoveS2CPacket.Argument.Z)) {
			f += playerEntity.z;
		} else {
			playerEntity.velocityZ = 0.0;
		}

		if (packet.getRelativeArgs().contains(PlayerMoveS2CPacket.Argument.PITCH)) {
			h += playerEntity.pitch;
		}

		if (packet.getRelativeArgs().contains(PlayerMoveS2CPacket.Argument.YAW)) {
			g += playerEntity.yaw;
		}

		playerEntity.updatePositionAndAngles(d, e, f, g, h);
		this.connection
			.send(new PlayerMoveC2SPacket.PositionAndAngles(playerEntity.x, playerEntity.getShape().minY, playerEntity.z, playerEntity.yaw, playerEntity.pitch, false));
		if (!this.started) {
			this.minecraft.player.lastX = this.minecraft.player.x;
			this.minecraft.player.lastY = this.minecraft.player.y;
			this.minecraft.player.lastZ = this.minecraft.player.z;
			this.started = true;
			this.minecraft.openScreen(null);
		}
	}

	@Override
	public void handleBlocksUpdate(BlocksUpdateS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);

		for (BlocksUpdateS2CPacket.BlockUpdate blockUpdate : packet.getUpdates()) {
			this.world.setBlockStateFromPacket(blockUpdate.getBlockPos(), blockUpdate.getBlockState());
		}
	}

	@Override
	public void handleWorldChunk(WorldChunkS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		if (packet.isFull()) {
			if (packet.getSections() == 0) {
				this.world.updateChunk(packet.getChunkX(), packet.getChunkZ(), false);
				return;
			}

			this.world.updateChunk(packet.getChunkX(), packet.getChunkZ(), true);
		}

		this.world.clearBlockResets(packet.getChunkX() << 4, 0, packet.getChunkZ() << 4, (packet.getChunkX() << 4) + 15, 256, (packet.getChunkZ() << 4) + 15);
		WorldChunk worldChunk = this.world.getChunkAt(packet.getChunkX(), packet.getChunkZ());
		worldChunk.update(packet.getChunkData(), packet.getSections(), packet.isFull());
		this.world.notifyRegionChanged(packet.getChunkX() << 4, 0, packet.getChunkZ() << 4, (packet.getChunkX() << 4) + 15, 256, (packet.getChunkZ() << 4) + 15);
		if (!packet.isFull() || !(this.world.dimension instanceof OverworldDimension)) {
			worldChunk.resetBorderLightChecks();
		}
	}

	@Override
	public void handleBlockUpdate(BlockUpdateS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		this.world.setBlockStateFromPacket(packet.getPos(), packet.getBlockState());
	}

	@Override
	public void handleDisconnect(DisconnectS2CPacket packet) {
		this.connection.disconnect(packet.getReason());
	}

	@Override
	public void onDisconnect(Text reason) {
		this.minecraft.setWorld(null);
		if (this.callbackScreen != null) {
			if (this.callbackScreen instanceof RealmsScreenProxy) {
				this.minecraft.openScreen(new DisconnectedRealmsScreen(((RealmsScreenProxy)this.callbackScreen).getDelegate(), "disconnect.lost", reason).getWrapped());
			} else {
				this.minecraft.openScreen(new DisconnectedScreen(this.callbackScreen, "disconnect.lost", reason));
			}
		} else {
			this.minecraft.openScreen(new DisconnectedScreen(new MultiplayerScreen(new TitleScreen()), "disconnect.lost", reason));
		}
	}

	public void sendPacket(Packet packet) {
		this.connection.send(packet);
	}

	@Override
	public void handleEntityPickup(EntityPickupS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = this.world.getEntity(packet.getId());
		LivingEntity livingEntity = (LivingEntity)this.world.getEntity(packet.getCollectorId());
		if (livingEntity == null) {
			livingEntity = this.minecraft.player;
		}

		if (entity != null) {
			if (entity instanceof ExperienceOrbEntity) {
				this.world.playSound((Entity)entity, "random.orb", 0.2F, ((this.random.nextFloat() - this.random.nextFloat()) * 0.7F + 1.0F) * 2.0F);
			} else {
				this.world.playSound((Entity)entity, "random.pop", 0.2F, ((this.random.nextFloat() - this.random.nextFloat()) * 0.7F + 1.0F) * 2.0F);
			}

			this.minecraft.particleManager.add(new EntityPickupParticle(this.world, entity, livingEntity, 0.5F));
			this.world.removeEntity(packet.getId());
		}
	}

	@Override
	public void handleChatMessage(ChatMessageS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		if (packet.getType() == 2) {
			this.minecraft.gui.setOverlayMessage(packet.getMessage(), false);
		} else {
			this.minecraft.gui.getChat().addMessage(packet.getMessage());
		}
	}

	@Override
	public void handleEntityAnimation(EntityAnimationS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = this.world.getEntity(packet.getId());
		if (entity != null) {
			if (packet.getAction() == 0) {
				LivingEntity livingEntity = (LivingEntity)entity;
				livingEntity.swingArm();
			} else if (packet.getAction() == 1) {
				entity.animateDamage();
			} else if (packet.getAction() == 2) {
				PlayerEntity playerEntity = (PlayerEntity)entity;
				playerEntity.wakeUp(false, false, false);
			} else if (packet.getAction() == 4) {
				this.minecraft.particleManager.addEmitter(entity, ParticleType.CRIT);
			} else if (packet.getAction() == 5) {
				this.minecraft.particleManager.addEmitter(entity, ParticleType.CRIT_MAGIC);
			}
		}
	}

	@Override
	public void handlePlayerSleep(PlayerSleepS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		packet.getPlayer(this.world).trySleep(packet.getPos());
	}

	@Override
	public void handleAddMob(AddMobS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		double d = packet.getX() / 32.0;
		double e = packet.getY() / 32.0;
		double f = packet.getZ() / 32.0;
		float g = packet.getYaw() * 360 / 256.0F;
		float h = packet.getPitch() * 360 / 256.0F;
		LivingEntity livingEntity = (LivingEntity)Entities.create(packet.getType(), this.minecraft.world);
		livingEntity.lastKnownX = packet.getX();
		livingEntity.lastKnownY = packet.getY();
		livingEntity.lastKnownZ = packet.getZ();
		livingEntity.bodyYaw = livingEntity.headYaw = packet.getHeadYaw() * 360 / 256.0F;
		Entity[] entitys = livingEntity.getParts();
		if (entitys != null) {
			int i = packet.getId() - livingEntity.getNetworkId();

			for (int j = 0; j < entitys.length; j++) {
				entitys[j].setNetworkId(entitys[j].getNetworkId() + i);
			}
		}

		livingEntity.setNetworkId(packet.getId());
		livingEntity.updatePositionAndAngles(d, e, f, g, h);
		livingEntity.velocityX = packet.getVelocityX() / 8000.0F;
		livingEntity.velocityY = packet.getVelocityY() / 8000.0F;
		livingEntity.velocityZ = packet.getVelocityZ() / 8000.0F;
		this.world.forceEntity(packet.getId(), livingEntity);
		List<SyncedData.Entry> list = packet.getDataEntries();
		if (list != null) {
			livingEntity.getSyncedData().update(list);
		}
	}

	@Override
	public void handleWorldTime(WorldTimeS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		this.minecraft.world.setTime(packet.getTime());
		this.minecraft.world.setTimeOfDay(packet.getTimeOfDay());
	}

	@Override
	public void handleSpawnPoint(SpawnPointS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		this.minecraft.player.setSpawnPoint(packet.getPos(), true);
		this.minecraft.world.getData().setSpawnPoint(packet.getPos());
	}

	@Override
	public void handleAttachEntity(AttachEntityS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = this.world.getEntity(packet.getId());
		Entity entity2 = this.world.getEntity(packet.getAttachedId());
		if (packet.getType() == 0) {
			boolean bl = false;
			if (packet.getId() == this.minecraft.player.getNetworkId()) {
				entity = this.minecraft.player;
				if (entity2 instanceof BoatEntity) {
					((BoatEntity)entity2).setEmpty(false);
				}

				bl = entity.vehicle == null && entity2 != null;
			} else if (entity2 instanceof BoatEntity) {
				((BoatEntity)entity2).setEmpty(true);
			}

			if (entity == null) {
				return;
			}

			entity.startRiding(entity2);
			if (bl) {
				GameOptions gameOptions = this.minecraft.options;
				this.minecraft.gui.setOverlayMessage(I18n.translate("mount.onboard", GameOptions.getKeyName(gameOptions.sneakKey.getKeyCode())), false);
			}
		} else if (packet.getType() == 1 && entity instanceof MobEntity) {
			if (entity2 != null) {
				((MobEntity)entity).attachLeash(entity2, false);
			} else {
				((MobEntity)entity).detachLeash(false, false);
			}
		}
	}

	@Override
	public void handleEntityEvent(EntityEventS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = packet.getEntity(this.world);
		if (entity != null) {
			if (packet.getEvent() == 21) {
				this.minecraft.getSoundManager().play(new GuardianAttackSoundInstance((GuardianEntity)entity));
			} else {
				entity.doEvent(packet.getEvent());
			}
		}
	}

	@Override
	public void handlePlayerHealth(PlayerHealthS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		this.minecraft.player.damageTo(packet.getHealth());
		this.minecraft.player.getHungerManager().setFoodLevel(packet.getHunger());
		this.minecraft.player.getHungerManager().setSaturationLevel(packet.getSaturation());
	}

	@Override
	public void handlePlayerXp(PlayerXpS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		this.minecraft.player.setXp(packet.getLevelProgress(), packet.getXp(), packet.getLevel());
	}

	@Override
	public void handlePlayerRespawn(PlayerRespawnS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		if (packet.getDimension() != this.minecraft.player.dimension) {
			this.started = false;
			Scoreboard scoreboard = this.world.getScoreboard();
			this.world = new ClientWorld(
				this,
				new WorldSettings(0L, packet.getGameMode(), false, this.minecraft.world.getData().isHardcore(), packet.getGeneratorType()),
				packet.getDimension(),
				packet.getDifficulty(),
				this.minecraft.profiler
			);
			this.world.setScoreboard(scoreboard);
			this.minecraft.setWorld(this.world);
			this.minecraft.player.dimension = packet.getDimension();
			this.minecraft.openScreen(new DownloadingTerrainScreen(this));
		}

		this.minecraft.respawnPlayer(packet.getDimension());
		this.minecraft.interactionManager.setGameMode(packet.getGameMode());
	}

	@Override
	public void handleExplosion(ExplosionS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Explosion explosion = new Explosion(this.minecraft.world, null, packet.getX(), packet.getY(), packet.getZ(), packet.getPower(), packet.getDamagedBlocks());
		explosion.damageBlocks(true);
		this.minecraft.player.velocityX = this.minecraft.player.velocityX + packet.getPlayerVelocityX();
		this.minecraft.player.velocityY = this.minecraft.player.velocityY + packet.getPlayerVelocityY();
		this.minecraft.player.velocityZ = this.minecraft.player.velocityZ + packet.getPlayerVelocityZ();
	}

	@Override
	public void handleOpenInventoryMenu(OpenInventoryMenuS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		LocalClientPlayerEntity localClientPlayerEntity = this.minecraft.player;
		if ("minecraft:container".equals(packet.getMenuType())) {
			localClientPlayerEntity.openChestMenu(new SimpleInventory(packet.getDisplayName(), packet.getSize()));
			localClientPlayerEntity.menu.networkId = packet.getMenuId();
		} else if ("minecraft:villager".equals(packet.getMenuType())) {
			localClientPlayerEntity.openTraderMenu(new ClientTrader(localClientPlayerEntity, packet.getDisplayName()));
			localClientPlayerEntity.menu.networkId = packet.getMenuId();
		} else if ("EntityHorse".equals(packet.getMenuType())) {
			Entity entity = this.world.getEntity(packet.getOwnerId());
			if (entity instanceof HorseBaseEntity) {
				localClientPlayerEntity.openHorseMenu((HorseBaseEntity)entity, new AnimalInventory(packet.getDisplayName(), packet.getSize()));
				localClientPlayerEntity.menu.networkId = packet.getMenuId();
			}
		} else if (!packet.hasSize()) {
			localClientPlayerEntity.openMenu(new EmptyMenuProvider(packet.getMenuType(), packet.getDisplayName()));
			localClientPlayerEntity.menu.networkId = packet.getMenuId();
		} else {
			MenuInventory menuInventory = new MenuInventory(packet.getMenuType(), packet.getDisplayName(), packet.getSize());
			localClientPlayerEntity.openChestMenu(menuInventory);
			localClientPlayerEntity.menu.networkId = packet.getMenuId();
		}
	}

	@Override
	public void handleInventoryMenuSlotContent(InventoryMenuSlotContentS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		PlayerEntity playerEntity = this.minecraft.player;
		if (packet.getMenuId() == -1) {
			playerEntity.inventory.setCursorItem(packet.getItem());
		} else {
			boolean bl = false;
			if (this.minecraft.screen instanceof CreativeInventoryScreen) {
				CreativeInventoryScreen creativeInventoryScreen = (CreativeInventoryScreen)this.minecraft.screen;
				bl = creativeInventoryScreen.getSelectedTab() != CreativeModeTab.INVENTORY.getId();
			}

			if (packet.getMenuId() == 0 && packet.getSlotId() >= 36 && packet.getSlotId() < 45) {
				ItemStack itemStack = playerEntity.playerMenu.getSlot(packet.getSlotId()).getItem();
				if (packet.getItem() != null && (itemStack == null || itemStack.size < packet.getItem().size)) {
					packet.getItem().popAnimationTime = 5;
				}

				playerEntity.playerMenu.setItem(packet.getSlotId(), packet.getItem());
			} else if (packet.getMenuId() == playerEntity.menu.networkId && (packet.getMenuId() != 0 || !bl)) {
				playerEntity.menu.setItem(packet.getSlotId(), packet.getItem());
			}
		}
	}

	@Override
	public void handleInventoryMenuConfirm(InventoryMenuConfirmS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		InventoryMenu inventoryMenu = null;
		PlayerEntity playerEntity = this.minecraft.player;
		if (packet.getMenuId() == 0) {
			inventoryMenu = playerEntity.playerMenu;
		} else if (packet.getMenuId() == playerEntity.menu.networkId) {
			inventoryMenu = playerEntity.menu;
		}

		if (inventoryMenu != null && !packet.getAccepted()) {
			this.sendPacket(new InventoryMenuConfirmC2SPacket(packet.getMenuId(), packet.getActionId(), true));
		}
	}

	@Override
	public void handleInventoryMenuContent(InventoryMenuContentS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		PlayerEntity playerEntity = this.minecraft.player;
		if (packet.getMenuId() == 0) {
			playerEntity.playerMenu.setItems(packet.getItems());
		} else if (packet.getMenuId() == playerEntity.menu.networkId) {
			playerEntity.menu.setItems(packet.getItems());
		}
	}

	@Override
	public void handleOpenSignEditor(OpenSignEditorS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		BlockEntity blockEntity = this.world.getBlockEntity(packet.getPos());
		if (!(blockEntity instanceof SignBlockEntity)) {
			blockEntity = new SignBlockEntity();
			blockEntity.setWorld(this.world);
			blockEntity.setPos(packet.getPos());
		}

		this.minecraft.player.openSignEditor((SignBlockEntity)blockEntity);
	}

	@Override
	public void handleSignBlockEntityUpdate(SignUpdateS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		boolean bl = false;
		if (this.minecraft.world.isChunkLoaded(packet.getPos())) {
			BlockEntity blockEntity = this.minecraft.world.getBlockEntity(packet.getPos());
			if (blockEntity instanceof SignBlockEntity) {
				SignBlockEntity signBlockEntity = (SignBlockEntity)blockEntity;
				if (signBlockEntity.isEditable()) {
					System.arraycopy(packet.getLines(), 0, signBlockEntity.lines, 0, 4);
					signBlockEntity.markDirty();
				}

				bl = true;
			}
		}

		if (!bl && this.minecraft.player != null) {
			this.minecraft
				.player
				.sendMessage(new LiteralText("Unable to locate sign at " + packet.getPos().getX() + ", " + packet.getPos().getY() + ", " + packet.getPos().getZ()));
		}
	}

	@Override
	public void handleBlockEntityUpdate(BlockEntityUpdateS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		if (this.minecraft.world.isChunkLoaded(packet.getPos())) {
			BlockEntity blockEntity = this.minecraft.world.getBlockEntity(packet.getPos());
			int i = packet.getType();
			if (i == 1 && blockEntity instanceof MobSpawnerBlockEntity
				|| i == 2 && blockEntity instanceof CommandBlockBlockEntity
				|| i == 3 && blockEntity instanceof BeaconBlockEntity
				|| i == 4 && blockEntity instanceof SkullBlockEntity
				|| i == 5 && blockEntity instanceof FlowerPotBlockEntity
				|| i == 6 && blockEntity instanceof BannerBlockEntity) {
				blockEntity.readNbt(packet.getNbt());
			}
		}
	}

	@Override
	public void handleInventoryMenuData(InventoryMenuDataS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		PlayerEntity playerEntity = this.minecraft.player;
		if (playerEntity.menu != null && playerEntity.menu.networkId == packet.getMenuId()) {
			playerEntity.menu.setData(packet.getDataId(), packet.getValue());
		}
	}

	@Override
	public void handleEntityEquipment(EntityEquipmentS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = this.world.getEntity(packet.getId());
		if (entity != null) {
			entity.setEquipment(packet.getEquipmentSlot(), packet.getItem());
		}
	}

	@Override
	public void handleCloseInventoryMenu(CloseInventoryMenuS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		this.minecraft.player.doCloseMenu();
	}

	@Override
	public void handleBlockEvent(BlockEventS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		this.minecraft.world.addBlockEvent(packet.getPos(), packet.getBlock(), packet.getType(), packet.getData());
	}

	@Override
	public void handleBlockMiningProgress(BlockMiningProgressS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		this.minecraft.world.updateBlockMiningProgress(packet.getPlayerId(), packet.getPos(), packet.getProgress());
	}

	@Override
	public void handleWorldChunks(WorldChunksS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);

		for (int i = 0; i < packet.getChunkCount(); i++) {
			int j = packet.getChunkX(i);
			int k = packet.getChunkZ(i);
			this.world.updateChunk(j, k, true);
			this.world.clearBlockResets(j << 4, 0, k << 4, (j << 4) + 15, 256, (k << 4) + 15);
			WorldChunk worldChunk = this.world.getChunkAt(j, k);
			worldChunk.update(packet.getData(i), packet.getSections(i), true);
			this.world.notifyRegionChanged(j << 4, 0, k << 4, (j << 4) + 15, 256, (k << 4) + 15);
			if (!(this.world.dimension instanceof OverworldDimension)) {
				worldChunk.resetBorderLightChecks();
			}
		}
	}

	@Override
	public void handleGameEvent(GameEventS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		PlayerEntity playerEntity = this.minecraft.player;
		int i = packet.getEvent();
		float f = packet.getData();
		int j = MathHelper.floor(f + 0.5F);
		if (i >= 0 && i < GameEventS2CPacket.EVENT_MESSAGES.length && GameEventS2CPacket.EVENT_MESSAGES[i] != null) {
			playerEntity.addMessage(new TranslatableText(GameEventS2CPacket.EVENT_MESSAGES[i]));
		}

		if (i == 1) {
			this.world.getData().setRaining(true);
			this.world.setRain(0.0F);
		} else if (i == 2) {
			this.world.getData().setRaining(false);
			this.world.setRain(1.0F);
		} else if (i == 3) {
			this.minecraft.interactionManager.setGameMode(WorldSettings.GameMode.byId(j));
		} else if (i == 4) {
			this.minecraft.openScreen(new CreditsScreen());
		} else if (i == 5) {
			GameOptions gameOptions = this.minecraft.options;
			if (f == 0.0F) {
				this.minecraft.openScreen(new DemoScreen());
			} else if (f == 101.0F) {
				this.minecraft
					.gui
					.getChat()
					.addMessage(
						new TranslatableText(
							"demo.help.movement",
							GameOptions.getKeyName(gameOptions.forwardKey.getKeyCode()),
							GameOptions.getKeyName(gameOptions.leftKey.getKeyCode()),
							GameOptions.getKeyName(gameOptions.backKey.getKeyCode()),
							GameOptions.getKeyName(gameOptions.rightKey.getKeyCode())
						)
					);
			} else if (f == 102.0F) {
				this.minecraft.gui.getChat().addMessage(new TranslatableText("demo.help.jump", GameOptions.getKeyName(gameOptions.jumpKey.getKeyCode())));
			} else if (f == 103.0F) {
				this.minecraft.gui.getChat().addMessage(new TranslatableText("demo.help.inventory", GameOptions.getKeyName(gameOptions.inventoryKey.getKeyCode())));
			}
		} else if (i == 6) {
			this.world.playSound(playerEntity.x, playerEntity.y + playerEntity.getEyeHeight(), playerEntity.z, "random.successful_hit", 0.18F, 0.45F, false);
		} else if (i == 7) {
			this.world.setRain(f);
		} else if (i == 8) {
			this.world.setThunder(f);
		} else if (i == 10) {
			this.world.addParticle(ParticleType.MOB_APPEARANCE, playerEntity.x, playerEntity.y, playerEntity.z, 0.0, 0.0, 0.0);
			this.world.playSound(playerEntity.x, playerEntity.y, playerEntity.z, "mob.guardian.curse", 1.0F, 1.0F, false);
		}
	}

	@Override
	public void handleMapData(MapDataS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		SavedMapData savedMapData = FilledMapItem.getMapData(packet.getId(), this.minecraft.world);
		packet.apply(savedMapData);
		this.minecraft.gameRenderer.getMapRenderer().updateTexture(savedMapData);
	}

	@Override
	public void handleWorldEvent(WorldEventS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		if (packet.isGlobal()) {
			this.minecraft.world.doGlobalEvent(packet.getEvent(), packet.getPos(), packet.getData());
		} else {
			this.minecraft.world.doEvent(packet.getEvent(), packet.getPos(), packet.getData());
		}
	}

	@Override
	public void handleStats(StatsS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		boolean bl = false;

		for (Entry<Stat, Integer> entry : packet.getStats().entrySet()) {
			Stat stat = entry.getKey();
			int i = entry.getValue();
			if (stat.isAchievement() && i > 0) {
				if (this.hasAchievements && this.minecraft.player.getStats().get(stat) == 0) {
					AchievementStat achievementStat = (AchievementStat)stat;
					this.minecraft.toast.set(achievementStat);
					this.minecraft.getTwitchStream().sendActionMetadata(new AchievementMetadata(achievementStat), 0L);
					if (stat == Achievements.OPEN_INVENTORY) {
						this.minecraft.options.showInventoryAchievementHint = false;
						this.minecraft.options.save();
					}
				}

				bl = true;
			}

			this.minecraft.player.getStats().set(this.minecraft.player, stat, i);
		}

		if (!this.hasAchievements && !bl && this.minecraft.options.showInventoryAchievementHint) {
			this.minecraft.toast.setTutorial(Achievements.OPEN_INVENTORY);
		}

		this.hasAchievements = true;
		if (this.minecraft.screen instanceof StatsListener) {
			((StatsListener)this.minecraft.screen).onStatsReady();
		}
	}

	@Override
	public void handleEntityStatusEffect(EntityStatusEffectS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = this.world.getEntity(packet.getId());
		if (entity instanceof LivingEntity) {
			StatusEffectInstance statusEffectInstance = new StatusEffectInstance(
				packet.getEffect(), packet.getDuration(), packet.getAmplifier(), false, packet.getParticles()
			);
			statusEffectInstance.setPermanent(packet.isPermanent());
			((LivingEntity)entity).addStatusEffect(statusEffectInstance);
		}
	}

	@Override
	public void handlePlayerCombat(PlayerCombatS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = this.world.getEntity(packet.killerId);
		LivingEntity livingEntity = entity instanceof LivingEntity ? (LivingEntity)entity : null;
		if (packet.event == PlayerCombatS2CPacket.Event.END_COMBAT) {
			long l = 1000 * packet.duration / 20;
			PlayerCombatMetadata playerCombatMetadata = new PlayerCombatMetadata(this.minecraft.player, livingEntity);
			this.minecraft.getTwitchStream().sendSpanMetadata(playerCombatMetadata, 0L - l, 0L);
		} else if (packet.event == PlayerCombatS2CPacket.Event.ENTITY_DIED) {
			Entity entity2 = this.world.getEntity(packet.playerId);
			if (entity2 instanceof PlayerEntity) {
				PlayerDeathMetadata playerDeathMetadata = new PlayerDeathMetadata((PlayerEntity)entity2, livingEntity);
				playerDeathMetadata.setDescription(packet.message);
				this.minecraft.getTwitchStream().sendActionMetadata(playerDeathMetadata, 0L);
			}
		}
	}

	@Override
	public void handleDifficulty(DifficultyS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		this.minecraft.world.getData().setDifficulty(packet.getDifficulty());
		this.minecraft.world.getData().setDifficultyLocked(packet.getLocked());
	}

	@Override
	public void handleCamera(CameraS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = packet.getCamera(this.world);
		if (entity != null) {
			this.minecraft.setCamera(entity);
		}
	}

	@Override
	public void handleWorldBorder(WorldBorderS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		packet.apply(this.world.getWorldBorder());
	}

	@Override
	public void handleTitles(TitlesS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		TitlesS2CPacket.Type type = packet.getType();
		String string = null;
		String string2 = null;
		String string3 = packet.getText() != null ? packet.getText().getFormattedString() : "";
		switch (type) {
			case TITLE:
				string = string3;
				break;
			case SUBTITLE:
				string2 = string3;
				break;
			case RESET:
				this.minecraft.gui.setTitles("", "", -1, -1, -1);
				this.minecraft.gui.resetTitleTimes();
				return;
		}

		this.minecraft.gui.setTitles(string, string2, packet.getFadeIn(), packet.getDuration(), packet.getFadeOut());
	}

	@Override
	public void handleCompressionThreshold(CompressionThresholdS2CPacket packet) {
		if (!this.connection.isLocal()) {
			this.connection.setCompressionThreshold(packet.getCompressionThreshold());
		}
	}

	@Override
	public void handleTabList(TabListS2CPacket packet) {
		this.minecraft.gui.getPlayerTabOverlay().setHeader(packet.getHeader().getFormattedString().length() == 0 ? null : packet.getHeader());
		this.minecraft.gui.getPlayerTabOverlay().setFooter(packet.getFooter().getFormattedString().length() == 0 ? null : packet.getFooter());
	}

	@Override
	public void handleEntityRemoveStatusEffect(EntityRemoveStatusEffectS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = this.world.getEntity(packet.getId());
		if (entity instanceof LivingEntity) {
			((LivingEntity)entity).removeEffect(packet.getEffect());
		}
	}

	@Override
	public void handlePlayerInfo(PlayerInfoS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);

		for (PlayerInfoS2CPacket.Entry entry : packet.getEntries()) {
			if (packet.getAction() == PlayerInfoS2CPacket.Action.REMOVE_PLAYER) {
				this.onlinePlayers.remove(entry.getProfile().getId());
			} else {
				PlayerInfo playerInfo = this.onlinePlayers.get(entry.getProfile().getId());
				if (packet.getAction() == PlayerInfoS2CPacket.Action.ADD_PLAYER) {
					playerInfo = new PlayerInfo(entry);
					this.onlinePlayers.put(playerInfo.getProfile().getId(), playerInfo);
				}

				if (playerInfo != null) {
					switch (packet.getAction()) {
						case ADD_PLAYER:
							playerInfo.setGameMode(entry.getGameMode());
							playerInfo.setPing(entry.getPing());
							break;
						case UPDATE_GAME_MODE:
							playerInfo.setGameMode(entry.getGameMode());
							break;
						case UPDATE_PING:
							playerInfo.setPing(entry.getPing());
							break;
						case UPDATE_DISPLAY_NAME:
							playerInfo.setDisplayName(entry.getDisplayName());
					}
				}
			}
		}
	}

	@Override
	public void handleKeepAlive(KeepAliveS2CPacket packet) {
		this.sendPacket(new KeepAliveC2SPacket(packet.getTimeMillis()));
	}

	@Override
	public void handlePlayerAbilities(PlayerAbilitiesS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		PlayerEntity playerEntity = this.minecraft.player;
		playerEntity.abilities.flying = packet.isFlying();
		playerEntity.abilities.creativeMode = packet.isCreativeMode();
		playerEntity.abilities.invulnerable = packet.isInvulnerable();
		playerEntity.abilities.canFly = packet.allowsFlying();
		playerEntity.abilities.setFlySpeed(packet.getFlySpeed());
		playerEntity.abilities.setWalkSpeed(packet.getWalkSpeed());
	}

	@Override
	public void handleCommandSuggestions(CommandSuggestionsS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		String[] strings = packet.getSuggestions();
		if (this.minecraft.screen instanceof ChatScreen) {
			ChatScreen chatScreen = (ChatScreen)this.minecraft.screen;
			chatScreen.setMessageHistory(strings);
		}
	}

	@Override
	public void handleSoundEvent(SoundEventS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		this.minecraft.world.playSound(packet.getX(), packet.getY(), packet.getZ(), packet.getSound(), packet.getVolume(), packet.getPitch(), false);
	}

	@Override
	public void handleResourcePack(ResourcePackS2CPacket packet) {
		final String string = packet.getUrl();
		final String string2 = packet.getHash();
		if (string.startsWith("level://")) {
			String string3 = string.substring("level://".length());
			File file = new File(this.minecraft.gameDir, "saves");
			File file2 = new File(file, string3);
			if (file2.isFile()) {
				this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.ACCEPTED));
				Futures.addCallback(this.minecraft.getResourcePacks().applyServerPack(file2), new FutureCallback<Object>() {
					@Override
					public void onSuccess(Object result) {
						ClientPlayNetworkHandler.this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.SUCCESSFULLY_LOADED));
					}

					@Override
					public void onFailure(Throwable t) {
						ClientPlayNetworkHandler.this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.FAILED_DOWNLOAD));
					}
				});
			} else {
				this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.FAILED_DOWNLOAD));
			}
		} else {
			if (this.minecraft.getCurrentServerEntry() != null
				&& this.minecraft.getCurrentServerEntry().getResourcePackStatus() == ServerListEntry.ResourcePackStatus.ENABLED) {
				this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.ACCEPTED));
				Futures.addCallback(this.minecraft.getResourcePacks().downloadServerPack(string, string2), new FutureCallback<Object>() {
					@Override
					public void onSuccess(Object object) {
						ClientPlayNetworkHandler.this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.SUCCESSFULLY_LOADED));
					}

					@Override
					public void onFailure(Throwable throwable) {
						ClientPlayNetworkHandler.this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.FAILED_DOWNLOAD));
					}
				});
			} else if (this.minecraft.getCurrentServerEntry() != null
				&& this.minecraft.getCurrentServerEntry().getResourcePackStatus() != ServerListEntry.ResourcePackStatus.PROMPT) {
				this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.DECLINED));
			} else {
				this.minecraft.executeTask(new Runnable() {
					@Override
					public void run() {
						ClientPlayNetworkHandler.this.minecraft.openScreen(new ConfirmScreen(new ConfirmationListener() {
							@Override
							public void confirmResult(boolean result, int id) {
								ClientPlayNetworkHandler.this.minecraft = Minecraft.getInstance();
								if (result) {
									if (ClientPlayNetworkHandler.this.minecraft.getCurrentServerEntry() != null) {
										ClientPlayNetworkHandler.this.minecraft.getCurrentServerEntry().setResourcePackStatus(ServerListEntry.ResourcePackStatus.ENABLED);
									}

									ClientPlayNetworkHandler.this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.ACCEPTED));
									Futures.addCallback(ClientPlayNetworkHandler.this.minecraft.getResourcePacks().downloadServerPack(string, string2), new FutureCallback<Object>() {
										@Override
										public void onSuccess(Object object) {
											ClientPlayNetworkHandler.this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.SUCCESSFULLY_LOADED));
										}

										@Override
										public void onFailure(Throwable throwable) {
											ClientPlayNetworkHandler.this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.FAILED_DOWNLOAD));
										}
									});
								} else {
									if (ClientPlayNetworkHandler.this.minecraft.getCurrentServerEntry() != null) {
										ClientPlayNetworkHandler.this.minecraft.getCurrentServerEntry().setResourcePackStatus(ServerListEntry.ResourcePackStatus.DISABLED);
									}

									ClientPlayNetworkHandler.this.connection.send(new ResourcePackC2SPacket(string2, ResourcePackC2SPacket.Response.DECLINED));
								}

								ServerList.update(ClientPlayNetworkHandler.this.minecraft.getCurrentServerEntry());
								ClientPlayNetworkHandler.this.minecraft.openScreen(null);
							}
						}, I18n.translate("multiplayer.texturePrompt.line1"), I18n.translate("multiplayer.texturePrompt.line2"), 0));
					}
				});
			}
		}
	}

	@Override
	public void handleEntitySync(EntitySyncS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = packet.getEntity(this.world);
		if (entity != null) {
			entity.syncNbt(packet.getNbt());
		}
	}

	@Override
	public void handleCustomPayload(CustomPayloadS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		if ("MC|TrList".equals(packet.getChannel())) {
			PacketByteBuf packetByteBuf = packet.getData();

			try {
				int i = packetByteBuf.readInt();
				Screen screen = this.minecraft.screen;
				if (screen != null && screen instanceof VillagerScreen && i == this.minecraft.player.menu.networkId) {
					Trader trader = ((VillagerScreen)screen).getTrader();
					TradeOffers tradeOffers = TradeOffers.deserialize(packetByteBuf);
					trader.setOffers(tradeOffers);
				}
			} catch (IOException iOException) {
				LOGGER.error("Couldn't load trade info", iOException);
			} finally {
				packetByteBuf.release();
			}
		} else if ("MC|Brand".equals(packet.getChannel())) {
			this.minecraft.player.setServerBrand(packet.getData().readString(32767));
		} else if ("MC|BOpen".equals(packet.getChannel())) {
			ItemStack itemStack = this.minecraft.player.getItemInHand();
			if (itemStack != null && itemStack.getItem() == Items.WRITTEN_BOOK) {
				this.minecraft.openScreen(new BookEditScreen(this.minecraft.player, itemStack, false));
			}
		}
	}

	@Override
	public void handleScoreboardObjective(ScoreboardObjectiveS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Scoreboard scoreboard = this.world.getScoreboard();
		if (packet.getAction() == 0) {
			ScoreboardObjective scoreboardObjective = scoreboard.createObjective(packet.getName(), ScoreboardCriterion.DUMMY);
			scoreboardObjective.setDisplayName(packet.getDisplayName());
			scoreboardObjective.setRenderType(packet.getRenderType());
		} else {
			ScoreboardObjective scoreboardObjective = scoreboard.getObjective(packet.getName());
			if (packet.getAction() == 1) {
				scoreboard.removeObjective(scoreboardObjective);
			} else if (packet.getAction() == 2) {
				scoreboardObjective.setDisplayName(packet.getDisplayName());
				scoreboardObjective.setRenderType(packet.getRenderType());
			}
		}
	}

	@Override
	public void handleScoreboardScore(ScoreboardScoreS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Scoreboard scoreboard = this.world.getScoreboard();
		ScoreboardObjective scoreboardObjective = scoreboard.getObjective(packet.getObjective());
		if (packet.getUpdateMode() == ScoreboardScoreS2CPacket.UpdateMode.CHANGE) {
			ScoreboardScore scoreboardScore = scoreboard.getScore(packet.getOwner(), scoreboardObjective);
			scoreboardScore.set(packet.getScore());
		} else if (packet.getUpdateMode() == ScoreboardScoreS2CPacket.UpdateMode.REMOVE) {
			if (StringUtils.isStringEmpty(packet.getObjective())) {
				scoreboard.removeScore(packet.getOwner(), null);
			} else if (scoreboardObjective != null) {
				scoreboard.removeScore(packet.getOwner(), scoreboardObjective);
			}
		}
	}

	@Override
	public void handleScoreboardDisplay(ScoreboardDisplayS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Scoreboard scoreboard = this.world.getScoreboard();
		if (packet.getObjective().length() == 0) {
			scoreboard.setDisplayObjective(packet.getSlot(), null);
		} else {
			ScoreboardObjective scoreboardObjective = scoreboard.getObjective(packet.getObjective());
			scoreboard.setDisplayObjective(packet.getSlot(), scoreboardObjective);
		}
	}

	@Override
	public void handleTeam(TeamS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Scoreboard scoreboard = this.world.getScoreboard();
		Team team;
		if (packet.getAction() == 0) {
			team = scoreboard.addTeam(packet.getName());
		} else {
			team = scoreboard.getTeam(packet.getName());
		}

		if (packet.getAction() == 0 || packet.getAction() == 2) {
			team.setDisplayName(packet.getDisplayName());
			team.setPrefix(packet.getPrefix());
			team.setSuffix(packet.getSuffix());
			team.setColor(Formatting.byId(packet.getColor()));
			team.unpackFriendlyFlags(packet.getFlags());
			AbstractTeam.Visibility visibility = AbstractTeam.Visibility.byKey(packet.getNameTagVisibility());
			if (visibility != null) {
				team.setNameTagVisibility(visibility);
			}
		}

		if (packet.getAction() == 0 || packet.getAction() == 3) {
			for (String string : packet.getMembers()) {
				scoreboard.addMemberToTeam(string, packet.getName());
			}
		}

		if (packet.getAction() == 4) {
			for (String string : packet.getMembers()) {
				scoreboard.removeMemberFromTeam(string, team);
			}
		}

		if (packet.getAction() == 1) {
			scoreboard.removeTeam(team);
		}
	}

	@Override
	public void handleParticle(ParticleS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		if (packet.getCount() == 0) {
			double d = packet.getVelocityScale() * packet.getVelocityX();
			double e = packet.getVelocityScale() * packet.getVelocityY();
			double f = packet.getVelocityScale() * packet.getVelocityZ();

			try {
				this.world.addParticle(packet.getType(), packet.getIgnoreDistance(), packet.getX(), packet.getY(), packet.getZ(), d, e, f, packet.getParameters());
			} catch (Throwable throwable) {
				LOGGER.warn("Could not spawn particle effect " + packet.getType());
			}
		} else {
			for (int i = 0; i < packet.getCount(); i++) {
				double g = this.random.nextGaussian() * packet.getVelocityX();
				double h = this.random.nextGaussian() * packet.getVelocityY();
				double j = this.random.nextGaussian() * packet.getVelocityZ();
				double k = this.random.nextGaussian() * packet.getVelocityScale();
				double l = this.random.nextGaussian() * packet.getVelocityScale();
				double m = this.random.nextGaussian() * packet.getVelocityScale();

				try {
					this.world
						.addParticle(packet.getType(), packet.getIgnoreDistance(), packet.getX() + g, packet.getY() + h, packet.getZ() + j, k, l, m, packet.getParameters());
				} catch (Throwable throwable2) {
					LOGGER.warn("Could not spawn particle effect " + packet.getType());
					return;
				}
			}
		}
	}

	@Override
	public void handleEntityAttributes(EntityAttributesS2CPacket packet) {
		PacketUtils.ensureOnSameThread(packet, this, this.minecraft);
		Entity entity = this.world.getEntity(packet.getEntityId());
		if (entity != null) {
			if (!(entity instanceof LivingEntity)) {
				throw new IllegalStateException("Server tried to update attributes of a non-living entity (actually: " + entity + ")");
			}

			AbstractEntityAttributeContainer abstractEntityAttributeContainer = ((LivingEntity)entity).getAttributes();

			for (EntityAttributesS2CPacket.Entry entry : packet.getEntries()) {
				EntityAttributeInstance entityAttributeInstance = abstractEntityAttributeContainer.get(entry.getId());
				if (entityAttributeInstance == null) {
					entityAttributeInstance = abstractEntityAttributeContainer.register(
						new RangedEntityAttribute(null, entry.getId(), 0.0, Double.MIN_NORMAL, Double.MAX_VALUE)
					);
				}

				entityAttributeInstance.setBase(entry.getBaseValue());
				entityAttributeInstance.clearModifiers();

				for (AttributeModifier attributeModifier : entry.getModifiers()) {
					entityAttributeInstance.addModifier(attributeModifier);
				}
			}
		}
	}

	public Connection getConnection() {
		return this.connection;
	}

	public Collection<PlayerInfo> getOnlinePlayers() {
		return this.onlinePlayers.values();
	}

	public PlayerInfo getOnlinePlayer(UUID uuid) {
		return this.onlinePlayers.get(uuid);
	}

	public PlayerInfo getOnlinePlayer(String name) {
		for (PlayerInfo playerInfo : this.onlinePlayers.values()) {
			if (playerInfo.getProfile().getName().equals(name)) {
				return playerInfo;
			}
		}

		return null;
	}

	public GameProfile getProfile() {
		return this.profile;
	}
}

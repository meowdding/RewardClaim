package net.minecraft.client.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class FrustumData {
	public float[][] frustum = new float[6][4];
	public float[] projectionMatrix = new float[16];
	public float[] modelMatrix = new float[16];
	public float[] clipMatrix = new float[16];

	private double discriminant(float[] side, double x, double y, double z) {
		return side[0] * x + side[1] * y + side[2] * z + side[3];
	}

	public boolean contains(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
		for (int i = 0; i < 6; i++) {
			float[] fs = this.frustum[i];
			if (!(this.discriminant(fs, minX, minY, minZ) > 0.0)
				&& !(this.discriminant(fs, maxX, minY, minZ) > 0.0)
				&& !(this.discriminant(fs, minX, maxY, minZ) > 0.0)
				&& !(this.discriminant(fs, maxX, maxY, minZ) > 0.0)
				&& !(this.discriminant(fs, minX, minY, maxZ) > 0.0)
				&& !(this.discriminant(fs, maxX, minY, maxZ) > 0.0)
				&& !(this.discriminant(fs, minX, maxY, maxZ) > 0.0)
				&& !(this.discriminant(fs, maxX, maxY, maxZ) > 0.0)) {
				return false;
			}
		}

		return true;
	}
}

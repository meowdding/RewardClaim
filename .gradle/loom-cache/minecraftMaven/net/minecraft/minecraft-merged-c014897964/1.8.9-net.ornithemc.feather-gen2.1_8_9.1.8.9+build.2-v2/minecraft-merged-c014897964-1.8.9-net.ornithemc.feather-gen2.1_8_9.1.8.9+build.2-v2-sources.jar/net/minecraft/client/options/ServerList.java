package net.minecraft.client.options;

import com.google.common.collect.Lists;
import java.io.File;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtList;
import net.ornithemc.feather.constants.NbtTypes;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Environment(EnvType.CLIENT)
public class ServerList {
	private static final Logger LOGGER = LogManager.getLogger();
	private final Minecraft minecraft;
	private final List<ServerListEntry> entries = Lists.newArrayList();

	public ServerList(Minecraft minecraft) {
		this.minecraft = minecraft;
		this.load();
	}

	public void load() {
		try {
			this.entries.clear();
			NbtCompound nbtCompound = NbtIo.read(new File(this.minecraft.gameDir, "servers.dat"));
			if (nbtCompound == null) {
				return;
			}

			NbtList nbtList = nbtCompound.getList("servers", NbtTypes.COMPOUND);

			for (int i = 0; i < nbtList.size(); i++) {
				this.entries.add(ServerListEntry.fromNbt(nbtList.getCompound(i)));
			}
		} catch (Exception exception) {
			LOGGER.error("Couldn't load server list", exception);
		}
	}

	public void save() {
		try {
			NbtList nbtList = new NbtList();

			for (ServerListEntry serverListEntry : this.entries) {
				nbtList.addElement(serverListEntry.toNbt());
			}

			NbtCompound nbtCompound = new NbtCompound();
			nbtCompound.put("servers", nbtList);
			NbtIo.writeSafely(nbtCompound, new File(this.minecraft.gameDir, "servers.dat"));
		} catch (Exception exception) {
			LOGGER.error("Couldn't save server list", exception);
		}
	}

	public ServerListEntry get(int index) {
		return this.entries.get(index);
	}

	public void remove(int index) {
		this.entries.remove(index);
	}

	public void add(ServerListEntry entry) {
		this.entries.add(entry);
	}

	public int size() {
		return this.entries.size();
	}

	public void swap(int index1, int index2) {
		ServerListEntry serverListEntry = this.get(index1);
		this.entries.set(index1, this.get(index2));
		this.entries.set(index2, serverListEntry);
		this.save();
	}

	public void set(int index, ServerListEntry entry) {
		this.entries.set(index, entry);
	}

	/**
	 * Update the given server entry in the {@code servers.dat} file.
	 */
	public static void update(ServerListEntry entry) {
		ServerList serverList = new ServerList(Minecraft.getInstance());
		serverList.load();

		for (int i = 0; i < serverList.size(); i++) {
			ServerListEntry serverListEntry = serverList.get(i);
			if (serverListEntry.name.equals(entry.name) && serverListEntry.ip.equals(entry.ip)) {
				serverList.set(i, entry);
				break;
			}
		}

		serverList.save();
	}
}

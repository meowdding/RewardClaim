package net.minecraft.client.gui.screen.game.inventory;

import io.netty.buffer.Unpooled;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.entity.living.player.PlayerInventory;
import net.minecraft.inventory.menu.TraderMenu;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.c2s.play.CustomPayloadC2SPacket;
import net.minecraft.resource.Identifier;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import net.minecraft.world.village.trade.TradeOffer;
import net.minecraft.world.village.trade.TradeOffers;
import net.minecraft.world.village.trade.Trader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Environment(EnvType.CLIENT)
public class VillagerScreen extends InventoryMenuScreen {
	private static final Logger LOGGER = LogManager.getLogger();
	private static final Identifier MENU_LOCATION = new Identifier("textures/gui/container/villager.png");
	private Trader trader;
	private VillagerScreen.PaginationButton buttonForward;
	private VillagerScreen.PaginationButton buttonBack;
	private int currentPage;
	private Text name;

	public VillagerScreen(PlayerInventory playerInventory, Trader trader, World world) {
		super(new TraderMenu(playerInventory, trader, world));
		this.trader = trader;
		this.name = trader.getDisplayName();
	}

	@Override
	public void init() {
		super.init();
		int i = (this.width - this.backgroundWidth) / 2;
		int j = (this.height - this.backgroundHeight) / 2;
		this.buttons.add(this.buttonForward = new VillagerScreen.PaginationButton(1, i + 120 + 27, j + 24 - 1, true));
		this.buttons.add(this.buttonBack = new VillagerScreen.PaginationButton(2, i + 36 - 19, j + 24 - 1, false));
		this.buttonForward.active = false;
		this.buttonBack.active = false;
	}

	@Override
	protected void renderLabels(int mouseX, int mouseY) {
		String string = this.name.getString();
		this.textRenderer.draw(string, this.backgroundWidth / 2 - this.textRenderer.getWidth(string) / 2, 6, 4210752);
		this.textRenderer.draw(I18n.translate("container.inventory"), 8, this.backgroundHeight - 96 + 2, 4210752);
	}

	@Override
	public void tick() {
		super.tick();
		TradeOffers tradeOffers = this.trader.getOffers(this.minecraft.player);
		if (tradeOffers != null) {
			this.buttonForward.active = this.currentPage < tradeOffers.size() - 1;
			this.buttonBack.active = this.currentPage > 0;
		}
	}

	@Override
	protected void buttonClicked(ButtonWidget button) {
		boolean bl = false;
		if (button == this.buttonForward) {
			this.currentPage++;
			TradeOffers tradeOffers = this.trader.getOffers(this.minecraft.player);
			if (tradeOffers != null && this.currentPage >= tradeOffers.size()) {
				this.currentPage = tradeOffers.size() - 1;
			}

			bl = true;
		} else if (button == this.buttonBack) {
			this.currentPage--;
			if (this.currentPage < 0) {
				this.currentPage = 0;
			}

			bl = true;
		}

		if (bl) {
			((TraderMenu)this.menu).setRecipeIndex(this.currentPage);
			PacketByteBuf packetByteBuf = new PacketByteBuf(Unpooled.buffer());
			packetByteBuf.writeInt(this.currentPage);
			this.minecraft.getNetworkHandler().sendPacket(new CustomPayloadC2SPacket("MC|TrSel", packetByteBuf));
		}
	}

	@Override
	protected void renderMenuBackground(float tickDelta, int mouseX, int mouseY) {
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.minecraft.getTextureManager().bind(MENU_LOCATION);
		int i = (this.width - this.backgroundWidth) / 2;
		int j = (this.height - this.backgroundHeight) / 2;
		this.drawTexture(i, j, 0, 0, this.backgroundWidth, this.backgroundHeight);
		TradeOffers tradeOffers = this.trader.getOffers(this.minecraft.player);
		if (tradeOffers != null && !tradeOffers.isEmpty()) {
			int k = this.currentPage;
			if (k < 0 || k >= tradeOffers.size()) {
				return;
			}

			TradeOffer tradeOffer = tradeOffers.get(k);
			if (tradeOffer.isDisabled()) {
				this.minecraft.getTextureManager().bind(MENU_LOCATION);
				GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
				GlStateManager.disableLighting();
				this.drawTexture(this.x + 83, this.y + 21, 212, 0, 28, 21);
				this.drawTexture(this.x + 83, this.y + 51, 212, 0, 28, 21);
			}
		}
	}

	@Override
	public void render(int mouseX, int mouseY, float tickDelta) {
		super.render(mouseX, mouseY, tickDelta);
		TradeOffers tradeOffers = this.trader.getOffers(this.minecraft.player);
		if (tradeOffers != null && !tradeOffers.isEmpty()) {
			int i = (this.width - this.backgroundWidth) / 2;
			int j = (this.height - this.backgroundHeight) / 2;
			int k = this.currentPage;
			TradeOffer tradeOffer = tradeOffers.get(k);
			ItemStack itemStack = tradeOffer.getPrimaryPayment();
			ItemStack itemStack2 = tradeOffer.getSecondaryPayment();
			ItemStack itemStack3 = tradeOffer.getResult();
			GlStateManager.pushMatrix();
			Lighting.turnOnGui();
			GlStateManager.disableLighting();
			GlStateManager.enableRescaleNormal();
			GlStateManager.enableColorMaterial();
			GlStateManager.enableLighting();
			this.itemRenderer.zOffset = 100.0F;
			this.itemRenderer.renderGuiItem(itemStack, i + 36, j + 24);
			this.itemRenderer.renderGuiItemDecoration(this.textRenderer, itemStack, i + 36, j + 24);
			if (itemStack2 != null) {
				this.itemRenderer.renderGuiItem(itemStack2, i + 62, j + 24);
				this.itemRenderer.renderGuiItemDecoration(this.textRenderer, itemStack2, i + 62, j + 24);
			}

			this.itemRenderer.renderGuiItem(itemStack3, i + 120, j + 24);
			this.itemRenderer.renderGuiItemDecoration(this.textRenderer, itemStack3, i + 120, j + 24);
			this.itemRenderer.zOffset = 0.0F;
			GlStateManager.disableLighting();
			if (this.isMouseInRegion(36, 24, 16, 16, mouseX, mouseY) && itemStack != null) {
				this.renderTooltip(itemStack, mouseX, mouseY);
			} else if (itemStack2 != null && this.isMouseInRegion(62, 24, 16, 16, mouseX, mouseY) && itemStack2 != null) {
				this.renderTooltip(itemStack2, mouseX, mouseY);
			} else if (itemStack3 != null && this.isMouseInRegion(120, 24, 16, 16, mouseX, mouseY) && itemStack3 != null) {
				this.renderTooltip(itemStack3, mouseX, mouseY);
			} else if (tradeOffer.isDisabled() && (this.isMouseInRegion(83, 21, 28, 21, mouseX, mouseY) || this.isMouseInRegion(83, 51, 28, 21, mouseX, mouseY))) {
				this.renderTooltip(I18n.translate("merchant.deprecated"), mouseX, mouseY);
			}

			GlStateManager.popMatrix();
			GlStateManager.enableLighting();
			GlStateManager.enableDepthTest();
			Lighting.turnOn();
		}
	}

	public Trader getTrader() {
		return this.trader;
	}

	@Environment(EnvType.CLIENT)
	static class PaginationButton extends ButtonWidget {
		private final boolean hasHeight;

		public PaginationButton(int id, int x, int y, boolean hasHeight) {
			super(id, x, y, 12, 19, "");
			this.hasHeight = hasHeight;
		}

		@Override
		public void render(Minecraft minecraft, int mouseX, int mouseY) {
			if (this.visible) {
				minecraft.getTextureManager().bind(VillagerScreen.MENU_LOCATION);
				GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
				boolean bl = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;
				int i = 0;
				int j = 176;
				if (!this.active) {
					j += this.width * 2;
				} else if (bl) {
					j += this.width;
				}

				if (!this.hasHeight) {
					i += this.height;
				}

				this.drawTexture(this.x, this.y, j, i, this.width, this.height);
			}
		}
	}
}

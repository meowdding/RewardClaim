package net.minecraft.block;

public class SingleRedSandstoneSlabBlock extends RedSandstoneSlabBlock {
	@Override
	public boolean isDouble() {
		return false;
	}
}

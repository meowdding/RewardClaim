package net.minecraft.client.gui.screen.menu;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.OptionButtonWidget;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.render.texture.TextureAtlasSprite;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import net.minecraft.resource.Identifier;
import net.minecraft.stat.PlayerStats;
import net.minecraft.stat.achievement.AchievementStat;
import net.minecraft.stat.achievement.Achievements;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.input.Mouse;

@Environment(EnvType.CLIENT)
public class AchievementsScreen extends Screen implements StatsListener {
	private static final int MIN_COLUMN = Achievements.minColumn * 24 - 112;
	private static final int MIN_ROW = Achievements.minRow * 24 - 112;
	private static final int MAX_COLUMN = Achievements.maxColumn * 24 - 77;
	private static final int MAX_ROW = Achievements.maxRow * 24 - 77;
	private static final Identifier BACKGROUND_LOCATION = new Identifier("textures/gui/achievement/achievement_background.png");
	protected Screen parent;
	protected int iconWidth = 256;
	protected int iconHeight = 202;
	protected int prevMouseX;
	protected int prevMouseY;
	protected float scale = 1.0F;
	protected double mouseX;
	protected double mouseY;
	protected double scaledMouseDx;
	protected double scaledMouseDy;
	protected double scrollX;
	protected double scrollY;
	private int scroll;
	private PlayerStats stats;
	private boolean downloading = true;

	public AchievementsScreen(Screen parent, PlayerStats statHandler) {
		this.parent = parent;
		this.stats = statHandler;
		int i = 141;
		int j = 141;
		this.mouseX = this.scaledMouseDx = this.scrollX = Achievements.OPEN_INVENTORY.column * 24 - i / 2 - 12;
		this.mouseY = this.scaledMouseDy = this.scrollY = Achievements.OPEN_INVENTORY.row * 24 - j / 2;
	}

	@Override
	public void init() {
		this.minecraft.getNetworkHandler().sendPacket(new ClientStatusC2SPacket(ClientStatusC2SPacket.Status.REQUEST_STATS));
		this.buttons.clear();
		this.buttons.add(new OptionButtonWidget(1, this.width / 2 + 24, this.height / 2 + 74, 80, 20, I18n.translate("gui.done")));
	}

	@Override
	protected void buttonClicked(ButtonWidget button) {
		if (!this.downloading) {
			if (button.id == 1) {
				this.minecraft.openScreen(this.parent);
			}
		}
	}

	@Override
	protected void keyPressed(char chr, int key) {
		if (key == this.minecraft.options.inventoryKey.getKeyCode()) {
			this.minecraft.openScreen(null);
			this.minecraft.lockMouse();
		} else {
			super.keyPressed(chr, key);
		}
	}

	@Override
	public void render(int mouseX, int mouseY, float tickDelta) {
		if (this.downloading) {
			this.renderBackground();
			this.drawCenteredString(this.textRenderer, I18n.translate("multiplayer.downloadingStats"), this.width / 2, this.height / 2, 16777215);
			this.drawCenteredString(
				this.textRenderer,
				PROGRESS_BAR_STAGES[(int)(Minecraft.getTime() / 150L % PROGRESS_BAR_STAGES.length)],
				this.width / 2,
				this.height / 2 + this.textRenderer.fontHeight * 2,
				16777215
			);
		} else {
			if (Mouse.isButtonDown(0)) {
				int i = (this.width - this.iconWidth) / 2;
				int j = (this.height - this.iconHeight) / 2;
				int k = i + 8;
				int l = j + 17;
				if ((this.scroll == 0 || this.scroll == 1) && mouseX >= k && mouseX < k + 224 && mouseY >= l && mouseY < l + 155) {
					if (this.scroll == 0) {
						this.scroll = 1;
					} else {
						this.scaledMouseDx = this.scaledMouseDx - (mouseX - this.prevMouseX) * this.scale;
						this.scaledMouseDy = this.scaledMouseDy - (mouseY - this.prevMouseY) * this.scale;
						this.scrollX = this.mouseX = this.scaledMouseDx;
						this.scrollY = this.mouseY = this.scaledMouseDy;
					}

					this.prevMouseX = mouseX;
					this.prevMouseY = mouseY;
				}
			} else {
				this.scroll = 0;
			}

			int i = Mouse.getDWheel();
			float f = this.scale;
			if (i < 0) {
				this.scale += 0.25F;
			} else if (i > 0) {
				this.scale -= 0.25F;
			}

			this.scale = MathHelper.clamp(this.scale, 1.0F, 2.0F);
			if (this.scale != f) {
				float g = f - this.scale;
				float h = f * this.iconWidth;
				float m = f * this.iconHeight;
				float n = this.scale * this.iconWidth;
				float o = this.scale * this.iconHeight;
				this.scaledMouseDx -= (n - h) * 0.5F;
				this.scaledMouseDy -= (o - m) * 0.5F;
				this.scrollX = this.mouseX = this.scaledMouseDx;
				this.scrollY = this.mouseY = this.scaledMouseDy;
			}

			if (this.scrollX < MIN_COLUMN) {
				this.scrollX = MIN_COLUMN;
			}

			if (this.scrollY < MIN_ROW) {
				this.scrollY = MIN_ROW;
			}

			if (this.scrollX >= MAX_COLUMN) {
				this.scrollX = MAX_COLUMN - 1;
			}

			if (this.scrollY >= MAX_ROW) {
				this.scrollY = MAX_ROW - 1;
			}

			this.renderBackground();
			this.renderIcons(mouseX, mouseY, tickDelta);
			GlStateManager.disableLighting();
			GlStateManager.disableDepthTest();
			this.setTitle();
			GlStateManager.enableLighting();
			GlStateManager.enableDepthTest();
		}
	}

	@Override
	public void onStatsReady() {
		if (this.downloading) {
			this.downloading = false;
		}
	}

	@Override
	public void tick() {
		if (!this.downloading) {
			this.mouseX = this.scaledMouseDx;
			this.mouseY = this.scaledMouseDy;
			double d = this.scrollX - this.scaledMouseDx;
			double e = this.scrollY - this.scaledMouseDy;
			if (d * d + e * e < 4.0) {
				this.scaledMouseDx += d;
				this.scaledMouseDy += e;
			} else {
				this.scaledMouseDx += d * 0.85;
				this.scaledMouseDy += e * 0.85;
			}
		}
	}

	protected void setTitle() {
		int i = (this.width - this.iconWidth) / 2;
		int j = (this.height - this.iconHeight) / 2;
		this.textRenderer.draw(I18n.translate("gui.achievements"), i + 15, j + 5, 4210752);
	}

	protected void renderIcons(int mouseX, int mouseY, float tickdelta) {
		int i = MathHelper.floor(this.mouseX + (this.scaledMouseDx - this.mouseX) * tickdelta);
		int j = MathHelper.floor(this.mouseY + (this.scaledMouseDy - this.mouseY) * tickdelta);
		if (i < MIN_COLUMN) {
			i = MIN_COLUMN;
		}

		if (j < MIN_ROW) {
			j = MIN_ROW;
		}

		if (i >= MAX_COLUMN) {
			i = MAX_COLUMN - 1;
		}

		if (j >= MAX_ROW) {
			j = MAX_ROW - 1;
		}

		int k = (this.width - this.iconWidth) / 2;
		int l = (this.height - this.iconHeight) / 2;
		int m = k + 16;
		int n = l + 17;
		this.drawOffset = 0.0F;
		GlStateManager.depthFunc(518);
		GlStateManager.pushMatrix();
		GlStateManager.translatef(m, n, -200.0F);
		GlStateManager.scalef(1.0F / this.scale, 1.0F / this.scale, 0.0F);
		GlStateManager.enableTexture();
		GlStateManager.disableLighting();
		GlStateManager.enableRescaleNormal();
		GlStateManager.enableColorMaterial();
		int o = i + 288 >> 4;
		int p = j + 288 >> 4;
		int q = (i + 288) % 16;
		int r = (j + 288) % 16;
		int s = 4;
		int t = 8;
		int u = 10;
		int v = 22;
		int w = 37;
		Random random = new Random();
		float f = 16.0F / this.scale;
		float g = 16.0F / this.scale;

		for (int x = 0; x * f - r < 155.0F; x++) {
			float h = 0.6F - (p + x) / 25.0F * 0.3F;
			GlStateManager.color4f(h, h, h, 1.0F);

			for (int y = 0; y * g - q < 224.0F; y++) {
				random.setSeed(this.minecraft.getSession().getUuid().hashCode() + o + y + (p + x) * 16);
				int z = random.nextInt(1 + p + x) + (p + x) / 2;
				TextureAtlasSprite textureAtlasSprite = this.getParticleIcon(Blocks.SAND);
				if (z > 37 || p + x == 35) {
					Block block = Blocks.BEDROCK;
					textureAtlasSprite = this.getParticleIcon(block);
				} else if (z == 22) {
					if (random.nextInt(2) == 0) {
						textureAtlasSprite = this.getParticleIcon(Blocks.DIAMOND_ORE);
					} else {
						textureAtlasSprite = this.getParticleIcon(Blocks.REDSTONE_ORE);
					}
				} else if (z == 10) {
					textureAtlasSprite = this.getParticleIcon(Blocks.IRON_ORE);
				} else if (z == 8) {
					textureAtlasSprite = this.getParticleIcon(Blocks.COAL_ORE);
				} else if (z > 4) {
					textureAtlasSprite = this.getParticleIcon(Blocks.STONE);
				} else if (z > 0) {
					textureAtlasSprite = this.getParticleIcon(Blocks.DIRT);
				}

				this.minecraft.getTextureManager().bind(TextureAtlas.BLOCKS_LOCATION);
				this.drawSprite(y * 16 - q, x * 16 - r, textureAtlasSprite, 16, 16);
			}
		}

		GlStateManager.enableDepthTest();
		GlStateManager.depthFunc(515);
		this.minecraft.getTextureManager().bind(BACKGROUND_LOCATION);

		for (int x = 0; x < Achievements.ALL.size(); x++) {
			AchievementStat achievementStat = Achievements.ALL.get(x);
			if (achievementStat.parent != null) {
				int y = achievementStat.column * 24 - i + 11;
				int z = achievementStat.row * 24 - j + 11;
				int aa = achievementStat.parent.column * 24 - i + 11;
				int ab = achievementStat.parent.row * 24 - j + 11;
				boolean bl = this.stats.hasAchievement(achievementStat);
				boolean bl2 = this.stats.hasParentAchievement(achievementStat);
				int ac = this.stats.get(achievementStat);
				if (ac <= 4) {
					int ad = -16777216;
					if (bl) {
						ad = -6250336;
					} else if (bl2) {
						ad = -16711936;
					}

					this.drawHorizontalLine(y, aa, z, ad);
					this.drawVerticalLine(aa, z, ab, ad);
					if (y > aa) {
						this.drawTexture(y - 11 - 7, z - 5, 114, 234, 7, 11);
					} else if (y < aa) {
						this.drawTexture(y + 11, z - 5, 107, 234, 7, 11);
					} else if (z > ab) {
						this.drawTexture(y - 5, z - 11 - 7, 96, 234, 11, 7);
					} else if (z < ab) {
						this.drawTexture(y - 5, z + 11, 96, 241, 11, 7);
					}
				}
			}
		}

		AchievementStat achievementStat2 = null;
		float h = (mouseX - m) * this.scale;
		float ae = (mouseY - n) * this.scale;
		Lighting.turnOnGui();
		GlStateManager.disableLighting();
		GlStateManager.enableRescaleNormal();
		GlStateManager.enableColorMaterial();

		for (int z = 0; z < Achievements.ALL.size(); z++) {
			AchievementStat achievementStat3 = Achievements.ALL.get(z);
			int ab = achievementStat3.column * 24 - i;
			int af = achievementStat3.row * 24 - j;
			if (ab >= -24 && af >= -24 && ab <= 224.0F * this.scale && af <= 155.0F * this.scale) {
				int ag = this.stats.get(achievementStat3);
				if (this.stats.hasAchievement(achievementStat3)) {
					float ah = 0.75F;
					GlStateManager.color4f(ah, ah, ah, 1.0F);
				} else if (this.stats.hasParentAchievement(achievementStat3)) {
					float ah = 1.0F;
					GlStateManager.color4f(ah, ah, ah, 1.0F);
				} else if (ag < 3) {
					float ah = 0.3F;
					GlStateManager.color4f(ah, ah, ah, 1.0F);
				} else if (ag == 3) {
					float ah = 0.2F;
					GlStateManager.color4f(ah, ah, ah, 1.0F);
				} else {
					if (ag != 4) {
						continue;
					}

					float ah = 0.1F;
					GlStateManager.color4f(ah, ah, ah, 1.0F);
				}

				this.minecraft.getTextureManager().bind(BACKGROUND_LOCATION);
				if (achievementStat3.isChallenge()) {
					this.drawTexture(ab - 2, af - 2, 26, 202, 26, 26);
				} else {
					this.drawTexture(ab - 2, af - 2, 0, 202, 26, 26);
				}

				if (!this.stats.hasParentAchievement(achievementStat3)) {
					float ah = 0.1F;
					GlStateManager.color4f(ah, ah, ah, 1.0F);
					this.itemRenderer.setUseCustomDisplayColor(false);
				}

				GlStateManager.enableLighting();
				GlStateManager.enableCull();
				this.itemRenderer.renderGuiItem(achievementStat3.icon, ab + 3, af + 3);
				GlStateManager.blendFunc(770, 771);
				GlStateManager.disableLighting();
				if (!this.stats.hasParentAchievement(achievementStat3)) {
					this.itemRenderer.setUseCustomDisplayColor(true);
				}

				GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
				if (h >= ab && h <= ab + 22 && ae >= af && ae <= af + 22) {
					achievementStat2 = achievementStat3;
				}
			}
		}

		GlStateManager.disableDepthTest();
		GlStateManager.enableBlend();
		GlStateManager.popMatrix();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.minecraft.getTextureManager().bind(BACKGROUND_LOCATION);
		this.drawTexture(k, l, 0, 0, this.iconWidth, this.iconHeight);
		this.drawOffset = 0.0F;
		GlStateManager.depthFunc(515);
		GlStateManager.disableDepthTest();
		GlStateManager.enableTexture();
		super.render(mouseX, mouseY, tickdelta);
		if (achievementStat2 != null) {
			String string = achievementStat2.getDecoratedName().getString();
			String string2 = achievementStat2.getDescription();
			int ab = mouseX + 12;
			int af = mouseY - 4;
			int ag = this.stats.get(achievementStat2);
			if (this.stats.hasParentAchievement(achievementStat2)) {
				int ac = Math.max(this.textRenderer.getWidth(string), 120);
				int ad = this.textRenderer.splitAndGetHeight(string2, ac);
				if (this.stats.hasAchievement(achievementStat2)) {
					ad += 12;
				}

				this.fillGradient(ab - 3, af - 3, ab + ac + 3, af + ad + 3 + 12, -1073741824, -1073741824);
				this.textRenderer.splitAndDraw(string2, ab, af + 12, ac, -6250336);
				if (this.stats.hasAchievement(achievementStat2)) {
					this.textRenderer.drawWithShadow(I18n.translate("achievement.taken"), ab, af + ad + 4, -7302913);
				}
			} else if (ag == 3) {
				string = I18n.translate("achievement.unknown");
				int ac = Math.max(this.textRenderer.getWidth(string), 120);
				String string3 = new TranslatableText("achievement.requires", achievementStat2.parent.getDecoratedName()).getString();
				int ai = this.textRenderer.splitAndGetHeight(string3, ac);
				this.fillGradient(ab - 3, af - 3, ab + ac + 3, af + ai + 12 + 3, -1073741824, -1073741824);
				this.textRenderer.splitAndDraw(string3, ab, af + 12, ac, -9416624);
			} else if (ag < 3) {
				int ac = Math.max(this.textRenderer.getWidth(string), 120);
				String string3 = new TranslatableText("achievement.requires", achievementStat2.parent.getDecoratedName()).getString();
				int ai = this.textRenderer.splitAndGetHeight(string3, ac);
				this.fillGradient(ab - 3, af - 3, ab + ac + 3, af + ai + 12 + 3, -1073741824, -1073741824);
				this.textRenderer.splitAndDraw(string3, ab, af + 12, ac, -9416624);
			} else {
				string = null;
			}

			if (string != null) {
				this.textRenderer
					.drawWithShadow(
						string,
						ab,
						af,
						this.stats.hasParentAchievement(achievementStat2) ? (achievementStat2.isChallenge() ? -128 : -1) : (achievementStat2.isChallenge() ? -8355776 : -8355712)
					);
			}
		}

		GlStateManager.enableDepthTest();
		GlStateManager.enableLighting();
		Lighting.turnOff();
	}

	private TextureAtlasSprite getParticleIcon(Block block) {
		return Minecraft.getInstance().getBlockRenderDispatcher().getModelShaper().getParticleIcon(block.defaultState());
	}

	@Override
	public boolean shouldPauseGame() {
		return !this.downloading;
	}
}

package net.minecraft.client.render;

import com.google.common.collect.Lists;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.text.Formatting;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public class TextRenderUtils {
	public static String prepareText(String text, boolean allowFormatting) {
		return !allowFormatting && !Minecraft.getInstance().options.chatColors ? Formatting.strip(text) : text;
	}

	public static List<Text> wrapText(Text text, int width, TextRenderer textRenderer, boolean stripLeadingSpaces, boolean allowFormatting) {
		int i = 0;
		Text text2 = new LiteralText("");
		List<Text> list = Lists.newArrayList();
		List<Text> list2 = Lists.newArrayList(text);

		for (int j = 0; j < list2.size(); j++) {
			Text text3 = list2.get(j);
			String string = text3.getContent();
			boolean bl = false;
			if (string.contains("\n")) {
				int k = string.indexOf(10);
				String string2 = string.substring(k + 1);
				string = string.substring(0, k + 1);
				LiteralText literalText = new LiteralText(string2);
				literalText.setStyle(text3.getStyle().deepCopy());
				list2.add(j + 1, literalText);
				bl = true;
			}

			String string3 = prepareText(text3.getStyle().asString() + string, allowFormatting);
			String string2 = string3.endsWith("\n") ? string3.substring(0, string3.length() - 1) : string3;
			int l = textRenderer.getWidth(string2);
			LiteralText literalText2 = new LiteralText(string2);
			literalText2.setStyle(text3.getStyle().deepCopy());
			if (i + l > width) {
				String string4 = textRenderer.trim(string3, width - i, false);
				String string5 = string4.length() < string3.length() ? string3.substring(string4.length()) : null;
				if (string5 != null && string5.length() > 0) {
					int m = string4.lastIndexOf(" ");
					if (m >= 0 && textRenderer.getWidth(string3.substring(0, m)) > 0) {
						string4 = string3.substring(0, m);
						if (stripLeadingSpaces) {
							m++;
						}

						string5 = string3.substring(m);
					} else if (i > 0 && !string3.contains(" ")) {
						string4 = "";
						string5 = string3;
					}

					LiteralText literalText3 = new LiteralText(string5);
					literalText3.setStyle(text3.getStyle().deepCopy());
					list2.add(j + 1, literalText3);
				}

				string3 = string4;
				l = textRenderer.getWidth(string3);
				literalText2 = new LiteralText(string3);
				literalText2.setStyle(text3.getStyle().deepCopy());
				bl = true;
			}

			if (i + l <= width) {
				i += l;
				text2.append(literalText2);
			} else {
				bl = true;
			}

			if (bl) {
				list.add(text2);
				i = 0;
				text2 = new LiteralText("");
			}
		}

		list.add(text2);
		return list;
	}
}

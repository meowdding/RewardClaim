package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.block.BlockRenderDispatcher;
import net.minecraft.client.render.model.block.BakedModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

@Environment(EnvType.CLIENT)
public class FallingBlockRenderer extends EntityRenderer<FallingBlockEntity> {
	public FallingBlockRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
		this.shadowSize = 0.5F;
	}

	public void render(FallingBlockEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		if (entity.getBlock() != null) {
			this.bindTexture(TextureAtlas.BLOCKS_LOCATION);
			BlockState blockState = entity.getBlock();
			Block block = blockState.getBlock();
			BlockPos blockPos = new BlockPos(entity);
			World world = entity.getWorld();
			if (blockState != world.getBlockState(blockPos) && block.getRenderType() != -1) {
				if (block.getRenderType() == 3) {
					GlStateManager.pushMatrix();
					GlStateManager.translatef((float)dx, (float)dy, (float)dz);
					GlStateManager.disableLighting();
					Tesselator tesselator = Tesselator.getInstance();
					BufferBuilder bufferBuilder = tesselator.getBuffer();
					bufferBuilder.begin(7, DefaultVertexFormat.BLOCK);
					int i = blockPos.getX();
					int j = blockPos.getY();
					int k = blockPos.getZ();
					bufferBuilder.offset(-i - 0.5F, -j, -k - 0.5F);
					BlockRenderDispatcher blockRenderDispatcher = Minecraft.getInstance().getBlockRenderDispatcher();
					BakedModel bakedModel = blockRenderDispatcher.getModel(blockState, world, null);
					blockRenderDispatcher.getModelRenderer().render(world, bakedModel, blockState, blockPos, bufferBuilder, false);
					bufferBuilder.offset(0.0, 0.0, 0.0);
					tesselator.end();
					GlStateManager.enableLighting();
					GlStateManager.popMatrix();
					super.render(entity, dx, dy, dz, yaw, tickDelta);
				}
			}
		}
	}

	protected Identifier getTextureLocation(FallingBlockEntity entity) {
		return TextureAtlas.BLOCKS_LOCATION;
	}
}

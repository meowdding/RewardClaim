package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.block.BlockRenderDispatcher;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class TntMinecartRenderer extends MinecartRenderer<TntMinecartEntity> {
	public TntMinecartRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
	}

	protected void renderBlockInMinecart(TntMinecartEntity minecart, float tickDelta, BlockState state) {
		int i = minecart.getFuseTicks();
		if (i > -1 && i - tickDelta + 1.0F < 10.0F) {
			float f = 1.0F - (i - tickDelta + 1.0F) / 10.0F;
			f = MathHelper.clamp(f, 0.0F, 1.0F);
			f *= f;
			f *= f;
			float g = 1.0F + f * 0.3F;
			GlStateManager.scalef(g, g, g);
		}

		super.renderBlockInMinecart(minecart, tickDelta, state);
		if (i > -1 && i / 5 % 2 == 0) {
			BlockRenderDispatcher blockRenderDispatcher = Minecraft.getInstance().getBlockRenderDispatcher();
			GlStateManager.disableTexture();
			GlStateManager.disableLighting();
			GlStateManager.enableBlend();
			GlStateManager.blendFunc(770, 772);
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, (1.0F - (i - tickDelta + 1.0F) / 100.0F) * 0.8F);
			GlStateManager.pushMatrix();
			blockRenderDispatcher.renderAsItem(Blocks.TNT.defaultState(), 1.0F);
			GlStateManager.popMatrix();
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			GlStateManager.disableBlend();
			GlStateManager.enableLighting();
			GlStateManager.enableTexture();
		}
	}
}

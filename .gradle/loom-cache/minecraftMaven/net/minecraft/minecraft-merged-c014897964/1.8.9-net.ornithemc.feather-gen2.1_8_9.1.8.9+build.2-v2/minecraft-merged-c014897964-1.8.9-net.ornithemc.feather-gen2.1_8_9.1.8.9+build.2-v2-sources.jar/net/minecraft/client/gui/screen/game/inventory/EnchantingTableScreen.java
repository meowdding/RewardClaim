package net.minecraft.client.gui.screen.game.inventory;

import com.google.common.collect.Lists;
import java.util.List;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.TextRenderer;
import net.minecraft.client.render.Window;
import net.minecraft.client.render.model.block.entity.EnchantingTableBookModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.living.player.PlayerInventory;
import net.minecraft.inventory.menu.EnchantingTableMenu;
import net.minecraft.item.ItemStack;
import net.minecraft.resource.Identifier;
import net.minecraft.text.Formatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Nameable;
import net.minecraft.world.World;
import org.lwjgl.util.glu.Project;

@Environment(EnvType.CLIENT)
public class EnchantingTableScreen extends InventoryMenuScreen {
	private static final Identifier MENU_LOCATION = new Identifier("textures/gui/container/enchanting_table.png");
	private static final Identifier BOOK_LOCATION = new Identifier("textures/entity/enchanting_table_book.png");
	private static final EnchantingTableBookModel BOOK_MODEL = new EnchantingTableBookModel();
	private final PlayerInventory playerInventory;
	private Random random = new Random();
	private EnchantingTableMenu enchantingMenu;
	public int ticksOpen;
	public float nextPageAngle;
	public float pageAngle;
	public float approximatePageAngle;
	public float pageRotationSpeed;
	public float nextTurningSpeed;
	public float turningSpeed;
	ItemStack itemToEnchant;
	private final Nameable inventory;

	public EnchantingTableScreen(PlayerInventory playerInventory, World world, Nameable inventory) {
		super(new EnchantingTableMenu(playerInventory, world));
		this.playerInventory = playerInventory;
		this.enchantingMenu = (EnchantingTableMenu)this.menu;
		this.inventory = inventory;
	}

	@Override
	protected void renderLabels(int mouseX, int mouseY) {
		this.textRenderer.draw(this.inventory.getDisplayName().getString(), 12, 5, 4210752);
		this.textRenderer.draw(this.playerInventory.getDisplayName().getString(), 8, this.backgroundHeight - 96 + 2, 4210752);
	}

	@Override
	public void tick() {
		super.tick();
		this.tickEnchantingScreen();
	}

	@Override
	protected void mouseClicked(int mouseX, int mouseY, int button) {
		super.mouseClicked(mouseX, mouseY, button);
		int i = (this.width - this.backgroundWidth) / 2;
		int j = (this.height - this.backgroundHeight) / 2;

		for (int k = 0; k < 3; k++) {
			int l = mouseX - (i + 60);
			int m = mouseY - (j + 14 + 19 * k);
			if (l >= 0 && m >= 0 && l < 108 && m < 19 && this.enchantingMenu.onButtonClick(this.minecraft.player, k)) {
				this.minecraft.interactionManager.clickMenuButton(this.enchantingMenu.networkId, k);
			}
		}
	}

	@Override
	protected void renderMenuBackground(float tickDelta, int mouseX, int mouseY) {
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.minecraft.getTextureManager().bind(MENU_LOCATION);
		int i = (this.width - this.backgroundWidth) / 2;
		int j = (this.height - this.backgroundHeight) / 2;
		this.drawTexture(i, j, 0, 0, this.backgroundWidth, this.backgroundHeight);
		GlStateManager.pushMatrix();
		GlStateManager.matrixMode(5889);
		GlStateManager.pushMatrix();
		GlStateManager.loadIdentity();
		Window window = new Window(this.minecraft);
		GlStateManager.viewport(
			(window.getWidth() - 320) / 2 * window.getScale(), (window.getHeight() - 240) / 2 * window.getScale(), 320 * window.getScale(), 240 * window.getScale()
		);
		GlStateManager.translatef(-0.34F, 0.23F, 0.0F);
		Project.gluPerspective(90.0F, 1.3333334F, 9.0F, 80.0F);
		float f = 1.0F;
		GlStateManager.matrixMode(5888);
		GlStateManager.loadIdentity();
		Lighting.turnOn();
		GlStateManager.translatef(0.0F, 3.3F, -16.0F);
		GlStateManager.scalef(f, f, f);
		float g = 5.0F;
		GlStateManager.scalef(g, g, g);
		GlStateManager.rotatef(180.0F, 0.0F, 0.0F, 1.0F);
		this.minecraft.getTextureManager().bind(BOOK_LOCATION);
		GlStateManager.rotatef(20.0F, 1.0F, 0.0F, 0.0F);
		float h = this.turningSpeed + (this.nextTurningSpeed - this.turningSpeed) * tickDelta;
		GlStateManager.translatef((1.0F - h) * 0.2F, (1.0F - h) * 0.1F, (1.0F - h) * 0.25F);
		GlStateManager.rotatef(-(1.0F - h) * 90.0F - 90.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(180.0F, 1.0F, 0.0F, 0.0F);
		float k = this.pageAngle + (this.nextPageAngle - this.pageAngle) * tickDelta + 0.25F;
		float l = this.pageAngle + (this.nextPageAngle - this.pageAngle) * tickDelta + 0.75F;
		k = (k - MathHelper.fastFloor(k)) * 1.6F - 0.3F;
		l = (l - MathHelper.fastFloor(l)) * 1.6F - 0.3F;
		if (k < 0.0F) {
			k = 0.0F;
		}

		if (l < 0.0F) {
			l = 0.0F;
		}

		if (k > 1.0F) {
			k = 1.0F;
		}

		if (l > 1.0F) {
			l = 1.0F;
		}

		GlStateManager.enableRescaleNormal();
		BOOK_MODEL.render(null, 0.0F, k, l, h, 0.0F, 0.0625F);
		GlStateManager.disableRescaleNormal();
		Lighting.turnOff();
		GlStateManager.matrixMode(5889);
		GlStateManager.viewport(0, 0, this.minecraft.width, this.minecraft.height);
		GlStateManager.popMatrix();
		GlStateManager.matrixMode(5888);
		GlStateManager.popMatrix();
		Lighting.turnOff();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		EnchantingPhrases.getInstance().setSeed(this.enchantingMenu.seed);
		int m = this.enchantingMenu.getLapisCount();

		for (int n = 0; n < 3; n++) {
			int o = i + 60;
			int p = o + 20;
			int q = 86;
			String string = EnchantingPhrases.getInstance().getRandomPhrase();
			this.drawOffset = 0.0F;
			this.minecraft.getTextureManager().bind(MENU_LOCATION);
			int r = this.enchantingMenu.enchantingCosts[n];
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			if (r == 0) {
				this.drawTexture(o, j + 14 + 19 * n, 0, 185, 108, 19);
			} else {
				String string2 = "" + r;
				TextRenderer textRenderer = this.minecraft.enchantingPhraseRenderer;
				int s = 6839882;
				if ((m < n + 1 || this.minecraft.player.xpLevel < r) && !this.minecraft.player.abilities.creativeMode) {
					this.drawTexture(o, j + 14 + 19 * n, 0, 185, 108, 19);
					this.drawTexture(o + 1, j + 15 + 19 * n, 16 * n, 239, 16, 16);
					textRenderer.splitAndDraw(string, p, j + 16 + 19 * n, q, (s & 16711422) >> 1);
					s = 4226832;
				} else {
					int t = mouseX - (i + 60);
					int u = mouseY - (j + 14 + 19 * n);
					if (t >= 0 && u >= 0 && t < 108 && u < 19) {
						this.drawTexture(o, j + 14 + 19 * n, 0, 204, 108, 19);
						s = 16777088;
					} else {
						this.drawTexture(o, j + 14 + 19 * n, 0, 166, 108, 19);
					}

					this.drawTexture(o + 1, j + 15 + 19 * n, 16 * n, 223, 16, 16);
					textRenderer.splitAndDraw(string, p, j + 16 + 19 * n, q, s);
					s = 8453920;
				}

				textRenderer = this.minecraft.textRenderer;
				textRenderer.drawWithShadow(string2, p + 86 - textRenderer.getWidth(string2), j + 16 + 19 * n + 7, s);
			}
		}
	}

	@Override
	public void render(int mouseX, int mouseY, float tickDelta) {
		super.render(mouseX, mouseY, tickDelta);
		boolean bl = this.minecraft.player.abilities.creativeMode;
		int i = this.enchantingMenu.getLapisCount();

		for (int j = 0; j < 3; j++) {
			int k = this.enchantingMenu.enchantingCosts[j];
			int l = this.enchantingMenu.enchantmentClues[j];
			int m = j + 1;
			if (this.isMouseInRegion(60, 14 + 19 * j, 108, 17, mouseX, mouseY) && k > 0 && l >= 0) {
				List<String> list = Lists.newArrayList();
				if (l >= 0 && Enchantment.byId(l & 0xFF) != null) {
					String string = Enchantment.byId(l & 0xFF).getName((l & 0xFF00) >> 8);
					list.add(Formatting.WHITE.toString() + Formatting.ITALIC.toString() + I18n.translate("container.enchant.clue", string));
				}

				if (!bl) {
					if (l >= 0) {
						list.add("");
					}

					if (this.minecraft.player.xpLevel < k) {
						list.add(Formatting.RED.toString() + "Level Requirement: " + this.enchantingMenu.enchantingCosts[j]);
					} else {
						String string = "";
						if (m == 1) {
							string = I18n.translate("container.enchant.lapis.one");
						} else {
							string = I18n.translate("container.enchant.lapis.many", m);
						}

						if (i >= m) {
							list.add(Formatting.GRAY.toString() + "" + string);
						} else {
							list.add(Formatting.RED.toString() + "" + string);
						}

						if (m == 1) {
							string = I18n.translate("container.enchant.level.one");
						} else {
							string = I18n.translate("container.enchant.level.many", m);
						}

						list.add(Formatting.GRAY.toString() + "" + string);
					}
				}

				this.renderTooltip(list, mouseX, mouseY);
				break;
			}
		}
	}

	public void tickEnchantingScreen() {
		ItemStack itemStack = this.menu.getSlot(0).getItem();
		if (!ItemStack.matches(itemStack, this.itemToEnchant)) {
			this.itemToEnchant = itemStack;

			do {
				this.approximatePageAngle = this.approximatePageAngle + (this.random.nextInt(4) - this.random.nextInt(4));
			} while (this.nextPageAngle <= this.approximatePageAngle + 1.0F && this.nextPageAngle >= this.approximatePageAngle - 1.0F);
		}

		this.ticksOpen++;
		this.pageAngle = this.nextPageAngle;
		this.turningSpeed = this.nextTurningSpeed;
		boolean bl = false;

		for (int i = 0; i < 3; i++) {
			if (this.enchantingMenu.enchantingCosts[i] != 0) {
				bl = true;
			}
		}

		if (bl) {
			this.nextTurningSpeed += 0.2F;
		} else {
			this.nextTurningSpeed -= 0.2F;
		}

		this.nextTurningSpeed = MathHelper.clamp(this.nextTurningSpeed, 0.0F, 1.0F);
		float f = (this.approximatePageAngle - this.nextPageAngle) * 0.4F;
		float g = 0.2F;
		f = MathHelper.clamp(f, -g, g);
		this.pageRotationSpeed = this.pageRotationSpeed + (f - this.pageRotationSpeed) * 0.9F;
		this.nextPageAngle = this.nextPageAngle + this.pageRotationSpeed;
	}
}

package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.entity.WitchRenderer;
import net.minecraft.client.render.model.entity.WitchModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.resource.model.ModelTransformations;
import net.minecraft.entity.living.mob.monster.WitchEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

@Environment(EnvType.CLIENT)
public class WitchItemInHandLayer implements EntityRenderLayer<WitchEntity> {
	private final WitchRenderer parent;

	public WitchItemInHandLayer(WitchRenderer parent) {
		this.parent = parent;
	}

	public void render(WitchEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale) {
		ItemStack itemStack = entity.getDisplayItemInHand();
		if (itemStack != null) {
			GlStateManager.color3f(1.0F, 1.0F, 1.0F);
			GlStateManager.pushMatrix();
			if (this.parent.getModel().isBaby) {
				GlStateManager.translatef(0.0F, 0.625F, 0.0F);
				GlStateManager.rotatef(-20.0F, -1.0F, 0.0F, 0.0F);
				float f = 0.5F;
				GlStateManager.scalef(f, f, f);
			}

			((WitchModel)this.parent.getModel()).nose.transform(0.0625F);
			GlStateManager.translatef(-0.0625F, 0.53125F, 0.21875F);
			Item item = itemStack.getItem();
			Minecraft minecraft = Minecraft.getInstance();
			if (item instanceof BlockItem && minecraft.getBlockRenderDispatcher().isItem3d(Block.byItem(item), itemStack.getMetadata())) {
				GlStateManager.translatef(0.0F, 0.0625F, -0.25F);
				GlStateManager.rotatef(30.0F, 1.0F, 0.0F, 0.0F);
				GlStateManager.rotatef(-5.0F, 0.0F, 1.0F, 0.0F);
				float g = 0.375F;
				GlStateManager.scalef(g, -g, g);
			} else if (item == Items.BOW) {
				GlStateManager.translatef(0.0F, 0.125F, -0.125F);
				GlStateManager.rotatef(-45.0F, 0.0F, 1.0F, 0.0F);
				float g = 0.625F;
				GlStateManager.scalef(g, -g, g);
				GlStateManager.rotatef(-100.0F, 1.0F, 0.0F, 0.0F);
				GlStateManager.rotatef(-20.0F, 0.0F, 1.0F, 0.0F);
			} else if (item.isWielded()) {
				if (item.isFlippedWhenWielded()) {
					GlStateManager.rotatef(180.0F, 0.0F, 0.0F, 1.0F);
					GlStateManager.translatef(0.0F, -0.0625F, 0.0F);
				}

				this.parent.glTranslate();
				GlStateManager.translatef(0.0625F, -0.125F, 0.0F);
				float g = 0.625F;
				GlStateManager.scalef(g, -g, g);
				GlStateManager.rotatef(0.0F, 1.0F, 0.0F, 0.0F);
				GlStateManager.rotatef(0.0F, 0.0F, 1.0F, 0.0F);
			} else {
				GlStateManager.translatef(0.1875F, 0.1875F, 0.0F);
				float g = 0.875F;
				GlStateManager.scalef(g, g, g);
				GlStateManager.rotatef(-20.0F, 0.0F, 0.0F, 1.0F);
				GlStateManager.rotatef(-60.0F, 1.0F, 0.0F, 0.0F);
				GlStateManager.rotatef(-30.0F, 0.0F, 0.0F, 1.0F);
			}

			GlStateManager.rotatef(-15.0F, 1.0F, 0.0F, 0.0F);
			GlStateManager.rotatef(40.0F, 0.0F, 0.0F, 1.0F);
			minecraft.getItemInHandRenderer().render(entity, itemStack, ModelTransformations.Type.THIRD_PERSON);
			GlStateManager.popMatrix();
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.PigRenderer;
import net.minecraft.client.render.model.entity.PigModel;
import net.minecraft.entity.living.mob.passive.animal.PigEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class PigSaddleLayer implements EntityRenderLayer<PigEntity> {
	private static final Identifier PIG_SADDLE_LOCATION = new Identifier("textures/entity/pig/pig_saddle.png");
	private final PigRenderer parent;
	private final PigModel model = new PigModel(0.5F);

	public PigSaddleLayer(PigRenderer parent) {
		this.parent = parent;
	}

	public void render(PigEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale) {
		if (entity.isSaddled()) {
			this.parent.bindTexture(PIG_SADDLE_LOCATION);
			this.model.copyPropertiesFrom(this.parent.getModel());
			this.model.render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

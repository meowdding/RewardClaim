package net.minecraft.client.gui.overlay;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.property.Property;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.client.FrameTimeLogger;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiElement;
import net.minecraft.client.render.TextRenderer;
import net.minecraft.client.render.Window;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.server.entity.living.player.ServerPlayerEntity;
import net.minecraft.text.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.HitResult;
import net.minecraft.world.LightType;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.gen.WorldGeneratorType;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;

@Environment(EnvType.CLIENT)
public class DebugOverlay extends GuiElement {
	private final Minecraft minecraft;
	private final TextRenderer textRenderer;

	public DebugOverlay(Minecraft minecraft) {
		this.minecraft = minecraft;
		this.textRenderer = minecraft.textRenderer;
	}

	public void render(Window window) {
		this.minecraft.profiler.push("debug");
		GlStateManager.pushMatrix();
		this.drawGameInfo();
		this.drawSystemInfo(window);
		GlStateManager.popMatrix();
		if (this.minecraft.options.debugTpsEnabled) {
			this.drawTpsChart();
		}

		this.minecraft.profiler.pop();
	}

	private boolean showReducedInfo() {
		return this.minecraft.player.hasReducedDebugInfo() || this.minecraft.options.reducedDebugInfo;
	}

	protected void drawGameInfo() {
		List<String> list = this.getGameInfo();

		for (int i = 0; i < list.size(); i++) {
			String string = list.get(i);
			if (!Strings.isNullOrEmpty(string)) {
				int j = this.textRenderer.fontHeight;
				int k = this.textRenderer.getWidth(string);
				int l = 2;
				int m = 2 + j * i;
				fill(1, m - 1, 2 + k + 1, m + j - 1, -1873784752);
				this.textRenderer.draw(string, 2, m, 14737632);
			}
		}
	}

	protected void drawSystemInfo(Window window) {
		List<String> list = this.getSystemInfo();

		for (int i = 0; i < list.size(); i++) {
			String string = list.get(i);
			if (!Strings.isNullOrEmpty(string)) {
				int j = this.textRenderer.fontHeight;
				int k = this.textRenderer.getWidth(string);
				int l = window.getWidth() - 2 - k;
				int m = 2 + j * i;
				fill(l - 1, m - 1, l + k + 1, m + j - 1, -1873784752);
				this.textRenderer.draw(string, l, m, 14737632);
			}
		}
	}

	protected List<String> getGameInfo() {
		BlockPos blockPos = new BlockPos(this.minecraft.getCamera().x, this.minecraft.getCamera().getShape().minY, this.minecraft.getCamera().z);
		if (this.showReducedInfo()) {
			return Lists.newArrayList(
				"Minecraft 1.8.9 (" + this.minecraft.getGameVersion() + "/" + ClientBrandRetriever.getClientModName() + ")",
				this.minecraft.fpsDebugInfo,
				this.minecraft.worldRenderer.getChunkDebugInfo(),
				this.minecraft.worldRenderer.getEntityDebugInfo(),
				"P: " + this.minecraft.particleManager.getDebugInfo() + ". T: " + this.minecraft.world.getDebugInfo(),
				this.minecraft.world.getChunkSourceDebugInfo(),
				"",
				String.format("Chunk-relative: %d %d %d", blockPos.getX() & 15, blockPos.getY() & 15, blockPos.getZ() & 15)
			);
		}

		Entity entity = this.minecraft.getCamera();
		Direction direction = entity.getHorizontalFacing();
		String string = "Invalid";
		switch (direction) {
			case NORTH:
				string = "Towards negative Z";
				break;
			case SOUTH:
				string = "Towards positive Z";
				break;
			case WEST:
				string = "Towards negative X";
				break;
			case EAST:
				string = "Towards positive X";
		}

		List<String> list = Lists.newArrayList(
			"Minecraft 1.8.9 (" + this.minecraft.getGameVersion() + "/" + ClientBrandRetriever.getClientModName() + ")",
			this.minecraft.fpsDebugInfo,
			this.minecraft.worldRenderer.getChunkDebugInfo(),
			this.minecraft.worldRenderer.getEntityDebugInfo(),
			"P: " + this.minecraft.particleManager.getDebugInfo() + ". T: " + this.minecraft.world.getDebugInfo(),
			this.minecraft.world.getChunkSourceDebugInfo(),
			"",
			String.format("XYZ: %.3f / %.5f / %.3f", this.minecraft.getCamera().x, this.minecraft.getCamera().getShape().minY, this.minecraft.getCamera().z),
			String.format("Block: %d %d %d", blockPos.getX(), blockPos.getY(), blockPos.getZ()),
			String.format(
				"Chunk: %d %d %d in %d %d %d",
				blockPos.getX() & 15,
				blockPos.getY() & 15,
				blockPos.getZ() & 15,
				blockPos.getX() >> 4,
				blockPos.getY() >> 4,
				blockPos.getZ() >> 4
			),
			String.format("Facing: %s (%s) (%.1f / %.1f)", direction, string, MathHelper.wrapDegrees(entity.yaw), MathHelper.wrapDegrees(entity.pitch))
		);
		if (this.minecraft.world != null && this.minecraft.world.isChunkLoaded(blockPos)) {
			WorldChunk worldChunk = this.minecraft.world.getChunk(blockPos);
			list.add("Biome: " + worldChunk.getBiome(blockPos, this.minecraft.world.getBiomeSource()).name);
			list.add(
				"Light: "
					+ worldChunk.getLight(blockPos, 0)
					+ " ("
					+ worldChunk.getLight(LightType.SKY, blockPos)
					+ " sky, "
					+ worldChunk.getLight(LightType.BLOCK, blockPos)
					+ " block)"
			);
			LocalDifficulty localDifficulty = this.minecraft.world.getLocalDifficulty(blockPos);
			if (this.minecraft.isIntegratedServerRunning() && this.minecraft.getServer() != null) {
				ServerPlayerEntity serverPlayerEntity = this.minecraft.getServer().getPlayerManager().get(this.minecraft.player.getUuid());
				if (serverPlayerEntity != null) {
					localDifficulty = serverPlayerEntity.world.getLocalDifficulty(new BlockPos(serverPlayerEntity));
				}
			}

			list.add(String.format("Local Difficulty: %.2f (Day %d)", localDifficulty.get(), this.minecraft.world.getTimeOfDay() / 24000L));
		}

		if (this.minecraft.gameRenderer != null && this.minecraft.gameRenderer.hasShader()) {
			list.add("Shader: " + this.minecraft.gameRenderer.getShader().getName());
		}

		if (this.minecraft.crosshairTarget != null && this.minecraft.crosshairTarget.type == HitResult.Type.BLOCK && this.minecraft.crosshairTarget.getPos() != null) {
			BlockPos blockPos2 = this.minecraft.crosshairTarget.getPos();
			list.add(String.format("Looking at: %d %d %d", blockPos2.getX(), blockPos2.getY(), blockPos2.getZ()));
		}

		return list;
	}

	protected List<String> getSystemInfo() {
		long l = Runtime.getRuntime().maxMemory();
		long m = Runtime.getRuntime().totalMemory();
		long n = Runtime.getRuntime().freeMemory();
		long o = m - n;
		List<String> list = Lists.newArrayList(
			String.format("Java: %s %dbit", System.getProperty("java.version"), this.minecraft.is64Bit() ? 64 : 32),
			String.format("Mem: % 2d%% %03d/%03dMB", o * 100L / l, convertBytesToMegaBytes(o), convertBytesToMegaBytes(l)),
			String.format("Allocated: % 2d%% %03dMB", m * 100L / l, convertBytesToMegaBytes(m)),
			"",
			String.format("CPU: %s", GLX.getCpuInfo()),
			"",
			String.format("Display: %dx%d (%s)", Display.getWidth(), Display.getHeight(), GL11.glGetString(7936)),
			GL11.glGetString(7937),
			GL11.glGetString(7938)
		);
		if (this.showReducedInfo()) {
			return list;
		}

		if (this.minecraft.crosshairTarget != null && this.minecraft.crosshairTarget.type == HitResult.Type.BLOCK && this.minecraft.crosshairTarget.getPos() != null) {
			BlockPos blockPos = this.minecraft.crosshairTarget.getPos();
			BlockState blockState = this.minecraft.world.getBlockState(blockPos);
			if (this.minecraft.world.getGeneratorType() != WorldGeneratorType.DEBUG_ALL_BLOCK_STATES) {
				blockState = blockState.getBlock().resolveVirtualProperties(blockState, this.minecraft.world, blockPos);
			}

			list.add("");
			list.add(String.valueOf(Block.REGISTRY.getKey(blockState.getBlock())));

			for (Entry<Property, Comparable> entry : blockState.values().entrySet()) {
				String string = entry.getValue().toString();
				if (entry.getValue() == Boolean.TRUE) {
					string = Formatting.GREEN + string;
				} else if (entry.getValue() == Boolean.FALSE) {
					string = Formatting.RED + string;
				}

				list.add(entry.getKey().getName() + ": " + string);
			}
		}

		return list;
	}

	private void drawTpsChart() {
		GlStateManager.disableDepthTest();
		FrameTimeLogger frameTimeLogger = this.minecraft.getFrameTimeLogger();
		int i = frameTimeLogger.getStartTime();
		int j = frameTimeLogger.getEndTime();
		long[] ls = frameTimeLogger.getFrameTimes();
		Window window = new Window(this.minecraft);
		int k = i;
		int l = 0;
		fill(0, window.getHeight() - 60, 240, window.getHeight(), -1873784752);

		while (k != j) {
			int m = frameTimeLogger.scaleFrameTime(ls[k], 30);
			int n = this.getFrameColor(MathHelper.clamp(m, 0, 60), 0, 30, 60);
			this.drawVerticalLine(l, window.getHeight(), window.getHeight() - m, n);
			l++;
			k = frameTimeLogger.wrapIndex(k + 1);
		}

		fill(1, window.getHeight() - 30 + 1, 14, window.getHeight() - 30 + 10, -1873784752);
		this.textRenderer.draw("60", 2, window.getHeight() - 30 + 2, 14737632);
		this.drawHorizontalLine(0, 239, window.getHeight() - 30, -1);
		fill(1, window.getHeight() - 60 + 1, 14, window.getHeight() - 60 + 10, -1873784752);
		this.textRenderer.draw("30", 2, window.getHeight() - 60 + 2, 14737632);
		this.drawHorizontalLine(0, 239, window.getHeight() - 60, -1);
		this.drawHorizontalLine(0, 239, window.getHeight() - 1, -1);
		this.drawVerticalLine(0, window.getHeight() - 60, window.getHeight(), -1);
		this.drawVerticalLine(239, window.getHeight() - 60, window.getHeight(), -1);
		if (this.minecraft.options.fpsLimit <= 120) {
			this.drawHorizontalLine(0, 239, window.getHeight() - 60 + this.minecraft.options.fpsLimit / 2, -16711681);
		}

		GlStateManager.enableDepthTest();
	}

	private int getFrameColor(int frameTime, int min, int mid, int max) {
		return frameTime < mid ? this.lerpColor(-16711936, -256, (float)frameTime / mid) : this.lerpColor(-256, -65536, (float)(frameTime - mid) / (max - mid));
	}

	private int lerpColor(int from, int to, float delta) {
		int i = from >> 24 & 0xFF;
		int j = from >> 16 & 0xFF;
		int k = from >> 8 & 0xFF;
		int l = from & 0xFF;
		int m = to >> 24 & 0xFF;
		int n = to >> 16 & 0xFF;
		int o = to >> 8 & 0xFF;
		int p = to & 0xFF;
		int q = MathHelper.clamp((int)(i + (m - i) * delta), 0, 255);
		int r = MathHelper.clamp((int)(j + (n - j) * delta), 0, 255);
		int s = MathHelper.clamp((int)(k + (o - k) * delta), 0, 255);
		int t = MathHelper.clamp((int)(l + (p - l) * delta), 0, 255);
		return q << 24 | r << 16 | s << 8 | t;
	}

	private static long convertBytesToMegaBytes(long bytes) {
		return bytes / 1024L / 1024L;
	}
}

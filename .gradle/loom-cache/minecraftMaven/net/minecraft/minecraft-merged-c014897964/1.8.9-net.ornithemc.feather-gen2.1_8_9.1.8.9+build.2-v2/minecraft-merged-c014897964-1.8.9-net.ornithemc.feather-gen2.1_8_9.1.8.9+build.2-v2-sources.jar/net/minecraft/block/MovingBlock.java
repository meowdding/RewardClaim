package net.minecraft.block;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MovingBlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.DirectionProperty;
import net.minecraft.block.state.property.EnumProperty;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.HitResult;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

public class MovingBlock extends BlockWithBlockEntity {
	public static final DirectionProperty FACING = PistonHeadBlock.FACING;
	public static final EnumProperty<PistonHeadBlock.Type> TYPE = PistonHeadBlock.TYPE;

	public MovingBlock() {
		super(Material.PISTON);
		this.setDefaultState(this.stateDefinition.any().set(FACING, Direction.NORTH).set(TYPE, PistonHeadBlock.Type.DEFAULT));
		this.setStrength(-1.0F);
	}

	@Override
	public BlockEntity createBlockEntity(World world, int metadata) {
		return null;
	}

	public static BlockEntity createMovingBlockEntity(BlockState movedState, Direction facing, boolean extending, boolean source) {
		return new MovingBlockEntity(movedState, facing, extending, source);
	}

	@Override
	public void onRemoved(World world, BlockPos pos, BlockState state) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof MovingBlockEntity) {
			((MovingBlockEntity)blockEntity).finish();
		} else {
			super.onRemoved(world, pos, state);
		}
	}

	@Override
	public boolean canBePlaced(World world, BlockPos pos) {
		return false;
	}

	@Override
	public boolean canBePlaced(World world, BlockPos pos, Direction face) {
		return false;
	}

	@Override
	public void onBroken(World world, BlockPos pos, BlockState state) {
		BlockPos blockPos = pos.offset(state.get(FACING).getOpposite());
		BlockState blockState = world.getBlockState(blockPos);
		if (blockState.getBlock() instanceof PistonBaseBlock && blockState.get(PistonBaseBlock.EXTENDED)) {
			world.removeBlock(blockPos);
		}
	}

	@Override
	public boolean isSolidRender() {
		return false;
	}

	@Override
	public boolean isCube() {
		return false;
	}

	@Override
	public boolean use(World world, BlockPos pos, BlockState state, PlayerEntity player, Direction face, float faceX, float faceY, float faceZ) {
		if (!world.isClient && world.getBlockEntity(pos) == null) {
			world.removeBlock(pos);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public Item getDropItem(BlockState state, Random random, int fortuneLevel) {
		return null;
	}

	@Override
	public void dropItems(World world, BlockPos pos, BlockState state, float luck, int fortuneLevel) {
		if (!world.isClient) {
			MovingBlockEntity movingBlockEntity = this.getMovingBlockEntity(world, pos);
			if (movingBlockEntity != null) {
				BlockState blockState = movingBlockEntity.getMovedState();
				blockState.getBlock().dropItems(world, pos, blockState, 0);
			}
		}
	}

	@Override
	public HitResult rayTrace(World world, BlockPos pos, Vec3d start, Vec3d end) {
		return null;
	}

	@Override
	public void neighborChanged(World world, BlockPos pos, BlockState state, Block neighborBlock) {
		if (!world.isClient) {
			world.getBlockEntity(pos);
		}
	}

	@Override
	public Box getCollisionShape(World world, BlockPos pos, BlockState state) {
		MovingBlockEntity movingBlockEntity = this.getMovingBlockEntity(world, pos);
		if (movingBlockEntity == null) {
			return null;
		}

		float f = movingBlockEntity.getProgress(0.0F);
		if (movingBlockEntity.isExtending()) {
			f = 1.0F - f;
		}

		return this.getCollisionShape(world, pos, movingBlockEntity.getMovedState(), f, movingBlockEntity.getFacing());
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		MovingBlockEntity movingBlockEntity = this.getMovingBlockEntity(world, pos);
		if (movingBlockEntity != null) {
			BlockState blockState = movingBlockEntity.getMovedState();
			Block block = blockState.getBlock();
			if (block == this || block.getMaterial() == Material.AIR) {
				return;
			}

			float f = movingBlockEntity.getProgress(0.0F);
			if (movingBlockEntity.isExtending()) {
				f = 1.0F - f;
			}

			block.updateShape(world, pos);
			if (block == Blocks.PISTON || block == Blocks.STICKY_PISTON) {
				f = 0.0F;
			}

			Direction direction = movingBlockEntity.getFacing();
			this.minX = block.getMinX() - direction.getOffsetX() * f;
			this.minY = block.getMinY() - direction.getOffsetY() * f;
			this.minZ = block.getMinZ() - direction.getOffsetZ() * f;
			this.maxX = block.getMaxX() - direction.getOffsetX() * f;
			this.maxY = block.getMaxY() - direction.getOffsetY() * f;
			this.maxZ = block.getMaxZ() - direction.getOffsetZ() * f;
		}
	}

	public Box getCollisionShape(World world, BlockPos pos, BlockState movedState, float progress, Direction facing) {
		if (movedState.getBlock() != this && movedState.getBlock().getMaterial() != Material.AIR) {
			Box box = movedState.getBlock().getCollisionShape(world, pos, movedState);
			if (box == null) {
				return null;
			}

			double d = box.minX;
			double e = box.minY;
			double f = box.minZ;
			double g = box.maxX;
			double h = box.maxY;
			double i = box.maxZ;
			if (facing.getOffsetX() < 0) {
				d -= facing.getOffsetX() * progress;
			} else {
				g -= facing.getOffsetX() * progress;
			}

			if (facing.getOffsetY() < 0) {
				e -= facing.getOffsetY() * progress;
			} else {
				h -= facing.getOffsetY() * progress;
			}

			if (facing.getOffsetZ() < 0) {
				f -= facing.getOffsetZ() * progress;
			} else {
				i -= facing.getOffsetZ() * progress;
			}

			return new Box(d, e, f, g, h, i);
		} else {
			return null;
		}
	}

	private MovingBlockEntity getMovingBlockEntity(WorldView world, BlockPos pos) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		return blockEntity instanceof MovingBlockEntity ? (MovingBlockEntity)blockEntity : null;
	}

	@Environment(EnvType.CLIENT)
	@Override
	public Item getPickItem(World world, BlockPos pos) {
		return null;
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		return this.defaultState()
			.set(FACING, PistonHeadBlock.getFacing(metadata))
			.set(TYPE, (metadata & 8) > 0 ? PistonHeadBlock.Type.STICKY : PistonHeadBlock.Type.DEFAULT);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		int i = 0;
		i |= state.get(FACING).getId();
		if (state.get(TYPE) == PistonHeadBlock.Type.STICKY) {
			i |= 8;
		}

		return i;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, FACING, TYPE);
	}
}

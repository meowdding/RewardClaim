package net.minecraft.client.render.entity;

import com.google.common.collect.Lists;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.layer.ArmorLayer;
import net.minecraft.client.render.entity.layer.EntityRenderLayer;
import net.minecraft.client.render.entity.layer.ItemInHandLayer;
import net.minecraft.client.render.entity.layer.WornSkullLayer;
import net.minecraft.client.render.entity.layer.ZombieVillagerArmorLayer;
import net.minecraft.client.render.model.entity.HumanoidModel;
import net.minecraft.client.render.model.entity.ZombieModel;
import net.minecraft.client.render.model.entity.ZombieVillagerModel;
import net.minecraft.entity.living.mob.monster.ZombieEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class ZombieRenderer extends UndeadMobRenderer<ZombieEntity> {
	private static final Identifier ZOMBIE_LOCATION = new Identifier("textures/entity/zombie/zombie.png");
	private static final Identifier ZOMBIE_VILLAGER_LOCATION = new Identifier("textures/entity/zombie/zombie_villager.png");
	private final HumanoidModel zombieModel;
	private final ZombieVillagerModel zombieVillagerModel;
	private final List<EntityRenderLayer<ZombieEntity>> zombieLayers;
	private final List<EntityRenderLayer<ZombieEntity>> zombieVillagerLayers;

	public ZombieRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher, new ZombieModel(), 0.5F, 1.0F);
		EntityRenderLayer entityRenderLayer = this.layers.get(0);
		this.zombieModel = this.humanoidModel;
		this.zombieVillagerModel = new ZombieVillagerModel();
		this.addLayer(new ItemInHandLayer(this));
		ArmorLayer armorLayer = new ArmorLayer(this) {
			@Override
			protected void hideAll() {
				this.innerModel = new ZombieModel(0.5F, true);
				this.outerModel = new ZombieModel(1.0F, true);
			}
		};
		this.addLayer(armorLayer);
		this.zombieVillagerLayers = Lists.newArrayList(this.layers);
		if (entityRenderLayer instanceof WornSkullLayer) {
			this.removeLayer(entityRenderLayer);
			this.addLayer(new WornSkullLayer(this.zombieVillagerModel.head));
		}

		this.removeLayer(armorLayer);
		this.addLayer(new ZombieVillagerArmorLayer(this));
		this.zombieLayers = Lists.newArrayList(this.layers);
	}

	public void render(ZombieEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		this.updateModels(entity);
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(ZombieEntity entity) {
		return entity.isVillager() ? ZOMBIE_VILLAGER_LOCATION : ZOMBIE_LOCATION;
	}

	private void updateModels(ZombieEntity zombie) {
		if (zombie.isVillager()) {
			this.model = this.zombieVillagerModel;
			this.layers = this.zombieLayers;
		} else {
			this.model = this.zombieModel;
			this.layers = this.zombieVillagerLayers;
		}

		this.humanoidModel = (HumanoidModel)this.model;
	}

	protected void applyRotation(ZombieEntity entity, float bob, float bodyYaw, float tickDelta) {
		if (entity.isConverting()) {
			bodyYaw += (float)(Math.cos(entity.ticks * 3.25) * Math.PI * 0.25);
		}

		super.applyRotation(entity, bob, bodyYaw, tickDelta);
	}
}

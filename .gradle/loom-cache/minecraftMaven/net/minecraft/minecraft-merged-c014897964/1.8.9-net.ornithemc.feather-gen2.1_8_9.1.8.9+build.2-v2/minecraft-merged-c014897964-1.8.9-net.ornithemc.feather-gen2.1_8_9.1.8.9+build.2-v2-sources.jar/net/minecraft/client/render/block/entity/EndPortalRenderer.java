package net.minecraft.client.render.block.entity;

import java.nio.Buffer;
import java.nio.FloatBuffer;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.EndPortalBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.MemoryTracker;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class EndPortalRenderer extends BlockEntityRenderer<EndPortalBlockEntity> {
	private static final Identifier END_SKY_LOCATION = new Identifier("textures/environment/end_sky.png");
	private static final Identifier END_PORTAL_LOCATION = new Identifier("textures/entity/end_portal.png");
	private static final Random RANDOM = new Random(31100L);
	FloatBuffer buffer = MemoryTracker.createFloatBuffer(16);

	public void render(EndPortalBlockEntity blockEntity, double dx, double dy, double dz, float tickDelta, int blockMiningProgress) {
		float f = (float)this.dispatcher.cameraX;
		float g = (float)this.dispatcher.cameraY;
		float h = (float)this.dispatcher.cameraZ;
		GlStateManager.disableLighting();
		RANDOM.setSeed(31100L);
		float i = 0.75F;

		for (int j = 0; j < 16; j++) {
			GlStateManager.pushMatrix();
			float k = 16 - j;
			float l = 0.0625F;
			float m = 1.0F / (k + 1.0F);
			if (j == 0) {
				this.bindTexture(END_SKY_LOCATION);
				m = 0.1F;
				k = 65.0F;
				l = 0.125F;
				GlStateManager.enableBlend();
				GlStateManager.blendFunc(770, 771);
			}

			if (j >= 1) {
				this.bindTexture(END_PORTAL_LOCATION);
			}

			if (j == 1) {
				GlStateManager.enableBlend();
				GlStateManager.blendFunc(1, 1);
				l = 0.5F;
			}

			float n = (float)(-(dy + i));
			float o = n + (float)Camera.offset().y;
			float p = n + k + (float)Camera.offset().y;
			float q = o / p;
			q = (float)(dy + i) + q;
			GlStateManager.translatef(f, q, h);
			GlStateManager.texGenMode(GlStateManager.TexGenMode.S, 9217);
			GlStateManager.texGenMode(GlStateManager.TexGenMode.T, 9217);
			GlStateManager.texGenMode(GlStateManager.TexGenMode.R, 9217);
			GlStateManager.texGenMode(GlStateManager.TexGenMode.Q, 9216);
			GlStateManager.texGenParam(GlStateManager.TexGenMode.S, 9473, this.getBuffer(1.0F, 0.0F, 0.0F, 0.0F));
			GlStateManager.texGenParam(GlStateManager.TexGenMode.T, 9473, this.getBuffer(0.0F, 0.0F, 1.0F, 0.0F));
			GlStateManager.texGenParam(GlStateManager.TexGenMode.R, 9473, this.getBuffer(0.0F, 0.0F, 0.0F, 1.0F));
			GlStateManager.texGenParam(GlStateManager.TexGenMode.Q, 9474, this.getBuffer(0.0F, 1.0F, 0.0F, 0.0F));
			GlStateManager.enableTexGen(GlStateManager.TexGenMode.S);
			GlStateManager.enableTexGen(GlStateManager.TexGenMode.T);
			GlStateManager.enableTexGen(GlStateManager.TexGenMode.R);
			GlStateManager.enableTexGen(GlStateManager.TexGenMode.Q);
			GlStateManager.popMatrix();
			GlStateManager.matrixMode(5890);
			GlStateManager.pushMatrix();
			GlStateManager.loadIdentity();
			GlStateManager.translatef(0.0F, (float)(Minecraft.getTime() % 700000L) / 700000.0F, 0.0F);
			GlStateManager.scalef(l, l, l);
			GlStateManager.translatef(0.5F, 0.5F, 0.0F);
			GlStateManager.rotatef((j * j * 4321 + j * 9) * 2.0F, 0.0F, 0.0F, 1.0F);
			GlStateManager.translatef(-0.5F, -0.5F, 0.0F);
			GlStateManager.translatef(-f, -h, -g);
			o = n + (float)Camera.offset().y;
			GlStateManager.translatef((float)Camera.offset().x * k / o, (float)Camera.offset().z * k / o, -g);
			Tesselator tesselator = Tesselator.getInstance();
			BufferBuilder bufferBuilder = tesselator.getBuffer();
			bufferBuilder.begin(7, DefaultVertexFormat.POSITION_COLOR);
			float r = (RANDOM.nextFloat() * 0.5F + 0.1F) * m;
			float s = (RANDOM.nextFloat() * 0.5F + 0.4F) * m;
			float t = (RANDOM.nextFloat() * 0.5F + 0.5F) * m;
			if (j == 0) {
				r = s = t = 1.0F * m;
			}

			bufferBuilder.vertex(dx, dy + i, dz).color(r, s, t, 1.0F).nextVertex();
			bufferBuilder.vertex(dx, dy + i, dz + 1.0).color(r, s, t, 1.0F).nextVertex();
			bufferBuilder.vertex(dx + 1.0, dy + i, dz + 1.0).color(r, s, t, 1.0F).nextVertex();
			bufferBuilder.vertex(dx + 1.0, dy + i, dz).color(r, s, t, 1.0F).nextVertex();
			tesselator.end();
			GlStateManager.popMatrix();
			GlStateManager.matrixMode(5888);
			this.bindTexture(END_SKY_LOCATION);
		}

		GlStateManager.disableBlend();
		GlStateManager.disableTexGen(GlStateManager.TexGenMode.S);
		GlStateManager.disableTexGen(GlStateManager.TexGenMode.T);
		GlStateManager.disableTexGen(GlStateManager.TexGenMode.R);
		GlStateManager.disableTexGen(GlStateManager.TexGenMode.Q);
		GlStateManager.enableLighting();
	}

	private FloatBuffer getBuffer(float f1, float f2, float f3, float f4) {
		((Buffer)this.buffer).clear();
		this.buffer.put(f1).put(f2).put(f3).put(f4);
		((Buffer)this.buffer).flip();
		return this.buffer;
	}
}

package net.minecraft.block.state.property;

public interface StringSerializable {
	String getSerializedName();
}

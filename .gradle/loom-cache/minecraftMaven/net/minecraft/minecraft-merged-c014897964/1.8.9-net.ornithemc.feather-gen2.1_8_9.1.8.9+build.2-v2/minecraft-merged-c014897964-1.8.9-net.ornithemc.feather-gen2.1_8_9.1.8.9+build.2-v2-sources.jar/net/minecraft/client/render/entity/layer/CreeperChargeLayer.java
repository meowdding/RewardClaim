package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.CreeperRenderer;
import net.minecraft.client.render.model.entity.CreeperModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.monster.CreeperEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class CreeperChargeLayer implements EntityRenderLayer<CreeperEntity> {
	private static final Identifier CREEPER_CHARGE_LOCATION = new Identifier("textures/entity/creeper/creeper_armor.png");
	private final CreeperRenderer parent;
	private final CreeperModel model = new CreeperModel(2.0F);

	public CreeperChargeLayer(CreeperRenderer parent) {
		this.parent = parent;
	}

	public void render(
		CreeperEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale
	) {
		if (entity.isCharged()) {
			boolean bl = entity.isInvisible();
			GlStateManager.depthMask(!bl);
			this.parent.bindTexture(CREEPER_CHARGE_LOCATION);
			GlStateManager.matrixMode(5890);
			GlStateManager.loadIdentity();
			float f = entity.ticks + tickDelta;
			GlStateManager.translatef(f * 0.01F, f * 0.01F, 0.0F);
			GlStateManager.matrixMode(5888);
			GlStateManager.enableBlend();
			float g = 0.5F;
			GlStateManager.color4f(g, g, g, 1.0F);
			GlStateManager.disableLighting();
			GlStateManager.blendFunc(1, 1);
			this.model.copyPropertiesFrom(this.parent.getModel());
			this.model.render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
			GlStateManager.matrixMode(5890);
			GlStateManager.loadIdentity();
			GlStateManager.matrixMode(5888);
			GlStateManager.enableLighting();
			GlStateManager.disableBlend();
			GlStateManager.depthMask(bl);
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

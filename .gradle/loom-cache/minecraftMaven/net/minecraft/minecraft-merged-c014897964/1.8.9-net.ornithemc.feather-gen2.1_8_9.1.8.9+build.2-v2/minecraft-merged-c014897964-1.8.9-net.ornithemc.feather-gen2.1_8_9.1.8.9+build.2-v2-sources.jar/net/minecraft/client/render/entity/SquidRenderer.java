package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.model.Model;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.water.SquidEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class SquidRenderer extends MobRenderer<SquidEntity> {
	private static final Identifier SQUID_LOCATION = new Identifier("textures/entity/squid.png");

	public SquidRenderer(EntityRenderDispatcher entityRenderDispatcher, Model model, float f) {
		super(entityRenderDispatcher, model, f);
	}

	protected Identifier getTextureLocation(SquidEntity entity) {
		return SQUID_LOCATION;
	}

	protected void applyRotation(SquidEntity entity, float bob, float bodyYaw, float tickDelta) {
		float f = entity.lastBodyPitch + (entity.bodyPitch - entity.lastBodyPitch) * tickDelta;
		float g = entity.lastBodyRoll + (entity.bodyRoll - entity.lastBodyRoll) * tickDelta;
		GlStateManager.translatef(0.0F, 0.5F, 0.0F);
		GlStateManager.rotatef(180.0F - bodyYaw, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(f, 1.0F, 0.0F, 0.0F);
		GlStateManager.rotatef(g, 0.0F, 1.0F, 0.0F);
		GlStateManager.translatef(0.0F, -1.2F, 0.0F);
	}

	protected float getBob(SquidEntity entity, float tickDelta) {
		return entity.lastTentacleRotation + (entity.tentacleRotation - entity.lastTentacleRotation) * tickDelta;
	}
}

package net.minecraft.block.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.FurnaceBlock;
import net.minecraft.block.material.Material;
import net.minecraft.crafting.SmeltingManager;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.entity.living.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SidedInventory;
import net.minecraft.inventory.menu.FurnaceMenu;
import net.minecraft.inventory.menu.InventoryMenu;
import net.minecraft.inventory.slot.FurnaceFuelSlot;
import net.minecraft.item.BlockItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.util.Tickable;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.ornithemc.feather.constants.NbtTypes;

public class FurnaceBlockEntity extends InventoryBlockEntity implements Tickable, SidedInventory {
	private static final int[] INVENTORY_SLOTS_TOP = new int[]{0};
	private static final int[] INVENTORY_SLOTS_BOTTOM = new int[]{2, 1};
	private static final int[] INVENTORY_SLOTS_SIDES = new int[]{1};
	private ItemStack[] inventory = new ItemStack[3];
	private int fuelTime;
	private int totalFuelTime;
	private int cookTime;
	private int totalCookTime;
	private String customName;

	@Override
	public int getSize() {
		return this.inventory.length;
	}

	@Override
	public ItemStack getItem(int slot) {
		return this.inventory[slot];
	}

	@Override
	public ItemStack removeItem(int slot, int amount) {
		if (this.inventory[slot] != null) {
			if (this.inventory[slot].size <= amount) {
				ItemStack itemStack = this.inventory[slot];
				this.inventory[slot] = null;
				return itemStack;
			}

			ItemStack itemStack = this.inventory[slot].split(amount);
			if (this.inventory[slot].size == 0) {
				this.inventory[slot] = null;
			}

			return itemStack;
		} else {
			return null;
		}
	}

	@Override
	public ItemStack removeItemQuietly(int slot) {
		if (this.inventory[slot] != null) {
			ItemStack itemStack = this.inventory[slot];
			this.inventory[slot] = null;
			return itemStack;
		} else {
			return null;
		}
	}

	@Override
	public void setItem(int slot, ItemStack item) {
		boolean bl = item != null && item.matchesItem(this.inventory[slot]) && ItemStack.matchesNbt(item, this.inventory[slot]);
		this.inventory[slot] = item;
		if (item != null && item.size > this.getMaxStackSize()) {
			item.size = this.getMaxStackSize();
		}

		if (slot == 0 && !bl) {
			this.totalCookTime = this.getTotalCookTime(item);
			this.cookTime = 0;
			this.markDirty();
		}
	}

	@Override
	public String getName() {
		return this.hasCustomName() ? this.customName : "container.furnace";
	}

	@Override
	public boolean hasCustomName() {
		return this.customName != null && this.customName.length() > 0;
	}

	public void setCustomName(String name) {
		this.customName = name;
	}

	@Override
	public void readNbt(NbtCompound nbt) {
		super.readNbt(nbt);
		NbtList nbtList = nbt.getList("Items", NbtTypes.COMPOUND);
		this.inventory = new ItemStack[this.getSize()];

		for (int i = 0; i < nbtList.size(); i++) {
			NbtCompound nbtCompound = nbtList.getCompound(i);
			int j = nbtCompound.getByte("Slot");
			if (j >= 0 && j < this.inventory.length) {
				this.inventory[j] = ItemStack.fromNbt(nbtCompound);
			}
		}

		this.fuelTime = nbt.getShort("BurnTime");
		this.cookTime = nbt.getShort("CookTime");
		this.totalCookTime = nbt.getShort("CookTimeTotal");
		this.totalFuelTime = getFuelTime(this.inventory[1]);
		if (nbt.contains("CustomName", NbtTypes.STRING)) {
			this.customName = nbt.getString("CustomName");
		}
	}

	@Override
	public void writeNbt(NbtCompound nbt) {
		super.writeNbt(nbt);
		nbt.putShort("BurnTime", (short)this.fuelTime);
		nbt.putShort("CookTime", (short)this.cookTime);
		nbt.putShort("CookTimeTotal", (short)this.totalCookTime);
		NbtList nbtList = new NbtList();

		for (int i = 0; i < this.inventory.length; i++) {
			if (this.inventory[i] != null) {
				NbtCompound nbtCompound = new NbtCompound();
				nbtCompound.putByte("Slot", (byte)i);
				this.inventory[i].writeNbt(nbtCompound);
				nbtList.addElement(nbtCompound);
			}
		}

		nbt.put("Items", nbtList);
		if (this.hasCustomName()) {
			nbt.putString("CustomName", this.customName);
		}
	}

	@Override
	public int getMaxStackSize() {
		return 64;
	}

	public boolean hasFuel() {
		return this.fuelTime > 0;
	}

	@Environment(EnvType.CLIENT)
	public static boolean isLit(Inventory furnace) {
		return furnace.getData(0) > 0;
	}

	@Override
	public void tick() {
		boolean bl = this.hasFuel();
		boolean bl2 = false;
		if (this.hasFuel()) {
			this.fuelTime--;
		}

		if (!this.world.isClient) {
			if (this.hasFuel() || this.inventory[1] != null && this.inventory[0] != null) {
				if (!this.hasFuel() && this.canCook()) {
					this.totalFuelTime = this.fuelTime = getFuelTime(this.inventory[1]);
					if (this.hasFuel()) {
						bl2 = true;
						if (this.inventory[1] != null) {
							this.inventory[1].size--;
							if (this.inventory[1].size == 0) {
								Item item = this.inventory[1].getItem().getRecipeRemainder();
								this.inventory[1] = item != null ? new ItemStack(item) : null;
							}
						}
					}
				}

				if (this.hasFuel() && this.canCook()) {
					this.cookTime++;
					if (this.cookTime == this.totalCookTime) {
						this.cookTime = 0;
						this.totalCookTime = this.getTotalCookTime(this.inventory[0]);
						this.finishCooking();
						bl2 = true;
					}
				} else {
					this.cookTime = 0;
				}
			} else if (!this.hasFuel() && this.cookTime > 0) {
				this.cookTime = MathHelper.clamp(this.cookTime - 2, 0, this.totalCookTime);
			}

			if (bl != this.hasFuel()) {
				bl2 = true;
				FurnaceBlock.updateLitState(this.hasFuel(), this.world, this.pos);
			}
		}

		if (bl2) {
			this.markDirty();
		}
	}

	public int getTotalCookTime(ItemStack item) {
		return 200;
	}

	private boolean canCook() {
		if (this.inventory[0] == null) {
			return false;
		} else {
			ItemStack itemStack = SmeltingManager.getInstance().getResult(this.inventory[0]);
			if (itemStack == null) {
				return false;
			} else if (this.inventory[2] == null) {
				return true;
			} else if (!this.inventory[2].matchesItem(itemStack)) {
				return false;
			} else {
				return this.inventory[2].size < this.getMaxStackSize() && this.inventory[2].size < this.inventory[2].getMaxSize()
					? true
					: this.inventory[2].size < itemStack.getMaxSize();
			}
		}
	}

	public void finishCooking() {
		if (this.canCook()) {
			ItemStack itemStack = SmeltingManager.getInstance().getResult(this.inventory[0]);
			if (this.inventory[2] == null) {
				this.inventory[2] = itemStack.copy();
			} else if (this.inventory[2].getItem() == itemStack.getItem()) {
				this.inventory[2].size++;
			}

			if (this.inventory[0].getItem() == Item.byBlock(Blocks.SPONGE)
				&& this.inventory[0].getMetadata() == 1
				&& this.inventory[1] != null
				&& this.inventory[1].getItem() == Items.BUCKET) {
				this.inventory[1] = new ItemStack(Items.WATER_BUCKET);
			}

			this.inventory[0].size--;
			if (this.inventory[0].size <= 0) {
				this.inventory[0] = null;
			}
		}
	}

	public static int getFuelTime(ItemStack item) {
		if (item == null) {
			return 0;
		}

		Item item2 = item.getItem();
		if (item2 instanceof BlockItem && Block.byItem(item2) != Blocks.AIR) {
			Block block = Block.byItem(item2);
			if (block == Blocks.WOODEN_SLAB) {
				return 150;
			}

			if (block.getMaterial() == Material.WOOD) {
				return 300;
			}

			if (block == Blocks.COAL_BLOCK) {
				return 16000;
			}
		}

		if (item2 instanceof ToolItem && ((ToolItem)item2).getTierName().equals("WOOD")) {
			return 200;
		} else if (item2 instanceof SwordItem && ((SwordItem)item2).getTierName().equals("WOOD")) {
			return 200;
		} else if (item2 instanceof HoeItem && ((HoeItem)item2).getTierName().equals("WOOD")) {
			return 200;
		} else if (item2 == Items.STICK) {
			return 100;
		} else if (item2 == Items.COAL) {
			return 1600;
		} else if (item2 == Items.LAVA_BUCKET) {
			return 20000;
		} else if (item2 == Item.byBlock(Blocks.SAPLING)) {
			return 100;
		} else {
			return item2 == Items.BLAZE_ROD ? 2400 : 0;
		}
	}

	public static boolean isFuel(ItemStack item) {
		return getFuelTime(item) > 0;
	}

	@Override
	public boolean isValid(PlayerEntity player) {
		return this.world.getBlockEntity(this.pos) != this
			? false
			: !(player.squaredDistanceTo(this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5) > 64.0);
	}

	@Override
	public void onOpen(PlayerEntity player) {
	}

	@Override
	public void onClose(PlayerEntity player) {
	}

	@Override
	public boolean isItemAllowed(int slot, ItemStack item) {
		if (slot == 2) {
			return false;
		} else {
			return slot != 1 ? true : isFuel(item) || FurnaceFuelSlot.isBucket(item);
		}
	}

	@Override
	public int[] getSlots(Direction side) {
		if (side == Direction.DOWN) {
			return INVENTORY_SLOTS_BOTTOM;
		} else {
			return side == Direction.UP ? INVENTORY_SLOTS_TOP : INVENTORY_SLOTS_SIDES;
		}
	}

	@Override
	public boolean canPushItem(int slot, ItemStack item, Direction side) {
		return this.isItemAllowed(slot, item);
	}

	@Override
	public boolean canPullItem(int slot, ItemStack item, Direction side) {
		if (side == Direction.DOWN && slot == 1) {
			Item item2 = item.getItem();
			if (item2 != Items.WATER_BUCKET && item2 != Items.BUCKET) {
				return false;
			}
		}

		return true;
	}

	@Override
	public String getMenuType() {
		return "minecraft:furnace";
	}

	@Override
	public InventoryMenu createMenu(PlayerInventory playerInventory, PlayerEntity player) {
		return new FurnaceMenu(playerInventory, this);
	}

	@Override
	public int getData(int id) {
		switch (id) {
			case 0:
				return this.fuelTime;
			case 1:
				return this.totalFuelTime;
			case 2:
				return this.cookTime;
			case 3:
				return this.totalCookTime;
			default:
				return 0;
		}
	}

	@Override
	public void setData(int id, int value) {
		switch (id) {
			case 0:
				this.fuelTime = value;
				break;
			case 1:
				this.totalFuelTime = value;
				break;
			case 2:
				this.cookTime = value;
				break;
			case 3:
				this.totalCookTime = value;
		}
	}

	@Override
	public int getDataSize() {
		return 4;
	}

	@Override
	public void clear() {
		for (int i = 0; i < this.inventory.length; i++) {
			this.inventory[i] = null;
		}
	}
}

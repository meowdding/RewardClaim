package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.HugeMushroomFeature;
import net.ornithemc.feather.constants.SetBlockFlags;

public class MushroomPlantBlock extends PlantBlock implements Fertilizable {
	protected MushroomPlantBlock() {
		float f = 0.2F;
		this.setShape(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f * 2.0F, 0.5F + f);
		this.setTicksRandomly(true);
	}

	@Override
	public void tick(World world, BlockPos pos, BlockState state, Random random) {
		if (random.nextInt(25) == 0) {
			int i = 5;
			int j = 4;

			for (BlockPos blockPos : BlockPos.iterateRegionMutable(pos.add(-4, -1, -4), pos.add(4, 1, 4))) {
				if (world.getBlockState(blockPos).getBlock() == this) {
					if (--i <= 0) {
						return;
					}
				}
			}

			BlockPos blockPos2 = pos.add(random.nextInt(3) - 1, random.nextInt(2) - random.nextInt(2), random.nextInt(3) - 1);

			for (int k = 0; k < 4; k++) {
				if (world.isAir(blockPos2) && this.canSurvive(world, blockPos2, this.defaultState())) {
					pos = blockPos2;
				}

				blockPos2 = pos.add(random.nextInt(3) - 1, random.nextInt(2) - random.nextInt(2), random.nextInt(3) - 1);
			}

			if (world.isAir(blockPos2) && this.canSurvive(world, blockPos2, this.defaultState())) {
				world.setBlockState(blockPos2, this.defaultState(), SetBlockFlags.NOTIFY_LISTENERS);
			}
		}
	}

	@Override
	public boolean canBePlaced(World world, BlockPos pos) {
		return super.canBePlaced(world, pos) && this.canSurvive(world, pos, this.defaultState());
	}

	@Override
	protected boolean canBePlacedOn(Block block) {
		return block.isOpaque();
	}

	@Override
	public boolean canSurvive(World world, BlockPos pos, BlockState state) {
		if (pos.getY() >= 0 && pos.getY() < 256) {
			BlockState blockState = world.getBlockState(pos.down());
			if (blockState.getBlock() == Blocks.MYCELIUM) {
				return true;
			} else {
				return blockState.getBlock() == Blocks.DIRT && blockState.get(DirtBlock.VARIANT) == DirtBlock.Variant.PODZOL
					? true
					: world.getActualLight(pos) < 13 && this.canBePlacedOn(blockState.getBlock());
			}
		} else {
			return false;
		}
	}

	public boolean grow(World world, BlockPos pos, BlockState state, Random random) {
		world.removeBlock(pos);
		Feature feature = null;
		if (this == Blocks.BROWN_MUSHROOM) {
			feature = new HugeMushroomFeature(Blocks.BROWN_MUSHROOM_BLOCK);
		} else if (this == Blocks.RED_MUSHROOM) {
			feature = new HugeMushroomFeature(Blocks.RED_MUSHROOM_BLOCK);
		}

		if (feature != null && feature.place(world, random, pos)) {
			return true;
		}

		world.setBlockState(pos, state, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
		return false;
	}

	@Override
	public boolean canGrow(World world, BlockPos pos, BlockState state, boolean isClient) {
		return true;
	}

	@Override
	public boolean canBeFertilized(World world, Random rand, BlockPos pos, BlockState state) {
		return rand.nextFloat() < 0.4;
	}

	@Override
	public void grow(World world, Random rand, BlockPos pos, BlockState state) {
		this.grow(world, pos, state, rand);
	}
}

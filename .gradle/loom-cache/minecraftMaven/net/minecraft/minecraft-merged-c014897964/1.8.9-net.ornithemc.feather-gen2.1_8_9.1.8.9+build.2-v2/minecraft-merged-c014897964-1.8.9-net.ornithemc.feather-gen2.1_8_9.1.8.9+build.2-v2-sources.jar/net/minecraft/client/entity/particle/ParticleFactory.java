package net.minecraft.client.entity.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.world.World;

@Environment(EnvType.CLIENT)
public interface ParticleFactory {
	Particle create(int type, World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, int... parameters);
}

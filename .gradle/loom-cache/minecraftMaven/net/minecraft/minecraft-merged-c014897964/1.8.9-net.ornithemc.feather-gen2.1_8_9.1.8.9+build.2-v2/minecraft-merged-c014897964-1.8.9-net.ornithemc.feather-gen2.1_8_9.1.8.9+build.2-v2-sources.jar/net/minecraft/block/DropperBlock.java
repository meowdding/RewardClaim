package net.minecraft.block;

import net.minecraft.block.dispenser.DispenseBehavior;
import net.minecraft.block.dispenser.DispenseItemBehavior;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.DropperBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockSource;
import net.minecraft.world.World;

public class DropperBlock extends DispenserBlock {
	private final DispenseBehavior dispenseBehavior = new DispenseItemBehavior();

	@Override
	protected DispenseBehavior getDispenseBehavior(ItemStack item) {
		return this.dispenseBehavior;
	}

	@Override
	public BlockEntity createBlockEntity(World world, int metadata) {
		return new DropperBlockEntity();
	}

	@Override
	protected void dispense(World world, BlockPos pos) {
		BlockSource blockSource = new BlockSource(world, pos);
		DispenserBlockEntity dispenserBlockEntity = blockSource.getBlockEntity();
		if (dispenserBlockEntity != null) {
			int i = dispenserBlockEntity.pickNonEmptySlot();
			if (i < 0) {
				world.doEvent(1001, pos, 0);
			} else {
				ItemStack itemStack = dispenserBlockEntity.getItem(i);
				if (itemStack != null) {
					Direction direction = world.getBlockState(pos).get(FACING);
					BlockPos blockPos = pos.offset(direction);
					Inventory inventory = HopperBlockEntity.getInventoryAt(world, blockPos.getX(), blockPos.getY(), blockPos.getZ());
					ItemStack itemStack2;
					if (inventory == null) {
						itemStack2 = this.dispenseBehavior.dispense(blockSource, itemStack);
						if (itemStack2 != null && itemStack2.size <= 0) {
							itemStack2 = null;
						}
					} else {
						itemStack2 = HopperBlockEntity.pushItem(inventory, itemStack.copy().split(1), direction.getOpposite());
						if (itemStack2 == null) {
							itemStack2 = itemStack.copy();
							if (--itemStack2.size <= 0) {
								itemStack2 = null;
							}
						} else {
							itemStack2 = itemStack.copy();
						}
					}

					dispenserBlockEntity.setItem(i, itemStack2);
				}
			}
		}
	}
}

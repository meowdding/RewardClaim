package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.layer.CreeperChargeLayer;
import net.minecraft.client.render.model.entity.CreeperModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.monster.CreeperEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class CreeperRenderer extends MobRenderer<CreeperEntity> {
	private static final Identifier CREEPER_LOCATION = new Identifier("textures/entity/creeper/creeper.png");

	public CreeperRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher, new CreeperModel(), 0.5F);
		this.addLayer(new CreeperChargeLayer(this));
	}

	protected void applyScale(CreeperEntity entity, float scale) {
		float f = entity.getFuse(scale);
		float g = 1.0F + MathHelper.sin(f * 100.0F) * f * 0.01F;
		f = MathHelper.clamp(f, 0.0F, 1.0F);
		f *= f;
		f *= f;
		float h = (1.0F + f * 0.4F) * g;
		float i = (1.0F + f * 0.1F) / g;
		GlStateManager.scalef(h, i, h);
	}

	protected int getOverlayColor(CreeperEntity entity, float brightness, float timeDelta) {
		float f = entity.getFuse(timeDelta);
		if ((int)(f * 10.0F) % 2 == 0) {
			return 0;
		}

		int i = (int)(f * 0.2F * 255.0F);
		i = MathHelper.clamp(i, 0, 255);
		return i << 24 | 16777215;
	}

	protected Identifier getTextureLocation(CreeperEntity entity) {
		return CREEPER_LOCATION;
	}
}

package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class ExperienceOrbRenderer extends EntityRenderer<ExperienceOrbEntity> {
	private static final Identifier EXPERIENCE_ORB_LOCATION = new Identifier("textures/entity/experience_orb.png");

	public ExperienceOrbRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
		this.shadowSize = 0.15F;
		this.shadowDarkness = 0.75F;
	}

	public void render(ExperienceOrbEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		GlStateManager.pushMatrix();
		GlStateManager.translatef((float)dx, (float)dy, (float)dz);
		this.bindTexture(entity);
		int i = entity.getSize();
		float f = (i % 4 * 16 + 0) / 64.0F;
		float g = (i % 4 * 16 + 16) / 64.0F;
		float h = (i / 4 * 16 + 0) / 64.0F;
		float j = (i / 4 * 16 + 16) / 64.0F;
		float k = 1.0F;
		float l = 0.5F;
		float m = 0.25F;
		int n = entity.getLightLevel(tickDelta);
		int o = n % 65536;
		int p = n / 65536;
		GLX.multiTexCoord2f(GLX.GL_TEXTURE1, o / 1.0F, p / 1.0F);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		float q = 255.0F;
		float r = (entity.renderTicks + tickDelta) / 2.0F;
		p = (int)((MathHelper.sin(r + 0.0F) + 1.0F) * 0.5F * 255.0F);
		int s = 255;
		int t = (int)((MathHelper.sin(r + (float) (Math.PI * 4.0 / 3.0)) + 1.0F) * 0.1F * 255.0F);
		GlStateManager.rotatef(180.0F - this.dispatcher.cameraYaw, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(-this.dispatcher.cameraPitch, 1.0F, 0.0F, 0.0F);
		float u = 0.3F;
		GlStateManager.scalef(0.3F, 0.3F, 0.3F);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR_NORMAL);
		bufferBuilder.vertex(0.0F - l, 0.0F - m, 0.0).texture(f, j).color(p, 255, t, 128).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(k - l, 0.0F - m, 0.0).texture(g, j).color(p, 255, t, 128).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(k - l, 1.0F - m, 0.0).texture(g, h).color(p, 255, t, 128).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(0.0F - l, 1.0F - m, 0.0).texture(f, h).color(p, 255, t, 128).normal(0.0F, 1.0F, 0.0F).nextVertex();
		tesselator.end();
		GlStateManager.disableBlend();
		GlStateManager.disableRescaleNormal();
		GlStateManager.popMatrix();
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(ExperienceOrbEntity entity) {
		return EXPERIENCE_ORB_LOCATION;
	}
}

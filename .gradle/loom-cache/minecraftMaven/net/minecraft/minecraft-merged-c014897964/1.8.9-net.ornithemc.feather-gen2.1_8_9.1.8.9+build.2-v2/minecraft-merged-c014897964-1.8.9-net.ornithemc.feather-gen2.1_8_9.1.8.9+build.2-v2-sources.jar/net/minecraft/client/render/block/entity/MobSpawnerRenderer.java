package net.minecraft.client.render.block.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.spawner.MobSpawner;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.Entity;

@Environment(EnvType.CLIENT)
public class MobSpawnerRenderer extends BlockEntityRenderer<MobSpawnerBlockEntity> {
	public void render(MobSpawnerBlockEntity blockEntity, double dx, double dy, double dz, float tickDelta, int blockMiningProgress) {
		GlStateManager.pushMatrix();
		GlStateManager.translatef((float)dx + 0.5F, (float)dy, (float)dz + 0.5F);
		renderDisplayEntity(blockEntity.getSpawner(), dx, dy, dz, tickDelta);
		GlStateManager.popMatrix();
	}

	public static void renderDisplayEntity(MobSpawner spawner, double dx, double dy, double dz, float tickDelta) {
		Entity entity = spawner.getDisplayEntity(spawner.getWorld());
		if (entity != null) {
			float f = 0.4375F;
			GlStateManager.translatef(0.0F, 0.4F, 0.0F);
			GlStateManager.rotatef((float)(spawner.getLastRotation() + (spawner.getRotation() - spawner.getLastRotation()) * tickDelta) * 10.0F, 0.0F, 1.0F, 0.0F);
			GlStateManager.rotatef(-30.0F, 1.0F, 0.0F, 0.0F);
			GlStateManager.translatef(0.0F, -0.4F, 0.0F);
			GlStateManager.scalef(f, f, f);
			entity.setPositionAndAngles(dx, dy, dz, 0.0F, 0.0F);
			Minecraft.getInstance().getEntityRenderDispatcher().render(entity, 0.0, 0.0, 0.0, 0.0F, tickDelta);
		}
	}
}

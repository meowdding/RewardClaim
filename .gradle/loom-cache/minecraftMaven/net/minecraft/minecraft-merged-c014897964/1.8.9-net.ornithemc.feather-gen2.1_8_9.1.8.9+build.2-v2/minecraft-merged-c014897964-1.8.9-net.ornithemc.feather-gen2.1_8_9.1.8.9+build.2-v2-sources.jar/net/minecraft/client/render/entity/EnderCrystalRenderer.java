package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.model.Model;
import net.minecraft.client.render.model.block.entity.EnderCrystalModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.EnderCrystalEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class EnderCrystalRenderer extends EntityRenderer<EnderCrystalEntity> {
	private static final Identifier ENDER_CRYSTAL_LOCATION = new Identifier("textures/entity/endercrystal/endercrystal.png");
	private Model model = new EnderCrystalModel(0.0F, true);

	public EnderCrystalRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
		this.shadowSize = 0.5F;
	}

	public void render(EnderCrystalEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		float f = entity.renderTicks + tickDelta;
		GlStateManager.pushMatrix();
		GlStateManager.translatef((float)dx, (float)dy, (float)dz);
		this.bindTexture(ENDER_CRYSTAL_LOCATION);
		float g = MathHelper.sin(f * 0.2F) / 2.0F + 0.5F;
		g = g * g + g;
		this.model.render(entity, 0.0F, f * 3.0F, g * 0.2F, 0.0F, 0.0F, 0.0625F);
		GlStateManager.popMatrix();
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(EnderCrystalEntity entity) {
		return ENDER_CRYSTAL_LOCATION;
	}
}

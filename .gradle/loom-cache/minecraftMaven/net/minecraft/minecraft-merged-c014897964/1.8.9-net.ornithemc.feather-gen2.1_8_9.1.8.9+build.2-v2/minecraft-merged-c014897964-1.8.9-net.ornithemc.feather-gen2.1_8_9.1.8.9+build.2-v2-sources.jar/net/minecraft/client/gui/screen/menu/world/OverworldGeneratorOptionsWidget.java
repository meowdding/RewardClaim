package net.minecraft.client.gui.screen.menu.world;

import com.google.common.base.Objects;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Lists;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiElement;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.EntryListWidget;
import net.minecraft.client.gui.widget.LabelWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.util.Int2ObjectHashMap;

@Environment(EnvType.CLIENT)
public class OverworldGeneratorOptionsWidget extends EntryListWidget {
	private final List<OverworldGeneratorOptionsWidget.GeneratorOptionsEntry> entries = Lists.newArrayList();
	private final Int2ObjectHashMap<GuiElement> elements = new Int2ObjectHashMap<>();
	private final List<TextFieldWidget> textFields = Lists.newArrayList();
	private final OverworldGeneratorOptionsWidget.GeneratorOption[][] options;
	private int page;
	private OverworldGeneratorOptionsWidget.Controller controller;
	private GuiElement selected;

	public OverworldGeneratorOptionsWidget(
		Minecraft minecraft,
		int width,
		int height,
		int minY,
		int maxY,
		int entryHeight,
		OverworldGeneratorOptionsWidget.Controller controller,
		OverworldGeneratorOptionsWidget.GeneratorOption[]... options
	) {
		super(minecraft, width, height, minY, maxY, entryHeight);
		this.controller = controller;
		this.options = options;
		this.centerAlongY = false;
		this.init();
		this.buildPage();
	}

	private void init() {
		for (OverworldGeneratorOptionsWidget.GeneratorOption[] generatorOptions2 : this.options) {
			for (int k = 0; k < generatorOptions2.length; k += 2) {
				OverworldGeneratorOptionsWidget.GeneratorOption generatorOption = generatorOptions2[k];
				OverworldGeneratorOptionsWidget.GeneratorOption generatorOption2 = k < generatorOptions2.length - 1 ? generatorOptions2[k + 1] : null;
				GuiElement guiElement = this.createElement(generatorOption, 0, generatorOption2 == null);
				GuiElement guiElement2 = this.createElement(generatorOption2, 160, generatorOption == null);
				OverworldGeneratorOptionsWidget.GeneratorOptionsEntry generatorOptionsEntry = new OverworldGeneratorOptionsWidget.GeneratorOptionsEntry(
					guiElement, guiElement2
				);
				this.entries.add(generatorOptionsEntry);
				if (generatorOption != null && guiElement != null) {
					this.elements.put(generatorOption.getId(), guiElement);
					if (guiElement instanceof TextFieldWidget) {
						this.textFields.add((TextFieldWidget)guiElement);
					}
				}

				if (generatorOption2 != null && guiElement2 != null) {
					this.elements.put(generatorOption2.getId(), guiElement2);
					if (guiElement2 instanceof TextFieldWidget) {
						this.textFields.add((TextFieldWidget)guiElement2);
					}
				}
			}
		}
	}

	private void buildPage() {
		this.entries.clear();

		for (int i = 0; i < this.options[this.page].length; i += 2) {
			OverworldGeneratorOptionsWidget.GeneratorOption generatorOption = this.options[this.page][i];
			OverworldGeneratorOptionsWidget.GeneratorOption generatorOption2 = i < this.options[this.page].length - 1 ? this.options[this.page][i + 1] : null;
			GuiElement guiElement = this.elements.get(generatorOption.getId());
			GuiElement guiElement2 = generatorOption2 != null ? this.elements.get(generatorOption2.getId()) : null;
			OverworldGeneratorOptionsWidget.GeneratorOptionsEntry generatorOptionsEntry = new OverworldGeneratorOptionsWidget.GeneratorOptionsEntry(
				guiElement, guiElement2
			);
			this.entries.add(generatorOptionsEntry);
		}
	}

	public void selectPage(int page) {
		if (page != this.page) {
			int i = this.page;
			this.page = page;
			this.buildPage();
			this.changePage(i, page);
			this.scrollAmount = 0.0F;
		}
	}

	public int getPage() {
		return this.page;
	}

	public int getOptionCount() {
		return this.options.length;
	}

	public GuiElement getSelected() {
		return this.selected;
	}

	public void prevPage() {
		if (this.page > 0) {
			this.selectPage(this.page - 1);
		}
	}

	public void nextPage() {
		if (this.page < this.options.length - 1) {
			this.selectPage(this.page + 1);
		}
	}

	public GuiElement getElement(int id) {
		return this.elements.get(id);
	}

	private void changePage(int from, int to) {
		for (OverworldGeneratorOptionsWidget.GeneratorOption generatorOption : this.options[from]) {
			if (generatorOption != null) {
				this.setVisible(this.elements.get(generatorOption.getId()), false);
			}
		}

		for (OverworldGeneratorOptionsWidget.GeneratorOption generatorOption : this.options[to]) {
			if (generatorOption != null) {
				this.setVisible(this.elements.get(generatorOption.getId()), true);
			}
		}
	}

	private void setVisible(GuiElement option, boolean visible) {
		if (option instanceof ButtonWidget) {
			((ButtonWidget)option).visible = visible;
		} else if (option instanceof TextFieldWidget) {
			((TextFieldWidget)option).setVisible(visible);
		} else if (option instanceof LabelWidget) {
			((LabelWidget)option).visible = visible;
		}
	}

	private GuiElement createElement(OverworldGeneratorOptionsWidget.GeneratorOption option, int x, boolean alone) {
		if (option instanceof OverworldGeneratorOptionsWidget.NumberOption) {
			return this.createSlider(this.width / 2 - 155 + x, 0, (OverworldGeneratorOptionsWidget.NumberOption)option);
		} else if (option instanceof OverworldGeneratorOptionsWidget.ToggleOption) {
			return this.createToggle(this.width / 2 - 155 + x, 0, (OverworldGeneratorOptionsWidget.ToggleOption)option);
		} else if (option instanceof OverworldGeneratorOptionsWidget.TextOption) {
			return this.createTextField(this.width / 2 - 155 + x, 0, (OverworldGeneratorOptionsWidget.TextOption)option);
		} else {
			return option instanceof OverworldGeneratorOptionsWidget.Label
				? this.createLabel(this.width / 2 - 155 + x, 0, (OverworldGeneratorOptionsWidget.Label)option, alone)
				: null;
		}
	}

	public void setActive(boolean active) {
		for (OverworldGeneratorOptionsWidget.GeneratorOptionsEntry generatorOptionsEntry : this.entries) {
			if (generatorOptionsEntry.left instanceof ButtonWidget) {
				((ButtonWidget)generatorOptionsEntry.left).active = active;
			}

			if (generatorOptionsEntry.right instanceof ButtonWidget) {
				((ButtonWidget)generatorOptionsEntry.right).active = active;
			}
		}
	}

	@Override
	public boolean mouseClicked(int mouseX, int mouseY, int button) {
		boolean bl = super.mouseClicked(mouseX, mouseY, button);
		int i = this.getEntryAt(mouseX, mouseY);
		if (i >= 0) {
			OverworldGeneratorOptionsWidget.GeneratorOptionsEntry generatorOptionsEntry = this.getEntry(i);
			if (this.selected != generatorOptionsEntry.selected && this.selected != null && this.selected instanceof TextFieldWidget) {
				((TextFieldWidget)this.selected).setFocused(false);
			}

			this.selected = generatorOptionsEntry.selected;
		}

		return bl;
	}

	private GeneratorOptionSlider createSlider(int x, int y, OverworldGeneratorOptionsWidget.NumberOption option) {
		GeneratorOptionSlider generatorOptionSlider = new GeneratorOptionSlider(
			this.controller, option.getId(), x, y, option.getMessage(), option.getMin(), option.getMax(), option.getDefaultValue(), option.getFormatter()
		);
		generatorOptionSlider.visible = option.isVisible();
		return generatorOptionSlider;
	}

	private GeneratorOptionToggle createToggle(int x, int y, OverworldGeneratorOptionsWidget.ToggleOption option) {
		GeneratorOptionToggle generatorOptionToggle = new GeneratorOptionToggle(this.controller, option.getId(), x, y, option.getMessage(), option.getDefaultValue());
		generatorOptionToggle.visible = option.isVisible();
		return generatorOptionToggle;
	}

	private TextFieldWidget createTextField(int x, int y, OverworldGeneratorOptionsWidget.TextOption option) {
		TextFieldWidget textFieldWidget = new TextFieldWidget(option.getId(), this.minecraft.textRenderer, x, y, 150, 20);
		textFieldWidget.setText(option.getMessage());
		textFieldWidget.setController(this.controller);
		textFieldWidget.setVisible(option.isVisible());
		textFieldWidget.setFilter(option.getValidator());
		return textFieldWidget;
	}

	private LabelWidget createLabel(int x, int y, OverworldGeneratorOptionsWidget.Label label, boolean alone) {
		LabelWidget labelWidget;
		if (alone) {
			labelWidget = new LabelWidget(this.minecraft.textRenderer, label.getId(), x, y, this.width - x * 2, 20, -1);
		} else {
			labelWidget = new LabelWidget(this.minecraft.textRenderer, label.getId(), x, y, 150, 20, -1);
		}

		labelWidget.visible = label.isVisible();
		labelWidget.add(label.getMessage());
		labelWidget.setCentered();
		return labelWidget;
	}

	public void keyPressed(char chr, int code) {
		if (this.selected instanceof TextFieldWidget) {
			TextFieldWidget textFieldWidget = (TextFieldWidget)this.selected;
			if (!Screen.isPaste(code)) {
				if (code == 15) {
					textFieldWidget.setFocused(false);
					int m = this.textFields.indexOf(this.selected);
					if (Screen.isShiftDown()) {
						if (m == 0) {
							m = this.textFields.size() - 1;
						} else {
							m--;
						}
					} else if (m == this.textFields.size() - 1) {
						m = 0;
					} else {
						m++;
					}

					this.selected = this.textFields.get(m);
					textFieldWidget = (TextFieldWidget)this.selected;
					textFieldWidget.setFocused(true);
					int n = textFieldWidget.y + this.entryHeight;
					int i = textFieldWidget.y;
					if (n > this.maxY) {
						this.scrollAmount = this.scrollAmount + (n - this.maxY);
					} else if (i < this.minY) {
						this.scrollAmount = i;
					}
				} else {
					textFieldWidget.keyPressed(chr, code);
				}
			} else {
				String string = Screen.getClipboard();
				String[] strings = string.split(";");
				int i = this.textFields.indexOf(this.selected);
				int j = i;

				for (String string2 : strings) {
					this.textFields.get(j).setText(string2);
					if (j == this.textFields.size() - 1) {
						j = 0;
					} else {
						j++;
					}

					if (j == i) {
						break;
					}
				}
			}
		}
	}

	public OverworldGeneratorOptionsWidget.GeneratorOptionsEntry getEntry(int index) {
		return this.entries.get(index);
	}

	@Override
	public int size() {
		return this.entries.size();
	}

	@Override
	public int getRowWidth() {
		return 400;
	}

	@Override
	protected int getScrollbarPosition() {
		return super.getScrollbarPosition() + 32;
	}

	@Environment(EnvType.CLIENT)
	public interface Controller {
		void setValue(int id, boolean value);

		void setValue(int id, float value);

		void setValue(int id, String value);
	}

	@Environment(EnvType.CLIENT)
	public static class GeneratorOption {
		private final int id;
		private final String message;
		private final boolean visible;

		public GeneratorOption(int id, String message, boolean visible) {
			this.id = id;
			this.message = message;
			this.visible = visible;
		}

		public int getId() {
			return this.id;
		}

		public String getMessage() {
			return this.message;
		}

		public boolean isVisible() {
			return this.visible;
		}
	}

	@Environment(EnvType.CLIENT)
	public static class GeneratorOptionsEntry implements EntryListWidget.Entry {
		private final Minecraft minecraft = Minecraft.getInstance();
		private final GuiElement left;
		private final GuiElement right;
		private GuiElement selected;

		public GeneratorOptionsEntry(GuiElement left, GuiElement right) {
			this.left = left;
			this.right = right;
		}

		public GuiElement getLeft() {
			return this.left;
		}

		public GuiElement getRight() {
			return this.right;
		}

		@Override
		public void render(int index, int x, int y, int width, int height, int mouseX, int mouseY, boolean hovered) {
			this.renderOption(this.left, y, mouseX, mouseY, false);
			this.renderOption(this.right, y, mouseX, mouseY, false);
		}

		private void renderOption(GuiElement option, int y, int mouseX, int mouseY, boolean outOfBounds) {
			if (option != null) {
				if (option instanceof ButtonWidget) {
					this.renderButton((ButtonWidget)option, y, mouseX, mouseY, outOfBounds);
				} else if (option instanceof TextFieldWidget) {
					this.renderTextField((TextFieldWidget)option, y, outOfBounds);
				} else if (option instanceof LabelWidget) {
					this.renderLabel((LabelWidget)option, y, mouseX, mouseY, outOfBounds);
				}
			}
		}

		private void renderButton(ButtonWidget option, int y, int mouseX, int mouseY, boolean outOfBounds) {
			option.y = y;
			if (!outOfBounds) {
				option.render(this.minecraft, mouseX, mouseY);
			}
		}

		private void renderTextField(TextFieldWidget option, int y, boolean outOfBounds) {
			option.y = y;
			if (!outOfBounds) {
				option.render();
			}
		}

		private void renderLabel(LabelWidget option, int y, int mouseX, int mouseY, boolean outOfBounds) {
			option.y = y;
			if (!outOfBounds) {
				option.render(this.minecraft, mouseX, mouseY);
			}
		}

		@Override
		public void renderOutOfBounds(int index, int x, int y) {
			this.renderOption(this.left, y, 0, 0, true);
			this.renderOption(this.right, y, 0, 0, true);
		}

		@Override
		public boolean mouseClicked(int index, int mouseX, int mouseY, int button, int entryMouseX, int entryMouseY) {
			boolean bl = this.mouseClicked(this.left, mouseX, mouseY, button);
			boolean bl2 = this.mouseClicked(this.right, mouseX, mouseY, button);
			return bl || bl2;
		}

		private boolean mouseClicked(GuiElement option, int mouseX, int mouseY, int button) {
			if (option == null) {
				return false;
			}

			if (option instanceof ButtonWidget) {
				return this.mouseClicked((ButtonWidget)option, mouseX, mouseY, button);
			}

			if (option instanceof TextFieldWidget) {
				this.mouseClicked((TextFieldWidget)option, mouseX, mouseY, button);
			}

			return false;
		}

		private boolean mouseClicked(ButtonWidget option, int mouseX, int mouseY, int button) {
			boolean bl = option.mouseClicked(this.minecraft, mouseX, mouseY);
			if (bl) {
				this.selected = option;
			}

			return bl;
		}

		private void mouseClicked(TextFieldWidget option, int mouseX, int mouseY, int button) {
			option.mouseClicked(mouseX, mouseY, button);
			if (option.isFocused()) {
				this.selected = option;
			}
		}

		@Override
		public void mouseReleased(int index, int mouseX, int mouseY, int button, int entryMouseX, int entryMouseY) {
			this.mouseReleased(this.left, mouseX, mouseY, button);
			this.mouseReleased(this.right, mouseX, mouseY, button);
		}

		private void mouseReleased(GuiElement option, int mouseX, int mouseY, int button) {
			if (option != null) {
				if (option instanceof ButtonWidget) {
					this.mouseReleased((ButtonWidget)option, mouseX, mouseY, button);
				}
			}
		}

		private void mouseReleased(ButtonWidget option, int mouseX, int mouseY, int button) {
			option.mouseReleased(mouseX, mouseY);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class Label extends OverworldGeneratorOptionsWidget.GeneratorOption {
		public Label(int i, String string, boolean bl) {
			super(i, string, bl);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class NumberOption extends OverworldGeneratorOptionsWidget.GeneratorOption {
		private final GeneratorOptionSlider.ValueFormatter formatter;
		private final float min;
		private final float max;
		private final float defaultValue;

		public NumberOption(int id, String message, boolean visible, GeneratorOptionSlider.ValueFormatter formatter, float min, float max, float defaultValue) {
			super(id, message, visible);
			this.formatter = formatter;
			this.min = min;
			this.max = max;
			this.defaultValue = defaultValue;
		}

		public GeneratorOptionSlider.ValueFormatter getFormatter() {
			return this.formatter;
		}

		public float getMin() {
			return this.min;
		}

		public float getMax() {
			return this.max;
		}

		public float getDefaultValue() {
			return this.defaultValue;
		}
	}

	@Environment(EnvType.CLIENT)
	public static class TextOption extends OverworldGeneratorOptionsWidget.GeneratorOption {
		private final Predicate<String> validator;

		public TextOption(int id, String message, boolean visible, Predicate<String> validator) {
			super(id, message, visible);
			this.validator = Objects.firstNonNull(validator, Predicates.alwaysTrue());
		}

		public Predicate<String> getValidator() {
			return this.validator;
		}
	}

	@Environment(EnvType.CLIENT)
	public static class ToggleOption extends OverworldGeneratorOptionsWidget.GeneratorOption {
		private final boolean defaultValue;

		public ToggleOption(int id, String message, boolean visible, boolean defaultValue) {
			super(id, message, visible);
			this.defaultValue = defaultValue;
		}

		public boolean getDefaultValue() {
			return this.defaultValue;
		}
	}
}

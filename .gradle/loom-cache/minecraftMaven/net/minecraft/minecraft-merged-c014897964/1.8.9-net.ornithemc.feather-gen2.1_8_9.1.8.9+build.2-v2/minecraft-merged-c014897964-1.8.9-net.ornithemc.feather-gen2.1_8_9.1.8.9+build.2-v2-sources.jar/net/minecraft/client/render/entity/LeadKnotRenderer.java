package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.model.entity.LeashModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.decoration.LeadKnotEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class LeadKnotRenderer extends EntityRenderer<LeadKnotEntity> {
	private static final Identifier LEAD_KNOT_LOCATION = new Identifier("textures/entity/lead_knot.png");
	private LeashModel model = new LeashModel();

	public LeadKnotRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
	}

	public void render(LeadKnotEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		GlStateManager.pushMatrix();
		GlStateManager.disableCull();
		GlStateManager.translatef((float)dx, (float)dy, (float)dz);
		float f = 0.0625F;
		GlStateManager.enableRescaleNormal();
		GlStateManager.scalef(-1.0F, -1.0F, 1.0F);
		GlStateManager.enableAlphaTest();
		this.bindTexture(entity);
		this.model.render(entity, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, f);
		GlStateManager.popMatrix();
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(LeadKnotEntity entity) {
		return LEAD_KNOT_LOCATION;
	}
}

package net.minecraft.client.gui.screen.menu.resourcepacks;

import com.google.common.collect.Lists;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Collections;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.OptionButtonWidget;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.resource.pack.ResourcePacks;
import net.minecraft.util.Utils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.Sys;

@Environment(EnvType.CLIENT)
public class ResourcePacksScreen extends Screen {
	private static final Logger LOGGER = LogManager.getLogger();
	private final Screen parent;
	private List<ResourcePackEntry> availablePacks;
	private List<ResourcePackEntry> selectedPacks;
	private AvailableResourcePackListWidget availablePacksWidget;
	private SelectedResourcePackListWidget selectedPacksWidget;
	private boolean changed = false;

	public ResourcePacksScreen(Screen parent) {
		this.parent = parent;
	}

	@Override
	public void init() {
		this.buttons.add(new OptionButtonWidget(2, this.width / 2 - 154, this.height - 48, I18n.translate("resourcePack.openFolder")));
		this.buttons.add(new OptionButtonWidget(1, this.width / 2 + 4, this.height - 48, I18n.translate("gui.done")));
		if (!this.changed) {
			this.availablePacks = Lists.newArrayList();
			this.selectedPacks = Lists.newArrayList();
			ResourcePacks resourcePacks = this.minecraft.getResourcePacks();
			resourcePacks.reload();
			List<ResourcePacks.UnopenedPack> list = Lists.newArrayList(resourcePacks.getAvailablePacks());
			list.removeAll(resourcePacks.getSelectedPacks());

			for (ResourcePacks.UnopenedPack unopenedPack : list) {
				this.availablePacks.add(new CustomResourcePackEntry(this, unopenedPack));
			}

			for (ResourcePacks.UnopenedPack unopenedPack : Lists.reverse(resourcePacks.getSelectedPacks())) {
				this.selectedPacks.add(new CustomResourcePackEntry(this, unopenedPack));
			}

			this.selectedPacks.add(new DefaultResourcePackEntry(this));
		}

		this.availablePacksWidget = new AvailableResourcePackListWidget(this.minecraft, 200, this.height, this.availablePacks);
		this.availablePacksWidget.setX(this.width / 2 - 4 - 200);
		this.availablePacksWidget.setScrollButtonIds(7, 8);
		this.selectedPacksWidget = new SelectedResourcePackListWidget(this.minecraft, 200, this.height, this.selectedPacks);
		this.selectedPacksWidget.setX(this.width / 2 + 4);
		this.selectedPacksWidget.setScrollButtonIds(7, 8);
	}

	@Override
	public void handleMouse() {
		super.handleMouse();
		this.selectedPacksWidget.handleMouse();
		this.availablePacksWidget.handleMouse();
	}

	public boolean isSelected(ResourcePackEntry pack) {
		return this.selectedPacks.contains(pack);
	}

	public List<ResourcePackEntry> getSiblingPacks(ResourcePackEntry pack) {
		return this.isSelected(pack) ? this.selectedPacks : this.availablePacks;
	}

	public List<ResourcePackEntry> getAvailablePacks() {
		return this.availablePacks;
	}

	public List<ResourcePackEntry> getSelectedPacks() {
		return this.selectedPacks;
	}

	@Override
	protected void buttonClicked(ButtonWidget button) {
		if (button.active) {
			if (button.id == 2) {
				File file = this.minecraft.getResourcePacks().getDirectory();
				String string = file.getAbsolutePath();
				if (Utils.getOS() == Utils.OS.MACOS) {
					try {
						LOGGER.info(string);
						Runtime.getRuntime().exec(new String[]{"/usr/bin/open", string});
						return;
					} catch (IOException iOException) {
						LOGGER.error("Couldn't open file", iOException);
					}
				} else if (Utils.getOS() == Utils.OS.WINDOWS) {
					String string2 = String.format("cmd.exe /C start \"Open file\" \"%s\"", string);

					try {
						Runtime.getRuntime().exec(string2);
						return;
					} catch (IOException iOException2) {
						LOGGER.error("Couldn't open file", iOException2);
					}
				}

				boolean bl = false;

				try {
					Class<?> class_ = Class.forName("java.awt.Desktop");
					Object object = class_.getMethod("getDesktop").invoke(null);
					class_.getMethod("browse", URI.class).invoke(object, file.toURI());
				} catch (Throwable throwable) {
					LOGGER.error("Couldn't open link", throwable);
					bl = true;
				}

				if (bl) {
					LOGGER.info("Opening via system class!");
					Sys.openURL("file://" + string);
				}
			} else if (button.id == 1) {
				if (this.changed) {
					List<ResourcePacks.UnopenedPack> list = Lists.newArrayList();

					for (ResourcePackEntry resourcePackEntry : this.selectedPacks) {
						if (resourcePackEntry instanceof CustomResourcePackEntry) {
							list.add(((CustomResourcePackEntry)resourcePackEntry).getPack());
						}
					}

					Collections.reverse(list);
					this.minecraft.getResourcePacks().setSelectedPacks(list);
					this.minecraft.options.resourcePacks.clear();
					this.minecraft.options.incompatibleResourcePacks.clear();

					for (ResourcePacks.UnopenedPack unopenedPack : list) {
						this.minecraft.options.resourcePacks.add(unopenedPack.getName());
						if (unopenedPack.getFormat() != 1) {
							this.minecraft.options.incompatibleResourcePacks.add(unopenedPack.getName());
						}
					}

					this.minecraft.options.save();
					this.minecraft.reloadResources();
				}

				this.minecraft.openScreen(this.parent);
			}
		}
	}

	@Override
	protected void mouseClicked(int mouseX, int mouseY, int button) {
		super.mouseClicked(mouseX, mouseY, button);
		this.availablePacksWidget.mouseClicked(mouseX, mouseY, button);
		this.selectedPacksWidget.mouseClicked(mouseX, mouseY, button);
	}

	@Override
	protected void mouseReleased(int mouseX, int mouseY, int button) {
		super.mouseReleased(mouseX, mouseY, button);
	}

	@Override
	public void render(int mouseX, int mouseY, float tickDelta) {
		this.drawBackgroundTexture(0);
		this.availablePacksWidget.render(mouseX, mouseY, tickDelta);
		this.selectedPacksWidget.render(mouseX, mouseY, tickDelta);
		this.drawCenteredString(this.textRenderer, I18n.translate("resourcePack.title"), this.width / 2, 16, 16777215);
		this.drawCenteredString(this.textRenderer, I18n.translate("resourcePack.folderInfo"), this.width / 2 - 77, this.height - 26, 8421504);
		super.render(mouseX, mouseY, tickDelta);
	}

	public void setChanged() {
		this.changed = true;
	}
}

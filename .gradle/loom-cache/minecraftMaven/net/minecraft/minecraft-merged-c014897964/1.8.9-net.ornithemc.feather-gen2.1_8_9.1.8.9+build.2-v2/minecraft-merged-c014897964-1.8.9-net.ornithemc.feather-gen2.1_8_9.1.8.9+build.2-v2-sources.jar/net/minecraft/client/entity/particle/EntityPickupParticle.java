package net.minecraft.client.entity.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;

@Environment(EnvType.CLIENT)
public class EntityPickupParticle extends Particle {
	/**
	 * The entity being picked up - this could be an item, arrow, or xp.
	 */
	private Entity entity;
	/**
	 * The collector that is picking up the entity.
	 */
	private Entity collector;
	private int age;
	private int lifetime;
	private float offsetY;
	private EntityRenderDispatcher entityRenderDispatcher = Minecraft.getInstance().getEntityRenderDispatcher();

	public EntityPickupParticle(World world, Entity entity, Entity collector, float offsetY) {
		super(world, entity.x, entity.y, entity.z, entity.velocityX, entity.velocityY, entity.velocityZ);
		this.entity = entity;
		this.collector = collector;
		this.lifetime = 3;
		this.offsetY = offsetY;
	}

	@Override
	public void render(BufferBuilder bufferBuilder, Entity camera, float tickDelta, float dx, float dy, float dz, float forwards, float sideways) {
		float f = (this.age + tickDelta) / this.lifetime;
		f *= f;
		double d = this.entity.x;
		double e = this.entity.y;
		double g = this.entity.z;
		double h = this.collector.prevX + (this.collector.x - this.collector.prevX) * tickDelta;
		double i = this.collector.prevY + (this.collector.y - this.collector.prevY) * tickDelta + this.offsetY;
		double j = this.collector.prevZ + (this.collector.z - this.collector.prevZ) * tickDelta;
		double k = d + (h - d) * f;
		double l = e + (i - e) * f;
		double m = g + (j - g) * f;
		int n = this.getLightLevel(tickDelta);
		int o = n % 65536;
		int p = n / 65536;
		GLX.multiTexCoord2f(GLX.GL_TEXTURE1, o / 1.0F, p / 1.0F);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		k -= cameraX;
		l -= cameraY;
		m -= cameraZ;
		this.entityRenderDispatcher.render(this.entity, (float)k, (float)l, (float)m, this.entity.yaw, tickDelta);
	}

	@Override
	public void tick() {
		this.age++;
		if (this.age == this.lifetime) {
			this.remove();
		}
	}

	@Override
	public int getAtlasType() {
		return 3;
	}
}

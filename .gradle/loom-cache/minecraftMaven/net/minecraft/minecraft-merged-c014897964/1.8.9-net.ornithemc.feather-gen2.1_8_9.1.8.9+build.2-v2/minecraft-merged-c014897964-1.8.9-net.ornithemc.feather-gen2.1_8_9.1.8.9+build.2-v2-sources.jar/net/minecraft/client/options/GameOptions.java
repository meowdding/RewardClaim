package net.minecraft.client.options;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.chat.ChatGui;
import net.minecraft.client.render.model.PlayerModelPart;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.sound.SoundCategory;
import net.minecraft.client.twitch.Twitch;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.ClientSettingsC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Difficulty;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;

@Environment(EnvType.CLIENT)
public class GameOptions {
	private static final Logger LOGGER = LogManager.getLogger();
	private static final Gson GSON = new Gson();
	private static final ParameterizedType STRING_LIST_TYPE = new ParameterizedType() {
		@Override
		public Type[] getActualTypeArguments() {
			return new Type[]{String.class};
		}

		@Override
		public Type getRawType() {
			return List.class;
		}

		@Override
		public Type getOwnerType() {
			return null;
		}
	};
	private static final String[] GUI_SCALE_SETTINGS = new String[]{
		"options.guiScale.auto", "options.guiScale.small", "options.guiScale.normal", "options.guiScale.large"
	};
	private static final String[] PARTICLE_SETTINGS = new String[]{"options.particles.all", "options.particles.decreased", "options.particles.minimal"};
	private static final String[] AMBIENT_OCCLUSION_SETTINGS = new String[]{"options.ao.off", "options.ao.min", "options.ao.max"};
	private static final String[] STREAM_COMPRESSION_SETTINGS = new String[]{
		"options.stream.compression.low", "options.stream.compression.medium", "options.stream.compression.high"
	};
	private static final String[] STREAM_CHAT_ENABLED_SETTINGS = new String[]{
		"options.stream.chat.enabled.streaming", "options.stream.chat.enabled.always", "options.stream.chat.enabled.never"
	};
	private static final String[] STREAM_USER_FILTER_SETTINGS = new String[]{
		"options.stream.chat.userFilter.all", "options.stream.chat.userFilter.subs", "options.stream.chat.userFilter.mods"
	};
	private static final String[] STREAM_MIC_TOGGLE_SETTINGS = new String[]{"options.stream.mic_toggle.mute", "options.stream.mic_toggle.talk"};
	private static final String[] GRAPHICS_SETTINGS = new String[]{"options.off", "options.graphics.fast", "options.graphics.fancy"};
	public float mouseSensitivity = 0.5F;
	public boolean invertMouseY;
	public int viewDistance = -1;
	public boolean viewBobbing = true;
	public boolean anaglyph;
	public boolean fboEnable = true;
	public int fpsLimit = 120;
	public int cloudRenderMode = 2;
	public boolean fancyGraphics = true;
	public int ambientOcclusion = 2;
	public List<String> resourcePacks = Lists.newArrayList();
	public List<String> incompatibleResourcePacks = Lists.newArrayList();
	public PlayerEntity.ChatVisibility chatVisibility = PlayerEntity.ChatVisibility.FULL;
	public boolean chatColors = true;
	public boolean chatLinks = true;
	public boolean chatLinksPrompt = true;
	public float chatOpacity = 1.0F;
	public boolean snooperEnabled = true;
	public boolean fullscreen;
	public boolean vsync = true;
	public boolean useVbo = false;
	public boolean allowBlockAlternatives = true;
	public boolean reducedDebugInfo = false;
	public boolean hideServerAddress;
	public boolean advancedItemTooltips;
	public boolean pauseOnUnfocus = true;
	private final Set<PlayerModelPart> playerModelParts = Sets.newHashSet(PlayerModelPart.values());
	public boolean touchscreen;
	public int overrideWidth;
	public int overrideHeight;
	public boolean itemInHandTooltips = true;
	public float chatScale = 1.0F;
	public float chatWidth = 1.0F;
	public float unfocusedChatHeight = 0.44366196F;
	public float focusedChatHeight = 1.0F;
	public boolean showInventoryAchievementHint = true;
	public int mipmapLevels = 4;
	private Map<SoundCategory, Float> soundCategoryVolumes = Maps.newEnumMap(SoundCategory.class);
	public float streamBytesPerPixel = 0.5F;
	public float streamMicVolume = 1.0F;
	public float streamSystemVolume = 1.0F;
	public float streamKbps = 0.5412844F;
	public float streamFps = 0.31690142F;
	public int streamCompression = 1;
	public boolean streamSendMetadata = true;
	public String streamPreferredServer = "";
	public int streamChatEnabled = 0;
	public int streamChatUserFilter = 0;
	public int streamMicToggleBehavior = 0;
	public boolean useNativeTransport = true;
	public boolean entityShadows = true;
	public boolean realmsNotifications = true;
	public KeyBinding forwardKey = new KeyBinding("key.forward", 17, "key.categories.movement");
	public KeyBinding leftKey = new KeyBinding("key.left", 30, "key.categories.movement");
	public KeyBinding backKey = new KeyBinding("key.back", 31, "key.categories.movement");
	public KeyBinding rightKey = new KeyBinding("key.right", 32, "key.categories.movement");
	public KeyBinding jumpKey = new KeyBinding("key.jump", 57, "key.categories.movement");
	public KeyBinding sneakKey = new KeyBinding("key.sneak", 42, "key.categories.movement");
	public KeyBinding sprintKey = new KeyBinding("key.sprint", 29, "key.categories.movement");
	public KeyBinding inventoryKey = new KeyBinding("key.inventory", 18, "key.categories.inventory");
	public KeyBinding useKey = new KeyBinding("key.use", -99, "key.categories.gameplay");
	public KeyBinding dropKey = new KeyBinding("key.drop", 16, "key.categories.gameplay");
	public KeyBinding attackKey = new KeyBinding("key.attack", -100, "key.categories.gameplay");
	public KeyBinding pickItemKey = new KeyBinding("key.pickItem", -98, "key.categories.gameplay");
	public KeyBinding chatKey = new KeyBinding("key.chat", 20, "key.categories.multiplayer");
	public KeyBinding playerListKey = new KeyBinding("key.playerlist", 15, "key.categories.multiplayer");
	public KeyBinding commandKey = new KeyBinding("key.command", 53, "key.categories.multiplayer");
	public KeyBinding screenshotKey = new KeyBinding("key.screenshot", 60, "key.categories.misc");
	public KeyBinding togglePerspectiveKey = new KeyBinding("key.togglePerspective", 63, "key.categories.misc");
	public KeyBinding smoothCameraKey = new KeyBinding("key.smoothCamera", 0, "key.categories.misc");
	public KeyBinding fullscreenKey = new KeyBinding("key.fullscreen", 87, "key.categories.misc");
	public KeyBinding spectatorOutlinesKey = new KeyBinding("key.spectatorOutlines", 0, "key.categories.misc");
	public KeyBinding streamStartStopKey = new KeyBinding("key.streamStartStop", 64, "key.categories.stream");
	public KeyBinding streamPauseKey = new KeyBinding("key.streamPauseUnpause", 65, "key.categories.stream");
	public KeyBinding streamCommercialKey = new KeyBinding("key.streamCommercial", 0, "key.categories.stream");
	public KeyBinding streamToggleMicKey = new KeyBinding("key.streamToggleMic", 0, "key.categories.stream");
	public KeyBinding[] hotbarKeyBindings = new KeyBinding[]{
		new KeyBinding("key.hotbar.1", 2, "key.categories.inventory"),
		new KeyBinding("key.hotbar.2", 3, "key.categories.inventory"),
		new KeyBinding("key.hotbar.3", 4, "key.categories.inventory"),
		new KeyBinding("key.hotbar.4", 5, "key.categories.inventory"),
		new KeyBinding("key.hotbar.5", 6, "key.categories.inventory"),
		new KeyBinding("key.hotbar.6", 7, "key.categories.inventory"),
		new KeyBinding("key.hotbar.7", 8, "key.categories.inventory"),
		new KeyBinding("key.hotbar.8", 9, "key.categories.inventory"),
		new KeyBinding("key.hotbar.9", 10, "key.categories.inventory")
	};
	public KeyBinding[] keyBindings = ArrayUtils.addAll(
		new KeyBinding[]{
			this.attackKey,
			this.useKey,
			this.forwardKey,
			this.leftKey,
			this.backKey,
			this.rightKey,
			this.jumpKey,
			this.sneakKey,
			this.sprintKey,
			this.dropKey,
			this.inventoryKey,
			this.chatKey,
			this.playerListKey,
			this.pickItemKey,
			this.commandKey,
			this.screenshotKey,
			this.togglePerspectiveKey,
			this.smoothCameraKey,
			this.streamStartStopKey,
			this.streamPauseKey,
			this.streamCommercialKey,
			this.streamToggleMicKey,
			this.fullscreenKey,
			this.spectatorOutlinesKey
		},
		this.hotbarKeyBindings
	);
	protected Minecraft minecraft;
	private File file;
	public Difficulty difficulty = Difficulty.NORMAL;
	public boolean hideGui;
	/**
	 * Camera perspective (0 = first person, 1 = second person, 2 = third person)
	 */
	public int perspective;
	public boolean debugEnabled;
	public boolean debugProfilerEnabled;
	public boolean debugTpsEnabled;
	public String lastServer = "";
	public boolean smoothCamera;
	public boolean debugCamera;
	public float fov = 70.0F;
	public float gamma;
	public float saturation;
	public int guiScale;
	public int particles;
	public String language = "en_US";
	public boolean forceUnicodeFont = false;

	public GameOptions(Minecraft minecraft, File dir) {
		this.minecraft = minecraft;
		this.file = new File(dir, "options.txt");
		if (minecraft.is64Bit() && Runtime.getRuntime().maxMemory() >= 1000000000L) {
			GameOptions.Option.RENDER_DISTANCE.setMax(32.0F);
		} else {
			GameOptions.Option.RENDER_DISTANCE.setMax(16.0F);
		}

		this.viewDistance = minecraft.is64Bit() ? 12 : 8;
		this.load();
	}

	public GameOptions() {
	}

	public static String getKeyName(int keyCode) {
		if (keyCode < 0) {
			return I18n.translate("key.mouseButton", keyCode + 101);
		} else {
			return keyCode < 256 ? Keyboard.getKeyName(keyCode) : String.format("%c", (char)(keyCode - 256)).toUpperCase();
		}
	}

	public static boolean isPressed(KeyBinding keyBinding) {
		if (keyBinding.getKeyCode() == 0) {
			return false;
		} else {
			return keyBinding.getKeyCode() < 0 ? Mouse.isButtonDown(keyBinding.getKeyCode() + 100) : Keyboard.isKeyDown(keyBinding.getKeyCode());
		}
	}

	public void setKeyCode(KeyBinding keyBinding, int code) {
		keyBinding.setKeyCode(code);
		this.save();
	}

	public void set(GameOptions.Option option, float value) {
		if (option == GameOptions.Option.SENSITIVITY) {
			this.mouseSensitivity = value;
		}

		if (option == GameOptions.Option.FOV) {
			this.fov = value;
		}

		if (option == GameOptions.Option.GAMMA) {
			this.gamma = value;
		}

		if (option == GameOptions.Option.FRAMERATE_LIMIT) {
			this.fpsLimit = (int)value;
		}

		if (option == GameOptions.Option.CHAT_OPACITY) {
			this.chatOpacity = value;
			this.minecraft.gui.getChat().reset();
		}

		if (option == GameOptions.Option.CHAT_HEIGHT_FOCUSED) {
			this.focusedChatHeight = value;
			this.minecraft.gui.getChat().reset();
		}

		if (option == GameOptions.Option.CHAT_HEIGHT_UNFOCUSED) {
			this.unfocusedChatHeight = value;
			this.minecraft.gui.getChat().reset();
		}

		if (option == GameOptions.Option.CHAT_WIDTH) {
			this.chatWidth = value;
			this.minecraft.gui.getChat().reset();
		}

		if (option == GameOptions.Option.CHAT_SCALE) {
			this.chatScale = value;
			this.minecraft.gui.getChat().reset();
		}

		if (option == GameOptions.Option.MIPMAP_LEVELS) {
			int i = this.mipmapLevels;
			this.mipmapLevels = (int)value;
			if (i != value) {
				this.minecraft.getBlocksAtlas().setMaxMipLevel(this.mipmapLevels);
				this.minecraft.getTextureManager().bind(TextureAtlas.BLOCKS_LOCATION);
				this.minecraft.getBlocksAtlas().setFilter(false, this.mipmapLevels > 0);
				this.minecraft.submitResourceReload();
			}
		}

		if (option == GameOptions.Option.BLOCK_ALTERNATIVES) {
			this.allowBlockAlternatives = !this.allowBlockAlternatives;
			this.minecraft.worldRenderer.reload();
		}

		if (option == GameOptions.Option.RENDER_DISTANCE) {
			this.viewDistance = (int)value;
			this.minecraft.worldRenderer.onViewChanged();
		}

		if (option == GameOptions.Option.STREAM_BYTES_PER_PIXEL) {
			this.streamBytesPerPixel = value;
		}

		if (option == GameOptions.Option.STREAM_VOLUME_MIC) {
			this.streamMicVolume = value;
			this.minecraft.getTwitchStream().updateVolume();
		}

		if (option == GameOptions.Option.STREAM_VOLUME_SYSTEM) {
			this.streamSystemVolume = value;
			this.minecraft.getTwitchStream().updateVolume();
		}

		if (option == GameOptions.Option.STREAM_KBPS) {
			this.streamKbps = value;
		}

		if (option == GameOptions.Option.STREAM_FPS) {
			this.streamFps = value;
		}
	}

	public void set(GameOptions.Option option, int value) {
		if (option == GameOptions.Option.INVERT_MOUSE) {
			this.invertMouseY = !this.invertMouseY;
		}

		if (option == GameOptions.Option.GUI_SCALE) {
			this.guiScale = this.guiScale + value & 3;
		}

		if (option == GameOptions.Option.PARTICLES) {
			this.particles = (this.particles + value) % 3;
		}

		if (option == GameOptions.Option.VIEW_BOBBING) {
			this.viewBobbing = !this.viewBobbing;
		}

		if (option == GameOptions.Option.RENDER_CLOUDS) {
			this.cloudRenderMode = (this.cloudRenderMode + value) % 3;
		}

		if (option == GameOptions.Option.FORCE_UNICODE_FONT) {
			this.forceUnicodeFont = !this.forceUnicodeFont;
			this.minecraft.textRenderer.setUnicode(this.minecraft.getLanguageManager().isUnicode() || this.forceUnicodeFont);
		}

		if (option == GameOptions.Option.FBO_ENABLE) {
			this.fboEnable = !this.fboEnable;
		}

		if (option == GameOptions.Option.ANAGLYPH) {
			this.anaglyph = !this.anaglyph;
			this.minecraft.reloadResources();
		}

		if (option == GameOptions.Option.GRAPHICS) {
			this.fancyGraphics = !this.fancyGraphics;
			this.minecraft.worldRenderer.reload();
		}

		if (option == GameOptions.Option.AMBIENT_OCCLUSION) {
			this.ambientOcclusion = (this.ambientOcclusion + value) % 3;
			this.minecraft.worldRenderer.reload();
		}

		if (option == GameOptions.Option.CHAT_VISIBILITY) {
			this.chatVisibility = PlayerEntity.ChatVisibility.byIndex((this.chatVisibility.getIndex() + value) % 3);
		}

		if (option == GameOptions.Option.STREAM_COMPRESSION) {
			this.streamCompression = (this.streamCompression + value) % 3;
		}

		if (option == GameOptions.Option.STREAM_SEND_METADATA) {
			this.streamSendMetadata = !this.streamSendMetadata;
		}

		if (option == GameOptions.Option.STREAM_CHAT_ENABLED) {
			this.streamChatEnabled = (this.streamChatEnabled + value) % 3;
		}

		if (option == GameOptions.Option.STREAM_CHAT_USER_FILTER) {
			this.streamChatUserFilter = (this.streamChatUserFilter + value) % 3;
		}

		if (option == GameOptions.Option.STREAM_MIC_TOGGLE_BEHAVIOR) {
			this.streamMicToggleBehavior = (this.streamMicToggleBehavior + value) % 2;
		}

		if (option == GameOptions.Option.CHAT_COLOR) {
			this.chatColors = !this.chatColors;
		}

		if (option == GameOptions.Option.CHAT_LINKS) {
			this.chatLinks = !this.chatLinks;
		}

		if (option == GameOptions.Option.CHAT_LINKS_PROMPT) {
			this.chatLinksPrompt = !this.chatLinksPrompt;
		}

		if (option == GameOptions.Option.SNOOPER_ENABLED) {
			this.snooperEnabled = !this.snooperEnabled;
		}

		if (option == GameOptions.Option.TOUCHSCREEN) {
			this.touchscreen = !this.touchscreen;
		}

		if (option == GameOptions.Option.USE_FULLSCREEN) {
			this.fullscreen = !this.fullscreen;
			if (this.minecraft.isFullscreen() != this.fullscreen) {
				this.minecraft.toggleFullscreen();
			}
		}

		if (option == GameOptions.Option.ENABLE_VSYNC) {
			this.vsync = !this.vsync;
			Display.setVSyncEnabled(this.vsync);
		}

		if (option == GameOptions.Option.USE_VBO) {
			this.useVbo = !this.useVbo;
			this.minecraft.worldRenderer.reload();
		}

		if (option == GameOptions.Option.BLOCK_ALTERNATIVES) {
			this.allowBlockAlternatives = !this.allowBlockAlternatives;
			this.minecraft.worldRenderer.reload();
		}

		if (option == GameOptions.Option.REDUCED_DEBUG_INFO) {
			this.reducedDebugInfo = !this.reducedDebugInfo;
		}

		if (option == GameOptions.Option.ENTITY_SHADOWS) {
			this.entityShadows = !this.entityShadows;
		}

		if (option == GameOptions.Option.REALMS_NOTIFICATIONS) {
			this.realmsNotifications = !this.realmsNotifications;
		}

		this.save();
	}

	public float getFloat(GameOptions.Option option) {
		if (option == GameOptions.Option.FOV) {
			return this.fov;
		} else if (option == GameOptions.Option.GAMMA) {
			return this.gamma;
		} else if (option == GameOptions.Option.SATURATION) {
			return this.saturation;
		} else if (option == GameOptions.Option.SENSITIVITY) {
			return this.mouseSensitivity;
		} else if (option == GameOptions.Option.CHAT_OPACITY) {
			return this.chatOpacity;
		} else if (option == GameOptions.Option.CHAT_HEIGHT_FOCUSED) {
			return this.focusedChatHeight;
		} else if (option == GameOptions.Option.CHAT_HEIGHT_UNFOCUSED) {
			return this.unfocusedChatHeight;
		} else if (option == GameOptions.Option.CHAT_SCALE) {
			return this.chatScale;
		} else if (option == GameOptions.Option.CHAT_WIDTH) {
			return this.chatWidth;
		} else if (option == GameOptions.Option.FRAMERATE_LIMIT) {
			return this.fpsLimit;
		} else if (option == GameOptions.Option.MIPMAP_LEVELS) {
			return this.mipmapLevels;
		} else if (option == GameOptions.Option.RENDER_DISTANCE) {
			return this.viewDistance;
		} else if (option == GameOptions.Option.STREAM_BYTES_PER_PIXEL) {
			return this.streamBytesPerPixel;
		} else if (option == GameOptions.Option.STREAM_VOLUME_MIC) {
			return this.streamMicVolume;
		} else if (option == GameOptions.Option.STREAM_VOLUME_SYSTEM) {
			return this.streamSystemVolume;
		} else if (option == GameOptions.Option.STREAM_KBPS) {
			return this.streamKbps;
		} else {
			return option == GameOptions.Option.STREAM_FPS ? this.streamFps : 0.0F;
		}
	}

	public boolean getBoolean(GameOptions.Option option) {
		switch (option) {
			case INVERT_MOUSE:
				return this.invertMouseY;
			case VIEW_BOBBING:
				return this.viewBobbing;
			case ANAGLYPH:
				return this.anaglyph;
			case FBO_ENABLE:
				return this.fboEnable;
			case CHAT_COLOR:
				return this.chatColors;
			case CHAT_LINKS:
				return this.chatLinks;
			case CHAT_LINKS_PROMPT:
				return this.chatLinksPrompt;
			case SNOOPER_ENABLED:
				return this.snooperEnabled;
			case USE_FULLSCREEN:
				return this.fullscreen;
			case ENABLE_VSYNC:
				return this.vsync;
			case USE_VBO:
				return this.useVbo;
			case TOUCHSCREEN:
				return this.touchscreen;
			case STREAM_SEND_METADATA:
				return this.streamSendMetadata;
			case FORCE_UNICODE_FONT:
				return this.forceUnicodeFont;
			case BLOCK_ALTERNATIVES:
				return this.allowBlockAlternatives;
			case REDUCED_DEBUG_INFO:
				return this.reducedDebugInfo;
			case ENTITY_SHADOWS:
				return this.entityShadows;
			case REALMS_NOTIFICATIONS:
				return this.realmsNotifications;
			default:
				return false;
		}
	}

	private static String translateIntegerValue(String[] translationKeys, int value) {
		if (value < 0 || value >= translationKeys.length) {
			value = 0;
		}

		return I18n.translate(translationKeys[value]);
	}

	public String getAsString(GameOptions.Option option) {
		String string = I18n.translate(option.getName()) + ": ";
		if (option.isFloat()) {
			float f = this.getFloat(option);
			float g = option.normalize(f);
			if (option == GameOptions.Option.SENSITIVITY) {
				if (g == 0.0F) {
					return string + I18n.translate("options.sensitivity.min");
				} else {
					return g == 1.0F ? string + I18n.translate("options.sensitivity.max") : string + (int)(g * 200.0F) + "%";
				}
			} else if (option == GameOptions.Option.FOV) {
				if (f == 70.0F) {
					return string + I18n.translate("options.fov.min");
				} else {
					return f == 110.0F ? string + I18n.translate("options.fov.max") : string + (int)f;
				}
			} else {
				if (option == GameOptions.Option.FRAMERATE_LIMIT) {
					return f == option.max ? string + I18n.translate("options.framerateLimit.max") : string + (int)f + " fps";
				}

				if (option == GameOptions.Option.RENDER_CLOUDS) {
					return f == option.min ? string + I18n.translate("options.cloudHeight.min") : string + ((int)f + 128);
				}

				if (option == GameOptions.Option.GAMMA) {
					if (g == 0.0F) {
						return string + I18n.translate("options.gamma.min");
					} else {
						return g == 1.0F ? string + I18n.translate("options.gamma.max") : string + "+" + (int)(g * 100.0F) + "%";
					}
				} else if (option == GameOptions.Option.SATURATION) {
					return string + (int)(g * 400.0F) + "%";
				} else if (option == GameOptions.Option.CHAT_OPACITY) {
					return string + (int)(g * 90.0F + 10.0F) + "%";
				} else if (option == GameOptions.Option.CHAT_HEIGHT_UNFOCUSED) {
					return string + ChatGui.getHeight(g) + "px";
				} else if (option == GameOptions.Option.CHAT_HEIGHT_FOCUSED) {
					return string + ChatGui.getHeight(g) + "px";
				} else if (option == GameOptions.Option.CHAT_WIDTH) {
					return string + ChatGui.getWidth(g) + "px";
				} else if (option == GameOptions.Option.RENDER_DISTANCE) {
					return string + (int)f + " chunks";
				} else if (option == GameOptions.Option.MIPMAP_LEVELS) {
					return f == 0.0F ? string + I18n.translate("options.off") : string + (int)f;
				} else if (option == GameOptions.Option.STREAM_FPS) {
					return string + Twitch.m_07155626(g) + " fps";
				} else if (option == GameOptions.Option.STREAM_KBPS) {
					return string + Twitch.m_19819309(g) + " Kbps";
				} else if (option == GameOptions.Option.STREAM_BYTES_PER_PIXEL) {
					return string + String.format("%.3f bpp", Twitch.m_70909363(g));
				} else {
					return g == 0.0F ? string + I18n.translate("options.off") : string + (int)(g * 100.0F) + "%";
				}
			}
		} else {
			if (option.isBoolean()) {
				boolean bl = this.getBoolean(option);
				return bl ? string + I18n.translate("options.on") : string + I18n.translate("options.off");
			}

			if (option == GameOptions.Option.GUI_SCALE) {
				return string + translateIntegerValue(GUI_SCALE_SETTINGS, this.guiScale);
			}

			if (option == GameOptions.Option.CHAT_VISIBILITY) {
				return string + I18n.translate(this.chatVisibility.getId());
			}

			if (option == GameOptions.Option.PARTICLES) {
				return string + translateIntegerValue(PARTICLE_SETTINGS, this.particles);
			}

			if (option == GameOptions.Option.AMBIENT_OCCLUSION) {
				return string + translateIntegerValue(AMBIENT_OCCLUSION_SETTINGS, this.ambientOcclusion);
			}

			if (option == GameOptions.Option.STREAM_COMPRESSION) {
				return string + translateIntegerValue(STREAM_COMPRESSION_SETTINGS, this.streamCompression);
			}

			if (option == GameOptions.Option.STREAM_CHAT_ENABLED) {
				return string + translateIntegerValue(STREAM_CHAT_ENABLED_SETTINGS, this.streamChatEnabled);
			}

			if (option == GameOptions.Option.STREAM_CHAT_USER_FILTER) {
				return string + translateIntegerValue(STREAM_USER_FILTER_SETTINGS, this.streamChatUserFilter);
			}

			if (option == GameOptions.Option.STREAM_MIC_TOGGLE_BEHAVIOR) {
				return string + translateIntegerValue(STREAM_MIC_TOGGLE_SETTINGS, this.streamMicToggleBehavior);
			}

			if (option == GameOptions.Option.RENDER_CLOUDS) {
				return string + translateIntegerValue(GRAPHICS_SETTINGS, this.cloudRenderMode);
			}

			if (option == GameOptions.Option.GRAPHICS) {
				if (this.fancyGraphics) {
					return string + I18n.translate("options.graphics.fancy");
				}

				String string2 = "options.graphics.fast";
				return string + I18n.translate("options.graphics.fast");
			} else {
				return string;
			}
		}
	}

	public void load() {
		try {
			if (!this.file.exists()) {
				return;
			}

			BufferedReader bufferedReader = new BufferedReader(new FileReader(this.file));
			String string = "";
			this.soundCategoryVolumes.clear();

			while ((string = bufferedReader.readLine()) != null) {
				try {
					String[] strings = string.split(":");
					if (strings[0].equals("mouseSensitivity")) {
						this.mouseSensitivity = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("fov")) {
						this.fov = this.parseFloat(strings[1]) * 40.0F + 70.0F;
					}

					if (strings[0].equals("gamma")) {
						this.gamma = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("saturation")) {
						this.saturation = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("invertYMouse")) {
						this.invertMouseY = strings[1].equals("true");
					}

					if (strings[0].equals("renderDistance")) {
						this.viewDistance = Integer.parseInt(strings[1]);
					}

					if (strings[0].equals("guiScale")) {
						this.guiScale = Integer.parseInt(strings[1]);
					}

					if (strings[0].equals("particles")) {
						this.particles = Integer.parseInt(strings[1]);
					}

					if (strings[0].equals("bobView")) {
						this.viewBobbing = strings[1].equals("true");
					}

					if (strings[0].equals("anaglyph3d")) {
						this.anaglyph = strings[1].equals("true");
					}

					if (strings[0].equals("maxFps")) {
						this.fpsLimit = Integer.parseInt(strings[1]);
					}

					if (strings[0].equals("fboEnable")) {
						this.fboEnable = strings[1].equals("true");
					}

					if (strings[0].equals("difficulty")) {
						this.difficulty = Difficulty.byId(Integer.parseInt(strings[1]));
					}

					if (strings[0].equals("fancyGraphics")) {
						this.fancyGraphics = strings[1].equals("true");
					}

					if (strings[0].equals("ao")) {
						if (strings[1].equals("true")) {
							this.ambientOcclusion = 2;
						} else if (strings[1].equals("false")) {
							this.ambientOcclusion = 0;
						} else {
							this.ambientOcclusion = Integer.parseInt(strings[1]);
						}
					}

					if (strings[0].equals("renderClouds")) {
						if (strings[1].equals("true")) {
							this.cloudRenderMode = 2;
						} else if (strings[1].equals("false")) {
							this.cloudRenderMode = 0;
						} else if (strings[1].equals("fast")) {
							this.cloudRenderMode = 1;
						}
					}

					if (strings[0].equals("resourcePacks")) {
						this.resourcePacks = GSON.fromJson(string.substring(string.indexOf(58) + 1), STRING_LIST_TYPE);
						if (this.resourcePacks == null) {
							this.resourcePacks = Lists.newArrayList();
						}
					}

					if (strings[0].equals("incompatibleResourcePacks")) {
						this.incompatibleResourcePacks = GSON.fromJson(string.substring(string.indexOf(58) + 1), STRING_LIST_TYPE);
						if (this.incompatibleResourcePacks == null) {
							this.incompatibleResourcePacks = Lists.newArrayList();
						}
					}

					if (strings[0].equals("lastServer") && strings.length >= 2) {
						this.lastServer = string.substring(string.indexOf(58) + 1);
					}

					if (strings[0].equals("lang") && strings.length >= 2) {
						this.language = strings[1];
					}

					if (strings[0].equals("chatVisibility")) {
						this.chatVisibility = PlayerEntity.ChatVisibility.byIndex(Integer.parseInt(strings[1]));
					}

					if (strings[0].equals("chatColors")) {
						this.chatColors = strings[1].equals("true");
					}

					if (strings[0].equals("chatLinks")) {
						this.chatLinks = strings[1].equals("true");
					}

					if (strings[0].equals("chatLinksPrompt")) {
						this.chatLinksPrompt = strings[1].equals("true");
					}

					if (strings[0].equals("chatOpacity")) {
						this.chatOpacity = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("snooperEnabled")) {
						this.snooperEnabled = strings[1].equals("true");
					}

					if (strings[0].equals("fullscreen")) {
						this.fullscreen = strings[1].equals("true");
					}

					if (strings[0].equals("enableVsync")) {
						this.vsync = strings[1].equals("true");
					}

					if (strings[0].equals("useVbo")) {
						this.useVbo = strings[1].equals("true");
					}

					if (strings[0].equals("hideServerAddress")) {
						this.hideServerAddress = strings[1].equals("true");
					}

					if (strings[0].equals("advancedItemTooltips")) {
						this.advancedItemTooltips = strings[1].equals("true");
					}

					if (strings[0].equals("pauseOnLostFocus")) {
						this.pauseOnUnfocus = strings[1].equals("true");
					}

					if (strings[0].equals("touchscreen")) {
						this.touchscreen = strings[1].equals("true");
					}

					if (strings[0].equals("overrideHeight")) {
						this.overrideHeight = Integer.parseInt(strings[1]);
					}

					if (strings[0].equals("overrideWidth")) {
						this.overrideWidth = Integer.parseInt(strings[1]);
					}

					if (strings[0].equals("heldItemTooltips")) {
						this.itemInHandTooltips = strings[1].equals("true");
					}

					if (strings[0].equals("chatHeightFocused")) {
						this.focusedChatHeight = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("chatHeightUnfocused")) {
						this.unfocusedChatHeight = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("chatScale")) {
						this.chatScale = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("chatWidth")) {
						this.chatWidth = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("showInventoryAchievementHint")) {
						this.showInventoryAchievementHint = strings[1].equals("true");
					}

					if (strings[0].equals("mipmapLevels")) {
						this.mipmapLevels = Integer.parseInt(strings[1]);
					}

					if (strings[0].equals("streamBytesPerPixel")) {
						this.streamBytesPerPixel = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("streamMicVolume")) {
						this.streamMicVolume = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("streamSystemVolume")) {
						this.streamSystemVolume = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("streamKbps")) {
						this.streamKbps = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("streamFps")) {
						this.streamFps = this.parseFloat(strings[1]);
					}

					if (strings[0].equals("streamCompression")) {
						this.streamCompression = Integer.parseInt(strings[1]);
					}

					if (strings[0].equals("streamSendMetadata")) {
						this.streamSendMetadata = strings[1].equals("true");
					}

					if (strings[0].equals("streamPreferredServer") && strings.length >= 2) {
						this.streamPreferredServer = string.substring(string.indexOf(58) + 1);
					}

					if (strings[0].equals("streamChatEnabled")) {
						this.streamChatEnabled = Integer.parseInt(strings[1]);
					}

					if (strings[0].equals("streamChatUserFilter")) {
						this.streamChatUserFilter = Integer.parseInt(strings[1]);
					}

					if (strings[0].equals("streamMicToggleBehavior")) {
						this.streamMicToggleBehavior = Integer.parseInt(strings[1]);
					}

					if (strings[0].equals("forceUnicodeFont")) {
						this.forceUnicodeFont = strings[1].equals("true");
					}

					if (strings[0].equals("allowBlockAlternatives")) {
						this.allowBlockAlternatives = strings[1].equals("true");
					}

					if (strings[0].equals("reducedDebugInfo")) {
						this.reducedDebugInfo = strings[1].equals("true");
					}

					if (strings[0].equals("useNativeTransport")) {
						this.useNativeTransport = strings[1].equals("true");
					}

					if (strings[0].equals("entityShadows")) {
						this.entityShadows = strings[1].equals("true");
					}

					if (strings[0].equals("realmsNotifications")) {
						this.realmsNotifications = strings[1].equals("true");
					}

					for (KeyBinding keyBinding : this.keyBindings) {
						if (strings[0].equals("key_" + keyBinding.getName())) {
							keyBinding.setKeyCode(Integer.parseInt(strings[1]));
						}
					}

					for (SoundCategory soundCategory : SoundCategory.values()) {
						if (strings[0].equals("soundCategory_" + soundCategory.getName())) {
							this.soundCategoryVolumes.put(soundCategory, this.parseFloat(strings[1]));
						}
					}

					for (PlayerModelPart playerModelPart : PlayerModelPart.values()) {
						if (strings[0].equals("modelPart_" + playerModelPart.getKey())) {
							this.setPlayerModelPart(playerModelPart, strings[1].equals("true"));
						}
					}
				} catch (Exception exception) {
					LOGGER.warn("Skipping bad option: " + string);
				}
			}

			KeyBinding.resetMapping();
			bufferedReader.close();
		} catch (Exception exception2) {
			LOGGER.error("Failed to load options", exception2);
		}
	}

	private float parseFloat(String s) {
		if (s.equals("true")) {
			return 1.0F;
		} else {
			return s.equals("false") ? 0.0F : Float.parseFloat(s);
		}
	}

	public void save() {
		try {
			PrintWriter printWriter = new PrintWriter(new FileWriter(this.file));
			printWriter.println("invertYMouse:" + this.invertMouseY);
			printWriter.println("mouseSensitivity:" + this.mouseSensitivity);
			printWriter.println("fov:" + (this.fov - 70.0F) / 40.0F);
			printWriter.println("gamma:" + this.gamma);
			printWriter.println("saturation:" + this.saturation);
			printWriter.println("renderDistance:" + this.viewDistance);
			printWriter.println("guiScale:" + this.guiScale);
			printWriter.println("particles:" + this.particles);
			printWriter.println("bobView:" + this.viewBobbing);
			printWriter.println("anaglyph3d:" + this.anaglyph);
			printWriter.println("maxFps:" + this.fpsLimit);
			printWriter.println("fboEnable:" + this.fboEnable);
			printWriter.println("difficulty:" + this.difficulty.getId());
			printWriter.println("fancyGraphics:" + this.fancyGraphics);
			printWriter.println("ao:" + this.ambientOcclusion);
			switch (this.cloudRenderMode) {
				case 0:
					printWriter.println("renderClouds:false");
					break;
				case 1:
					printWriter.println("renderClouds:fast");
					break;
				case 2:
					printWriter.println("renderClouds:true");
			}

			printWriter.println("resourcePacks:" + GSON.toJson(this.resourcePacks));
			printWriter.println("incompatibleResourcePacks:" + GSON.toJson(this.incompatibleResourcePacks));
			printWriter.println("lastServer:" + this.lastServer);
			printWriter.println("lang:" + this.language);
			printWriter.println("chatVisibility:" + this.chatVisibility.getIndex());
			printWriter.println("chatColors:" + this.chatColors);
			printWriter.println("chatLinks:" + this.chatLinks);
			printWriter.println("chatLinksPrompt:" + this.chatLinksPrompt);
			printWriter.println("chatOpacity:" + this.chatOpacity);
			printWriter.println("snooperEnabled:" + this.snooperEnabled);
			printWriter.println("fullscreen:" + this.fullscreen);
			printWriter.println("enableVsync:" + this.vsync);
			printWriter.println("useVbo:" + this.useVbo);
			printWriter.println("hideServerAddress:" + this.hideServerAddress);
			printWriter.println("advancedItemTooltips:" + this.advancedItemTooltips);
			printWriter.println("pauseOnLostFocus:" + this.pauseOnUnfocus);
			printWriter.println("touchscreen:" + this.touchscreen);
			printWriter.println("overrideWidth:" + this.overrideWidth);
			printWriter.println("overrideHeight:" + this.overrideHeight);
			printWriter.println("heldItemTooltips:" + this.itemInHandTooltips);
			printWriter.println("chatHeightFocused:" + this.focusedChatHeight);
			printWriter.println("chatHeightUnfocused:" + this.unfocusedChatHeight);
			printWriter.println("chatScale:" + this.chatScale);
			printWriter.println("chatWidth:" + this.chatWidth);
			printWriter.println("showInventoryAchievementHint:" + this.showInventoryAchievementHint);
			printWriter.println("mipmapLevels:" + this.mipmapLevels);
			printWriter.println("streamBytesPerPixel:" + this.streamBytesPerPixel);
			printWriter.println("streamMicVolume:" + this.streamMicVolume);
			printWriter.println("streamSystemVolume:" + this.streamSystemVolume);
			printWriter.println("streamKbps:" + this.streamKbps);
			printWriter.println("streamFps:" + this.streamFps);
			printWriter.println("streamCompression:" + this.streamCompression);
			printWriter.println("streamSendMetadata:" + this.streamSendMetadata);
			printWriter.println("streamPreferredServer:" + this.streamPreferredServer);
			printWriter.println("streamChatEnabled:" + this.streamChatEnabled);
			printWriter.println("streamChatUserFilter:" + this.streamChatUserFilter);
			printWriter.println("streamMicToggleBehavior:" + this.streamMicToggleBehavior);
			printWriter.println("forceUnicodeFont:" + this.forceUnicodeFont);
			printWriter.println("allowBlockAlternatives:" + this.allowBlockAlternatives);
			printWriter.println("reducedDebugInfo:" + this.reducedDebugInfo);
			printWriter.println("useNativeTransport:" + this.useNativeTransport);
			printWriter.println("entityShadows:" + this.entityShadows);
			printWriter.println("realmsNotifications:" + this.realmsNotifications);

			for (KeyBinding keyBinding : this.keyBindings) {
				printWriter.println("key_" + keyBinding.getName() + ":" + keyBinding.getKeyCode());
			}

			for (SoundCategory soundCategory : SoundCategory.values()) {
				printWriter.println("soundCategory_" + soundCategory.getName() + ":" + this.getSoundCategoryVolume(soundCategory));
			}

			for (PlayerModelPart playerModelPart : PlayerModelPart.values()) {
				printWriter.println("modelPart_" + playerModelPart.getKey() + ":" + this.playerModelParts.contains(playerModelPart));
			}

			printWriter.close();
		} catch (Exception exception) {
			LOGGER.error("Failed to save options", exception);
		}

		this.syncClientSettings();
	}

	public float getSoundCategoryVolume(SoundCategory category) {
		return this.soundCategoryVolumes.containsKey(category) ? this.soundCategoryVolumes.get(category) : 1.0F;
	}

	public void setSoundCategoryVolume(SoundCategory category, float volume) {
		this.minecraft.getSoundManager().setVolume(category, volume);
		this.soundCategoryVolumes.put(category, volume);
	}

	public void syncClientSettings() {
		if (this.minecraft.player != null) {
			int i = 0;

			for (PlayerModelPart playerModelPart : this.playerModelParts) {
				i |= playerModelPart.getFlag();
			}

			this.minecraft.player.networkHandler.sendPacket(new ClientSettingsC2SPacket(this.language, this.viewDistance, this.chatVisibility, this.chatColors, i));
		}
	}

	public Set<PlayerModelPart> getPlayerModelParts() {
		return ImmutableSet.copyOf(this.playerModelParts);
	}

	public void setPlayerModelPart(PlayerModelPart part, boolean enable) {
		if (enable) {
			this.playerModelParts.add(part);
		} else {
			this.playerModelParts.remove(part);
		}

		this.syncClientSettings();
	}

	public void togglePlayerModelPart(PlayerModelPart part) {
		if (!this.getPlayerModelParts().contains(part)) {
			this.playerModelParts.add(part);
		} else {
			this.playerModelParts.remove(part);
		}

		this.syncClientSettings();
	}

	public int getCloudRenderMode() {
		return this.viewDistance >= 4 ? this.cloudRenderMode : 0;
	}

	public boolean shouldUseNativeTransport() {
		return this.useNativeTransport;
	}

	@Environment(EnvType.CLIENT)
	public enum Option {
		INVERT_MOUSE("options.invertMouse", false, true),
		SENSITIVITY("options.sensitivity", true, false),
		FOV("options.fov", true, false, 30.0F, 110.0F, 1.0F),
		GAMMA("options.gamma", true, false),
		SATURATION("options.saturation", true, false),
		RENDER_DISTANCE("options.renderDistance", true, false, 2.0F, 16.0F, 1.0F),
		VIEW_BOBBING("options.viewBobbing", false, true),
		ANAGLYPH("options.anaglyph", false, true),
		FRAMERATE_LIMIT("options.framerateLimit", true, false, 10.0F, 260.0F, 10.0F),
		FBO_ENABLE("options.fboEnable", false, true),
		RENDER_CLOUDS("options.renderClouds", false, false),
		GRAPHICS("options.graphics", false, false),
		AMBIENT_OCCLUSION("options.ao", false, false),
		GUI_SCALE("options.guiScale", false, false),
		PARTICLES("options.particles", false, false),
		CHAT_VISIBILITY("options.chat.visibility", false, false),
		CHAT_COLOR("options.chat.color", false, true),
		CHAT_LINKS("options.chat.links", false, true),
		CHAT_OPACITY("options.chat.opacity", true, false),
		CHAT_LINKS_PROMPT("options.chat.links.prompt", false, true),
		SNOOPER_ENABLED("options.snooper", false, true),
		USE_FULLSCREEN("options.fullscreen", false, true),
		ENABLE_VSYNC("options.vsync", false, true),
		USE_VBO("options.vbo", false, true),
		TOUCHSCREEN("options.touchscreen", false, true),
		CHAT_SCALE("options.chat.scale", true, false),
		CHAT_WIDTH("options.chat.width", true, false),
		CHAT_HEIGHT_FOCUSED("options.chat.height.focused", true, false),
		CHAT_HEIGHT_UNFOCUSED("options.chat.height.unfocused", true, false),
		MIPMAP_LEVELS("options.mipmapLevels", true, false, 0.0F, 4.0F, 1.0F),
		FORCE_UNICODE_FONT("options.forceUnicodeFont", false, true),
		STREAM_BYTES_PER_PIXEL("options.stream.bytesPerPixel", true, false),
		STREAM_VOLUME_MIC("options.stream.micVolumne", true, false),
		STREAM_VOLUME_SYSTEM("options.stream.systemVolume", true, false),
		STREAM_KBPS("options.stream.kbps", true, false),
		STREAM_FPS("options.stream.fps", true, false),
		STREAM_COMPRESSION("options.stream.compression", false, false),
		STREAM_SEND_METADATA("options.stream.sendMetadata", false, true),
		STREAM_CHAT_ENABLED("options.stream.chat.enabled", false, false),
		STREAM_CHAT_USER_FILTER("options.stream.chat.userFilter", false, false),
		STREAM_MIC_TOGGLE_BEHAVIOR("options.stream.micToggleBehavior", false, false),
		BLOCK_ALTERNATIVES("options.blockAlternatives", false, true),
		REDUCED_DEBUG_INFO("options.reducedDebugInfo", false, true),
		ENTITY_SHADOWS("options.entityShadows", false, true),
		REALMS_NOTIFICATIONS("options.realmsNotifications", false, true);

		private final boolean isFloat;
		private final boolean isBoolean;
		private final String name;
		private final float step;
		private float min;
		private float max;

		public static GameOptions.Option byId(int id) {
			for (GameOptions.Option option : values()) {
				if (option.getId() == id) {
					return option;
				}
			}

			return null;
		}

		Option(String name, boolean isFloat, boolean isBoolean) {
			this(name, isFloat, isBoolean, 0.0F, 1.0F, 0.0F);
		}

		Option(String name, boolean isFloat, boolean isBoolean, float min, float max, float step) {
			this.name = name;
			this.isFloat = isFloat;
			this.isBoolean = isBoolean;
			this.min = min;
			this.max = max;
			this.step = step;
		}

		public boolean isFloat() {
			return this.isFloat;
		}

		public boolean isBoolean() {
			return this.isBoolean;
		}

		public int getId() {
			return this.ordinal();
		}

		public String getName() {
			return this.name;
		}

		public float getMax() {
			return this.max;
		}

		public void setMax(float value) {
			this.max = value;
		}

		public float normalize(float value) {
			return MathHelper.clamp((this.clampAndRoundToStepMultiple(value) - this.min) / (this.max - this.min), 0.0F, 1.0F);
		}

		public float denormalize(float value) {
			return this.clampAndRoundToStepMultiple(this.min + (this.max - this.min) * MathHelper.clamp(value, 0.0F, 1.0F));
		}

		public float clampAndRoundToStepMultiple(float value) {
			value = this.roundToStepMultiple(value);
			return MathHelper.clamp(value, this.min, this.max);
		}

		protected float roundToStepMultiple(float value) {
			if (this.step > 0.0F) {
				value = this.step * Math.round(value / this.step);
			}

			return value;
		}
	}
}

package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.block.BlockRenderDispatcher;
import net.minecraft.client.render.entity.EndermanRenderer;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.entity.living.mob.monster.EndermanEntity;

@Environment(EnvType.CLIENT)
public class EndermanCarriedBlockLayer implements EntityRenderLayer<EndermanEntity> {
	private final EndermanRenderer parent;

	public EndermanCarriedBlockLayer(EndermanRenderer parent) {
		this.parent = parent;
	}

	public void render(
		EndermanEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale
	) {
		BlockState blockState = entity.getCarriedBlock();
		if (blockState.getBlock().getMaterial() != Material.AIR) {
			BlockRenderDispatcher blockRenderDispatcher = Minecraft.getInstance().getBlockRenderDispatcher();
			GlStateManager.enableRescaleNormal();
			GlStateManager.pushMatrix();
			GlStateManager.translatef(0.0F, 0.6875F, -0.75F);
			GlStateManager.rotatef(20.0F, 1.0F, 0.0F, 0.0F);
			GlStateManager.rotatef(45.0F, 0.0F, 1.0F, 0.0F);
			GlStateManager.translatef(0.25F, 0.1875F, 0.25F);
			float f = 0.5F;
			GlStateManager.scalef(-f, -f, f);
			int i = entity.getLightLevel(tickDelta);
			int j = i % 65536;
			int k = i / 65536;
			GLX.multiTexCoord2f(GLX.GL_TEXTURE1, j / 1.0F, k / 1.0F);
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			this.parent.bindTexture(TextureAtlas.BLOCKS_LOCATION);
			blockRenderDispatcher.renderAsItem(blockState, 1.0F);
			GlStateManager.popMatrix();
			GlStateManager.disableRescaleNormal();
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

package net.minecraft.client.render.math;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Vector3d {
	public double x;
	public double y;
	public double z;

	public Vector3d() {
		this.x = this.y = this.z = 0.0;
	}
}

package net.minecraft.block;

import java.util.List;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.client.render.block.BlockLayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.ornithemc.feather.constants.SetBlockFlags;

public class TripwireBlock extends Block {
	public static final BooleanProperty POWERED = BooleanProperty.of("powered");
	public static final BooleanProperty SUSPENDED = BooleanProperty.of("suspended");
	public static final BooleanProperty ATTACHED = BooleanProperty.of("attached");
	public static final BooleanProperty DISARMED = BooleanProperty.of("disarmed");
	public static final BooleanProperty NORTH = BooleanProperty.of("north");
	public static final BooleanProperty EAST = BooleanProperty.of("east");
	public static final BooleanProperty SOUTH = BooleanProperty.of("south");
	public static final BooleanProperty WEST = BooleanProperty.of("west");

	public TripwireBlock() {
		super(Material.DECORATION);
		this.setDefaultState(
			this.stateDefinition
				.any()
				.set(POWERED, false)
				.set(SUSPENDED, false)
				.set(ATTACHED, false)
				.set(DISARMED, false)
				.set(NORTH, false)
				.set(EAST, false)
				.set(SOUTH, false)
				.set(WEST, false)
		);
		this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 0.15625F, 1.0F);
		this.setTicksRandomly(true);
	}

	@Override
	public BlockState resolveVirtualProperties(BlockState state, WorldView world, BlockPos pos) {
		return state.set(NORTH, shouldConnectTo(world, pos, state, Direction.NORTH))
			.set(EAST, shouldConnectTo(world, pos, state, Direction.EAST))
			.set(SOUTH, shouldConnectTo(world, pos, state, Direction.SOUTH))
			.set(WEST, shouldConnectTo(world, pos, state, Direction.WEST));
	}

	@Override
	public Box getCollisionShape(World world, BlockPos pos, BlockState state) {
		return null;
	}

	@Override
	public boolean isSolidRender() {
		return false;
	}

	@Override
	public boolean isCube() {
		return false;
	}

	@Environment(EnvType.CLIENT)
	@Override
	public BlockLayer getRenderLayer() {
		return BlockLayer.TRANSLUCENT;
	}

	@Override
	public Item getDropItem(BlockState state, Random random, int fortuneLevel) {
		return Items.STRING;
	}

	@Environment(EnvType.CLIENT)
	@Override
	public Item getPickItem(World world, BlockPos pos) {
		return Items.STRING;
	}

	@Override
	public void neighborChanged(World world, BlockPos pos, BlockState state, Block neighborBlock) {
		boolean bl = state.get(SUSPENDED);
		boolean bl2 = !World.hasSolidTop(world, pos.down());
		if (bl != bl2) {
			this.dropItems(world, pos, state, 0);
			world.removeBlock(pos);
		}
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		BlockState blockState = world.getBlockState(pos);
		boolean bl = blockState.get(ATTACHED);
		boolean bl2 = blockState.get(SUSPENDED);
		if (!bl2) {
			this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 0.09375F, 1.0F);
		} else if (!bl) {
			this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
		} else {
			this.setShape(0.0F, 0.0625F, 0.0F, 1.0F, 0.15625F, 1.0F);
		}
	}

	@Override
	public void onAdded(World world, BlockPos pos, BlockState state) {
		state = state.set(SUSPENDED, !World.hasSolidTop(world, pos.down()));
		world.setBlockState(pos, state, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
		this.updateTripwireHooks(world, pos, state);
	}

	@Override
	public void onRemoved(World world, BlockPos pos, BlockState state) {
		this.updateTripwireHooks(world, pos, state.set(POWERED, true));
	}

	@Override
	public void beforeMinedByPlayer(World world, BlockPos pos, BlockState state, PlayerEntity player) {
		if (!world.isClient) {
			if (player.getItemInHand() != null && player.getItemInHand().getItem() == Items.SHEARS) {
				world.setBlockState(pos, state.set(DISARMED, true), SetBlockFlags.NO_REDRAW);
			}
		}
	}

	private void updateTripwireHooks(World world, BlockPos pos, BlockState state) {
		for (Direction direction : new Direction[]{Direction.SOUTH, Direction.WEST}) {
			for (int k = 1; k < 42; k++) {
				BlockPos blockPos = pos.offset(direction, k);
				BlockState blockState = world.getBlockState(blockPos);
				if (blockState.getBlock() == Blocks.TRIPWIRE_HOOK) {
					if (blockState.get(TripwireHookBlock.FACING) == direction.getOpposite()) {
						Blocks.TRIPWIRE_HOOK.updateState(world, blockPos, blockState, false, true, k, state);
					}
					break;
				}

				if (blockState.getBlock() != Blocks.TRIPWIRE) {
					break;
				}
			}
		}
	}

	@Override
	public void onEntityCollision(World world, BlockPos pos, BlockState state, Entity entity) {
		if (!world.isClient) {
			if (!state.get(POWERED)) {
				this.updateOutputState(world, pos);
			}
		}
	}

	@Override
	public void randomTick(World world, BlockPos pos, BlockState state, Random random) {
	}

	@Override
	public void tick(World world, BlockPos pos, BlockState state, Random random) {
		if (!world.isClient) {
			if (world.getBlockState(pos).get(POWERED)) {
				this.updateOutputState(world, pos);
			}
		}
	}

	private void updateOutputState(World world, BlockPos pos) {
		BlockState blockState = world.getBlockState(pos);
		boolean bl = blockState.get(POWERED);
		boolean bl2 = false;
		List<? extends Entity> list = world.getEntities(
			null,
			new Box(pos.getX() + this.minX, pos.getY() + this.minY, pos.getZ() + this.minZ, pos.getX() + this.maxX, pos.getY() + this.maxY, pos.getZ() + this.maxZ)
		);
		if (!list.isEmpty()) {
			for (Entity entity : list) {
				if (!entity.canAvoidTraps()) {
					bl2 = true;
					break;
				}
			}
		}

		if (bl2 != bl) {
			blockState = blockState.set(POWERED, bl2);
			world.setBlockState(pos, blockState, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
			this.updateTripwireHooks(world, pos, blockState);
		}

		if (bl2) {
			world.scheduleTick(pos, this, this.getTickRate(world));
		}
	}

	public static boolean shouldConnectTo(WorldView world, BlockPos pos, BlockState state, Direction dir) {
		BlockPos blockPos = pos.offset(dir);
		BlockState blockState = world.getBlockState(blockPos);
		Block block = blockState.getBlock();
		if (block == Blocks.TRIPWIRE_HOOK) {
			Direction direction = dir.getOpposite();
			return blockState.get(TripwireHookBlock.FACING) == direction;
		} else if (block == Blocks.TRIPWIRE) {
			boolean bl = state.get(SUSPENDED);
			boolean bl2 = blockState.get(SUSPENDED);
			return bl == bl2;
		} else {
			return false;
		}
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		return this.defaultState()
			.set(POWERED, (metadata & 1) > 0)
			.set(SUSPENDED, (metadata & 2) > 0)
			.set(ATTACHED, (metadata & 4) > 0)
			.set(DISARMED, (metadata & 8) > 0);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		int i = 0;
		if (state.get(POWERED)) {
			i |= 1;
		}

		if (state.get(SUSPENDED)) {
			i |= 2;
		}

		if (state.get(ATTACHED)) {
			i |= 4;
		}

		if (state.get(DISARMED)) {
			i |= 8;
		}

		return i;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, POWERED, SUSPENDED, ATTACHED, DISARMED, NORTH, EAST, WEST, SOUTH);
	}
}

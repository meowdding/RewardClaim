package net.minecraft.block;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityProvider;
import net.minecraft.block.entity.MovingBlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.block.piston.PistonMoveStructureResolver;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.block.state.property.DirectionProperty;
import net.minecraft.entity.Entity;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.ornithemc.feather.constants.SetBlockFlags;

public class PistonBaseBlock extends Block {
	public static final DirectionProperty FACING = DirectionProperty.of("facing");
	public static final BooleanProperty EXTENDED = BooleanProperty.of("extended");
	private final boolean sticky;

	public PistonBaseBlock(boolean sticky) {
		super(Material.PISTON);
		this.setDefaultState(this.stateDefinition.any().set(FACING, Direction.NORTH).set(EXTENDED, false));
		this.sticky = sticky;
		this.setSounds(STONE_SOUNDS);
		this.setStrength(0.5F);
		this.setCreativeModeTab(CreativeModeTab.REDSTONE);
	}

	@Override
	public boolean isSolidRender() {
		return false;
	}

	@Override
	public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity entity, ItemStack item) {
		world.setBlockState(pos, state.set(FACING, getFacingForPlacement(world, pos, entity)), SetBlockFlags.NOTIFY_LISTENERS);
		if (!world.isClient) {
			this.checkExtended(world, pos, state);
		}
	}

	@Override
	public void neighborChanged(World world, BlockPos pos, BlockState state, Block neighborBlock) {
		if (!world.isClient) {
			this.checkExtended(world, pos, state);
		}
	}

	@Override
	public void onAdded(World world, BlockPos pos, BlockState state) {
		if (!world.isClient && world.getBlockEntity(pos) == null) {
			this.checkExtended(world, pos, state);
		}
	}

	@Override
	public BlockState getPlacementState(World world, BlockPos pos, Direction dir, float dx, float dy, float dz, int metadata, LivingEntity entity) {
		return this.defaultState().set(FACING, getFacingForPlacement(world, pos, entity)).set(EXTENDED, false);
	}

	private void checkExtended(World world, BlockPos pos, BlockState state) {
		Direction direction = state.get(FACING);
		boolean bl = this.shouldExtend(world, pos, direction);
		if (bl && !state.get(EXTENDED)) {
			if (new PistonMoveStructureResolver(world, pos, direction, true).resolve()) {
				world.addBlockEvent(pos, this, 0, direction.getId());
			}
		} else if (!bl && state.get(EXTENDED)) {
			world.setBlockState(pos, state.set(EXTENDED, false), SetBlockFlags.NOTIFY_LISTENERS);
			world.addBlockEvent(pos, this, 1, direction.getId());
		}
	}

	private boolean shouldExtend(World world, BlockPos pos, Direction facing) {
		for (Direction direction : Direction.values()) {
			if (direction != facing && world.hasSignal(pos.offset(direction), direction)) {
				return true;
			}
		}

		if (world.hasSignal(pos, Direction.DOWN)) {
			return true;
		}

		BlockPos blockPos = pos.up();

		for (Direction direction2 : Direction.values()) {
			if (direction2 != Direction.DOWN && world.hasSignal(blockPos.offset(direction2), direction2)) {
				return true;
			}
		}

		return false;
	}

	@Override
	public boolean doEvent(World world, BlockPos pos, BlockState state, int type, int data) {
		Direction direction = state.get(FACING);
		if (!world.isClient) {
			boolean bl = this.shouldExtend(world, pos, direction);
			if (bl && type == 1) {
				world.setBlockState(pos, state.set(EXTENDED, true), SetBlockFlags.NOTIFY_LISTENERS);
				return false;
			}

			if (!bl && type == 0) {
				return false;
			}
		}

		if (type == 0) {
			if (!this.move(world, pos, direction, true)) {
				return false;
			}

			world.setBlockState(pos, state.set(EXTENDED, true), SetBlockFlags.NOTIFY_LISTENERS);
			world.playSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, "tile.piston.out", 0.5F, world.random.nextFloat() * 0.25F + 0.6F);
		} else if (type == 1) {
			BlockEntity blockEntity = world.getBlockEntity(pos.offset(direction));
			if (blockEntity instanceof MovingBlockEntity) {
				((MovingBlockEntity)blockEntity).finish();
			}

			world.setBlockState(
				pos,
				Blocks.MOVING_BLOCK
					.defaultState()
					.set(MovingBlock.FACING, direction)
					.set(MovingBlock.TYPE, this.sticky ? PistonHeadBlock.Type.STICKY : PistonHeadBlock.Type.DEFAULT),
				SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS
			);
			world.setBlockEntity(pos, MovingBlock.createMovingBlockEntity(this.getStateFromMetadata(data), direction, false, true));
			if (this.sticky) {
				BlockPos blockPos = pos.add(direction.getOffsetX() * 2, direction.getOffsetY() * 2, direction.getOffsetZ() * 2);
				Block block = world.getBlockState(blockPos).getBlock();
				boolean bl2 = false;
				if (block == Blocks.MOVING_BLOCK) {
					BlockEntity blockEntity2 = world.getBlockEntity(blockPos);
					if (blockEntity2 instanceof MovingBlockEntity) {
						MovingBlockEntity movingBlockEntity = (MovingBlockEntity)blockEntity2;
						if (movingBlockEntity.getFacing() == direction && movingBlockEntity.isExtending()) {
							movingBlockEntity.finish();
							bl2 = true;
						}
					}
				}

				if (!bl2
					&& block.getMaterial() != Material.AIR
					&& canMoveBlock(block, world, blockPos, direction.getOpposite(), false)
					&& (block.getPistonMoveBehavior() == 0 || block == Blocks.PISTON || block == Blocks.STICKY_PISTON)) {
					this.move(world, pos, direction, false);
				}
			} else {
				world.removeBlock(pos.offset(direction));
			}

			world.playSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, "tile.piston.in", 0.5F, world.random.nextFloat() * 0.15F + 0.6F);
		}

		return true;
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		BlockState blockState = world.getBlockState(pos);
		if (blockState.getBlock() == this && blockState.get(EXTENDED)) {
			float f = 0.25F;
			Direction direction = blockState.get(FACING);
			if (direction != null) {
				switch (direction) {
					case DOWN:
						this.setShape(0.0F, 0.25F, 0.0F, 1.0F, 1.0F, 1.0F);
						break;
					case UP:
						this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 0.75F, 1.0F);
						break;
					case NORTH:
						this.setShape(0.0F, 0.0F, 0.25F, 1.0F, 1.0F, 1.0F);
						break;
					case SOUTH:
						this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.75F);
						break;
					case WEST:
						this.setShape(0.25F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
						break;
					case EAST:
						this.setShape(0.0F, 0.0F, 0.0F, 0.75F, 1.0F, 1.0F);
				}
			}
		} else {
			this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		}
	}

	@Override
	public void resetShape() {
		this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
	}

	@Override
	public void addCollisions(World world, BlockPos pos, BlockState state, Box shape, List<Box> collisions, Entity entity) {
		this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		super.addCollisions(world, pos, state, shape, collisions, entity);
	}

	@Override
	public Box getCollisionShape(World world, BlockPos pos, BlockState state) {
		this.updateShape(world, pos);
		return super.getCollisionShape(world, pos, state);
	}

	@Override
	public boolean isCube() {
		return false;
	}

	public static Direction getFacing(int metadata) {
		int i = metadata & 7;
		return i > 5 ? null : Direction.byId(i);
	}

	public static Direction getFacingForPlacement(World world, BlockPos pos, LivingEntity entity) {
		if (MathHelper.abs((float)entity.x - pos.getX()) < 2.0F && MathHelper.abs((float)entity.z - pos.getZ()) < 2.0F) {
			double d = entity.y + entity.getEyeHeight();
			if (d - pos.getY() > 2.0) {
				return Direction.UP;
			}

			if (pos.getY() - d > 0.0) {
				return Direction.DOWN;
			}
		}

		return entity.getHorizontalFacing().getOpposite();
	}

	public static boolean canMoveBlock(Block block, World world, BlockPos pos, Direction dir, boolean allowBreaking) {
		if (block == Blocks.OBSIDIAN) {
			return false;
		}

		if (!world.getWorldBorder().contains(pos)) {
			return false;
		}

		if (pos.getY() >= 0 && (dir != Direction.DOWN || pos.getY() != 0)) {
			if (pos.getY() <= world.getHeight() - 1 && (dir != Direction.UP || pos.getY() != world.getHeight() - 1)) {
				if (block != Blocks.PISTON && block != Blocks.STICKY_PISTON) {
					if (block.getMiningTime(world, pos) == -1.0F) {
						return false;
					}

					if (block.getPistonMoveBehavior() == 2) {
						return false;
					}

					if (block.getPistonMoveBehavior() == 1) {
						if (!allowBreaking) {
							return false;
						}

						return true;
					}
				} else if (world.getBlockState(pos).get(EXTENDED)) {
					return false;
				}

				return !(block instanceof BlockEntityProvider);
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	private boolean move(World world, BlockPos pos, Direction facing, boolean extend) {
		if (!extend) {
			world.removeBlock(pos.offset(facing));
		}

		PistonMoveStructureResolver pistonMoveStructureResolver = new PistonMoveStructureResolver(world, pos, facing, extend);
		List<BlockPos> list = pistonMoveStructureResolver.getToMove();
		List<BlockPos> list2 = pistonMoveStructureResolver.getToBreak();
		if (!pistonMoveStructureResolver.resolve()) {
			return false;
		}

		int i = list.size() + list2.size();
		Block[] blocks = new Block[i];
		Direction direction = extend ? facing : facing.getOpposite();

		for (int j = list2.size() - 1; j >= 0; j--) {
			BlockPos blockPos = list2.get(j);
			Block block = world.getBlockState(blockPos).getBlock();
			block.dropItems(world, blockPos, world.getBlockState(blockPos), 0);
			world.removeBlock(blockPos);
			blocks[--i] = block;
		}

		for (int j = list.size() - 1; j >= 0; j--) {
			BlockPos blockPos = list.get(j);
			BlockState blockState = world.getBlockState(blockPos);
			Block block2 = blockState.getBlock();
			int k = block2.getMetadataFromState(blockState);
			world.removeBlock(blockPos);
			blockPos = blockPos.offset(direction);
			world.setBlockState(blockPos, Blocks.MOVING_BLOCK.defaultState().set(FACING, facing), SetBlockFlags.NO_REDRAW);
			world.setBlockEntity(blockPos, MovingBlock.createMovingBlockEntity(blockState, facing, extend, false));
			blocks[--i] = block2;
		}

		BlockPos blockPos2 = pos.offset(facing);
		if (extend) {
			PistonHeadBlock.Type type = this.sticky ? PistonHeadBlock.Type.STICKY : PistonHeadBlock.Type.DEFAULT;
			BlockState blockState = Blocks.PISTON_HEAD.defaultState().set(PistonHeadBlock.FACING, facing).set(PistonHeadBlock.TYPE, type);
			BlockState blockState2 = Blocks.MOVING_BLOCK
				.defaultState()
				.set(MovingBlock.FACING, facing)
				.set(MovingBlock.TYPE, this.sticky ? PistonHeadBlock.Type.STICKY : PistonHeadBlock.Type.DEFAULT);
			world.setBlockState(blockPos2, blockState2, SetBlockFlags.NO_REDRAW);
			world.setBlockEntity(blockPos2, MovingBlock.createMovingBlockEntity(blockState, facing, true, false));
		}

		for (int l = list2.size() - 1; l >= 0; l--) {
			world.updateNeighbors(list2.get(l), blocks[i++]);
		}

		for (int l = list.size() - 1; l >= 0; l--) {
			world.updateNeighbors(list.get(l), blocks[i++]);
		}

		if (extend) {
			world.updateNeighbors(blockPos2, Blocks.PISTON_HEAD);
			world.updateNeighbors(pos, this);
		}

		return true;
	}

	@Environment(EnvType.CLIENT)
	@Override
	public BlockState getStateForItemModel(BlockState state) {
		return this.defaultState().set(FACING, Direction.UP);
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		return this.defaultState().set(FACING, getFacing(metadata)).set(EXTENDED, (metadata & 8) > 0);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		int i = 0;
		i |= state.get(FACING).getId();
		if (state.get(EXTENDED)) {
			i |= 8;
		}

		return i;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, FACING, EXTENDED);
	}
}

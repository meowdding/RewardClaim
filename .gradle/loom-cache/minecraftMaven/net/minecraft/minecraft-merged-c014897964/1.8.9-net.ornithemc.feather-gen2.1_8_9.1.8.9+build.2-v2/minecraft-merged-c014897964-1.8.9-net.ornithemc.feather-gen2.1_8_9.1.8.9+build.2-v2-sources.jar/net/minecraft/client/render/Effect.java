package net.minecraft.client.render;

import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.pipeline.RenderTarget;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.shaders.BlendMode;
import net.minecraft.client.render.shaders.DummyUniform;
import net.minecraft.client.render.shaders.Program;
import net.minecraft.client.render.shaders.ProgramManager;
import net.minecraft.client.render.shaders.Uniform;
import net.minecraft.client.render.texture.Texture;
import net.minecraft.client.resource.manager.ResourceManager;
import net.minecraft.resource.Identifier;
import net.minecraft.server.ChainedJsonException;
import net.minecraft.util.JsonUtils;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Environment(EnvType.CLIENT)
public class Effect {
	private static final Logger LOGGER = LogManager.getLogger();
	private static final DummyUniform DUMMY_UNIFORM = new DummyUniform();
	private static Effect lastAppliedEffect = null;
	private static int lastProgramId = -1;
	private static boolean cullEnabled = true;
	private final Map<String, Object> samplerMap = Maps.newHashMap();
	private final List<String> samplerNames = Lists.newArrayList();
	private final List<Integer> samplerLocations = Lists.newArrayList();
	private final List<Uniform> uniforms = Lists.newArrayList();
	private final List<Integer> uniformLocations = Lists.newArrayList();
	private final Map<String, Uniform> uniformMap = Maps.newHashMap();
	private final int programId;
	private final String name;
	private final boolean cull;
	private boolean dirty;
	private final BlendMode blend;
	private final List<Integer> attributes;
	private final List<String> attributeNames;
	private final Program vertexProgram;
	private final Program fragmentProgram;

	public Effect(ResourceManager resourceManager, String name) throws IOException {
		JsonParser jsonParser = new JsonParser();
		Identifier identifier = new Identifier("shaders/program/" + name + ".json");
		this.name = name;
		InputStream inputStream = null;

		try {
			inputStream = resourceManager.getResource(identifier).asStream();
			JsonObject jsonObject = jsonParser.parse(IOUtils.toString(inputStream, Charsets.UTF_8)).getAsJsonObject();
			String string = JsonUtils.getString(jsonObject, "vertex");
			String string2 = JsonUtils.getString(jsonObject, "fragment");
			JsonArray jsonArray = JsonUtils.getJsonArrayOrDefault(jsonObject, "samplers", null);
			if (jsonArray != null) {
				int i = 0;

				for (JsonElement jsonElement : jsonArray) {
					try {
						this.parseSamplerNode(jsonElement);
					} catch (Exception exception) {
						ChainedJsonException chainedJsonException = ChainedJsonException.forException(exception);
						chainedJsonException.prependJsonKey("samplers[" + i + "]");
						throw chainedJsonException;
					}

					i++;
				}
			}

			JsonArray jsonArray2 = JsonUtils.getJsonArrayOrDefault(jsonObject, "attributes", null);
			if (jsonArray2 != null) {
				int j = 0;
				this.attributes = Lists.newArrayListWithCapacity(jsonArray2.size());
				this.attributeNames = Lists.newArrayListWithCapacity(jsonArray2.size());

				for (JsonElement jsonElement2 : jsonArray2) {
					try {
						this.attributeNames.add(JsonUtils.asString(jsonElement2, "attribute"));
					} catch (Exception exception2) {
						ChainedJsonException chainedJsonException2 = ChainedJsonException.forException(exception2);
						chainedJsonException2.prependJsonKey("attributes[" + j + "]");
						throw chainedJsonException2;
					}

					j++;
				}
			} else {
				this.attributes = null;
				this.attributeNames = null;
			}

			JsonArray jsonArray3 = JsonUtils.getJsonArrayOrDefault(jsonObject, "uniforms", null);
			if (jsonArray3 != null) {
				int k = 0;

				for (JsonElement jsonElement3 : jsonArray3) {
					try {
						this.parseUniformNode(jsonElement3);
					} catch (Exception exception3) {
						ChainedJsonException chainedJsonException3 = ChainedJsonException.forException(exception3);
						chainedJsonException3.prependJsonKey("uniforms[" + k + "]");
						throw chainedJsonException3;
					}

					k++;
				}
			}

			this.blend = BlendMode.fromJson(JsonUtils.getJsonObjectOrDefault(jsonObject, "blend", null));
			this.cull = JsonUtils.getBooleanOrDefault(jsonObject, "cull", true);
			this.vertexProgram = Program.compileShader(resourceManager, Program.Type.VERTEX, string);
			this.fragmentProgram = Program.compileShader(resourceManager, Program.Type.FRAGMENT, string2);
			this.programId = ProgramManager.getInstance().createProgram();
			ProgramManager.getInstance().linkProgram(this);
			this.updateLocations();
			if (this.attributeNames != null) {
				for (String string3 : this.attributeNames) {
					int l = GLX.getAttribLocation(this.programId, string3);
					this.attributes.add(l);
				}
			}
		} catch (Exception exception4) {
			ChainedJsonException chainedJsonException4 = ChainedJsonException.forException(exception4);
			chainedJsonException4.setFileNameAndFlush(identifier.getPath());
			throw chainedJsonException4;
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

		this.markDirty();
	}

	public void close() {
		ProgramManager.getInstance().releaseProgram(this);
	}

	public void clear() {
		GLX.useProgram(0);
		lastProgramId = -1;
		lastAppliedEffect = null;
		cullEnabled = true;

		for (int i = 0; i < this.samplerLocations.size(); i++) {
			if (this.samplerMap.get(this.samplerNames.get(i)) != null) {
				GlStateManager.activeTexture(GLX.GL_TEXTURE0 + i);
				GlStateManager.bindTexture(0);
			}
		}
	}

	public void apply() {
		this.dirty = false;
		lastAppliedEffect = this;
		this.blend.apply();
		if (this.programId != lastProgramId) {
			GLX.useProgram(this.programId);
			lastProgramId = this.programId;
		}

		if (this.cull) {
			GlStateManager.enableCull();
		} else {
			GlStateManager.disableCull();
		}

		for (int i = 0; i < this.samplerLocations.size(); i++) {
			if (this.samplerMap.get(this.samplerNames.get(i)) != null) {
				GlStateManager.activeTexture(GLX.GL_TEXTURE0 + i);
				GlStateManager.enableTexture();
				Object object = this.samplerMap.get(this.samplerNames.get(i));
				int j = -1;
				if (object instanceof RenderTarget) {
					j = ((RenderTarget)object).colorTextureId;
				} else if (object instanceof Texture) {
					j = ((Texture)object).getGlId();
				} else if (object instanceof Integer) {
					j = (Integer)object;
				}

				if (j != -1) {
					GlStateManager.bindTexture(j);
					GLX.uniform1i(GLX.getUniformLocation(this.programId, this.samplerNames.get(i)), i);
				}
			}
		}

		for (Uniform uniform : this.uniforms) {
			uniform.upload();
		}
	}

	public void markDirty() {
		this.dirty = true;
	}

	public Uniform getUniform(String name) {
		return this.uniformMap.containsKey(name) ? this.uniformMap.get(name) : null;
	}

	public Uniform safeGetUniform(String name) {
		return this.uniformMap.containsKey(name) ? this.uniformMap.get(name) : DUMMY_UNIFORM;
	}

	private void updateLocations() {
		int i = 0;

		for (int j = 0; i < this.samplerNames.size(); j++) {
			String string = this.samplerNames.get(i);
			int k = GLX.getUniformLocation(this.programId, string);
			if (k == -1) {
				LOGGER.warn("Shader " + this.name + "could not find sampler named " + string + " in the specified shader program.");
				this.samplerMap.remove(string);
				this.samplerNames.remove(j);
				j--;
			} else {
				this.samplerLocations.add(k);
			}

			i++;
		}

		for (Uniform uniform : this.uniforms) {
			String string = uniform.getName();
			int k = GLX.getUniformLocation(this.programId, string);
			if (k == -1) {
				LOGGER.warn("Could not find uniform named " + string + " in the specified" + " shader program.");
			} else {
				this.uniformLocations.add(k);
				uniform.setLocation(k);
				this.uniformMap.put(string, uniform);
			}
		}
	}

	private void parseSamplerNode(JsonElement json) throws ChainedJsonException {
		JsonObject jsonObject = JsonUtils.asJsonObject(json, "sampler");
		String string = JsonUtils.getString(jsonObject, "name");
		if (!JsonUtils.hasString(jsonObject, "file")) {
			this.samplerMap.put(string, null);
			this.samplerNames.add(string);
		} else {
			this.samplerNames.add(string);
		}
	}

	public void setSampler(String name, Object sampler) {
		if (this.samplerMap.containsKey(name)) {
			this.samplerMap.remove(name);
		}

		this.samplerMap.put(name, sampler);
		this.markDirty();
	}

	private void parseUniformNode(JsonElement json) throws ChainedJsonException {
		JsonObject jsonObject = JsonUtils.asJsonObject(json, "uniform");
		String string = JsonUtils.getString(jsonObject, "name");
		int i = Uniform.getTypeFromString(JsonUtils.getString(jsonObject, "type"));
		int j = JsonUtils.getInteger(jsonObject, "count");
		float[] fs = new float[Math.max(j, 16)];
		JsonArray jsonArray = JsonUtils.getJsonArray(jsonObject, "values");
		if (jsonArray.size() != j && jsonArray.size() > 1) {
			throw new ChainedJsonException("Invalid amount of values specified (expected " + j + ", found " + jsonArray.size() + ")");
		}

		int k = 0;

		for (JsonElement jsonElement : jsonArray) {
			try {
				fs[k] = JsonUtils.asFloat(jsonElement, "value");
			} catch (Exception exception) {
				ChainedJsonException chainedJsonException = ChainedJsonException.forException(exception);
				chainedJsonException.prependJsonKey("values[" + k + "]");
				throw chainedJsonException;
			}

			k++;
		}

		if (j > 1 && jsonArray.size() == 1) {
			while (k < j) {
				fs[k] = fs[0];
				k++;
			}
		}

		int l = j > 1 && j <= 4 && i < 8 ? j - 1 : 0;
		Uniform uniform = new Uniform(string, i + l, j, this);
		if (i <= 3) {
			uniform.setSafe((int)fs[0], (int)fs[1], (int)fs[2], (int)fs[3]);
		} else if (i <= 7) {
			uniform.setSafe(fs[0], fs[1], fs[2], fs[3]);
		} else {
			uniform.set(fs);
		}

		this.uniforms.add(uniform);
	}

	public Program getVertexProgram() {
		return this.vertexProgram;
	}

	public Program getFragmentProgram() {
		return this.fragmentProgram;
	}

	public int getId() {
		return this.programId;
	}
}

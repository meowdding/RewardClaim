package net.minecraft.client.render.block;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.LiquidBlock;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.render.texture.TextureAtlasSprite;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.WorldView;

@Environment(EnvType.CLIENT)
public class LiquidRenderer {
	private TextureAtlasSprite[] lavaSprites = new TextureAtlasSprite[2];
	private TextureAtlasSprite[] waterSprites = new TextureAtlasSprite[2];

	public LiquidRenderer() {
		this.reload();
	}

	protected void reload() {
		TextureAtlas textureAtlas = Minecraft.getInstance().getBlocksAtlas();
		this.lavaSprites[0] = textureAtlas.getSprite("minecraft:blocks/lava_still");
		this.lavaSprites[1] = textureAtlas.getSprite("minecraft:blocks/lava_flow");
		this.waterSprites[0] = textureAtlas.getSprite("minecraft:blocks/water_still");
		this.waterSprites[1] = textureAtlas.getSprite("minecraft:blocks/water_flow");
	}

	public boolean render(WorldView world, BlockState state, BlockPos pos, BufferBuilder bufferBuilder) {
		LiquidBlock liquidBlock = (LiquidBlock)state.getBlock();
		liquidBlock.updateShape(world, pos);
		TextureAtlasSprite[] textureAtlasSprites = liquidBlock.getMaterial() == Material.LAVA ? this.lavaSprites : this.waterSprites;
		int i = liquidBlock.getColorTint(world, pos);
		float f = (i >> 16 & 0xFF) / 255.0F;
		float g = (i >> 8 & 0xFF) / 255.0F;
		float h = (i & 0xFF) / 255.0F;
		boolean bl = liquidBlock.shouldRenderFace(world, pos.up(), Direction.UP);
		boolean bl2 = liquidBlock.shouldRenderFace(world, pos.down(), Direction.DOWN);
		boolean[] bls = new boolean[]{
			liquidBlock.shouldRenderFace(world, pos.north(), Direction.NORTH),
			liquidBlock.shouldRenderFace(world, pos.south(), Direction.SOUTH),
			liquidBlock.shouldRenderFace(world, pos.west(), Direction.WEST),
			liquidBlock.shouldRenderFace(world, pos.east(), Direction.EAST)
		};
		if (!bl && !bl2 && !bls[0] && !bls[1] && !bls[2] && !bls[3]) {
			return false;
		}

		boolean bl3 = false;
		float j = 0.5F;
		float k = 1.0F;
		float l = 0.8F;
		float m = 0.6F;
		Material material = liquidBlock.getMaterial();
		float n = this.getLiquidHeight(world, pos, material);
		float o = this.getLiquidHeight(world, pos.south(), material);
		float p = this.getLiquidHeight(world, pos.east().south(), material);
		float q = this.getLiquidHeight(world, pos.east(), material);
		double d = pos.getX();
		double e = pos.getY();
		double r = pos.getZ();
		float s = 0.001F;
		if (bl) {
			bl3 = true;
			TextureAtlasSprite textureAtlasSprite = textureAtlasSprites[0];
			float t = (float)LiquidBlock.getFlowAngle(world, pos, material);
			if (t > -999.0F) {
				textureAtlasSprite = textureAtlasSprites[1];
			}

			n -= s;
			o -= s;
			p -= s;
			q -= s;
			float u;
			float w;
			float y;
			float aa;
			float v;
			float x;
			float z;
			float ab;
			if (t < -999.0F) {
				u = textureAtlasSprite.getU(0.0);
				v = textureAtlasSprite.getV(0.0);
				w = u;
				x = textureAtlasSprite.getV(16.0);
				y = textureAtlasSprite.getU(16.0);
				z = x;
				aa = y;
				ab = v;
			} else {
				float ac = MathHelper.sin(t) * 0.25F;
				float ad = MathHelper.cos(t) * 0.25F;
				float ae = 8.0F;
				u = textureAtlasSprite.getU(8.0F + (-ad - ac) * 16.0F);
				v = textureAtlasSprite.getV(8.0F + (-ad + ac) * 16.0F);
				w = textureAtlasSprite.getU(8.0F + (-ad + ac) * 16.0F);
				x = textureAtlasSprite.getV(8.0F + (ad + ac) * 16.0F);
				y = textureAtlasSprite.getU(8.0F + (ad + ac) * 16.0F);
				z = textureAtlasSprite.getV(8.0F + (ad - ac) * 16.0F);
				aa = textureAtlasSprite.getU(8.0F + (ad - ac) * 16.0F);
				ab = textureAtlasSprite.getV(8.0F + (-ad - ac) * 16.0F);
			}

			int af = liquidBlock.getLightColor(world, pos);
			int ag = af >> 16 & 65535;
			int ah = af & 65535;
			float ai = k * f;
			float aj = k * g;
			float ak = k * h;
			bufferBuilder.vertex(d + 0.0, e + n, r + 0.0).color(ai, aj, ak, 1.0F).texture(u, v).texture(ag, ah).nextVertex();
			bufferBuilder.vertex(d + 0.0, e + o, r + 1.0).color(ai, aj, ak, 1.0F).texture(w, x).texture(ag, ah).nextVertex();
			bufferBuilder.vertex(d + 1.0, e + p, r + 1.0).color(ai, aj, ak, 1.0F).texture(y, z).texture(ag, ah).nextVertex();
			bufferBuilder.vertex(d + 1.0, e + q, r + 0.0).color(ai, aj, ak, 1.0F).texture(aa, ab).texture(ag, ah).nextVertex();
			if (liquidBlock.isNeighboringGap(world, pos.up())) {
				bufferBuilder.vertex(d + 0.0, e + n, r + 0.0).color(ai, aj, ak, 1.0F).texture(u, v).texture(ag, ah).nextVertex();
				bufferBuilder.vertex(d + 1.0, e + q, r + 0.0).color(ai, aj, ak, 1.0F).texture(aa, ab).texture(ag, ah).nextVertex();
				bufferBuilder.vertex(d + 1.0, e + p, r + 1.0).color(ai, aj, ak, 1.0F).texture(y, z).texture(ag, ah).nextVertex();
				bufferBuilder.vertex(d + 0.0, e + o, r + 1.0).color(ai, aj, ak, 1.0F).texture(w, x).texture(ag, ah).nextVertex();
			}
		}

		if (bl2) {
			float t = textureAtlasSprites[0].getUMin();
			float u = textureAtlasSprites[0].getUMax();
			float w = textureAtlasSprites[0].getVMin();
			float y = textureAtlasSprites[0].getVMax();
			int al = liquidBlock.getLightColor(world, pos.down());
			int am = al >> 16 & 65535;
			int an = al & 65535;
			bufferBuilder.vertex(d, e, r + 1.0).color(j, j, j, 1.0F).texture(t, y).texture(am, an).nextVertex();
			bufferBuilder.vertex(d, e, r).color(j, j, j, 1.0F).texture(t, w).texture(am, an).nextVertex();
			bufferBuilder.vertex(d + 1.0, e, r).color(j, j, j, 1.0F).texture(u, w).texture(am, an).nextVertex();
			bufferBuilder.vertex(d + 1.0, e, r + 1.0).color(j, j, j, 1.0F).texture(u, y).texture(am, an).nextVertex();
			bl3 = true;
		}

		for (int ao = 0; ao < 4; ao++) {
			int ap = 0;
			int aq = 0;
			if (ao == 0) {
				aq--;
			}

			if (ao == 1) {
				aq++;
			}

			if (ao == 2) {
				ap--;
			}

			if (ao == 3) {
				ap++;
			}

			BlockPos blockPos = pos.add(ap, 0, aq);
			TextureAtlasSprite textureAtlasSprite = textureAtlasSprites[1];
			if (bls[ao]) {
				float aa;
				float v;
				double ar;
				double at;
				double as;
				double au;
				if (ao == 0) {
					aa = n;
					v = q;
					ar = d;
					as = d + 1.0;
					at = r + s;
					au = r + s;
				} else if (ao == 1) {
					aa = p;
					v = o;
					ar = d + 1.0;
					as = d;
					at = r + 1.0 - s;
					au = r + 1.0 - s;
				} else if (ao == 2) {
					aa = o;
					v = n;
					ar = d + s;
					as = d + s;
					at = r + 1.0;
					au = r;
				} else {
					aa = q;
					v = p;
					ar = d + 1.0 - s;
					as = d + 1.0 - s;
					at = r;
					au = r + 1.0;
				}

				bl3 = true;
				float ak = textureAtlasSprite.getU(0.0);
				float av = textureAtlasSprite.getU(8.0);
				float aw = textureAtlasSprite.getV((1.0F - aa) * 16.0F * 0.5F);
				float ax = textureAtlasSprite.getV((1.0F - v) * 16.0F * 0.5F);
				float ay = textureAtlasSprite.getV(8.0);
				int az = liquidBlock.getLightColor(world, blockPos);
				int ba = az >> 16 & 65535;
				int bb = az & 65535;
				float bc = ao < 2 ? l : m;
				float bd = k * bc * f;
				float be = k * bc * g;
				float bf = k * bc * h;
				bufferBuilder.vertex(ar, e + aa, at).color(bd, be, bf, 1.0F).texture(ak, aw).texture(ba, bb).nextVertex();
				bufferBuilder.vertex(as, e + v, au).color(bd, be, bf, 1.0F).texture(av, ax).texture(ba, bb).nextVertex();
				bufferBuilder.vertex(as, e + 0.0, au).color(bd, be, bf, 1.0F).texture(av, ay).texture(ba, bb).nextVertex();
				bufferBuilder.vertex(ar, e + 0.0, at).color(bd, be, bf, 1.0F).texture(ak, ay).texture(ba, bb).nextVertex();
				bufferBuilder.vertex(ar, e + 0.0, at).color(bd, be, bf, 1.0F).texture(ak, ay).texture(ba, bb).nextVertex();
				bufferBuilder.vertex(as, e + 0.0, au).color(bd, be, bf, 1.0F).texture(av, ay).texture(ba, bb).nextVertex();
				bufferBuilder.vertex(as, e + v, au).color(bd, be, bf, 1.0F).texture(av, ax).texture(ba, bb).nextVertex();
				bufferBuilder.vertex(ar, e + aa, at).color(bd, be, bf, 1.0F).texture(ak, aw).texture(ba, bb).nextVertex();
			}
		}

		return bl3;
	}

	private float getLiquidHeight(WorldView world, BlockPos pos, Material material) {
		int i = 0;
		float f = 0.0F;

		for (int j = 0; j < 4; j++) {
			BlockPos blockPos = pos.add(-(j & 1), 0, -(j >> 1 & 1));
			if (world.getBlockState(blockPos.up()).getBlock().getMaterial() == material) {
				return 1.0F;
			}

			BlockState blockState = world.getBlockState(blockPos);
			Material material2 = blockState.getBlock().getMaterial();
			if (material2 == material) {
				int k = blockState.get(LiquidBlock.LEVEL);
				if (k >= 8 || k == 0) {
					f += LiquidBlock.getHeightLoss(k) * 10.0F;
					i += 10;
				}

				f += LiquidBlock.getHeightLoss(k);
				i++;
			} else if (!material2.isSolid()) {
				f++;
				i++;
			}
		}

		return 1.0F - f / i;
	}
}

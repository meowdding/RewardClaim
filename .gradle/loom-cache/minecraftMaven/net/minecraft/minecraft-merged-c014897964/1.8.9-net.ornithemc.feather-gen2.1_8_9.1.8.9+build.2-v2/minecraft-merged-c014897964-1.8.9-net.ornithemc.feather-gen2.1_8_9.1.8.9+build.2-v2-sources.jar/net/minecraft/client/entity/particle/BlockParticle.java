package net.minecraft.client.entity.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

@Environment(EnvType.CLIENT)
public class BlockParticle extends Particle {
	private BlockState state;
	private BlockPos pos;

	protected BlockParticle(World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, BlockState state) {
		super(world, x, y, z, velocityX, velocityY, velocityZ);
		this.state = state;
		this.setTexture(Minecraft.getInstance().getBlockRenderDispatcher().getModelShaper().getParticleIcon(state));
		this.gravity = state.getBlock().gravity;
		this.red = this.green = this.blue = 0.6F;
		this.size /= 2.0F;
	}

	public BlockParticle init(BlockPos pos) {
		this.pos = pos;
		if (this.state.getBlock() == Blocks.GRASS) {
			return this;
		}

		int i = this.state.getBlock().getColorTint(this.world, pos);
		this.red *= (i >> 16 & 0xFF) / 255.0F;
		this.green *= (i >> 8 & 0xFF) / 255.0F;
		this.blue *= (i & 0xFF) / 255.0F;
		return this;
	}

	public BlockParticle updateColor() {
		this.pos = new BlockPos(this.x, this.y, this.z);
		Block block = this.state.getBlock();
		if (block == Blocks.GRASS) {
			return this;
		}

		int i = block.getColor(this.state);
		this.red *= (i >> 16 & 0xFF) / 255.0F;
		this.green *= (i >> 8 & 0xFF) / 255.0F;
		this.blue *= (i & 0xFF) / 255.0F;
		return this;
	}

	@Override
	public int getAtlasType() {
		return 1;
	}

	@Override
	public void render(BufferBuilder bufferBuilder, Entity camera, float tickDelta, float dx, float dy, float dz, float forwards, float sideways) {
		float f = (this.spriteRow + this.offsetU / 4.0F) / 16.0F;
		float g = f + 0.015609375F;
		float h = (this.spriteColumn + this.offsetV / 4.0F) / 16.0F;
		float i = h + 0.015609375F;
		float j = 0.1F * this.size;
		if (this.sprite != null) {
			f = this.sprite.getU(this.offsetU / 4.0F * 16.0F);
			g = this.sprite.getU((this.offsetU + 1.0F) / 4.0F * 16.0F);
			h = this.sprite.getV(this.offsetV / 4.0F * 16.0F);
			i = this.sprite.getV((this.offsetV + 1.0F) / 4.0F * 16.0F);
		}

		float k = (float)(this.lastX + (this.x - this.lastX) * tickDelta - cameraX);
		float l = (float)(this.lastY + (this.y - this.lastY) * tickDelta - cameraY);
		float m = (float)(this.lastZ + (this.z - this.lastZ) * tickDelta - cameraZ);
		int n = this.getLightLevel(tickDelta);
		int o = n >> 16 & 65535;
		int p = n & 65535;
		bufferBuilder.vertex(k - dx * j - forwards * j, l - dy * j, m - dz * j - sideways * j)
			.texture(f, i)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
		bufferBuilder.vertex(k - dx * j + forwards * j, l + dy * j, m - dz * j + sideways * j)
			.texture(f, h)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
		bufferBuilder.vertex(k + dx * j + forwards * j, l + dy * j, m + dz * j + sideways * j)
			.texture(g, h)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
		bufferBuilder.vertex(k + dx * j - forwards * j, l - dy * j, m + dz * j - sideways * j)
			.texture(g, i)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
	}

	@Override
	public int getLightLevel(float tickDelta) {
		int i = super.getLightLevel(tickDelta);
		int j = 0;
		if (this.world.isChunkLoaded(this.pos)) {
			j = this.world.getLightColor(this.pos, 0);
		}

		return i == 0 ? j : i;
	}

	@Environment(EnvType.CLIENT)
	public static class Factory implements ParticleFactory {
		@Override
		public Particle create(int type, World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, int... parameters) {
			return new BlockParticle(world, x, y, z, velocityX, velocityY, velocityZ, Block.deserialize(parameters[0])).updateColor();
		}
	}
}

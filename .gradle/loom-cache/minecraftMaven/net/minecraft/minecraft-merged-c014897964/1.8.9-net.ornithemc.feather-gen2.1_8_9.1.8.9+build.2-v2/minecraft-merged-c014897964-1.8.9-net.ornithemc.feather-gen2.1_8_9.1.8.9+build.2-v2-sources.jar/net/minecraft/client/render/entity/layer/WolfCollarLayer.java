package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.WolfRenderer;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.passive.animal.SheepEntity;
import net.minecraft.entity.living.mob.passive.animal.tameable.WolfEntity;
import net.minecraft.item.DyeColor;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class WolfCollarLayer implements EntityRenderLayer<WolfEntity> {
	private static final Identifier WOLF_COLLAR_LOCATION = new Identifier("textures/entity/wolf/wolf_collar.png");
	private final WolfRenderer parent;

	public WolfCollarLayer(WolfRenderer parent) {
		this.parent = parent;
	}

	public void render(WolfEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale) {
		if (entity.isTamed() && !entity.isInvisible()) {
			this.parent.bindTexture(WOLF_COLLAR_LOCATION);
			DyeColor dyeColor = DyeColor.byId(entity.getCollarColor().getId());
			float[] fs = SheepEntity.getColorRgb(dyeColor);
			GlStateManager.color3f(fs[0], fs[1], fs[2]);
			this.parent.getModel().render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return true;
	}
}

package net.minecraft.block;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.DirectionProperty;
import net.minecraft.entity.Entity;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.mob.passive.animal.tameable.OcelotEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.inventory.DoubleInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.InventoryUtils;
import net.minecraft.inventory.menu.InventoryMenu;
import net.minecraft.inventory.menu.LockableMenuProvider;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.ItemStack;
import net.minecraft.stat.Stats;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.ornithemc.feather.constants.SetBlockFlags;

public class ChestBlock extends BlockWithBlockEntity {
	public static final DirectionProperty FACING = DirectionProperty.of("facing", Direction.Plane.HORIZONTAL);
	public final int type;

	protected ChestBlock(int type) {
		super(Material.WOOD);
		this.setDefaultState(this.stateDefinition.any().set(FACING, Direction.NORTH));
		this.type = type;
		this.setCreativeModeTab(CreativeModeTab.DECORATIONS);
		this.setShape(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
	}

	@Override
	public boolean isSolidRender() {
		return false;
	}

	@Override
	public boolean isCube() {
		return false;
	}

	@Override
	public int getRenderType() {
		return 2;
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		if (world.getBlockState(pos.north()).getBlock() == this) {
			this.setShape(0.0625F, 0.0F, 0.0F, 0.9375F, 0.875F, 0.9375F);
		} else if (world.getBlockState(pos.south()).getBlock() == this) {
			this.setShape(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 1.0F);
		} else if (world.getBlockState(pos.west()).getBlock() == this) {
			this.setShape(0.0F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
		} else if (world.getBlockState(pos.east()).getBlock() == this) {
			this.setShape(0.0625F, 0.0F, 0.0625F, 1.0F, 0.875F, 0.9375F);
		} else {
			this.setShape(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
		}
	}

	@Override
	public void onAdded(World world, BlockPos pos, BlockState state) {
		this.updateState(world, pos, state);

		for (Direction direction : Direction.Plane.HORIZONTAL) {
			BlockPos blockPos = pos.offset(direction);
			BlockState blockState = world.getBlockState(blockPos);
			if (blockState.getBlock() == this) {
				this.updateState(world, blockPos, blockState);
			}
		}
	}

	@Override
	public BlockState getPlacementState(World world, BlockPos pos, Direction dir, float dx, float dy, float dz, int metadata, LivingEntity entity) {
		return this.defaultState().set(FACING, entity.getHorizontalFacing());
	}

	@Override
	public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity entity, ItemStack item) {
		Direction direction = Direction.byIdHorizontal(MathHelper.floor(entity.yaw * 4.0F / 360.0F + 0.5) & 3).getOpposite();
		state = state.set(FACING, direction);
		BlockPos blockPos = pos.north();
		BlockPos blockPos2 = pos.south();
		BlockPos blockPos3 = pos.west();
		BlockPos blockPos4 = pos.east();
		boolean bl = this == world.getBlockState(blockPos).getBlock();
		boolean bl2 = this == world.getBlockState(blockPos2).getBlock();
		boolean bl3 = this == world.getBlockState(blockPos3).getBlock();
		boolean bl4 = this == world.getBlockState(blockPos4).getBlock();
		if (!bl && !bl2 && !bl3 && !bl4) {
			world.setBlockState(pos, state, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
		} else if (direction.getAxis() != Direction.Axis.X || !bl && !bl2) {
			if (direction.getAxis() == Direction.Axis.Z && (bl3 || bl4)) {
				if (bl3) {
					world.setBlockState(blockPos3, state, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
				} else {
					world.setBlockState(blockPos4, state, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
				}

				world.setBlockState(pos, state, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
			}
		} else {
			if (bl) {
				world.setBlockState(blockPos, state, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
			} else {
				world.setBlockState(blockPos2, state, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
			}

			world.setBlockState(pos, state, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
		}

		if (item.hasCustomHoverName()) {
			BlockEntity blockEntity = world.getBlockEntity(pos);
			if (blockEntity instanceof ChestBlockEntity) {
				((ChestBlockEntity)blockEntity).setCustomName(item.getHoverName());
			}
		}
	}

	public BlockState updateState(World world, BlockPos pos, BlockState state) {
		if (world.isClient) {
			return state;
		}

		BlockState blockState = world.getBlockState(pos.north());
		BlockState blockState2 = world.getBlockState(pos.south());
		BlockState blockState3 = world.getBlockState(pos.west());
		BlockState blockState4 = world.getBlockState(pos.east());
		Direction direction = state.get(FACING);
		Block block = blockState.getBlock();
		Block block2 = blockState2.getBlock();
		Block block3 = blockState3.getBlock();
		Block block4 = blockState4.getBlock();
		if (block != this && block2 != this) {
			boolean bl = block.isOpaque();
			boolean bl2 = block2.isOpaque();
			if (block3 == this || block4 == this) {
				BlockPos blockPos2 = block3 == this ? pos.west() : pos.east();
				BlockState blockState7 = world.getBlockState(blockPos2.north());
				BlockState blockState8 = world.getBlockState(blockPos2.south());
				direction = Direction.SOUTH;
				Direction direction3;
				if (block3 == this) {
					direction3 = blockState3.get(FACING);
				} else {
					direction3 = blockState4.get(FACING);
				}

				if (direction3 == Direction.NORTH) {
					direction = Direction.NORTH;
				}

				Block block7 = blockState7.getBlock();
				Block block8 = blockState8.getBlock();
				if ((bl || block7.isOpaque()) && !bl2 && !block8.isOpaque()) {
					direction = Direction.SOUTH;
				}

				if ((bl2 || block8.isOpaque()) && !bl && !block7.isOpaque()) {
					direction = Direction.NORTH;
				}
			}
		} else {
			BlockPos blockPos = block == this ? pos.north() : pos.south();
			BlockState blockState5 = world.getBlockState(blockPos.west());
			BlockState blockState6 = world.getBlockState(blockPos.east());
			direction = Direction.EAST;
			Direction direction2;
			if (block == this) {
				direction2 = blockState.get(FACING);
			} else {
				direction2 = blockState2.get(FACING);
			}

			if (direction2 == Direction.WEST) {
				direction = Direction.WEST;
			}

			Block block5 = blockState5.getBlock();
			Block block6 = blockState6.getBlock();
			if ((block3.isOpaque() || block5.isOpaque()) && !block4.isOpaque() && !block6.isOpaque()) {
				direction = Direction.EAST;
			}

			if ((block4.isOpaque() || block6.isOpaque()) && !block3.isOpaque() && !block5.isOpaque()) {
				direction = Direction.WEST;
			}
		}

		state = state.set(FACING, direction);
		world.setBlockState(pos, state, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
		return state;
	}

	public BlockState updateFacing(World world, BlockPos pos, BlockState state) {
		Direction direction = null;

		for (Direction direction2 : Direction.Plane.HORIZONTAL) {
			BlockState blockState = world.getBlockState(pos.offset(direction2));
			if (blockState.getBlock() == this) {
				return state;
			}

			if (blockState.getBlock().isOpaque()) {
				if (direction != null) {
					direction = null;
					break;
				}

				direction = direction2;
			}
		}

		if (direction != null) {
			return state.set(FACING, direction.getOpposite());
		}

		Direction direction3 = state.get(FACING);
		if (world.getBlockState(pos.offset(direction3)).getBlock().isOpaque()) {
			direction3 = direction3.getOpposite();
		}

		if (world.getBlockState(pos.offset(direction3)).getBlock().isOpaque()) {
			direction3 = direction3.clockwiseY();
		}

		if (world.getBlockState(pos.offset(direction3)).getBlock().isOpaque()) {
			direction3 = direction3.getOpposite();
		}

		return state.set(FACING, direction3);
	}

	@Override
	public boolean canBePlaced(World world, BlockPos pos) {
		int i = 0;
		BlockPos blockPos = pos.west();
		BlockPos blockPos2 = pos.east();
		BlockPos blockPos3 = pos.north();
		BlockPos blockPos4 = pos.south();
		if (world.getBlockState(blockPos).getBlock() == this) {
			if (this.isDoubleChest(world, blockPos)) {
				return false;
			}

			i++;
		}

		if (world.getBlockState(blockPos2).getBlock() == this) {
			if (this.isDoubleChest(world, blockPos2)) {
				return false;
			}

			i++;
		}

		if (world.getBlockState(blockPos3).getBlock() == this) {
			if (this.isDoubleChest(world, blockPos3)) {
				return false;
			}

			i++;
		}

		if (world.getBlockState(blockPos4).getBlock() == this) {
			if (this.isDoubleChest(world, blockPos4)) {
				return false;
			}

			i++;
		}

		return i <= 1;
	}

	private boolean isDoubleChest(World world, BlockPos pos) {
		if (world.getBlockState(pos).getBlock() != this) {
			return false;
		}

		for (Direction direction : Direction.Plane.HORIZONTAL) {
			if (world.getBlockState(pos.offset(direction)).getBlock() == this) {
				return true;
			}
		}

		return false;
	}

	@Override
	public void neighborChanged(World world, BlockPos pos, BlockState state, Block neighborBlock) {
		super.neighborChanged(world, pos, state, neighborBlock);
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof ChestBlockEntity) {
			blockEntity.clearBlockCache();
		}
	}

	@Override
	public void onRemoved(World world, BlockPos pos, BlockState state) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof Inventory) {
			InventoryUtils.dropItems(world, pos, (Inventory)blockEntity);
			world.updateNeighborComparators(pos, this);
		}

		super.onRemoved(world, pos, state);
	}

	@Override
	public boolean use(World world, BlockPos pos, BlockState state, PlayerEntity player, Direction face, float faceX, float faceY, float faceZ) {
		if (world.isClient) {
			return true;
		}

		LockableMenuProvider lockableMenuProvider = this.getInventory(world, pos);
		if (lockableMenuProvider != null) {
			player.openChestMenu(lockableMenuProvider);
			if (this.type == 0) {
				player.incrementStat(Stats.CHESTS_OPENED);
			} else if (this.type == 1) {
				player.incrementStat(Stats.TRAPPED_CHESTS_TRIGGERED);
			}
		}

		return true;
	}

	public LockableMenuProvider getInventory(World world, BlockPos pos) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (!(blockEntity instanceof ChestBlockEntity)) {
			return null;
		}

		LockableMenuProvider lockableMenuProvider = (ChestBlockEntity)blockEntity;
		if (this.isLocked(world, pos)) {
			return null;
		}

		for (Direction direction : Direction.Plane.HORIZONTAL) {
			BlockPos blockPos = pos.offset(direction);
			Block block = world.getBlockState(blockPos).getBlock();
			if (block == this) {
				if (this.isLocked(world, blockPos)) {
					return null;
				}

				BlockEntity blockEntity2 = world.getBlockEntity(blockPos);
				if (blockEntity2 instanceof ChestBlockEntity) {
					if (direction != Direction.WEST && direction != Direction.NORTH) {
						lockableMenuProvider = new DoubleInventory("container.chestDouble", lockableMenuProvider, (ChestBlockEntity)blockEntity2);
					} else {
						lockableMenuProvider = new DoubleInventory("container.chestDouble", (ChestBlockEntity)blockEntity2, lockableMenuProvider);
					}
				}
			}
		}

		return lockableMenuProvider;
	}

	@Override
	public BlockEntity createBlockEntity(World world, int metadata) {
		return new ChestBlockEntity();
	}

	@Override
	public boolean isSignalSource() {
		return this.type == 1;
	}

	@Override
	public int getSignal(WorldView world, BlockPos pos, BlockState state, Direction dir) {
		if (!this.isSignalSource()) {
			return 0;
		}

		int i = 0;
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof ChestBlockEntity) {
			i = ((ChestBlockEntity)blockEntity).viewerCount;
		}

		return MathHelper.clamp(i, 0, 15);
	}

	@Override
	public int getDirectSignal(WorldView world, BlockPos pos, BlockState state, Direction dir) {
		return dir == Direction.UP ? this.getSignal(world, pos, state, dir) : 0;
	}

	private boolean isLocked(World world, BlockPos pos) {
		return this.isLockedByBlock(world, pos) || this.isLockedByOcelot(world, pos);
	}

	private boolean isLockedByBlock(World world, BlockPos pos) {
		return world.getBlockState(pos.up()).getBlock().isSolid();
	}

	private boolean isLockedByOcelot(World world, BlockPos pos) {
		for (Entity entity : world.getEntitiesOfType(
			OcelotEntity.class, new Box(pos.getX(), pos.getY() + 1, pos.getZ(), pos.getX() + 1, pos.getY() + 2, pos.getZ() + 1)
		)) {
			OcelotEntity ocelotEntity = (OcelotEntity)entity;
			if (ocelotEntity.isSitting()) {
				return true;
			}
		}

		return false;
	}

	@Override
	public boolean isAnalogSignalSource() {
		return true;
	}

	@Override
	public int getAnalogSignal(World world, BlockPos pos) {
		return InventoryMenu.getAnalogSignal(this.getInventory(world, pos));
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		Direction direction = Direction.byId(metadata);
		if (direction.getAxis() == Direction.Axis.Y) {
			direction = Direction.NORTH;
		}

		return this.defaultState().set(FACING, direction);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		return state.get(FACING).getId();
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, FACING);
	}
}

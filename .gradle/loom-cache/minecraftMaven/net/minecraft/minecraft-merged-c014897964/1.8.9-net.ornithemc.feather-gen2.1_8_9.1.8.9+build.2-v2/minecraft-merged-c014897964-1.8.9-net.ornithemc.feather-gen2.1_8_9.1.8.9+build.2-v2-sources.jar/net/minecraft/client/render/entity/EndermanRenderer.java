package net.minecraft.client.render.entity;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.material.Material;
import net.minecraft.client.render.entity.layer.EndermanCarriedBlockLayer;
import net.minecraft.client.render.entity.layer.EndermanEyesLayer;
import net.minecraft.client.render.model.entity.EndermanModel;
import net.minecraft.entity.living.mob.monster.EndermanEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class EndermanRenderer extends MobRenderer<EndermanEntity> {
	private static final Identifier ENDERMAN_LOCATION = new Identifier("textures/entity/enderman/enderman.png");
	private EndermanModel model;
	private Random random = new Random();

	public EndermanRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher, new EndermanModel(0.0F), 0.5F);
		this.model = (EndermanModel)super.model;
		this.addLayer(new EndermanEyesLayer(this));
		this.addLayer(new EndermanCarriedBlockLayer(this));
	}

	public void render(EndermanEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		this.model.carryingBlock = entity.getCarriedBlock().getBlock().getMaterial() != Material.AIR;
		this.model.angry = entity.isAngry();
		if (entity.isAngry()) {
			double d = 0.02;
			dx += this.random.nextGaussian() * d;
			dz += this.random.nextGaussian() * d;
		}

		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(EndermanEntity entity) {
		return ENDERMAN_LOCATION;
	}
}

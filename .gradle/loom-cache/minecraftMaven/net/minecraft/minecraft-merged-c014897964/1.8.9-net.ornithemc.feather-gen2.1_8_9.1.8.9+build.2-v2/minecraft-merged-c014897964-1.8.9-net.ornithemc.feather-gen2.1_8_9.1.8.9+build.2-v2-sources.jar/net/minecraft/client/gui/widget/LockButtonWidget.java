package net.minecraft.client.gui.widget;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.platform.GlStateManager;

@Environment(EnvType.CLIENT)
public class LockButtonWidget extends ButtonWidget {
	private boolean locked = false;

	public LockButtonWidget(int id, int x, int y) {
		super(id, x, y, 20, 20, "");
	}

	public boolean isLocked() {
		return this.locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	@Override
	public void render(Minecraft minecraft, int mouseX, int mouseY) {
		if (this.visible) {
			minecraft.getTextureManager().bind(ButtonWidget.WIDGETS_LOCATION);
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			boolean bl = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;
			LockButtonWidget.Icon icon;
			if (this.locked) {
				if (!this.active) {
					icon = LockButtonWidget.Icon.LOCKED_DISABLED;
				} else if (bl) {
					icon = LockButtonWidget.Icon.LOCKED_HOVER;
				} else {
					icon = LockButtonWidget.Icon.LOCKED;
				}
			} else if (!this.active) {
				icon = LockButtonWidget.Icon.UNLOCKED_DISABLED;
			} else if (bl) {
				icon = LockButtonWidget.Icon.UNLOCKED_HOVER;
			} else {
				icon = LockButtonWidget.Icon.UNLOCKED;
			}

			this.drawTexture(this.x, this.y, icon.getU(), icon.getV(), this.width, this.height);
		}
	}

	@Environment(EnvType.CLIENT)
	enum Icon {
		LOCKED(0, 146),
		LOCKED_HOVER(0, 166),
		LOCKED_DISABLED(0, 186),
		UNLOCKED(20, 146),
		UNLOCKED_HOVER(20, 166),
		UNLOCKED_DISABLED(20, 186);

		private final int u;
		private final int v;

		Icon(int u, int v) {
			this.u = u;
			this.v = v;
		}

		public int getU() {
			return this.u;
		}

		public int getV() {
			return this.v;
		}
	}
}

package net.minecraft.client.gui.screen.menu.resourcepacks;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.resource.pack.ResourcePacks;

@Environment(EnvType.CLIENT)
public class CustomResourcePackEntry extends ResourcePackEntry {
	private final ResourcePacks.UnopenedPack pack;

	public CustomResourcePackEntry(ResourcePacksScreen parent, ResourcePacks.UnopenedPack pack) {
		super(parent);
		this.pack = pack;
	}

	@Override
	protected void bindIcon() {
		this.pack.bindIcon(this.minecraft.getTextureManager());
	}

	@Override
	protected int getFormat() {
		return this.pack.getFormat();
	}

	@Override
	protected String getDescription() {
		return this.pack.getDescription();
	}

	@Override
	protected String getName() {
		return this.pack.getName();
	}

	public ResourcePacks.UnopenedPack getPack() {
		return this.pack;
	}
}

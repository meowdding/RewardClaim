package net.minecraft.block;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.client.render.block.BlockLayer;
import net.minecraft.client.world.color.FoliageColors;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.stat.Stats;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.ornithemc.feather.constants.SetBlockFlags;

public class VineBlock extends Block {
	public static final BooleanProperty UP = BooleanProperty.of("up");
	public static final BooleanProperty NORTH = BooleanProperty.of("north");
	public static final BooleanProperty EAST = BooleanProperty.of("east");
	public static final BooleanProperty SOUTH = BooleanProperty.of("south");
	public static final BooleanProperty WEST = BooleanProperty.of("west");
	public static final BooleanProperty[] PROPERTIES = new BooleanProperty[]{UP, NORTH, SOUTH, WEST, EAST};

	public VineBlock() {
		super(Material.REPLACEABLE_PLANT);
		this.setDefaultState(this.stateDefinition.any().set(UP, false).set(NORTH, false).set(EAST, false).set(SOUTH, false).set(WEST, false));
		this.setTicksRandomly(true);
		this.setCreativeModeTab(CreativeModeTab.DECORATIONS);
	}

	@Override
	public BlockState resolveVirtualProperties(BlockState state, WorldView world, BlockPos pos) {
		return state.set(UP, world.getBlockState(pos.up()).getBlock().blocksAmbientLight());
	}

	@Override
	public void resetShape() {
		this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
	}

	@Override
	public boolean isSolidRender() {
		return false;
	}

	@Override
	public boolean isCube() {
		return false;
	}

	@Override
	public boolean canBeReplaced(World world, BlockPos pos) {
		return true;
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		float f = 0.0625F;
		float g = 1.0F;
		float h = 1.0F;
		float i = 1.0F;
		float j = 0.0F;
		float k = 0.0F;
		float l = 0.0F;
		boolean bl = false;
		if (world.getBlockState(pos).get(WEST)) {
			j = Math.max(j, 0.0625F);
			g = 0.0F;
			h = 0.0F;
			k = 1.0F;
			i = 0.0F;
			l = 1.0F;
			bl = true;
		}

		if (world.getBlockState(pos).get(EAST)) {
			g = Math.min(g, 0.9375F);
			j = 1.0F;
			h = 0.0F;
			k = 1.0F;
			i = 0.0F;
			l = 1.0F;
			bl = true;
		}

		if (world.getBlockState(pos).get(NORTH)) {
			l = Math.max(l, 0.0625F);
			i = 0.0F;
			g = 0.0F;
			j = 1.0F;
			h = 0.0F;
			k = 1.0F;
			bl = true;
		}

		if (world.getBlockState(pos).get(SOUTH)) {
			i = Math.min(i, 0.9375F);
			l = 1.0F;
			g = 0.0F;
			j = 1.0F;
			h = 0.0F;
			k = 1.0F;
			bl = true;
		}

		if (!bl && this.canGrowOn(world.getBlockState(pos.up()).getBlock())) {
			h = Math.min(h, 0.9375F);
			k = 1.0F;
			g = 0.0F;
			j = 1.0F;
			i = 0.0F;
			l = 1.0F;
		}

		this.setShape(g, h, i, j, k, l);
	}

	@Override
	public Box getCollisionShape(World world, BlockPos pos, BlockState state) {
		return null;
	}

	@Override
	public boolean canBePlaced(World world, BlockPos pos, Direction face) {
		switch (face) {
			case UP:
				return this.canGrowOn(world.getBlockState(pos.up()).getBlock());
			case NORTH:
			case SOUTH:
			case EAST:
			case WEST:
				return this.canGrowOn(world.getBlockState(pos.offset(face.getOpposite())).getBlock());
			default:
				return false;
		}
	}

	private boolean canGrowOn(Block block) {
		return block.isCube() && block.material.blocksMovement();
	}

	private boolean hasConnections(World world, BlockPos pos, BlockState state) {
		BlockState blockState = state;

		for (Direction direction : Direction.Plane.HORIZONTAL) {
			BooleanProperty booleanProperty = getPropertyForDirection(direction);
			if (state.get(booleanProperty) && !this.canGrowOn(world.getBlockState(pos.offset(direction)).getBlock())) {
				BlockState blockState2 = world.getBlockState(pos.up());
				if (blockState2.getBlock() != this || !blockState2.get(booleanProperty)) {
					state = state.set(booleanProperty, false);
				}
			}
		}

		if (getConnectionCount(state) == 0) {
			return false;
		}

		if (blockState != state) {
			world.setBlockState(pos, state, SetBlockFlags.NOTIFY_LISTENERS);
		}

		return true;
	}

	@Environment(EnvType.CLIENT)
	@Override
	public int getColor() {
		return FoliageColors.getDefaultColor();
	}

	@Environment(EnvType.CLIENT)
	@Override
	public int getColor(BlockState state) {
		return FoliageColors.getDefaultColor();
	}

	@Environment(EnvType.CLIENT)
	@Override
	public int getColorTint(WorldView world, BlockPos pos, int tint) {
		return world.getBiome(pos).getFoliageColor(pos);
	}

	@Override
	public void neighborChanged(World world, BlockPos pos, BlockState state, Block neighborBlock) {
		if (!world.isClient && !this.hasConnections(world, pos, state)) {
			this.dropItems(world, pos, state, 0);
			world.removeBlock(pos);
		}
	}

	@Override
	public void tick(World world, BlockPos pos, BlockState state, Random random) {
		if (!world.isClient) {
			if (world.random.nextInt(4) == 0) {
				int i = 4;
				int j = 5;
				boolean bl = false;

				label189:
				for (int k = -i; k <= i; k++) {
					for (int l = -i; l <= i; l++) {
						for (int m = -1; m <= 1; m++) {
							if (world.getBlockState(pos.add(k, m, l)).getBlock() == this) {
								if (--j <= 0) {
									bl = true;
									break label189;
								}
							}
						}
					}
				}

				Direction direction = Direction.pick(random);
				BlockPos blockPos = pos.up();
				if (direction == Direction.UP && pos.getY() < 255 && world.isAir(blockPos)) {
					if (!bl) {
						BlockState blockState = state;

						for (Direction direction2 : Direction.Plane.HORIZONTAL) {
							if (random.nextBoolean() || !this.canGrowOn(world.getBlockState(blockPos.offset(direction2)).getBlock())) {
								blockState = blockState.set(getPropertyForDirection(direction2), false);
							}
						}

						if (blockState.get(NORTH) || blockState.get(EAST) || blockState.get(SOUTH) || blockState.get(WEST)) {
							world.setBlockState(blockPos, blockState, SetBlockFlags.NOTIFY_LISTENERS);
						}
					}
				} else if (!direction.getAxis().isHorizontal() || state.get(getPropertyForDirection(direction))) {
					if (pos.getY() > 1) {
						BlockPos blockPos2 = pos.down();
						BlockState blockState2 = world.getBlockState(blockPos2);
						Block block2 = blockState2.getBlock();
						if (block2.material == Material.AIR) {
							BlockState blockState3 = state;

							for (Direction direction4 : Direction.Plane.HORIZONTAL) {
								if (random.nextBoolean()) {
									blockState3 = blockState3.set(getPropertyForDirection(direction4), false);
								}
							}

							if (blockState3.get(NORTH) || blockState3.get(EAST) || blockState3.get(SOUTH) || blockState3.get(WEST)) {
								world.setBlockState(blockPos2, blockState3, SetBlockFlags.NOTIFY_LISTENERS);
							}
						} else if (block2 == this) {
							BlockState blockState3 = blockState2;

							for (Direction direction4 : Direction.Plane.HORIZONTAL) {
								BooleanProperty booleanProperty = getPropertyForDirection(direction4);
								if (random.nextBoolean() && state.get(booleanProperty)) {
									blockState3 = blockState3.set(booleanProperty, true);
								}
							}

							if (blockState3.get(NORTH) || blockState3.get(EAST) || blockState3.get(SOUTH) || blockState3.get(WEST)) {
								world.setBlockState(blockPos2, blockState3, SetBlockFlags.NOTIFY_LISTENERS);
							}
						}
					}
				} else if (!bl) {
					BlockPos blockPos2 = pos.offset(direction);
					Block block = world.getBlockState(blockPos2).getBlock();
					if (block.material == Material.AIR) {
						Direction direction2 = direction.clockwiseY();
						Direction direction3 = direction.counterClockwiseY();
						boolean bl2 = state.get(getPropertyForDirection(direction2));
						boolean bl3 = state.get(getPropertyForDirection(direction3));
						BlockPos blockPos3 = blockPos2.offset(direction2);
						BlockPos blockPos4 = blockPos2.offset(direction3);
						if (bl2 && this.canGrowOn(world.getBlockState(blockPos3).getBlock())) {
							world.setBlockState(blockPos2, this.defaultState().set(getPropertyForDirection(direction2), true), SetBlockFlags.NOTIFY_LISTENERS);
						} else if (bl3 && this.canGrowOn(world.getBlockState(blockPos4).getBlock())) {
							world.setBlockState(blockPos2, this.defaultState().set(getPropertyForDirection(direction3), true), SetBlockFlags.NOTIFY_LISTENERS);
						} else if (bl2 && world.isAir(blockPos3) && this.canGrowOn(world.getBlockState(pos.offset(direction2)).getBlock())) {
							world.setBlockState(blockPos3, this.defaultState().set(getPropertyForDirection(direction.getOpposite()), true), SetBlockFlags.NOTIFY_LISTENERS);
						} else if (bl3 && world.isAir(blockPos4) && this.canGrowOn(world.getBlockState(pos.offset(direction3)).getBlock())) {
							world.setBlockState(blockPos4, this.defaultState().set(getPropertyForDirection(direction.getOpposite()), true), SetBlockFlags.NOTIFY_LISTENERS);
						} else if (this.canGrowOn(world.getBlockState(blockPos2.up()).getBlock())) {
							world.setBlockState(blockPos2, this.defaultState(), SetBlockFlags.NOTIFY_LISTENERS);
						}
					} else if (block.material.isSolidBlocking() && block.isCube()) {
						world.setBlockState(pos, state.set(getPropertyForDirection(direction), true), SetBlockFlags.NOTIFY_LISTENERS);
					}
				}
			}
		}
	}

	@Override
	public BlockState getPlacementState(World world, BlockPos pos, Direction dir, float dx, float dy, float dz, int metadata, LivingEntity entity) {
		BlockState blockState = this.defaultState().set(UP, false).set(NORTH, false).set(EAST, false).set(SOUTH, false).set(WEST, false);
		return dir.getAxis().isHorizontal() ? blockState.set(getPropertyForDirection(dir.getOpposite()), true) : blockState;
	}

	@Override
	public Item getDropItem(BlockState state, Random random, int fortuneLevel) {
		return null;
	}

	@Override
	public int getBaseDropCount(Random random) {
		return 0;
	}

	@Override
	public void afterMinedByPlayer(World world, PlayerEntity player, BlockPos pos, BlockState state, BlockEntity blockEntity) {
		if (!world.isClient && player.getItemInHand() != null && player.getItemInHand().getItem() == Items.SHEARS) {
			player.incrementStat(Stats.BLOCKS_MINED[Block.getId(this)]);
			dropItem(world, pos, new ItemStack(Blocks.VINE, 1, 0));
		} else {
			super.afterMinedByPlayer(world, player, pos, state, blockEntity);
		}
	}

	@Environment(EnvType.CLIENT)
	@Override
	public BlockLayer getRenderLayer() {
		return BlockLayer.CUTOUT;
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		return this.defaultState().set(SOUTH, (metadata & 1) > 0).set(WEST, (metadata & 2) > 0).set(NORTH, (metadata & 4) > 0).set(EAST, (metadata & 8) > 0);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		int i = 0;
		if (state.get(SOUTH)) {
			i |= 1;
		}

		if (state.get(WEST)) {
			i |= 2;
		}

		if (state.get(NORTH)) {
			i |= 4;
		}

		if (state.get(EAST)) {
			i |= 8;
		}

		return i;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, UP, NORTH, EAST, SOUTH, WEST);
	}

	public static BooleanProperty getPropertyForDirection(Direction dir) {
		switch (dir) {
			case UP:
				return UP;
			case NORTH:
				return NORTH;
			case SOUTH:
				return SOUTH;
			case EAST:
				return EAST;
			case WEST:
				return WEST;
			default:
				throw new IllegalArgumentException(dir + " is an invalid choice");
		}
	}

	public static int getConnectionCount(BlockState state) {
		int i = 0;

		for (BooleanProperty booleanProperty : PROPERTIES) {
			if (state.get(booleanProperty)) {
				i++;
			}
		}

		return i;
	}
}

package net.minecraft.client.entity.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.world.World;

@Environment(EnvType.CLIENT)
public class ItemParticle extends Particle {
	protected ItemParticle(World world, double x, double y, double z, Item item) {
		this(world, x, y, z, item, 0);
	}

	protected ItemParticle(World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, Item item, int metadata) {
		this(world, x, y, z, item, metadata);
		this.velocityX *= 0.1F;
		this.velocityY *= 0.1F;
		this.velocityZ *= 0.1F;
		this.velocityX += velocityX;
		this.velocityY += velocityY;
		this.velocityZ += velocityZ;
	}

	protected ItemParticle(World world, double x, double y, double z, Item item, int metadata) {
		super(world, x, y, z, 0.0, 0.0, 0.0);
		this.setTexture(Minecraft.getInstance().getItemRenderer().getModelShaper().getParticleIcon(item, metadata));
		this.red = this.green = this.blue = 1.0F;
		this.gravity = Blocks.SNOW.gravity;
		this.size /= 2.0F;
	}

	@Override
	public int getAtlasType() {
		return 1;
	}

	@Override
	public void render(BufferBuilder bufferBuilder, Entity camera, float tickDelta, float dx, float dy, float dz, float forwards, float sideways) {
		float f = (this.spriteRow + this.offsetU / 4.0F) / 16.0F;
		float g = f + 0.015609375F;
		float h = (this.spriteColumn + this.offsetV / 4.0F) / 16.0F;
		float i = h + 0.015609375F;
		float j = 0.1F * this.size;
		if (this.sprite != null) {
			f = this.sprite.getU(this.offsetU / 4.0F * 16.0F);
			g = this.sprite.getU((this.offsetU + 1.0F) / 4.0F * 16.0F);
			h = this.sprite.getV(this.offsetV / 4.0F * 16.0F);
			i = this.sprite.getV((this.offsetV + 1.0F) / 4.0F * 16.0F);
		}

		float k = (float)(this.lastX + (this.x - this.lastX) * tickDelta - cameraX);
		float l = (float)(this.lastY + (this.y - this.lastY) * tickDelta - cameraY);
		float m = (float)(this.lastZ + (this.z - this.lastZ) * tickDelta - cameraZ);
		int n = this.getLightLevel(tickDelta);
		int o = n >> 16 & 65535;
		int p = n & 65535;
		bufferBuilder.vertex(k - dx * j - forwards * j, l - dy * j, m - dz * j - sideways * j)
			.texture(f, i)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
		bufferBuilder.vertex(k - dx * j + forwards * j, l + dy * j, m - dz * j + sideways * j)
			.texture(f, h)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
		bufferBuilder.vertex(k + dx * j + forwards * j, l + dy * j, m + dz * j + sideways * j)
			.texture(g, h)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
		bufferBuilder.vertex(k + dx * j - forwards * j, l - dy * j, m + dz * j - sideways * j)
			.texture(g, i)
			.color(this.red, this.green, this.blue, 1.0F)
			.texture(o, p)
			.nextVertex();
	}

	@Environment(EnvType.CLIENT)
	public static class Factory implements ParticleFactory {
		@Override
		public Particle create(int type, World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, int... parameters) {
			int i = parameters.length > 1 ? parameters[1] : 0;
			return new ItemParticle(world, x, y, z, velocityX, velocityY, velocityZ, Item.byId(parameters[0]), i);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class SlimeBallFactory implements ParticleFactory {
		@Override
		public Particle create(int type, World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, int... parameters) {
			return new ItemParticle(world, x, y, z, Items.SLIME_BALL);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class SnowballFactory implements ParticleFactory {
		@Override
		public Particle create(int type, World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, int... parameters) {
			return new ItemParticle(world, x, y, z, Items.SNOWBALL);
		}
	}
}

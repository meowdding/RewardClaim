package net.minecraft.client.main;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.authlib.properties.PropertyMap;
import com.mojang.authlib.properties.PropertyMap.Serializer;
import java.io.File;
import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.util.List;
import joptsimple.OptionParser;
import joptsimple.OptionSet;
import joptsimple.OptionSpec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Session;

@Environment(EnvType.CLIENT)
public class Main {
	public static void main(String[] args) {
		System.setProperty("java.net.preferIPv4Stack", "true");
		OptionParser optionParser = new OptionParser();
		optionParser.allowsUnrecognizedOptions();
		optionParser.accepts("demo");
		optionParser.accepts("fullscreen");
		optionParser.accepts("checkGlErrors");
		OptionSpec<String> optionSpec = optionParser.accepts("server").withRequiredArg();
		OptionSpec<Integer> optionSpec2 = optionParser.accepts("port").withRequiredArg().ofType(Integer.class).defaultsTo(25565);
		OptionSpec<File> optionSpec3 = optionParser.accepts("gameDir").withRequiredArg().ofType(File.class).defaultsTo(new File("."));
		OptionSpec<File> optionSpec4 = optionParser.accepts("assetsDir").withRequiredArg().ofType(File.class);
		OptionSpec<File> optionSpec5 = optionParser.accepts("resourcePackDir").withRequiredArg().ofType(File.class);
		OptionSpec<String> optionSpec6 = optionParser.accepts("proxyHost").withRequiredArg();
		OptionSpec<Integer> optionSpec7 = optionParser.accepts("proxyPort").withRequiredArg().defaultsTo("8080").ofType(Integer.class);
		OptionSpec<String> optionSpec8 = optionParser.accepts("proxyUser").withRequiredArg();
		OptionSpec<String> optionSpec9 = optionParser.accepts("proxyPass").withRequiredArg();
		OptionSpec<String> optionSpec10 = optionParser.accepts("username").withRequiredArg().defaultsTo("Player" + Minecraft.getTime() % 1000L);
		OptionSpec<String> optionSpec11 = optionParser.accepts("uuid").withRequiredArg();
		OptionSpec<String> optionSpec12 = optionParser.accepts("accessToken").withRequiredArg().required();
		OptionSpec<String> optionSpec13 = optionParser.accepts("version").withRequiredArg().required();
		OptionSpec<Integer> optionSpec14 = optionParser.accepts("width").withRequiredArg().ofType(Integer.class).defaultsTo(854);
		OptionSpec<Integer> optionSpec15 = optionParser.accepts("height").withRequiredArg().ofType(Integer.class).defaultsTo(480);
		OptionSpec<String> optionSpec16 = optionParser.accepts("userProperties").withRequiredArg().defaultsTo("{}");
		OptionSpec<String> optionSpec17 = optionParser.accepts("profileProperties").withRequiredArg().defaultsTo("{}");
		OptionSpec<String> optionSpec18 = optionParser.accepts("assetIndex").withRequiredArg();
		OptionSpec<String> optionSpec19 = optionParser.accepts("userType").withRequiredArg().defaultsTo("legacy");
		OptionSpec<String> optionSpec20 = optionParser.nonOptions();
		OptionSet optionSet = optionParser.parse(args);
		List<String> list = optionSet.valuesOf(optionSpec20);
		if (!list.isEmpty()) {
			System.out.println("Completely ignored arguments: " + list);
		}

		String string = optionSet.valueOf(optionSpec6);
		Proxy proxy = Proxy.NO_PROXY;
		if (string != null) {
			try {
				proxy = new Proxy(Type.SOCKS, new InetSocketAddress(string, optionSet.valueOf(optionSpec7)));
			} catch (Exception var46) {
			}
		}

		final String string2 = optionSet.valueOf(optionSpec8);
		final String string3 = optionSet.valueOf(optionSpec9);
		if (!proxy.equals(Proxy.NO_PROXY) && isNotNullOrEmpty(string2) && isNotNullOrEmpty(string3)) {
			Authenticator.setDefault(new Authenticator() {
				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(string2, string3.toCharArray());
				}
			});
		}

		int i = optionSet.valueOf(optionSpec14);
		int j = optionSet.valueOf(optionSpec15);
		boolean bl = optionSet.has("fullscreen");
		boolean bl2 = optionSet.has("checkGlErrors");
		boolean bl3 = optionSet.has("demo");
		String string4 = optionSet.valueOf(optionSpec13);
		Gson gson = new GsonBuilder().registerTypeAdapter(PropertyMap.class, new Serializer()).create();
		PropertyMap propertyMap = gson.fromJson(optionSet.valueOf(optionSpec16), PropertyMap.class);
		PropertyMap propertyMap2 = gson.fromJson(optionSet.valueOf(optionSpec17), PropertyMap.class);
		File file = optionSet.valueOf(optionSpec3);
		File file2 = optionSet.has(optionSpec4) ? optionSet.valueOf(optionSpec4) : new File(file, "assets/");
		File file3 = optionSet.has(optionSpec5) ? optionSet.valueOf(optionSpec5) : new File(file, "resourcepacks/");
		String string5 = optionSet.has(optionSpec11) ? optionSpec11.value(optionSet) : optionSpec10.value(optionSet);
		String string6 = optionSet.has(optionSpec18) ? optionSpec18.value(optionSet) : null;
		String string7 = optionSet.valueOf(optionSpec);
		Integer integer = optionSet.valueOf(optionSpec2);
		Session session = new Session(optionSpec10.value(optionSet), string5, optionSpec12.value(optionSet), optionSpec19.value(optionSet));
		RunArgs runArgs = new RunArgs(
			new RunArgs.User(session, propertyMap, propertyMap2, proxy),
			new RunArgs.Display(i, j, bl, bl2),
			new RunArgs.Directories(file, file3, file2, string6),
			new RunArgs.Game(bl3, string4),
			new RunArgs.Server(string7, integer)
		);
		Runtime.getRuntime().addShutdownHook(new Thread("Client Shutdown Thread") {
			@Override
			public void run() {
				Minecraft.stopServer();
			}
		});
		Thread.currentThread().setName("Client thread");
		new Minecraft(runArgs).run();
	}

	private static boolean isNotNullOrEmpty(String s) {
		return s != null && !s.isEmpty();
	}
}

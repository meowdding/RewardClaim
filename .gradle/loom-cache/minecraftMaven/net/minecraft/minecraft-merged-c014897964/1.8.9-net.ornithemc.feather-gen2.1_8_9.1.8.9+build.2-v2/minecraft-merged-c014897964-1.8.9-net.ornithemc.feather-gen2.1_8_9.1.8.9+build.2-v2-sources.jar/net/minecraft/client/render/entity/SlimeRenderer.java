package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.layer.SlimeOuterLayer;
import net.minecraft.client.render.model.Model;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.monster.SlimeEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class SlimeRenderer extends MobRenderer<SlimeEntity> {
	private static final Identifier SLIME_LOCATION = new Identifier("textures/entity/slime/slime.png");

	public SlimeRenderer(EntityRenderDispatcher entityRenderDispatcher, Model model, float f) {
		super(entityRenderDispatcher, model, f);
		this.addLayer(new SlimeOuterLayer(this));
	}

	public void render(SlimeEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		this.shadowSize = 0.25F * entity.getSize();
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected void applyScale(SlimeEntity entity, float scale) {
		float f = entity.getSize();
		float g = (entity.lastStretch + (entity.stretch - entity.lastStretch) * scale) / (f * 0.5F + 1.0F);
		float h = 1.0F / (g + 1.0F);
		GlStateManager.scalef(h * f, 1.0F / h * f, h * f);
	}

	protected Identifier getTextureLocation(SlimeEntity entity) {
		return SLIME_LOCATION;
	}
}

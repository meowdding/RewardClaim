package net.minecraft.client.gui.spectator;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public interface SpectatorMenuCategory {
	List<SpectatorMenuItem> getItems();

	Text getPrompt();
}

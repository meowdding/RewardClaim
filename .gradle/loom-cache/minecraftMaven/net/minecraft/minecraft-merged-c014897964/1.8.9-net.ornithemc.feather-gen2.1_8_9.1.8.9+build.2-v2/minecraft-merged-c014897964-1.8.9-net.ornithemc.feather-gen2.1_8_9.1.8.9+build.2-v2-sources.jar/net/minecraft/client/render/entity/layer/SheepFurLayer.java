package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.SheepRenderer;
import net.minecraft.client.render.model.entity.SheepFurModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.passive.animal.SheepEntity;
import net.minecraft.item.DyeColor;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class SheepFurLayer implements EntityRenderLayer<SheepEntity> {
	private static final Identifier SHEEP_FUR_LOCATION = new Identifier("textures/entity/sheep/sheep_fur.png");
	private final SheepRenderer parent;
	private final SheepFurModel model = new SheepFurModel();

	public SheepFurLayer(SheepRenderer parent) {
		this.parent = parent;
	}

	public void render(SheepEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale) {
		if (!entity.isSheared() && !entity.isInvisible()) {
			this.parent.bindTexture(SHEEP_FUR_LOCATION);
			if (entity.hasCustomName() && "jeb_".equals(entity.getCustomName())) {
				int i = 25;
				int j = entity.ticks / 25 + entity.getNetworkId();
				int k = DyeColor.values().length;
				int l = j % k;
				int m = (j + 1) % k;
				float f = (entity.ticks % 25 + tickDelta) / 25.0F;
				float[] fs = SheepEntity.getColorRgb(DyeColor.byId(l));
				float[] gs = SheepEntity.getColorRgb(DyeColor.byId(m));
				GlStateManager.color3f(fs[0] * (1.0F - f) + gs[0] * f, fs[1] * (1.0F - f) + gs[1] * f, fs[2] * (1.0F - f) + gs[2] * f);
			} else {
				float[] hs = SheepEntity.getColorRgb(entity.getColor());
				GlStateManager.color3f(hs[0], hs[1], hs[2]);
			}

			this.model.copyPropertiesFrom(this.parent.getModel());
			this.model.prepare(entity, walkAnimationProgress, walkAnimationSpeed, tickDelta);
			this.model.render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return true;
	}
}

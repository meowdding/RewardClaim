package net.minecraft.client.entity.living.player;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.PlayerInfo;
import net.minecraft.client.render.texture.HttpTexture;
import net.minecraft.client.render.texture.SkinImageProcessor;
import net.minecraft.client.render.texture.Texture;
import net.minecraft.client.render.texture.TextureManager;
import net.minecraft.client.resource.skin.DefaultSkinUtils;
import net.minecraft.entity.living.attribute.EntityAttributeInstance;
import net.minecraft.entity.living.attribute.EntityAttributes;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.resource.Identifier;
import net.minecraft.text.StringUtils;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings;

@Environment(EnvType.CLIENT)
public abstract class ClientPlayerEntity extends PlayerEntity {
	private PlayerInfo player;

	public ClientPlayerEntity(World world, GameProfile gameProfile) {
		super(world, gameProfile);
	}

	@Override
	public boolean isSpectator() {
		PlayerInfo playerInfo = Minecraft.getInstance().getNetworkHandler().getOnlinePlayer(this.getGameProfile().getId());
		return playerInfo != null && playerInfo.getGameMode() == WorldSettings.GameMode.SPECTATOR;
	}

	public boolean hasInfo() {
		return this.getInfo() != null;
	}

	protected PlayerInfo getInfo() {
		if (this.player == null) {
			this.player = Minecraft.getInstance().getNetworkHandler().getOnlinePlayer(this.getUuid());
		}

		return this.player;
	}

	public boolean hasSkinTexture() {
		PlayerInfo playerInfo = this.getInfo();
		return playerInfo != null && playerInfo.hasSkinTexture();
	}

	public Identifier getSkinTextureLocation() {
		PlayerInfo playerInfo = this.getInfo();
		return playerInfo == null ? DefaultSkinUtils.getDefaultSkin(this.getUuid()) : playerInfo.getSkinTexture();
	}

	public Identifier getCapeTextureLocation() {
		PlayerInfo playerInfo = this.getInfo();
		return playerInfo == null ? null : playerInfo.getCapeTexture();
	}

	public static HttpTexture loadSkinTexture(Identifier location, String playerName) {
		TextureManager textureManager = Minecraft.getInstance().getTextureManager();
		Texture texture = textureManager.get(location);
		if (texture == null) {
			texture = new HttpTexture(
				null,
				String.format("http://skins.minecraft.net/MinecraftSkins/%s.png", StringUtils.stripFormatting(playerName)),
				DefaultSkinUtils.getDefaultSkin(getUuidForOffline(playerName)),
				new SkinImageProcessor()
			);
			textureManager.register(location, texture);
		}

		return (HttpTexture)texture;
	}

	public static Identifier getSkinTextureLocation(String playerName) {
		return new Identifier("skins/" + StringUtils.stripFormatting(playerName));
	}

	public String getModelType() {
		PlayerInfo playerInfo = this.getInfo();
		return playerInfo == null ? DefaultSkinUtils.getDefaultModelType(this.getUuid()) : playerInfo.getModelType();
	}

	public float getFovModifier() {
		float f = 1.0F;
		if (this.abilities.flying) {
			f *= 1.1F;
		}

		EntityAttributeInstance entityAttributeInstance = this.getAttribute(EntityAttributes.MOVEMENT_SPEED);
		f = (float)(f * ((entityAttributeInstance.get() / this.abilities.getWalkSpeed() + 1.0) / 2.0));
		if (this.abilities.getWalkSpeed() == 0.0F || Float.isNaN(f) || Float.isInfinite(f)) {
			f = 1.0F;
		}

		if (this.hasItemInUse() && this.getItemInUse().getItem() == Items.BOW) {
			int i = this.getRemainingItemUseDuration();
			float g = i / 20.0F;
			if (g > 1.0F) {
				g = 1.0F;
			} else {
				g *= g;
			}

			f *= 1.0F - g * 0.15F;
		}

		return f;
	}
}

package net.minecraft.block;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.DirectionProperty;
import net.minecraft.block.state.property.EnumProperty;
import net.minecraft.block.state.property.StringSerializable;
import net.minecraft.client.render.block.BlockLayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.HitResult;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.explosion.Explosion;

public class StairsBlock extends Block {
	public static final DirectionProperty FACING = DirectionProperty.of("facing", Direction.Plane.HORIZONTAL);
	public static final EnumProperty<StairsBlock.Half> HALF = EnumProperty.of("half", StairsBlock.Half.class);
	public static final EnumProperty<StairsBlock.Shape> SHAPE = EnumProperty.of("shape", StairsBlock.Shape.class);
	private static final int[][] ROTATIONS = new int[][]{{4, 5}, {5, 7}, {6, 7}, {4, 6}, {0, 1}, {1, 3}, {2, 3}, {0, 2}};
	private final Block baseBlock;
	private final BlockState baseState;
	private boolean isCorner;
	private int stairType;

	protected StairsBlock(BlockState baseState) {
		super(baseState.getBlock().material);
		this.setDefaultState(this.stateDefinition.any().set(FACING, Direction.NORTH).set(HALF, StairsBlock.Half.BOTTOM).set(SHAPE, StairsBlock.Shape.STRAIGHT));
		this.baseBlock = baseState.getBlock();
		this.baseState = baseState;
		this.setStrength(this.baseBlock.miningTime);
		this.setBlastResistance(this.baseBlock.blastResistance / 3.0F);
		this.setSounds(this.baseBlock.sounds);
		this.setOpacity(255);
		this.setCreativeModeTab(CreativeModeTab.BUILDING_BLOCKS);
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		if (this.isCorner) {
			this.setShape(
				0.5F * (this.stairType % 2),
				0.5F * (this.stairType / 4 % 2),
				0.5F * (this.stairType / 2 % 2),
				0.5F + 0.5F * (this.stairType % 2),
				0.5F + 0.5F * (this.stairType / 4 % 2),
				0.5F + 0.5F * (this.stairType / 2 % 2)
			);
		} else {
			this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		}
	}

	@Override
	public boolean isSolidRender() {
		return false;
	}

	@Override
	public boolean isCube() {
		return false;
	}

	public void setBaseShapeForCollisions(WorldView world, BlockPos pos) {
		if (world.getBlockState(pos).get(HALF) == StairsBlock.Half.TOP) {
			this.setShape(0.0F, 0.5F, 0.0F, 1.0F, 1.0F, 1.0F);
		} else {
			this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
		}
	}

	public static boolean isStair(Block block) {
		return block instanceof StairsBlock;
	}

	public static boolean isStairSameHalfSameFacing(WorldView world, BlockPos pos, BlockState state) {
		BlockState blockState = world.getBlockState(pos);
		Block block = blockState.getBlock();
		return isStair(block) && blockState.get(HALF) == state.get(HALF) && blockState.get(FACING) == state.get(FACING);
	}

	public int getMetadataForOuterStair(WorldView world, BlockPos pos) {
		BlockState blockState = world.getBlockState(pos);
		Direction direction = blockState.get(FACING);
		StairsBlock.Half half = blockState.get(HALF);
		boolean bl = half == StairsBlock.Half.TOP;
		if (direction == Direction.EAST) {
			BlockState blockState2 = world.getBlockState(pos.east());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.NORTH && !isStairSameHalfSameFacing(world, pos.south(), blockState)) {
					return bl ? 1 : 2;
				}

				if (direction2 == Direction.SOUTH && !isStairSameHalfSameFacing(world, pos.north(), blockState)) {
					return bl ? 2 : 1;
				}
			}
		} else if (direction == Direction.WEST) {
			BlockState blockState2 = world.getBlockState(pos.west());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.NORTH && !isStairSameHalfSameFacing(world, pos.south(), blockState)) {
					return bl ? 2 : 1;
				}

				if (direction2 == Direction.SOUTH && !isStairSameHalfSameFacing(world, pos.north(), blockState)) {
					return bl ? 1 : 2;
				}
			}
		} else if (direction == Direction.SOUTH) {
			BlockState blockState2 = world.getBlockState(pos.south());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.WEST && !isStairSameHalfSameFacing(world, pos.east(), blockState)) {
					return bl ? 2 : 1;
				}

				if (direction2 == Direction.EAST && !isStairSameHalfSameFacing(world, pos.west(), blockState)) {
					return bl ? 1 : 2;
				}
			}
		} else if (direction == Direction.NORTH) {
			BlockState blockState2 = world.getBlockState(pos.north());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.WEST && !isStairSameHalfSameFacing(world, pos.east(), blockState)) {
					return bl ? 1 : 2;
				}

				if (direction2 == Direction.EAST && !isStairSameHalfSameFacing(world, pos.west(), blockState)) {
					return bl ? 2 : 1;
				}
			}
		}

		return 0;
	}

	public int getMetadataForInnerStair(WorldView world, BlockPos pos) {
		BlockState blockState = world.getBlockState(pos);
		Direction direction = blockState.get(FACING);
		StairsBlock.Half half = blockState.get(HALF);
		boolean bl = half == StairsBlock.Half.TOP;
		if (direction == Direction.EAST) {
			BlockState blockState2 = world.getBlockState(pos.west());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.NORTH && !isStairSameHalfSameFacing(world, pos.north(), blockState)) {
					return bl ? 1 : 2;
				}

				if (direction2 == Direction.SOUTH && !isStairSameHalfSameFacing(world, pos.south(), blockState)) {
					return bl ? 2 : 1;
				}
			}
		} else if (direction == Direction.WEST) {
			BlockState blockState2 = world.getBlockState(pos.east());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.NORTH && !isStairSameHalfSameFacing(world, pos.north(), blockState)) {
					return bl ? 2 : 1;
				}

				if (direction2 == Direction.SOUTH && !isStairSameHalfSameFacing(world, pos.south(), blockState)) {
					return bl ? 1 : 2;
				}
			}
		} else if (direction == Direction.SOUTH) {
			BlockState blockState2 = world.getBlockState(pos.north());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.WEST && !isStairSameHalfSameFacing(world, pos.west(), blockState)) {
					return bl ? 2 : 1;
				}

				if (direction2 == Direction.EAST && !isStairSameHalfSameFacing(world, pos.east(), blockState)) {
					return bl ? 1 : 2;
				}
			}
		} else if (direction == Direction.NORTH) {
			BlockState blockState2 = world.getBlockState(pos.south());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.WEST && !isStairSameHalfSameFacing(world, pos.west(), blockState)) {
					return bl ? 1 : 2;
				}

				if (direction2 == Direction.EAST && !isStairSameHalfSameFacing(world, pos.east(), blockState)) {
					return bl ? 2 : 1;
				}
			}
		}

		return 0;
	}

	public boolean isInnerStair(WorldView world, BlockPos pos) {
		BlockState blockState = world.getBlockState(pos);
		Direction direction = blockState.get(FACING);
		StairsBlock.Half half = blockState.get(HALF);
		boolean bl = half == StairsBlock.Half.TOP;
		float f = 0.5F;
		float g = 1.0F;
		if (bl) {
			f = 0.0F;
			g = 0.5F;
		}

		float h = 0.0F;
		float i = 1.0F;
		float j = 0.0F;
		float k = 0.5F;
		boolean bl2 = true;
		if (direction == Direction.EAST) {
			h = 0.5F;
			k = 1.0F;
			BlockState blockState2 = world.getBlockState(pos.east());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.NORTH && !isStairSameHalfSameFacing(world, pos.south(), blockState)) {
					k = 0.5F;
					bl2 = false;
				} else if (direction2 == Direction.SOUTH && !isStairSameHalfSameFacing(world, pos.north(), blockState)) {
					j = 0.5F;
					bl2 = false;
				}
			}
		} else if (direction == Direction.WEST) {
			i = 0.5F;
			k = 1.0F;
			BlockState blockState2 = world.getBlockState(pos.west());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.NORTH && !isStairSameHalfSameFacing(world, pos.south(), blockState)) {
					k = 0.5F;
					bl2 = false;
				} else if (direction2 == Direction.SOUTH && !isStairSameHalfSameFacing(world, pos.north(), blockState)) {
					j = 0.5F;
					bl2 = false;
				}
			}
		} else if (direction == Direction.SOUTH) {
			j = 0.5F;
			k = 1.0F;
			BlockState blockState2 = world.getBlockState(pos.south());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.WEST && !isStairSameHalfSameFacing(world, pos.east(), blockState)) {
					i = 0.5F;
					bl2 = false;
				} else if (direction2 == Direction.EAST && !isStairSameHalfSameFacing(world, pos.west(), blockState)) {
					h = 0.5F;
					bl2 = false;
				}
			}
		} else if (direction == Direction.NORTH) {
			BlockState blockState2 = world.getBlockState(pos.north());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.WEST && !isStairSameHalfSameFacing(world, pos.east(), blockState)) {
					i = 0.5F;
					bl2 = false;
				} else if (direction2 == Direction.EAST && !isStairSameHalfSameFacing(world, pos.west(), blockState)) {
					h = 0.5F;
					bl2 = false;
				}
			}
		}

		this.setShape(h, f, j, i, g, k);
		return bl2;
	}

	public boolean setStepShapeForCollisions(WorldView world, BlockPos pos) {
		BlockState blockState = world.getBlockState(pos);
		Direction direction = blockState.get(FACING);
		StairsBlock.Half half = blockState.get(HALF);
		boolean bl = half == StairsBlock.Half.TOP;
		float f = 0.5F;
		float g = 1.0F;
		if (bl) {
			f = 0.0F;
			g = 0.5F;
		}

		float h = 0.0F;
		float i = 0.5F;
		float j = 0.5F;
		float k = 1.0F;
		boolean bl2 = false;
		if (direction == Direction.EAST) {
			BlockState blockState2 = world.getBlockState(pos.west());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.NORTH && !isStairSameHalfSameFacing(world, pos.north(), blockState)) {
					j = 0.0F;
					k = 0.5F;
					bl2 = true;
				} else if (direction2 == Direction.SOUTH && !isStairSameHalfSameFacing(world, pos.south(), blockState)) {
					j = 0.5F;
					k = 1.0F;
					bl2 = true;
				}
			}
		} else if (direction == Direction.WEST) {
			BlockState blockState2 = world.getBlockState(pos.east());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				h = 0.5F;
				i = 1.0F;
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.NORTH && !isStairSameHalfSameFacing(world, pos.north(), blockState)) {
					j = 0.0F;
					k = 0.5F;
					bl2 = true;
				} else if (direction2 == Direction.SOUTH && !isStairSameHalfSameFacing(world, pos.south(), blockState)) {
					j = 0.5F;
					k = 1.0F;
					bl2 = true;
				}
			}
		} else if (direction == Direction.SOUTH) {
			BlockState blockState2 = world.getBlockState(pos.north());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				j = 0.0F;
				k = 0.5F;
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.WEST && !isStairSameHalfSameFacing(world, pos.west(), blockState)) {
					bl2 = true;
				} else if (direction2 == Direction.EAST && !isStairSameHalfSameFacing(world, pos.east(), blockState)) {
					h = 0.5F;
					i = 1.0F;
					bl2 = true;
				}
			}
		} else if (direction == Direction.NORTH) {
			BlockState blockState2 = world.getBlockState(pos.south());
			Block block = blockState2.getBlock();
			if (isStair(block) && half == blockState2.get(HALF)) {
				Direction direction2 = blockState2.get(FACING);
				if (direction2 == Direction.WEST && !isStairSameHalfSameFacing(world, pos.west(), blockState)) {
					bl2 = true;
				} else if (direction2 == Direction.EAST && !isStairSameHalfSameFacing(world, pos.east(), blockState)) {
					h = 0.5F;
					i = 1.0F;
					bl2 = true;
				}
			}
		}

		if (bl2) {
			this.setShape(h, f, j, i, g, k);
		}

		return bl2;
	}

	@Override
	public void addCollisions(World world, BlockPos pos, BlockState state, Box shape, List<Box> collisions, Entity entity) {
		this.setBaseShapeForCollisions(world, pos);
		super.addCollisions(world, pos, state, shape, collisions, entity);
		boolean bl = this.isInnerStair(world, pos);
		super.addCollisions(world, pos, state, shape, collisions, entity);
		if (bl && this.setStepShapeForCollisions(world, pos)) {
			super.addCollisions(world, pos, state, shape, collisions, entity);
		}

		this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public void randomDisplayTick(World world, BlockPos pos, BlockState state, Random random) {
		this.baseBlock.randomDisplayTick(world, pos, state, random);
	}

	@Override
	public void startMining(World world, BlockPos pos, PlayerEntity player) {
		this.baseBlock.startMining(world, pos, player);
	}

	@Override
	public void onBroken(World world, BlockPos pos, BlockState state) {
		this.baseBlock.onBroken(world, pos, state);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public int getLightColor(WorldView world, BlockPos pos) {
		return this.baseBlock.getLightColor(world, pos);
	}

	@Override
	public float getBlastResistance(Entity entity) {
		return this.baseBlock.getBlastResistance(entity);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public BlockLayer getRenderLayer() {
		return this.baseBlock.getRenderLayer();
	}

	@Override
	public int getTickRate(World world) {
		return this.baseBlock.getTickRate(world);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public Box getOutlineShape(World world, BlockPos pos) {
		return this.baseBlock.getOutlineShape(world, pos);
	}

	@Override
	public Vec3d applyMaterialDrag(World world, BlockPos pos, Entity entity, Vec3d velocity) {
		return this.baseBlock.applyMaterialDrag(world, pos, entity, velocity);
	}

	@Override
	public boolean canRayTrace() {
		return this.baseBlock.canRayTrace();
	}

	@Override
	public boolean canRayTrace(BlockState state, boolean allowLiquids) {
		return this.baseBlock.canRayTrace(state, allowLiquids);
	}

	@Override
	public boolean canBePlaced(World world, BlockPos pos) {
		return this.baseBlock.canBePlaced(world, pos);
	}

	@Override
	public void onAdded(World world, BlockPos pos, BlockState state) {
		this.neighborChanged(world, pos, this.baseState, Blocks.AIR);
		this.baseBlock.onAdded(world, pos, this.baseState);
	}

	@Override
	public void onRemoved(World world, BlockPos pos, BlockState state) {
		this.baseBlock.onRemoved(world, pos, this.baseState);
	}

	@Override
	public void onSteppedOn(World world, BlockPos pos, Entity entity) {
		this.baseBlock.onSteppedOn(world, pos, entity);
	}

	@Override
	public void tick(World world, BlockPos pos, BlockState state, Random random) {
		this.baseBlock.tick(world, pos, state, random);
	}

	@Override
	public boolean use(World world, BlockPos pos, BlockState state, PlayerEntity player, Direction face, float faceX, float faceY, float faceZ) {
		return this.baseBlock.use(world, pos, this.baseState, player, Direction.DOWN, 0.0F, 0.0F, 0.0F);
	}

	@Override
	public void onExploded(World world, BlockPos pos, Explosion explosion) {
		this.baseBlock.onExploded(world, pos, explosion);
	}

	@Override
	public MapColor getMapColor(BlockState state) {
		return this.baseBlock.getMapColor(this.baseState);
	}

	@Override
	public BlockState getPlacementState(World world, BlockPos pos, Direction dir, float dx, float dy, float dz, int metadata, LivingEntity entity) {
		BlockState blockState = super.getPlacementState(world, pos, dir, dx, dy, dz, metadata, entity);
		blockState = blockState.set(FACING, entity.getHorizontalFacing()).set(SHAPE, StairsBlock.Shape.STRAIGHT);
		return dir != Direction.DOWN && (dir == Direction.UP || !(dy > 0.5))
			? blockState.set(HALF, StairsBlock.Half.BOTTOM)
			: blockState.set(HALF, StairsBlock.Half.TOP);
	}

	@Override
	public HitResult rayTrace(World world, BlockPos pos, Vec3d start, Vec3d end) {
		HitResult[] hitResults = new HitResult[8];
		BlockState blockState = world.getBlockState(pos);
		int i = blockState.get(FACING).getIdHorizontal();
		boolean bl = blockState.get(HALF) == StairsBlock.Half.TOP;
		int[] is = ROTATIONS[i + (bl ? 4 : 0)];
		this.isCorner = true;

		for (int j = 0; j < 8; j++) {
			this.stairType = j;
			if (Arrays.binarySearch(is, j) < 0) {
				hitResults[j] = super.rayTrace(world, pos, start, end);
			}
		}

		for (int m : is) {
			hitResults[m] = null;
		}

		HitResult hitResult = null;
		double d = 0.0;

		for (HitResult hitResult2 : hitResults) {
			if (hitResult2 != null) {
				double e = hitResult2.facePos.squaredDistanceTo(end);
				if (e > d) {
					hitResult = hitResult2;
					d = e;
				}
			}
		}

		return hitResult;
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		BlockState blockState = this.defaultState().set(HALF, (metadata & 4) > 0 ? StairsBlock.Half.TOP : StairsBlock.Half.BOTTOM);
		return blockState.set(FACING, Direction.byId(5 - (metadata & 3)));
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		int i = 0;
		if (state.get(HALF) == StairsBlock.Half.TOP) {
			i |= 4;
		}

		return i | 5 - state.get(FACING).getId();
	}

	@Override
	public BlockState resolveVirtualProperties(BlockState state, WorldView world, BlockPos pos) {
		if (this.isInnerStair(world, pos)) {
			switch (this.getMetadataForInnerStair(world, pos)) {
				case 0:
					state = state.set(SHAPE, StairsBlock.Shape.STRAIGHT);
					break;
				case 1:
					state = state.set(SHAPE, StairsBlock.Shape.INNER_RIGHT);
					break;
				case 2:
					state = state.set(SHAPE, StairsBlock.Shape.INNER_LEFT);
			}
		} else {
			switch (this.getMetadataForOuterStair(world, pos)) {
				case 0:
					state = state.set(SHAPE, StairsBlock.Shape.STRAIGHT);
					break;
				case 1:
					state = state.set(SHAPE, StairsBlock.Shape.OUTER_RIGHT);
					break;
				case 2:
					state = state.set(SHAPE, StairsBlock.Shape.OUTER_LEFT);
			}
		}

		return state;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, FACING, HALF, SHAPE);
	}

	public enum Half implements StringSerializable {
		TOP("top"),
		BOTTOM("bottom");

		private final String key;

		Half(String key) {
			this.key = key;
		}

		@Override
		public String toString() {
			return this.key;
		}

		@Override
		public String getSerializedName() {
			return this.key;
		}
	}

	public enum Shape implements StringSerializable {
		STRAIGHT("straight"),
		INNER_LEFT("inner_left"),
		INNER_RIGHT("inner_right"),
		OUTER_LEFT("outer_left"),
		OUTER_RIGHT("outer_right");

		private final String key;

		Shape(String key) {
			this.key = key;
		}

		@Override
		public String toString() {
			return this.key;
		}

		@Override
		public String getSerializedName() {
			return this.key;
		}
	}
}

package net.minecraft.client.render.block.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.client.render.model.block.entity.EnchantingTableBookModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class EnchantingTableRenderer extends BlockEntityRenderer<EnchantingTableBlockEntity> {
	private static final Identifier BOOK_LOCATION = new Identifier("textures/entity/enchanting_table_book.png");
	private EnchantingTableBookModel bookModel = new EnchantingTableBookModel();

	public void render(EnchantingTableBlockEntity blockEntity, double dx, double dy, double dz, float tickDelta, int blockMiningProgress) {
		GlStateManager.pushMatrix();
		GlStateManager.translatef((float)dx + 0.5F, (float)dy + 0.75F, (float)dz + 0.5F);
		float f = blockEntity.ticks + tickDelta;
		GlStateManager.translatef(0.0F, 0.1F + MathHelper.sin(f * 0.1F) * 0.01F, 0.0F);
		float g = blockEntity.pageRotation - blockEntity.lastPageRotation;

		while (g >= (float) Math.PI) {
			g -= (float) (Math.PI * 2);
		}

		while (g < (float) -Math.PI) {
			g += (float) (Math.PI * 2);
		}

		float h = blockEntity.lastPageRotation + g * tickDelta;
		GlStateManager.rotatef(-h * 180.0F / (float) Math.PI, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(80.0F, 0.0F, 0.0F, 1.0F);
		this.bindTexture(BOOK_LOCATION);
		float i = blockEntity.lastPageAngle + (blockEntity.pageAngle - blockEntity.lastPageAngle) * tickDelta + 0.25F;
		float j = blockEntity.lastPageAngle + (blockEntity.pageAngle - blockEntity.lastPageAngle) * tickDelta + 0.75F;
		i = (i - MathHelper.fastFloor(i)) * 1.6F - 0.3F;
		j = (j - MathHelper.fastFloor(j)) * 1.6F - 0.3F;
		if (i < 0.0F) {
			i = 0.0F;
		}

		if (j < 0.0F) {
			j = 0.0F;
		}

		if (i > 1.0F) {
			i = 1.0F;
		}

		if (j > 1.0F) {
			j = 1.0F;
		}

		float k = blockEntity.lastPageTurningSpeed + (blockEntity.pageTurningSpeed - blockEntity.lastPageTurningSpeed) * tickDelta;
		GlStateManager.enableCull();
		this.bookModel.render(null, f, i, j, k, 0.0F, 0.0625F);
		GlStateManager.popMatrix();
	}
}

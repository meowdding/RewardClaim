package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.entity.SnowGolemRenderer;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.resource.model.ModelTransformations;
import net.minecraft.entity.living.mob.SnowGolemEntity;
import net.minecraft.item.ItemStack;

@Environment(EnvType.CLIENT)
public class SnowGolemHeadLayer implements EntityRenderLayer<SnowGolemEntity> {
	private final SnowGolemRenderer parent;

	public SnowGolemHeadLayer(SnowGolemRenderer parent) {
		this.parent = parent;
	}

	public void render(
		SnowGolemEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale
	) {
		if (!entity.isInvisible()) {
			GlStateManager.pushMatrix();
			this.parent.getModel().head.transform(0.0625F);
			float f = 0.625F;
			GlStateManager.translatef(0.0F, -0.34375F, 0.0F);
			GlStateManager.rotatef(180.0F, 0.0F, 1.0F, 0.0F);
			GlStateManager.scalef(f, -f, -f);
			Minecraft.getInstance().getItemInHandRenderer().render(entity, new ItemStack(Blocks.PUMPKIN, 1), ModelTransformations.Type.HEAD);
			GlStateManager.popMatrix();
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return true;
	}
}

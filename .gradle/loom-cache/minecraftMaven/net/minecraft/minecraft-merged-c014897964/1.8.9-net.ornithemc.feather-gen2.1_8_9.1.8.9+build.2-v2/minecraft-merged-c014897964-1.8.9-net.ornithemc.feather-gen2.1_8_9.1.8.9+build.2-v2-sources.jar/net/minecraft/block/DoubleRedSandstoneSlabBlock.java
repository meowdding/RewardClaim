package net.minecraft.block;

public class DoubleRedSandstoneSlabBlock extends RedSandstoneSlabBlock {
	@Override
	public boolean isDouble() {
		return true;
	}
}

package net.minecraft.client.render.entity;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BannerBlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.render.block.entity.SkullRenderer;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.util.math.Direction;
import net.ornithemc.feather.constants.NbtTypes;

@Environment(EnvType.CLIENT)
public class BlockEntityItemRenderer {
	public static BlockEntityItemRenderer INSTANCE = new BlockEntityItemRenderer();
	private ChestBlockEntity chest = new ChestBlockEntity(0);
	private ChestBlockEntity trappedChest = new ChestBlockEntity(1);
	private EnderChestBlockEntity enderChest = new EnderChestBlockEntity();
	private BannerBlockEntity banner = new BannerBlockEntity();
	private SkullBlockEntity skull = new SkullBlockEntity();

	public void render(ItemStack item) {
		if (item.getItem() == Items.BANNER) {
			this.banner.set(item);
			BlockEntityRenderDispatcher.INSTANCE.render(this.banner, 0.0, 0.0, 0.0, 0.0F);
		} else if (item.getItem() == Items.SKULL) {
			GameProfile gameProfile = null;
			if (item.hasNbt()) {
				NbtCompound nbtCompound = item.getNbt();
				if (nbtCompound.contains("SkullOwner", NbtTypes.COMPOUND)) {
					gameProfile = NbtUtils.readProfile(nbtCompound.getCompound("SkullOwner"));
				} else if (nbtCompound.contains("SkullOwner", NbtTypes.STRING) && nbtCompound.getString("SkullOwner").length() > 0) {
					GameProfile var4 = new GameProfile(null, nbtCompound.getString("SkullOwner"));
					gameProfile = SkullBlockEntity.updateProfile(var4);
					nbtCompound.remove("SkullOwner");
					nbtCompound.put("SkullOwner", NbtUtils.writeProfile(new NbtCompound(), gameProfile));
				}
			}

			if (SkullRenderer.INSTANCE != null) {
				GlStateManager.pushMatrix();
				GlStateManager.translatef(-0.5F, 0.0F, -0.5F);
				GlStateManager.scalef(2.0F, 2.0F, 2.0F);
				GlStateManager.disableCull();
				SkullRenderer.INSTANCE.render(0.0F, 0.0F, 0.0F, Direction.UP, 0.0F, item.getMetadata(), gameProfile, -1);
				GlStateManager.enableCull();
				GlStateManager.popMatrix();
			}
		} else {
			Block block = Block.byItem(item.getItem());
			if (block == Blocks.ENDER_CHEST) {
				BlockEntityRenderDispatcher.INSTANCE.render(this.enderChest, 0.0, 0.0, 0.0, 0.0F);
			} else if (block == Blocks.TRAPPED_CHEST) {
				BlockEntityRenderDispatcher.INSTANCE.render(this.trappedChest, 0.0, 0.0, 0.0, 0.0F);
			} else {
				BlockEntityRenderDispatcher.INSTANCE.render(this.chest, 0.0, 0.0, 0.0, 0.0F);
			}
		}
	}
}

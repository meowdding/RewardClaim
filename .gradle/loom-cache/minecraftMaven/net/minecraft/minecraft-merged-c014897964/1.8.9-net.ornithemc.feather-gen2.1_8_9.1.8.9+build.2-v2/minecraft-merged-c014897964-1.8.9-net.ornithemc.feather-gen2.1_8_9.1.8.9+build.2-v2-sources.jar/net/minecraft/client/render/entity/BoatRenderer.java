package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.model.Model;
import net.minecraft.client.render.model.entity.BoatModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class BoatRenderer extends EntityRenderer<BoatEntity> {
	private static final Identifier BOAT_LOCATION = new Identifier("textures/entity/boat.png");
	protected Model model = new BoatModel();

	public BoatRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
		this.shadowSize = 0.5F;
	}

	public void render(BoatEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		GlStateManager.pushMatrix();
		GlStateManager.translatef((float)dx, (float)dy + 0.25F, (float)dz);
		GlStateManager.rotatef(180.0F - yaw, 0.0F, 1.0F, 0.0F);
		float f = entity.getDamagedTimer() - tickDelta;
		float g = entity.getDamage() - tickDelta;
		if (g < 0.0F) {
			g = 0.0F;
		}

		if (f > 0.0F) {
			GlStateManager.rotatef(MathHelper.sin(f) * f * g / 10.0F * entity.getDamagedSwingDirection(), 1.0F, 0.0F, 0.0F);
		}

		float h = 0.75F;
		GlStateManager.scalef(h, h, h);
		GlStateManager.scalef(1.0F / h, 1.0F / h, 1.0F / h);
		this.bindTexture(entity);
		GlStateManager.scalef(-1.0F, -1.0F, 1.0F);
		this.model.render(entity, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0625F);
		GlStateManager.popMatrix();
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(BoatEntity entity) {
		return BOAT_LOCATION;
	}
}

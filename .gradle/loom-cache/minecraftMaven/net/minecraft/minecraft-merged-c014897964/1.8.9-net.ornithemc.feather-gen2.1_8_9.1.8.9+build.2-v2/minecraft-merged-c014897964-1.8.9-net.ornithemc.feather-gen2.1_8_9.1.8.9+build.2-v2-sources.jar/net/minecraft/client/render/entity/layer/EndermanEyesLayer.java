package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.EndermanRenderer;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.monster.EndermanEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class EndermanEyesLayer implements EntityRenderLayer<EndermanEntity> {
	private static final Identifier ENDERMAN_EYES_LOCATION = new Identifier("textures/entity/enderman/enderman_eyes.png");
	private final EndermanRenderer parent;

	public EndermanEyesLayer(EndermanRenderer parent) {
		this.parent = parent;
	}

	public void render(
		EndermanEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale
	) {
		this.parent.bindTexture(ENDERMAN_EYES_LOCATION);
		GlStateManager.enableBlend();
		GlStateManager.disableAlphaTest();
		GlStateManager.blendFunc(1, 1);
		GlStateManager.disableLighting();
		GlStateManager.depthMask(!entity.isInvisible());
		int i = 61680;
		int j = i % 65536;
		int k = i / 65536;
		GLX.multiTexCoord2f(GLX.GL_TEXTURE1, j / 1.0F, k / 1.0F);
		GlStateManager.enableLighting();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.parent.getModel().render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
		this.parent.setLightColor(entity, tickDelta);
		GlStateManager.depthMask(true);
		GlStateManager.disableBlend();
		GlStateManager.enableAlphaTest();
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

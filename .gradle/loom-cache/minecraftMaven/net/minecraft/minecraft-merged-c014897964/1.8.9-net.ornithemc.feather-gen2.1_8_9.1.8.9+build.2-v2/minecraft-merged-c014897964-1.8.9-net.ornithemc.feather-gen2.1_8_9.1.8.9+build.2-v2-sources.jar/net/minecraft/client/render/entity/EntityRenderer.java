package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.Culler;
import net.minecraft.client.render.TextRenderer;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.render.texture.TextureAtlasSprite;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.living.mob.MobEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;

@Environment(EnvType.CLIENT)
public abstract class EntityRenderer<T extends Entity> {
	private static final Identifier SHADOW_LOCATION = new Identifier("textures/misc/shadow.png");
	protected final EntityRenderDispatcher dispatcher;
	protected float shadowSize;
	protected float shadowDarkness = 1.0F;

	protected EntityRenderer(EntityRenderDispatcher dispatcher) {
		this.dispatcher = dispatcher;
	}

	public boolean shouldRender(T entity, Culler view, double cameraX, double cameraY, double cameraZ) {
		Box box = entity.getShape();
		if (box.isInvalid() || box.getAverageSideLength() == 0.0) {
			box = new Box(entity.x - 2.0, entity.y - 2.0, entity.z - 2.0, entity.x + 2.0, entity.y + 2.0, entity.z + 2.0);
		}

		return entity.shouldRender(cameraX, cameraY, cameraZ) && (entity.ignoreCameraFrustum || view.isVisible(box));
	}

	public void render(T entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		this.renderNameTag(entity, dx, dy, dz);
	}

	protected void renderNameTag(T entity, double dx, double dy, double dz) {
		if (this.shouldRenderNameTag(entity)) {
			this.renderNameTag(entity, entity.getDisplayName().getFormattedString(), dx, dy, dz, 64);
		}
	}

	protected boolean shouldRenderNameTag(T entity) {
		return entity.shouldShowNameTag() && entity.hasCustomName();
	}

	protected void renderNameTag(T entity, double dx, double dy, double dz, String name, float tickDelta, double squaredDistance) {
		this.renderNameTag(entity, name, dx, dy, dz, 64);
	}

	protected abstract Identifier getTextureLocation(T entity);

	protected boolean bindTexture(T entity) {
		Identifier identifier = this.getTextureLocation(entity);
		if (identifier == null) {
			return false;
		}

		this.bindTexture(identifier);
		return true;
	}

	public void bindTexture(Identifier location) {
		this.dispatcher.textureManager.bind(location);
	}

	private void renderOnFire(Entity entity, double dx, double dy, double dz, float tickDelta) {
		GlStateManager.disableLighting();
		TextureAtlas textureAtlas = Minecraft.getInstance().getBlocksAtlas();
		TextureAtlasSprite textureAtlasSprite = textureAtlas.getSprite("minecraft:blocks/fire_layer_0");
		TextureAtlasSprite textureAtlasSprite2 = textureAtlas.getSprite("minecraft:blocks/fire_layer_1");
		GlStateManager.pushMatrix();
		GlStateManager.translatef((float)dx, (float)dy, (float)dz);
		float f = entity.width * 1.4F;
		GlStateManager.scalef(f, f, f);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		float g = 0.5F;
		float h = 0.0F;
		float i = entity.height / f;
		float j = (float)(entity.y - entity.getShape().minY);
		GlStateManager.rotatef(-this.dispatcher.cameraYaw, 0.0F, 1.0F, 0.0F);
		GlStateManager.translatef(0.0F, 0.0F, -0.3F + (int)i * 0.02F);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		float k = 0.0F;
		int l = 0;
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);

		while (i > 0.0F) {
			TextureAtlasSprite textureAtlasSprite3 = l % 2 == 0 ? textureAtlasSprite : textureAtlasSprite2;
			this.bindTexture(TextureAtlas.BLOCKS_LOCATION);
			float m = textureAtlasSprite3.getUMin();
			float n = textureAtlasSprite3.getVMin();
			float o = textureAtlasSprite3.getUMax();
			float p = textureAtlasSprite3.getVMax();
			if (l / 2 % 2 == 0) {
				float q = o;
				o = m;
				m = q;
			}

			bufferBuilder.vertex(g - h, 0.0F - j, k).texture(o, p).nextVertex();
			bufferBuilder.vertex(-g - h, 0.0F - j, k).texture(m, p).nextVertex();
			bufferBuilder.vertex(-g - h, 1.4F - j, k).texture(m, n).nextVertex();
			bufferBuilder.vertex(g - h, 1.4F - j, k).texture(o, n).nextVertex();
			i -= 0.45F;
			j -= 0.45F;
			g *= 0.9F;
			k += 0.03F;
			l++;
		}

		tesselator.end();
		GlStateManager.popMatrix();
		GlStateManager.enableLighting();
	}

	private void renderShadow(Entity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		GlStateManager.enableBlend();
		GlStateManager.blendFunc(770, 771);
		this.dispatcher.textureManager.bind(SHADOW_LOCATION);
		World world = this.getWorld();
		GlStateManager.depthMask(false);
		float f = this.shadowSize;
		if (entity instanceof MobEntity) {
			MobEntity mobEntity = (MobEntity)entity;
			f *= mobEntity.getShadowScale();
			if (mobEntity.isBaby()) {
				f *= 0.5F;
			}
		}

		double d = entity.prevX + (entity.x - entity.prevX) * tickDelta;
		double e = entity.prevY + (entity.y - entity.prevY) * tickDelta;
		double g = entity.prevZ + (entity.z - entity.prevZ) * tickDelta;
		int i = MathHelper.floor(d - f);
		int j = MathHelper.floor(d + f);
		int k = MathHelper.floor(e - f);
		int l = MathHelper.floor(e);
		int m = MathHelper.floor(g - f);
		int n = MathHelper.floor(g + f);
		double h = dx - d;
		double o = dy - e;
		double p = dz - g;
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);

		for (BlockPos blockPos : BlockPos.iterateRegionMutable(new BlockPos(i, k, m), new BlockPos(j, l, n))) {
			Block block = world.getBlockState(blockPos.down()).getBlock();
			if (block.getRenderType() != -1 && world.getRawBrightness(blockPos) > 3) {
				this.renderShadowOnBlock(block, dx, dy, dz, blockPos, yaw, f, h, o, p);
			}
		}

		tesselator.end();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.disableBlend();
		GlStateManager.depthMask(true);
	}

	private World getWorld() {
		return this.dispatcher.world;
	}

	private void renderShadowOnBlock(Block block, double dx, double dy, double dz, BlockPos pos, float yaw, float shadowSize, double cx, double cy, double cz) {
		if (block.isCube()) {
			Tesselator tesselator = Tesselator.getInstance();
			BufferBuilder bufferBuilder = tesselator.getBuffer();
			double d = (yaw - (dy - (pos.getY() + cy)) / 2.0) * 0.5 * this.getWorld().getBrightness(pos);
			if (!(d < 0.0)) {
				if (d > 1.0) {
					d = 1.0;
				}

				double e = pos.getX() + block.getMinX() + cx;
				double f = pos.getX() + block.getMaxX() + cx;
				double g = pos.getY() + block.getMinY() + cy + 0.015625;
				double h = pos.getZ() + block.getMinZ() + cz;
				double i = pos.getZ() + block.getMaxZ() + cz;
				float j = (float)((dx - e) / 2.0 / shadowSize + 0.5);
				float k = (float)((dx - f) / 2.0 / shadowSize + 0.5);
				float l = (float)((dz - h) / 2.0 / shadowSize + 0.5);
				float m = (float)((dz - i) / 2.0 / shadowSize + 0.5);
				bufferBuilder.vertex(e, g, h).texture(j, l).color(1.0F, 1.0F, 1.0F, (float)d).nextVertex();
				bufferBuilder.vertex(e, g, i).texture(j, m).color(1.0F, 1.0F, 1.0F, (float)d).nextVertex();
				bufferBuilder.vertex(f, g, i).texture(k, m).color(1.0F, 1.0F, 1.0F, (float)d).nextVertex();
				bufferBuilder.vertex(f, g, h).texture(k, l).color(1.0F, 1.0F, 1.0F, (float)d).nextVertex();
			}
		}
	}

	public static void renderShape(Box shape, double dx, double dy, double dz) {
		GlStateManager.disableTexture();
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		bufferBuilder.offset(dx, dy, dz);
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_NORMAL);
		bufferBuilder.vertex(shape.minX, shape.maxY, shape.minZ).normal(0.0F, 0.0F, -1.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.maxY, shape.minZ).normal(0.0F, 0.0F, -1.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.minY, shape.minZ).normal(0.0F, 0.0F, -1.0F).nextVertex();
		bufferBuilder.vertex(shape.minX, shape.minY, shape.minZ).normal(0.0F, 0.0F, -1.0F).nextVertex();
		bufferBuilder.vertex(shape.minX, shape.minY, shape.maxZ).normal(0.0F, 0.0F, 1.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.minY, shape.maxZ).normal(0.0F, 0.0F, 1.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.maxY, shape.maxZ).normal(0.0F, 0.0F, 1.0F).nextVertex();
		bufferBuilder.vertex(shape.minX, shape.maxY, shape.maxZ).normal(0.0F, 0.0F, 1.0F).nextVertex();
		bufferBuilder.vertex(shape.minX, shape.minY, shape.minZ).normal(0.0F, -1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.minY, shape.minZ).normal(0.0F, -1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.minY, shape.maxZ).normal(0.0F, -1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.minX, shape.minY, shape.maxZ).normal(0.0F, -1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.minX, shape.maxY, shape.maxZ).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.maxY, shape.maxZ).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.maxY, shape.minZ).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.minX, shape.maxY, shape.minZ).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.minX, shape.minY, shape.maxZ).normal(-1.0F, 0.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.minX, shape.maxY, shape.maxZ).normal(-1.0F, 0.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.minX, shape.maxY, shape.minZ).normal(-1.0F, 0.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.minX, shape.minY, shape.minZ).normal(-1.0F, 0.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.minY, shape.minZ).normal(1.0F, 0.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.maxY, shape.minZ).normal(1.0F, 0.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.maxY, shape.maxZ).normal(1.0F, 0.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(shape.maxX, shape.minY, shape.maxZ).normal(1.0F, 0.0F, 0.0F).nextVertex();
		tesselator.end();
		bufferBuilder.offset(0.0, 0.0, 0.0);
		GlStateManager.enableTexture();
	}

	public void postRender(Entity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		if (this.dispatcher.options != null) {
			if (this.dispatcher.options.entityShadows && this.shadowSize > 0.0F && !entity.isInvisible() && this.dispatcher.shouldRenderShadow()) {
				double d = this.dispatcher.squaredDistanceToCamera(entity.x, entity.y, entity.z);
				float f = (float)((1.0 - d / 256.0) * this.shadowDarkness);
				if (f > 0.0F) {
					this.renderShadow(entity, dx, dy, dz, f, tickDelta);
				}
			}

			if (entity.shouldRenderOnFire() && (!(entity instanceof PlayerEntity) || !((PlayerEntity)entity).isSpectator())) {
				this.renderOnFire(entity, dx, dy, dz, tickDelta);
			}
		}
	}

	public TextRenderer getTextRenderer() {
		return this.dispatcher.getTextRenderer();
	}

	protected void renderNameTag(T entity, String name, double dx, double dy, double dz, int distance) {
		double d = entity.squaredDistanceTo(this.dispatcher.camera);
		if (!(d > distance * distance)) {
			TextRenderer textRenderer = this.getTextRenderer();
			float f = 1.6F;
			float g = 0.016666668F * f;
			GlStateManager.pushMatrix();
			GlStateManager.translatef((float)dx + 0.0F, (float)dy + entity.height + 0.5F, (float)dz);
			GL11.glNormal3f(0.0F, 1.0F, 0.0F);
			GlStateManager.rotatef(-this.dispatcher.cameraYaw, 0.0F, 1.0F, 0.0F);
			GlStateManager.rotatef(this.dispatcher.cameraPitch, 1.0F, 0.0F, 0.0F);
			GlStateManager.scalef(-g, -g, g);
			GlStateManager.disableLighting();
			GlStateManager.depthMask(false);
			GlStateManager.disableDepthTest();
			GlStateManager.enableBlend();
			GlStateManager.blendFuncSeparate(770, 771, 1, 0);
			Tesselator tesselator = Tesselator.getInstance();
			BufferBuilder bufferBuilder = tesselator.getBuffer();
			int i = 0;
			if (name.equals("deadmau5")) {
				i = -10;
			}

			int j = textRenderer.getWidth(name) / 2;
			GlStateManager.disableTexture();
			bufferBuilder.begin(7, DefaultVertexFormat.POSITION_COLOR);
			bufferBuilder.vertex(-j - 1, -1 + i, 0.0).color(0.0F, 0.0F, 0.0F, 0.25F).nextVertex();
			bufferBuilder.vertex(-j - 1, 8 + i, 0.0).color(0.0F, 0.0F, 0.0F, 0.25F).nextVertex();
			bufferBuilder.vertex(j + 1, 8 + i, 0.0).color(0.0F, 0.0F, 0.0F, 0.25F).nextVertex();
			bufferBuilder.vertex(j + 1, -1 + i, 0.0).color(0.0F, 0.0F, 0.0F, 0.25F).nextVertex();
			tesselator.end();
			GlStateManager.enableTexture();
			textRenderer.draw(name, -textRenderer.getWidth(name) / 2, i, 553648127);
			GlStateManager.enableDepthTest();
			GlStateManager.depthMask(true);
			textRenderer.draw(name, -textRenderer.getWidth(name) / 2, i, -1);
			GlStateManager.enableLighting();
			GlStateManager.disableBlend();
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			GlStateManager.popMatrix();
		}
	}

	public EntityRenderDispatcher getDispatcher() {
		return this.dispatcher;
	}
}

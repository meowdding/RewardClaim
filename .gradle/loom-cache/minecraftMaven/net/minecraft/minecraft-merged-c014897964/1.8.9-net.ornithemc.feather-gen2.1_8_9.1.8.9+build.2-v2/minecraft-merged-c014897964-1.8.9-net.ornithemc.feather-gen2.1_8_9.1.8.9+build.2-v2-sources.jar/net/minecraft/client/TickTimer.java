package net.minecraft.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class TickTimer {
	float tps;
	private double timeSec;
	public int ticksThisFrame;
	public float partialTick;
	public float tpsScale = 1.0F;
	public float tickDelta;
	private long lastTickTime;
	private long lastCorrectionTime;
	private long cumTickTime;
	private double tickTimeCorrection = 1.0;

	public TickTimer(float tps) {
		this.tps = tps;
		this.lastTickTime = Minecraft.getTime();
		this.lastCorrectionTime = System.nanoTime() / 1000000L;
	}

	public void advance() {
		long l = Minecraft.getTime();
		long m = l - this.lastTickTime;
		long n = System.nanoTime() / 1000000L;
		double d = n / 1000.0;
		if (m <= 1000L && m >= 0L) {
			this.cumTickTime += m;
			if (this.cumTickTime > 1000L) {
				long o = n - this.lastCorrectionTime;
				double e = (double)this.cumTickTime / o;
				this.tickTimeCorrection = this.tickTimeCorrection + (e - this.tickTimeCorrection) * 0.2F;
				this.lastCorrectionTime = n;
				this.cumTickTime = 0L;
			}

			if (this.cumTickTime < 0L) {
				this.lastCorrectionTime = n;
			}
		} else {
			this.timeSec = d;
		}

		this.lastTickTime = l;
		double f = (d - this.timeSec) * this.tickTimeCorrection;
		this.timeSec = d;
		f = MathHelper.clamp(f, 0.0, 1.0);
		this.tickDelta = (float)(this.tickDelta + f * this.tpsScale * this.tps);
		this.ticksThisFrame = (int)this.tickDelta;
		this.tickDelta = this.tickDelta - this.ticksThisFrame;
		if (this.ticksThisFrame > 10) {
			this.ticksThisFrame = 10;
		}

		this.partialTick = this.tickDelta;
	}
}

package net.minecraft.client.render.block.entity;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;

@Environment(EnvType.CLIENT)
public class BeaconRenderer extends BlockEntityRenderer<BeaconBlockEntity> {
	private static final Identifier BEACON_BEAM_LOCATION = new Identifier("textures/entity/beacon_beam.png");

	public void render(BeaconBlockEntity blockEntity, double dx, double dy, double dz, float tickDelta, int blockMiningProgress) {
		float f = blockEntity.getBeamAngle();
		GlStateManager.alphaFunc(516, 0.1F);
		if (f > 0.0F) {
			Tesselator tesselator = Tesselator.getInstance();
			BufferBuilder bufferBuilder = tesselator.getBuffer();
			GlStateManager.disableFog();
			List<BeaconBlockEntity.BeamSection> list = blockEntity.getBeamSections();
			int i = 0;

			for (int j = 0; j < list.size(); j++) {
				BeaconBlockEntity.BeamSection beamSection = list.get(j);
				int k = i + beamSection.getHeight();
				this.bindTexture(BEACON_BEAM_LOCATION);
				GL11.glTexParameterf(3553, 10242, 10497.0F);
				GL11.glTexParameterf(3553, 10243, 10497.0F);
				GlStateManager.disableLighting();
				GlStateManager.disableCull();
				GlStateManager.disableBlend();
				GlStateManager.depthMask(true);
				GlStateManager.blendFuncSeparate(770, 1, 1, 0);
				double d = (double)blockEntity.getWorld().getTime() + tickDelta;
				double e = MathHelper.floorDiff(-d * 0.2 - MathHelper.floor(-d * 0.1));
				float g = beamSection.getColor()[0];
				float h = beamSection.getColor()[1];
				float l = beamSection.getColor()[2];
				double m = d * 0.025 * -1.5;
				double n = 0.2;
				double o = 0.5 + Math.cos(m + (Math.PI * 3.0 / 4.0)) * 0.2;
				double p = 0.5 + Math.sin(m + (Math.PI * 3.0 / 4.0)) * 0.2;
				double q = 0.5 + Math.cos(m + (Math.PI / 4)) * 0.2;
				double r = 0.5 + Math.sin(m + (Math.PI / 4)) * 0.2;
				double s = 0.5 + Math.cos(m + (Math.PI * 5.0 / 4.0)) * 0.2;
				double t = 0.5 + Math.sin(m + (Math.PI * 5.0 / 4.0)) * 0.2;
				double u = 0.5 + Math.cos(m + (Math.PI * 7.0 / 4.0)) * 0.2;
				double v = 0.5 + Math.sin(m + (Math.PI * 7.0 / 4.0)) * 0.2;
				double w = 0.0;
				double x = 1.0;
				double y = -1.0 + e;
				double z = beamSection.getHeight() * f * 2.5 + y;
				bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
				bufferBuilder.vertex(dx + o, dy + k, dz + p).texture(1.0, z).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + o, dy + i, dz + p).texture(1.0, y).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + q, dy + i, dz + r).texture(0.0, y).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + q, dy + k, dz + r).texture(0.0, z).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + u, dy + k, dz + v).texture(1.0, z).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + u, dy + i, dz + v).texture(1.0, y).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + s, dy + i, dz + t).texture(0.0, y).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + s, dy + k, dz + t).texture(0.0, z).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + q, dy + k, dz + r).texture(1.0, z).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + q, dy + i, dz + r).texture(1.0, y).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + u, dy + i, dz + v).texture(0.0, y).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + u, dy + k, dz + v).texture(0.0, z).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + s, dy + k, dz + t).texture(1.0, z).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + s, dy + i, dz + t).texture(1.0, y).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + o, dy + i, dz + p).texture(0.0, y).color(g, h, l, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + o, dy + k, dz + p).texture(0.0, z).color(g, h, l, 1.0F).nextVertex();
				tesselator.end();
				GlStateManager.enableBlend();
				GlStateManager.blendFuncSeparate(770, 771, 1, 0);
				GlStateManager.depthMask(false);
				m = 0.2;
				n = 0.2;
				o = 0.8;
				p = 0.2;
				q = 0.2;
				r = 0.8;
				s = 0.8;
				t = 0.8;
				u = 0.0;
				v = 1.0;
				w = -1.0 + e;
				x = beamSection.getHeight() * f + w;
				bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
				bufferBuilder.vertex(dx + 0.2, dy + k, dz + 0.2).texture(1.0, x).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.2, dy + i, dz + 0.2).texture(1.0, w).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.8, dy + i, dz + 0.2).texture(0.0, w).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.8, dy + k, dz + 0.2).texture(0.0, x).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.8, dy + k, dz + 0.8).texture(1.0, x).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.8, dy + i, dz + 0.8).texture(1.0, w).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.2, dy + i, dz + 0.8).texture(0.0, w).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.2, dy + k, dz + 0.8).texture(0.0, x).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.8, dy + k, dz + 0.2).texture(1.0, x).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.8, dy + i, dz + 0.2).texture(1.0, w).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.8, dy + i, dz + 0.8).texture(0.0, w).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.8, dy + k, dz + 0.8).texture(0.0, x).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.2, dy + k, dz + 0.8).texture(1.0, x).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.2, dy + i, dz + 0.8).texture(1.0, w).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.2, dy + i, dz + 0.2).texture(0.0, w).color(g, h, l, 0.125F).nextVertex();
				bufferBuilder.vertex(dx + 0.2, dy + k, dz + 0.2).texture(0.0, x).color(g, h, l, 0.125F).nextVertex();
				tesselator.end();
				GlStateManager.enableLighting();
				GlStateManager.enableTexture();
				GlStateManager.depthMask(true);
				i = k;
			}

			GlStateManager.enableFog();
		}
	}

	@Override
	public boolean shouldRenderOffScreen() {
		return true;
	}
}

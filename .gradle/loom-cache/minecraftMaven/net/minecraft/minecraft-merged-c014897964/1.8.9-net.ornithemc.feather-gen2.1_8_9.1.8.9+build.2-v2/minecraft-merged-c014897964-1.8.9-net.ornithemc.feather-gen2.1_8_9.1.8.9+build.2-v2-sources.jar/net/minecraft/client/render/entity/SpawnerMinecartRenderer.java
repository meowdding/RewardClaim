package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.render.block.entity.MobSpawnerRenderer;
import net.minecraft.entity.vehicle.SpawnerMinecartEntity;

@Environment(EnvType.CLIENT)
public class SpawnerMinecartRenderer extends MinecartRenderer<SpawnerMinecartEntity> {
	public SpawnerMinecartRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
	}

	protected void renderBlockInMinecart(SpawnerMinecartEntity minecart, float tickDelta, BlockState state) {
		super.renderBlockInMinecart(minecart, tickDelta, state);
		if (state.getBlock() == Blocks.MOB_SPAWNER) {
			MobSpawnerRenderer.renderDisplayEntity(minecart.getSpawner(), minecart.x, minecart.y, minecart.z, tickDelta);
		}
	}
}

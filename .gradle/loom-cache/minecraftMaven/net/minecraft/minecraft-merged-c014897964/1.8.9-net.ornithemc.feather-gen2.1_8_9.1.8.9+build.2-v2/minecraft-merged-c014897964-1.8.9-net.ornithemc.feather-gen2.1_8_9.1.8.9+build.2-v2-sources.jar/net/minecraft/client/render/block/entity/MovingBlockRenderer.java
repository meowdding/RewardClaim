package net.minecraft.client.render.block.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.PistonBaseBlock;
import net.minecraft.block.PistonHeadBlock;
import net.minecraft.block.entity.MovingBlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.block.BlockRenderDispatcher;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

@Environment(EnvType.CLIENT)
public class MovingBlockRenderer extends BlockEntityRenderer<MovingBlockEntity> {
	private final BlockRenderDispatcher blockRenderDispatcher = Minecraft.getInstance().getBlockRenderDispatcher();

	public void render(MovingBlockEntity blockEntity, double dx, double dy, double dz, float tickDelta, int blockMiningProgress) {
		BlockPos blockPos = blockEntity.getPos();
		BlockState blockState = blockEntity.getMovedState();
		Block block = blockState.getBlock();
		if (block.getMaterial() != Material.AIR && !(blockEntity.getProgress(tickDelta) >= 1.0F)) {
			Tesselator tesselator = Tesselator.getInstance();
			BufferBuilder bufferBuilder = tesselator.getBuffer();
			this.bindTexture(TextureAtlas.BLOCKS_LOCATION);
			Lighting.turnOff();
			GlStateManager.blendFunc(770, 771);
			GlStateManager.enableBlend();
			GlStateManager.disableCull();
			if (Minecraft.isAmbientOcclusionEnabled()) {
				GlStateManager.shadeModel(7425);
			} else {
				GlStateManager.shadeModel(7424);
			}

			bufferBuilder.begin(7, DefaultVertexFormat.BLOCK);
			bufferBuilder.offset(
				(float)dx - blockPos.getX() + blockEntity.getRenderOffsetX(tickDelta),
				(float)dy - blockPos.getY() + blockEntity.getRenderOffsetY(tickDelta),
				(float)dz - blockPos.getZ() + blockEntity.getRenderOffsetZ(tickDelta)
			);
			World world = this.getWorld();
			if (block == Blocks.PISTON_HEAD && blockEntity.getProgress(tickDelta) < 0.5F) {
				blockState = blockState.set(PistonHeadBlock.SHORT, true);
				this.blockRenderDispatcher
					.getModelRenderer()
					.render(world, this.blockRenderDispatcher.getModel(blockState, world, blockPos), blockState, blockPos, bufferBuilder, true);
			} else if (blockEntity.isSource() && !blockEntity.isExtending()) {
				PistonHeadBlock.Type type = block == Blocks.STICKY_PISTON ? PistonHeadBlock.Type.STICKY : PistonHeadBlock.Type.DEFAULT;
				BlockState blockState2 = Blocks.PISTON_HEAD
					.defaultState()
					.set(PistonHeadBlock.TYPE, type)
					.set(PistonHeadBlock.FACING, blockState.get(PistonBaseBlock.FACING));
				blockState2 = blockState2.set(PistonHeadBlock.SHORT, blockEntity.getProgress(tickDelta) >= 0.5F);
				this.blockRenderDispatcher
					.getModelRenderer()
					.render(world, this.blockRenderDispatcher.getModel(blockState2, world, blockPos), blockState2, blockPos, bufferBuilder, true);
				bufferBuilder.offset((float)dx - blockPos.getX(), (float)dy - blockPos.getY(), (float)dz - blockPos.getZ());
				blockState.set(PistonBaseBlock.EXTENDED, true);
				this.blockRenderDispatcher
					.getModelRenderer()
					.render(world, this.blockRenderDispatcher.getModel(blockState, world, blockPos), blockState, blockPos, bufferBuilder, true);
			} else {
				this.blockRenderDispatcher
					.getModelRenderer()
					.render(world, this.blockRenderDispatcher.getModel(blockState, world, blockPos), blockState, blockPos, bufferBuilder, false);
			}

			bufferBuilder.offset(0.0, 0.0, 0.0);
			tesselator.end();
			Lighting.turnOn();
		}
	}
}

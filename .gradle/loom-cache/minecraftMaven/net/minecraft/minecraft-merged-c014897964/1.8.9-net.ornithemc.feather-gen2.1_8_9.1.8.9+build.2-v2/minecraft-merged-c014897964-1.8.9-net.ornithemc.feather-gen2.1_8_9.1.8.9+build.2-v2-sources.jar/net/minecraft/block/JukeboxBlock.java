package net.minecraft.block;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.ornithemc.feather.constants.NbtTypes;
import net.ornithemc.feather.constants.SetBlockFlags;

public class JukeboxBlock extends BlockWithBlockEntity {
	public static final BooleanProperty HAS_RECORD = BooleanProperty.of("has_record");

	protected JukeboxBlock() {
		super(Material.WOOD, MapColor.DIRT);
		this.setDefaultState(this.stateDefinition.any().set(HAS_RECORD, false));
		this.setCreativeModeTab(CreativeModeTab.DECORATIONS);
	}

	@Override
	public boolean use(World world, BlockPos pos, BlockState state, PlayerEntity player, Direction face, float faceX, float faceY, float faceZ) {
		if (state.get(HAS_RECORD)) {
			this.removeRecord(world, pos, state);
			state = state.set(HAS_RECORD, false);
			world.setBlockState(pos, state, SetBlockFlags.NOTIFY_LISTENERS);
			return true;
		} else {
			return false;
		}
	}

	public void setRecord(World world, BlockPos pos, BlockState state, ItemStack item) {
		if (!world.isClient) {
			BlockEntity blockEntity = world.getBlockEntity(pos);
			if (blockEntity instanceof JukeboxBlock.JukeboxBlockEntity) {
				((JukeboxBlock.JukeboxBlockEntity)blockEntity).setRecord(new ItemStack(item.getItem(), 1, item.getMetadata()));
				world.setBlockState(pos, state.set(HAS_RECORD, true), SetBlockFlags.NOTIFY_LISTENERS);
			}
		}
	}

	private void removeRecord(World world, BlockPos pos, BlockState state) {
		if (!world.isClient) {
			BlockEntity blockEntity = world.getBlockEntity(pos);
			if (blockEntity instanceof JukeboxBlock.JukeboxBlockEntity) {
				JukeboxBlock.JukeboxBlockEntity jukeboxBlockEntity = (JukeboxBlock.JukeboxBlockEntity)blockEntity;
				ItemStack itemStack = jukeboxBlockEntity.getRecord();
				if (itemStack != null) {
					world.doEvent(1005, pos, 0);
					world.playRecordMusic(pos, null);
					jukeboxBlockEntity.setRecord(null);
					float f = 0.7F;
					double d = world.random.nextFloat() * f + (1.0F - f) * 0.5;
					double e = world.random.nextFloat() * f + (1.0F - f) * 0.2 + 0.6;
					double g = world.random.nextFloat() * f + (1.0F - f) * 0.5;
					ItemStack itemStack2 = itemStack.copy();
					ItemEntity itemEntity = new ItemEntity(world, pos.getX() + d, pos.getY() + e, pos.getZ() + g, itemStack2);
					itemEntity.setDefaultPickUpDelay();
					world.addEntity(itemEntity);
				}
			}
		}
	}

	@Override
	public void onRemoved(World world, BlockPos pos, BlockState state) {
		this.removeRecord(world, pos, state);
		super.onRemoved(world, pos, state);
	}

	@Override
	public void dropItems(World world, BlockPos pos, BlockState state, float luck, int fortuneLevel) {
		if (!world.isClient) {
			super.dropItems(world, pos, state, luck, 0);
		}
	}

	@Override
	public BlockEntity createBlockEntity(World world, int metadata) {
		return new JukeboxBlock.JukeboxBlockEntity();
	}

	@Override
	public boolean isAnalogSignalSource() {
		return true;
	}

	@Override
	public int getAnalogSignal(World world, BlockPos pos) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof JukeboxBlock.JukeboxBlockEntity) {
			ItemStack itemStack = ((JukeboxBlock.JukeboxBlockEntity)blockEntity).getRecord();
			if (itemStack != null) {
				return Item.getId(itemStack.getItem()) + 1 - Item.getId(Items.RECORD_13);
			}
		}

		return 0;
	}

	@Override
	public int getRenderType() {
		return 3;
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		return this.defaultState().set(HAS_RECORD, metadata > 0);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		return state.get(HAS_RECORD) ? 1 : 0;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, HAS_RECORD);
	}

	public static class JukeboxBlockEntity extends BlockEntity {
		private ItemStack record;

		@Override
		public void readNbt(NbtCompound nbt) {
			super.readNbt(nbt);
			if (nbt.contains("RecordItem", NbtTypes.COMPOUND)) {
				this.setRecord(ItemStack.fromNbt(nbt.getCompound("RecordItem")));
			} else if (nbt.getInt("Record") > 0) {
				this.setRecord(new ItemStack(Item.byId(nbt.getInt("Record")), 1, 0));
			}
		}

		@Override
		public void writeNbt(NbtCompound nbt) {
			super.writeNbt(nbt);
			if (this.getRecord() != null) {
				nbt.put("RecordItem", this.getRecord().writeNbt(new NbtCompound()));
			}
		}

		public ItemStack getRecord() {
			return this.record;
		}

		public void setRecord(ItemStack record) {
			this.record = record;
			this.markDirty();
		}
	}
}

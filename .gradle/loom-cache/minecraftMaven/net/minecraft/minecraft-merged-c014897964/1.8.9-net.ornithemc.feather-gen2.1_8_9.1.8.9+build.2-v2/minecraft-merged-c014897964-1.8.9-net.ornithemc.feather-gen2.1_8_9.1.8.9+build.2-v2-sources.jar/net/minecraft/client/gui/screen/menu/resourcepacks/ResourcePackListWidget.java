package net.minecraft.client.gui.screen.menu.resourcepacks;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.widget.EntryListWidget;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.text.Formatting;

@Environment(EnvType.CLIENT)
public abstract class ResourcePackListWidget extends EntryListWidget {
	protected final Minecraft minecraft;
	protected final List<ResourcePackEntry> packs;

	public ResourcePackListWidget(Minecraft minecraft, int x, int y, List<ResourcePackEntry> packs) {
		super(minecraft, x, y, 32, y - 55 + 4, 36);
		this.minecraft = minecraft;
		this.packs = packs;
		this.centerAlongY = false;
		this.setHeader(true, (int)(minecraft.textRenderer.fontHeight * 1.5F));
	}

	@Override
	protected void renderHeader(int x, int y, Tesselator tesselator) {
		String string = Formatting.UNDERLINE + "" + Formatting.BOLD + this.getTitle();
		this.minecraft.textRenderer.draw(string, x + this.width / 2 - this.minecraft.textRenderer.getWidth(string) / 2, Math.min(this.minY + 3, y), 16777215);
	}

	protected abstract String getTitle();

	public List<ResourcePackEntry> getPacks() {
		return this.packs;
	}

	@Override
	protected int size() {
		return this.getPacks().size();
	}

	public ResourcePackEntry getEntry(int index) {
		return this.getPacks().get(index);
	}

	@Override
	public int getRowWidth() {
		return this.width;
	}

	@Override
	protected int getScrollbarPosition() {
		return this.maxX - 6;
	}
}

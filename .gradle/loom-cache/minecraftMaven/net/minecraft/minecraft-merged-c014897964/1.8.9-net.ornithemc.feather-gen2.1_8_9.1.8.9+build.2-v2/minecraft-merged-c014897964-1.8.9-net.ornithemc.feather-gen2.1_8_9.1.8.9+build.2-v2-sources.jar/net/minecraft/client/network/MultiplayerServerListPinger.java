package net.minecraft.client.network;

import com.google.common.base.Charsets;
import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelException;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.socket.nio.NioSocketChannel;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.handler.ClientQueryPacketHandler;
import net.minecraft.client.options.ServerListEntry;
import net.minecraft.network.Connection;
import net.minecraft.network.NetworkProtocol;
import net.minecraft.network.packet.c2s.handshake.HandshakeC2SPacket;
import net.minecraft.network.packet.c2s.query.PingC2SPacket;
import net.minecraft.network.packet.c2s.query.ServerStatusC2SPacket;
import net.minecraft.network.packet.s2c.query.PingS2CPacket;
import net.minecraft.network.packet.s2c.query.ServerStatusS2CPacket;
import net.minecraft.server.ServerStatus;
import net.minecraft.text.Formatting;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Environment(EnvType.CLIENT)
public class MultiplayerServerListPinger {
	private static final Splitter ZERO_SPLITTER = Splitter.on('\u0000').limit(6);
	private static final Logger LOGGER = LogManager.getLogger();
	private final List<Connection> clientConnectionList = Collections.synchronizedList(Lists.newArrayList());

	public void add(ServerListEntry serverEntry) throws UnknownHostException {
		ServerAddress serverAddress = ServerAddress.parse(serverEntry.ip);
		final Connection connection = Connection.connect(InetAddress.getByName(serverAddress.getAddress()), serverAddress.getPort(), false);
		this.clientConnectionList.add(connection);
		serverEntry.motd = "Pinging...";
		serverEntry.ping = -1L;
		serverEntry.onlinePlayers = null;
		connection.setListener(
			new ClientQueryPacketHandler() {
				private boolean success = false;
				private boolean received = false;
				private long statusReceivedTime = 0L;

				@Override
				public void handleServerStatus(ServerStatusS2CPacket packet) {
					if (this.received) {
						connection.disconnect(new LiteralText("Received unrequested status"));
					} else {
						this.received = true;
						ServerStatus serverStatus = packet.getServerStatus();
						if (serverStatus.getDescription() != null) {
							serverEntry.motd = serverStatus.getDescription().getFormattedString();
						} else {
							serverEntry.motd = "";
						}

						if (serverStatus.getVersion() != null) {
							serverEntry.version = serverStatus.getVersion().getName();
							serverEntry.protocol = serverStatus.getVersion().getProtocol();
						} else {
							serverEntry.version = "Old";
							serverEntry.protocol = 0;
						}

						if (serverStatus.getPlayers() != null) {
							serverEntry.status = Formatting.GRAY
								+ ""
								+ serverStatus.getPlayers().getOnline()
								+ ""
								+ Formatting.DARK_GRAY
								+ "/"
								+ Formatting.GRAY
								+ serverStatus.getPlayers().getMax();
							if (ArrayUtils.isNotEmpty(serverStatus.getPlayers().get())) {
								StringBuilder stringBuilder = new StringBuilder();

								for (GameProfile gameProfile : serverStatus.getPlayers().get()) {
									if (stringBuilder.length() > 0) {
										stringBuilder.append("\n");
									}

									stringBuilder.append(gameProfile.getName());
								}

								if (serverStatus.getPlayers().get().length < serverStatus.getPlayers().getOnline()) {
									if (stringBuilder.length() > 0) {
										stringBuilder.append("\n");
									}

									stringBuilder.append("... and ").append(serverStatus.getPlayers().getOnline() - serverStatus.getPlayers().get().length).append(" more ...");
								}

								serverEntry.onlinePlayers = stringBuilder.toString();
							}
						} else {
							serverEntry.status = Formatting.DARK_GRAY + "???";
						}

						if (serverStatus.getFavicon() != null) {
							String string = serverStatus.getFavicon();
							if (string.startsWith("data:image/png;base64,")) {
								serverEntry.setIcon(string.substring("data:image/png;base64,".length()));
							} else {
								MultiplayerServerListPinger.LOGGER.error("Invalid server icon (unknown format)");
							}
						} else {
							serverEntry.setIcon(null);
						}

						this.statusReceivedTime = Minecraft.getTime();
						connection.send(new PingC2SPacket(this.statusReceivedTime));
						this.success = true;
					}
				}

				@Override
				public void handlePing(PingS2CPacket packet) {
					long l = this.statusReceivedTime;
					long m = Minecraft.getTime();
					serverEntry.ping = m - l;
					connection.disconnect(new LiteralText("Finished"));
				}

				@Override
				public void onDisconnect(Text reason) {
					if (!this.success) {
						MultiplayerServerListPinger.LOGGER.error("Can't ping " + serverEntry.ip + ": " + reason.getString());
						serverEntry.motd = Formatting.DARK_RED + "Can't connect to server.";
						serverEntry.status = "";
						MultiplayerServerListPinger.this.ping(serverEntry);
					}
				}
			}
		);

		try {
			connection.send(new HandshakeC2SPacket(47, serverAddress.getAddress(), serverAddress.getPort(), NetworkProtocol.STATUS));
			connection.send(new ServerStatusC2SPacket());
		} catch (Throwable throwable) {
			LOGGER.error(throwable);
		}
	}

	private void ping(ServerListEntry serverListEntry) {
		final ServerAddress serverAddress = ServerAddress.parse(serverListEntry.ip);
		new Bootstrap().group(Connection.NETWORK_GROUP.get()).handler(new ChannelInitializer<Channel>() {
			@Override
			protected void initChannel(Channel channel) throws Exception {
				try {
					channel.config().setOption(ChannelOption.TCP_NODELAY, true);
				} catch (ChannelException var3) {
				}

				channel.pipeline().addLast(new SimpleChannelInboundHandler<ByteBuf>() {
					@Override
					public void channelActive(ChannelHandlerContext channelHandlerContext) throws Exception {
						super.channelActive(channelHandlerContext);
						ByteBuf byteBuf = Unpooled.buffer();

						try {
							byteBuf.writeByte(254);
							byteBuf.writeByte(1);
							byteBuf.writeByte(250);
							char[] cs = "MC|PingHost".toCharArray();
							byteBuf.writeShort(cs.length);

							for (char c : cs) {
								byteBuf.writeChar(c);
							}

							byteBuf.writeShort(7 + 2 * serverAddress.getAddress().length());
							byteBuf.writeByte(127);
							cs = serverAddress.getAddress().toCharArray();
							byteBuf.writeShort(cs.length);

							for (char c : cs) {
								byteBuf.writeChar(c);
							}

							byteBuf.writeInt(serverAddress.getPort());
							channelHandlerContext.channel().writeAndFlush(byteBuf).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
						} finally {
							byteBuf.release();
						}
					}

					protected void channelRead0(ChannelHandlerContext channelHandlerContext, ByteBuf byteBuf) throws Exception {
						short s = byteBuf.readUnsignedByte();
						if (s == 255) {
							String string = new String(byteBuf.readBytes(byteBuf.readShort() * 2).array(), Charsets.UTF_16BE);
							String[] strings = Iterables.toArray(MultiplayerServerListPinger.ZERO_SPLITTER.split(string), String.class);
							if ("§1".equals(strings[0])) {
								int i = MathHelper.parseInt(strings[1], 0);
								String string2 = strings[2];
								String string3 = strings[3];
								int j = MathHelper.parseInt(strings[4], -1);
								int k = MathHelper.parseInt(strings[5], -1);
								serverListEntry.protocol = -1;
								serverListEntry.version = string2;
								serverListEntry.motd = string3;
								serverListEntry.status = Formatting.GRAY + "" + j + "" + Formatting.DARK_GRAY + "/" + Formatting.GRAY + k;
							}
						}

						channelHandlerContext.close();
					}

					@Override
					public void exceptionCaught(ChannelHandlerContext channelHandlerContext, Throwable throwable) throws Exception {
						channelHandlerContext.close();
					}
				});
			}
		}).channel(NioSocketChannel.class).connect(serverAddress.getAddress(), serverAddress.getPort());
	}

	public void tick() {
		synchronized (this.clientConnectionList) {
			Iterator<Connection> iterator = this.clientConnectionList.iterator();

			while (iterator.hasNext()) {
				Connection connection = iterator.next();
				if (connection.isConnected()) {
					connection.tick();
				} else {
					iterator.remove();
					connection.handleDisconnection();
				}
			}
		}
	}

	public void cancel() {
		synchronized (this.clientConnectionList) {
			Iterator<Connection> iterator = this.clientConnectionList.iterator();

			while (iterator.hasNext()) {
				Connection connection = iterator.next();
				if (connection.isConnected()) {
					iterator.remove();
					connection.disconnect(new LiteralText("Cancelled"));
				}
			}
		}
	}
}

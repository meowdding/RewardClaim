package net.minecraft.client.render.entity.layer;

import com.google.common.collect.Maps;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.model.Model;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public abstract class AbstractArmorLayer<T extends Model> implements EntityRenderLayer<LivingEntity> {
	protected static final Identifier ENCHANTMENT_GLINT_TEXTURE = new Identifier("textures/misc/enchanted_item_glint.png");
	protected T innerModel;
	protected T outerModel;
	private final LivingEntityRenderer<?> parent;
	private float alpha = 1.0F;
	private float red = 1.0F;
	private float green = 1.0F;
	private float blue = 1.0F;
	private boolean hasColor;
	private static final Map<String, Identifier> TEXTURE_CACHE = Maps.newHashMap();

	public AbstractArmorLayer(LivingEntityRenderer<?> parent) {
		this.parent = parent;
		this.hideAll();
	}

	@Override
	public void render(LivingEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale) {
		this.renderArmor(entity, walkAnimationProgress, walkAnimationSpeed, tickDelta, bob, yaw, pitch, scale, 4);
		this.renderArmor(entity, walkAnimationProgress, walkAnimationSpeed, tickDelta, bob, yaw, pitch, scale, 3);
		this.renderArmor(entity, walkAnimationProgress, walkAnimationSpeed, tickDelta, bob, yaw, pitch, scale, 2);
		this.renderArmor(entity, walkAnimationProgress, walkAnimationSpeed, tickDelta, bob, yaw, pitch, scale, 1);
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}

	private void renderArmor(
		LivingEntity entity,
		float walkAnimationProgress,
		float walkAnimationSpeed,
		float tickDelta,
		float bob,
		float yaw,
		float pitch,
		float scale,
		int equipmentSlot
	) {
		ItemStack itemStack = this.getArmor(entity, equipmentSlot);
		if (itemStack != null && itemStack.getItem() instanceof ArmorItem) {
			ArmorItem armorItem = (ArmorItem)itemStack.getItem();
			T model = this.getModel(equipmentSlot);
			model.copyPropertiesFrom(this.parent.getModel());
			model.prepare(entity, walkAnimationProgress, walkAnimationSpeed, tickDelta);
			this.setVisible(model, equipmentSlot);
			boolean bl = this.usesInnerModel(equipmentSlot);
			this.parent.bindTexture(this.getArmorTexture(armorItem, bl));
			switch (armorItem.getTier()) {
				case CLOTH:
					int i = armorItem.getColor(itemStack);
					float f = (i >> 16 & 0xFF) / 255.0F;
					float g = (i >> 8 & 0xFF) / 255.0F;
					float h = (i & 0xFF) / 255.0F;
					GlStateManager.color4f(this.red * f, this.green * g, this.blue * h, this.alpha);
					model.render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
					this.parent.bindTexture(this.getArmorTexture(armorItem, bl, "overlay"));
				case CHAIN:
				case IRON:
				case GOLD:
				case DIAMOND:
					GlStateManager.color4f(this.red, this.green, this.blue, this.alpha);
					model.render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
				default:
					if (!this.hasColor && itemStack.hasEnchantments()) {
						this.renderEnchantmentGlint(entity, model, walkAnimationProgress, walkAnimationSpeed, tickDelta, bob, yaw, pitch, scale);
					}
			}
		}
	}

	public ItemStack getArmor(LivingEntity entity, int equipmentSlot) {
		return entity.getArmor(equipmentSlot - 1);
	}

	public T getModel(int equipmentSlot) {
		return this.usesInnerModel(equipmentSlot) ? this.innerModel : this.outerModel;
	}

	private boolean usesInnerModel(int equipmentSlot) {
		return equipmentSlot == 2;
	}

	private void renderEnchantmentGlint(
		LivingEntity entity, T model, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale
	) {
		float f = entity.ticks + tickDelta;
		this.parent.bindTexture(ENCHANTMENT_GLINT_TEXTURE);
		GlStateManager.enableBlend();
		GlStateManager.depthFunc(514);
		GlStateManager.depthMask(false);
		float g = 0.5F;
		GlStateManager.color4f(g, g, g, 1.0F);

		for (int i = 0; i < 2; i++) {
			GlStateManager.disableLighting();
			GlStateManager.blendFunc(768, 1);
			float h = 0.76F;
			GlStateManager.color4f(0.5F * h, 0.25F * h, 0.8F * h, 1.0F);
			GlStateManager.matrixMode(5890);
			GlStateManager.loadIdentity();
			float j = 0.33333334F;
			GlStateManager.scalef(j, j, j);
			GlStateManager.rotatef(30.0F - i * 60.0F, 0.0F, 0.0F, 1.0F);
			GlStateManager.translatef(0.0F, f * (0.001F + i * 0.003F) * 20.0F, 0.0F);
			GlStateManager.matrixMode(5888);
			model.render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
		}

		GlStateManager.matrixMode(5890);
		GlStateManager.loadIdentity();
		GlStateManager.matrixMode(5888);
		GlStateManager.enableLighting();
		GlStateManager.depthMask(true);
		GlStateManager.depthFunc(515);
		GlStateManager.disableBlend();
	}

	private Identifier getArmorTexture(ArmorItem armor, boolean innerModel) {
		return this.getArmorTexture(armor, innerModel, null);
	}

	private Identifier getArmorTexture(ArmorItem armor, boolean innerModel, String type) {
		String string = String.format(
			"textures/models/armor/%s_layer_%d%s.png", armor.getTier().getKey(), innerModel ? 2 : 1, type == null ? "" : String.format("_%s", type)
		);
		Identifier identifier = TEXTURE_CACHE.get(string);
		if (identifier == null) {
			identifier = new Identifier(string);
			TEXTURE_CACHE.put(string, identifier);
		}

		return identifier;
	}

	protected abstract void hideAll();

	protected abstract void setVisible(T model, int equipmentSlot);
}

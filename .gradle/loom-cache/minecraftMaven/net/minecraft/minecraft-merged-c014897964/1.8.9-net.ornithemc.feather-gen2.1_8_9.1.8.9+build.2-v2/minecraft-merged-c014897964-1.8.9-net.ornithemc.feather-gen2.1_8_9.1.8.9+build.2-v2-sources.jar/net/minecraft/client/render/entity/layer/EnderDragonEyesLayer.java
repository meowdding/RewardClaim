package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.EnderDragonRenderer;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.monster.boss.EnderDragonEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class EnderDragonEyesLayer implements EntityRenderLayer<EnderDragonEntity> {
	private static final Identifier DRAGON_EYES_LOCATION = new Identifier("textures/entity/enderdragon/dragon_eyes.png");
	private final EnderDragonRenderer parent;

	public EnderDragonEyesLayer(EnderDragonRenderer parent) {
		this.parent = parent;
	}

	public void render(
		EnderDragonEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale
	) {
		this.parent.bindTexture(DRAGON_EYES_LOCATION);
		GlStateManager.enableBlend();
		GlStateManager.disableAlphaTest();
		GlStateManager.blendFunc(1, 1);
		GlStateManager.disableLighting();
		GlStateManager.depthFunc(514);
		int i = 61680;
		int j = i % 65536;
		int k = i / 65536;
		GLX.multiTexCoord2f(GLX.GL_TEXTURE1, j / 1.0F, k / 1.0F);
		GlStateManager.enableLighting();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.parent.getModel().render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
		this.parent.setLightColor(entity, tickDelta);
		GlStateManager.disableBlend();
		GlStateManager.enableAlphaTest();
		GlStateManager.depthFunc(515);
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

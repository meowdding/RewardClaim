package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.layer.IronGolemFlowerInHandLayer;
import net.minecraft.client.render.model.entity.IronGolemModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.IronGolemEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class IronGolemRenderer extends MobRenderer<IronGolemEntity> {
	private static final Identifier IRON_GOLEM_LOCATION = new Identifier("textures/entity/iron_golem.png");

	public IronGolemRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher, new IronGolemModel(), 0.5F);
		this.addLayer(new IronGolemFlowerInHandLayer(this));
	}

	protected Identifier getTextureLocation(IronGolemEntity entity) {
		return IRON_GOLEM_LOCATION;
	}

	protected void applyRotation(IronGolemEntity entity, float bob, float bodyYaw, float tickDelta) {
		super.applyRotation(entity, bob, bodyYaw, tickDelta);
		if (!(entity.walkAnimationSpeed < 0.01)) {
			float f = 13.0F;
			float g = entity.walkAnimationProgress - entity.walkAnimationSpeed * (1.0F - tickDelta) + 6.0F;
			float h = (Math.abs(g % f - f * 0.5F) - f * 0.25F) / (f * 0.25F);
			GlStateManager.rotatef(6.5F * h, 0.0F, 0.0F, 1.0F);
		}
	}
}

package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.block.BlockRenderDispatcher;
import net.minecraft.client.render.entity.IronGolemRenderer;
import net.minecraft.client.render.model.entity.IronGolemModel;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.entity.living.mob.IronGolemEntity;

@Environment(EnvType.CLIENT)
public class IronGolemFlowerInHandLayer implements EntityRenderLayer<IronGolemEntity> {
	private final IronGolemRenderer parent;

	public IronGolemFlowerInHandLayer(IronGolemRenderer parent) {
		this.parent = parent;
	}

	public void render(
		IronGolemEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale
	) {
		if (entity.getLookingAtVillagerTicks() != 0) {
			BlockRenderDispatcher blockRenderDispatcher = Minecraft.getInstance().getBlockRenderDispatcher();
			GlStateManager.enableRescaleNormal();
			GlStateManager.pushMatrix();
			GlStateManager.rotatef(5.0F + 180.0F * ((IronGolemModel)this.parent.getModel()).rightArm.rotationX / (float) Math.PI, 1.0F, 0.0F, 0.0F);
			GlStateManager.rotatef(90.0F, 1.0F, 0.0F, 0.0F);
			GlStateManager.translatef(-0.9375F, -0.625F, -0.9375F);
			float f = 0.5F;
			GlStateManager.scalef(f, -f, f);
			int i = entity.getLightLevel(tickDelta);
			int j = i % 65536;
			int k = i / 65536;
			GLX.multiTexCoord2f(GLX.GL_TEXTURE1, j / 1.0F, k / 1.0F);
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			this.parent.bindTexture(TextureAtlas.BLOCKS_LOCATION);
			blockRenderDispatcher.renderAsItem(Blocks.RED_FLOWER.defaultState(), 1.0F);
			GlStateManager.popMatrix();
			GlStateManager.disableRescaleNormal();
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

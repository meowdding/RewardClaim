package net.minecraft.client.gui;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.chat.ChatGui;
import net.minecraft.client.gui.overlay.DebugOverlay;
import net.minecraft.client.gui.overlay.PlayerTabOverlay;
import net.minecraft.client.gui.overlay.StreamOverlay;
import net.minecraft.client.gui.spectator.SpectatorGui;
import net.minecraft.client.render.TextRenderer;
import net.minecraft.client.render.Window;
import net.minecraft.client.render.entity.ItemRenderer;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.render.texture.TextureAtlasSprite;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.attribute.EntityAttributeInstance;
import net.minecraft.entity.living.attribute.EntityAttributes;
import net.minecraft.entity.living.effect.StatusEffect;
import net.minecraft.entity.living.player.HungerManager;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.resource.Identifier;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.ScoreboardScore;
import net.minecraft.scoreboard.team.Team;
import net.minecraft.text.Formatting;
import net.minecraft.text.StringUtils;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.HitResult;
import net.minecraft.world.border.WorldBorder;

@Environment(EnvType.CLIENT)
public class GameGui extends GuiElement {
	private static final Identifier VIGNETTE_LOCATION = new Identifier("textures/misc/vignette.png");
	private static final Identifier WIDGETS_LOCATION = new Identifier("textures/gui/widgets.png");
	private static final Identifier PUMPKIN_BLUR_LOCATION = new Identifier("textures/misc/pumpkinblur.png");
	private final Random random = new Random();
	private final Minecraft minecraft;
	private final ItemRenderer itemRenderer;
	private final ChatGui chat;
	private final StreamOverlay streamOverlay;
	private int ticks;
	private String overlayMessage = "";
	private int overlayMessageCooldown;
	private boolean overlayMessageTinted;
	public float vignetteBrightness = 1.0F;
	private int itemSelectedTimer;
	private ItemStack selectedItem;
	private final DebugOverlay debugOverlay;
	private final SpectatorGui spectatorGui;
	private final PlayerTabOverlay playerTabOverlay;
	private int titleTime;
	private String title = "";
	private String subtitle = "";
	private int titleFadeInTime;
	private int titleDuration;
	private int titleFadeOutTime;
	private int lastHealth = 0;
	private int displayHealth = 0;
	private long lastHealthTime = 0L;
	private long lastHealthAnimationTime = 0L;

	public GameGui(Minecraft minecraft) {
		this.minecraft = minecraft;
		this.itemRenderer = minecraft.getItemRenderer();
		this.debugOverlay = new DebugOverlay(minecraft);
		this.spectatorGui = new SpectatorGui(minecraft);
		this.chat = new ChatGui(minecraft);
		this.streamOverlay = new StreamOverlay(minecraft);
		this.playerTabOverlay = new PlayerTabOverlay(minecraft, this);
		this.resetTitleTimes();
	}

	public void resetTitleTimes() {
		this.titleFadeInTime = 10;
		this.titleDuration = 70;
		this.titleFadeOutTime = 20;
	}

	public void render(float tickDelta) {
		Window window = new Window(this.minecraft);
		int i = window.getWidth();
		int j = window.getHeight();
		this.minecraft.gameRenderer.setupGuiState();
		GlStateManager.enableBlend();
		if (Minecraft.isFancyGraphicsEnabled()) {
			this.renderVignette(this.minecraft.player.getBrightness(tickDelta), window);
		} else {
			GlStateManager.blendFuncSeparate(770, 771, 1, 0);
		}

		ItemStack itemStack = this.minecraft.player.inventory.getArmor(3);
		if (this.minecraft.options.perspective == 0 && itemStack != null && itemStack.getItem() == Item.byBlock(Blocks.PUMPKIN)) {
			this.renderPumpkinOverlay(window);
		}

		if (!this.minecraft.player.hasStatusEffect(StatusEffect.NAUSEA)) {
			float f = this.minecraft.player.lastPortalTime + (this.minecraft.player.portalTime - this.minecraft.player.lastPortalTime) * tickDelta;
			if (f > 0.0F) {
				this.renderNauseaOverlay(f, window);
			}
		}

		if (this.minecraft.interactionManager.hidesGui()) {
			this.spectatorGui.renderHotbar(window, tickDelta);
		} else {
			this.renderHotbar(window, tickDelta);
		}

		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.minecraft.getTextureManager().bind(ICONS_LOCATION);
		GlStateManager.enableBlend();
		if (this.hasCrosshair()) {
			GlStateManager.blendFuncSeparate(775, 769, 1, 0);
			GlStateManager.enableAlphaTest();
			this.drawTexture(i / 2 - 7, j / 2 - 7, 0, 0, 16, 16);
		}

		GlStateManager.blendFuncSeparate(770, 771, 1, 0);
		this.minecraft.profiler.push("bossHealth");
		this.renderBossBars();
		this.minecraft.profiler.pop();
		if (this.minecraft.interactionManager.hasStatusBars()) {
			this.renderStatusBars(window);
		}

		GlStateManager.disableBlend();
		if (this.minecraft.player.getSleepingTime() > 0) {
			this.minecraft.profiler.push("sleep");
			GlStateManager.disableDepthTest();
			GlStateManager.disableAlphaTest();
			int k = this.minecraft.player.getSleepingTime();
			float g = k / 100.0F;
			if (g > 1.0F) {
				g = 1.0F - (k - 100) / 10.0F;
			}

			int l = (int)(220.0F * g) << 24 | 1052704;
			fill(0, 0, i, j, l);
			GlStateManager.enableAlphaTest();
			GlStateManager.enableDepthTest();
			this.minecraft.profiler.pop();
		}

		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		int k = i / 2 - 91;
		if (this.minecraft.player.isRidingRideableMob()) {
			this.renderJumpBar(window, k);
		} else if (this.minecraft.interactionManager.hasXpBar()) {
			this.renderXpBar(window, k);
		}

		if (this.minecraft.options.itemInHandTooltips && !this.minecraft.interactionManager.hidesGui()) {
			this.renderSelectedItemName(window);
		} else if (this.minecraft.player.isSpectator()) {
			this.spectatorGui.renderTooltip(window);
		}

		if (this.minecraft.isDemo()) {
			this.renderDemoMessage(window);
		}

		if (this.minecraft.options.debugEnabled) {
			this.debugOverlay.render(window);
		}

		if (this.overlayMessageCooldown > 0) {
			this.minecraft.profiler.push("overlayMessage");
			float g = this.overlayMessageCooldown - tickDelta;
			int l = (int)(g * 255.0F / 20.0F);
			if (l > 255) {
				l = 255;
			}

			if (l > 8) {
				GlStateManager.pushMatrix();
				GlStateManager.translatef(i / 2, j - 68, 0.0F);
				GlStateManager.enableBlend();
				GlStateManager.blendFuncSeparate(770, 771, 1, 0);
				int m = 16777215;
				if (this.overlayMessageTinted) {
					m = MathHelper.toRgb(g / 50.0F, 0.7F, 0.6F) & 16777215;
				}

				this.getTextRenderer().draw(this.overlayMessage, -this.getTextRenderer().getWidth(this.overlayMessage) / 2, -4, m + (l << 24 & 0xFF000000));
				GlStateManager.disableBlend();
				GlStateManager.popMatrix();
			}

			this.minecraft.profiler.pop();
		}

		if (this.titleTime > 0) {
			this.minecraft.profiler.push("titleAndSubtitle");
			float g = this.titleTime - tickDelta;
			int l = 255;
			if (this.titleTime > this.titleFadeOutTime + this.titleDuration) {
				float h = this.titleFadeInTime + this.titleDuration + this.titleFadeOutTime - g;
				l = (int)(h * 255.0F / this.titleFadeInTime);
			}

			if (this.titleTime <= this.titleFadeOutTime) {
				float h = g;
				l = (int)(h * 255.0F / this.titleFadeOutTime);
			}

			l = MathHelper.clamp(l, 0, 255);
			if (l > 8) {
				GlStateManager.pushMatrix();
				GlStateManager.translatef(i / 2, j / 2, 0.0F);
				GlStateManager.enableBlend();
				GlStateManager.blendFuncSeparate(770, 771, 1, 0);
				GlStateManager.pushMatrix();
				GlStateManager.scalef(4.0F, 4.0F, 4.0F);
				int m = l << 24 & 0xFF000000;
				this.getTextRenderer().draw(this.title, -this.getTextRenderer().getWidth(this.title) / 2, -10.0F, 16777215 | m, true);
				GlStateManager.popMatrix();
				GlStateManager.pushMatrix();
				GlStateManager.scalef(2.0F, 2.0F, 2.0F);
				this.getTextRenderer().draw(this.subtitle, -this.getTextRenderer().getWidth(this.subtitle) / 2, 5.0F, 16777215 | m, true);
				GlStateManager.popMatrix();
				GlStateManager.disableBlend();
				GlStateManager.popMatrix();
			}

			this.minecraft.profiler.pop();
		}

		Scoreboard scoreboard = this.minecraft.world.getScoreboard();
		ScoreboardObjective scoreboardObjective = null;
		Team team = scoreboard.getTeamOfMember(this.minecraft.player.getName());
		if (team != null) {
			int n = team.getColor().getId();
			if (n >= 0) {
				scoreboardObjective = scoreboard.getDisplayObjective(3 + n);
			}
		}

		ScoreboardObjective scoreboardObjective2 = scoreboardObjective != null ? scoreboardObjective : scoreboard.getDisplayObjective(1);
		if (scoreboardObjective2 != null) {
			this.renderScoreboardObjective(scoreboardObjective2, window);
		}

		GlStateManager.enableBlend();
		GlStateManager.blendFuncSeparate(770, 771, 1, 0);
		GlStateManager.disableAlphaTest();
		GlStateManager.pushMatrix();
		GlStateManager.translatef(0.0F, j - 48, 0.0F);
		this.minecraft.profiler.push("chat");
		this.chat.render(this.ticks);
		this.minecraft.profiler.pop();
		GlStateManager.popMatrix();
		scoreboardObjective2 = scoreboard.getDisplayObjective(0);
		if (!this.minecraft.options.playerListKey.isPressed()
			|| this.minecraft.isIntegratedServerRunning() && this.minecraft.player.networkHandler.getOnlinePlayers().size() <= 1 && scoreboardObjective2 == null) {
			this.playerTabOverlay.setVisible(false);
		} else {
			this.playerTabOverlay.setVisible(true);
			this.playerTabOverlay.render(i, scoreboard, scoreboardObjective2);
		}

		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.disableLighting();
		GlStateManager.enableAlphaTest();
	}

	protected void renderHotbar(Window window, float tickDelta) {
		if (this.minecraft.getCamera() instanceof PlayerEntity) {
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			this.minecraft.getTextureManager().bind(WIDGETS_LOCATION);
			PlayerEntity playerEntity = (PlayerEntity)this.minecraft.getCamera();
			int i = window.getWidth() / 2;
			float f = this.drawOffset;
			this.drawOffset = -90.0F;
			this.drawTexture(i - 91, window.getHeight() - 22, 0, 0, 182, 22);
			this.drawTexture(i - 91 - 1 + playerEntity.inventory.selectedSlot * 20, window.getHeight() - 22 - 1, 0, 22, 24, 22);
			this.drawOffset = f;
			GlStateManager.enableRescaleNormal();
			GlStateManager.enableBlend();
			GlStateManager.blendFuncSeparate(770, 771, 1, 0);
			Lighting.turnOnGui();

			for (int j = 0; j < 9; j++) {
				int k = window.getWidth() / 2 - 90 + j * 20 + 2;
				int l = window.getHeight() - 16 - 3;
				this.renderItemSlot(j, k, l, tickDelta, playerEntity);
			}

			Lighting.turnOff();
			GlStateManager.disableRescaleNormal();
			GlStateManager.disableBlend();
		}
	}

	public void renderJumpBar(Window window, int x) {
		this.minecraft.profiler.push("jumpBar");
		this.minecraft.getTextureManager().bind(GuiElement.ICONS_LOCATION);
		float f = this.minecraft.player.getRidingJumpProgress();
		int i = 182;
		int j = (int)(f * (i + 1));
		int k = window.getHeight() - 32 + 3;
		this.drawTexture(x, k, 0, 84, i, 5);
		if (j > 0) {
			this.drawTexture(x, k, 0, 89, j, 5);
		}

		this.minecraft.profiler.pop();
	}

	public void renderXpBar(Window window, int x) {
		this.minecraft.profiler.push("expBar");
		this.minecraft.getTextureManager().bind(GuiElement.ICONS_LOCATION);
		int i = this.minecraft.player.getNextLevelExperience();
		if (i > 0) {
			int j = 182;
			int k = (int)(this.minecraft.player.xpProgress * (j + 1));
			int l = window.getHeight() - 32 + 3;
			this.drawTexture(x, l, 0, 64, j, 5);
			if (k > 0) {
				this.drawTexture(x, l, 0, 69, k, 5);
			}
		}

		this.minecraft.profiler.pop();
		if (this.minecraft.player.xpLevel > 0) {
			this.minecraft.profiler.push("expLevel");
			int j = 8453920;
			String string = "" + this.minecraft.player.xpLevel;
			int l = (window.getWidth() - this.getTextRenderer().getWidth(string)) / 2;
			int m = window.getHeight() - 31 - 4;
			int n = 0;
			this.getTextRenderer().draw(string, l + 1, m, 0);
			this.getTextRenderer().draw(string, l - 1, m, 0);
			this.getTextRenderer().draw(string, l, m + 1, 0);
			this.getTextRenderer().draw(string, l, m - 1, 0);
			this.getTextRenderer().draw(string, l, m, j);
			this.minecraft.profiler.pop();
		}
	}

	public void renderSelectedItemName(Window window) {
		this.minecraft.profiler.push("selectedItemName");
		if (this.itemSelectedTimer > 0 && this.selectedItem != null) {
			String string = this.selectedItem.getHoverName();
			if (this.selectedItem.hasCustomHoverName()) {
				string = Formatting.ITALIC + string;
			}

			int i = (window.getWidth() - this.getTextRenderer().getWidth(string)) / 2;
			int j = window.getHeight() - 59;
			if (!this.minecraft.interactionManager.hasStatusBars()) {
				j += 14;
			}

			int k = (int)(this.itemSelectedTimer * 256.0F / 10.0F);
			if (k > 255) {
				k = 255;
			}

			if (k > 0) {
				GlStateManager.pushMatrix();
				GlStateManager.enableBlend();
				GlStateManager.blendFuncSeparate(770, 771, 1, 0);
				this.getTextRenderer().drawWithShadow(string, i, j, 16777215 + (k << 24));
				GlStateManager.disableBlend();
				GlStateManager.popMatrix();
			}
		}

		this.minecraft.profiler.pop();
	}

	public void renderDemoMessage(Window window) {
		this.minecraft.profiler.push("demo");
		String string = "";
		if (this.minecraft.world.getTime() >= 120500L) {
			string = I18n.translate("demo.demoExpired");
		} else {
			string = I18n.translate("demo.remainingTime", StringUtils.getDurationString((int)(120500L - this.minecraft.world.getTime())));
		}

		int i = this.getTextRenderer().getWidth(string);
		this.getTextRenderer().drawWithShadow(string, window.getWidth() - i - 10, 5.0F, 16777215);
		this.minecraft.profiler.pop();
	}

	protected boolean hasCrosshair() {
		if (this.minecraft.options.debugEnabled && !this.minecraft.player.hasReducedDebugInfo() && !this.minecraft.options.reducedDebugInfo) {
			return false;
		}

		if (this.minecraft.interactionManager.hidesGui()) {
			if (this.minecraft.targetEntity != null) {
				return true;
			}

			if (this.minecraft.crosshairTarget != null && this.minecraft.crosshairTarget.type == HitResult.Type.BLOCK) {
				BlockPos blockPos = this.minecraft.crosshairTarget.getPos();
				if (this.minecraft.world.getBlockEntity(blockPos) instanceof Inventory) {
					return true;
				}
			}

			return false;
		} else {
			return true;
		}
	}

	public void renderStreamOverlay(Window window) {
		this.streamOverlay.render(window.getWidth() - 10, 10);
	}

	private void renderScoreboardObjective(ScoreboardObjective objective, Window width) {
		Scoreboard scoreboard = objective.getScoreboard();
		Collection<ScoreboardScore> collection = scoreboard.getScores(objective);
		List<ScoreboardScore> list = Lists.newArrayList(Iterables.filter(collection, new Predicate<ScoreboardScore>() {
			public boolean apply(ScoreboardScore score) {
				return score.getOwner() != null && !score.getOwner().startsWith("#");
			}
		}));
		if (list.size() > 15) {
			collection = Lists.newArrayList(Iterables.skip(list, collection.size() - 15));
		} else {
			collection = list;
		}

		int i = this.getTextRenderer().getWidth(objective.getDisplayName());

		for (ScoreboardScore scoreboardScore : collection) {
			Team team = scoreboard.getTeamOfMember(scoreboardScore.getOwner());
			String string = Team.getMemberDisplayName(team, scoreboardScore.getOwner()) + ": " + Formatting.RED + scoreboardScore.get();
			i = Math.max(i, this.getTextRenderer().getWidth(string));
		}

		int j = collection.size() * this.getTextRenderer().fontHeight;
		int k = width.getHeight() / 2 + j / 3;
		int l = 3;
		int m = width.getWidth() - i - l;
		int n = 0;

		for (ScoreboardScore scoreboardScore2 : collection) {
			n++;
			Team team2 = scoreboard.getTeamOfMember(scoreboardScore2.getOwner());
			String string2 = Team.getMemberDisplayName(team2, scoreboardScore2.getOwner());
			String string3 = Formatting.RED + "" + scoreboardScore2.get();
			int o = m;
			int p = k - n * this.getTextRenderer().fontHeight;
			int q = width.getWidth() - l + 2;
			fill(o - 2, p, q, p + this.getTextRenderer().fontHeight, 1342177280);
			this.getTextRenderer().draw(string2, o, p, 553648127);
			this.getTextRenderer().draw(string3, q - this.getTextRenderer().getWidth(string3), p, 553648127);
			if (n == collection.size()) {
				String string4 = objective.getDisplayName();
				fill(o - 2, p - this.getTextRenderer().fontHeight - 1, q, p - 1, 1610612736);
				fill(o - 2, p - 1, q, p, 1342177280);
				this.getTextRenderer().draw(string4, o + i / 2 - this.getTextRenderer().getWidth(string4) / 2, p - this.getTextRenderer().fontHeight, 553648127);
			}
		}
	}

	private void renderStatusBars(Window width) {
		if (this.minecraft.getCamera() instanceof PlayerEntity) {
			PlayerEntity playerEntity = (PlayerEntity)this.minecraft.getCamera();
			int i = MathHelper.ceil(playerEntity.getHealth());
			boolean bl = this.lastHealthAnimationTime > this.ticks && (this.lastHealthAnimationTime - this.ticks) / 3L % 2L == 1L;
			if (i < this.lastHealth && playerEntity.invulnerableTimer > 0) {
				this.lastHealthTime = Minecraft.getTime();
				this.lastHealthAnimationTime = this.ticks + 20;
			} else if (i > this.lastHealth && playerEntity.invulnerableTimer > 0) {
				this.lastHealthTime = Minecraft.getTime();
				this.lastHealthAnimationTime = this.ticks + 10;
			}

			if (Minecraft.getTime() - this.lastHealthTime > 1000L) {
				this.lastHealth = i;
				this.displayHealth = i;
				this.lastHealthTime = Minecraft.getTime();
			}

			this.lastHealth = i;
			int j = this.displayHealth;
			this.random.setSeed(this.ticks * 312871);
			boolean bl2 = false;
			HungerManager hungerManager = playerEntity.getHungerManager();
			int k = hungerManager.getFoodLevel();
			int l = hungerManager.getLastFoodLevel();
			EntityAttributeInstance entityAttributeInstance = playerEntity.getAttribute(EntityAttributes.MAX_HEALTH);
			int m = width.getWidth() / 2 - 91;
			int n = width.getWidth() / 2 + 91;
			int o = width.getHeight() - 39;
			float f = (float)entityAttributeInstance.get();
			float g = playerEntity.getAbsorption();
			int p = MathHelper.ceil((f + g) / 2.0F / 10.0F);
			int q = Math.max(10 - (p - 2), 3);
			int r = o - (p - 1) * q - 10;
			float h = g;
			int s = playerEntity.getArmorProtection();
			int t = -1;
			if (playerEntity.hasStatusEffect(StatusEffect.REGENERATION)) {
				t = this.ticks % MathHelper.ceil(f + 5.0F);
			}

			this.minecraft.profiler.push("armor");

			for (int u = 0; u < 10; u++) {
				if (s > 0) {
					int v = m + u * 8;
					if (u * 2 + 1 < s) {
						this.drawTexture(v, r, 34, 9, 9, 9);
					}

					if (u * 2 + 1 == s) {
						this.drawTexture(v, r, 25, 9, 9, 9);
					}

					if (u * 2 + 1 > s) {
						this.drawTexture(v, r, 16, 9, 9, 9);
					}
				}
			}

			this.minecraft.profiler.swap("health");

			for (int u = MathHelper.ceil((f + g) / 2.0F) - 1; u >= 0; u--) {
				int v = 16;
				if (playerEntity.hasStatusEffect(StatusEffect.POISON)) {
					v += 36;
				} else if (playerEntity.hasStatusEffect(StatusEffect.WITHER)) {
					v += 72;
				}

				int w = 0;
				if (bl) {
					w = 1;
				}

				int x = MathHelper.ceil((u + 1) / 10.0F) - 1;
				int y = m + u % 10 * 8;
				int z = o - x * q;
				if (i <= 4) {
					z += this.random.nextInt(2);
				}

				if (u == t) {
					z -= 2;
				}

				int aa = 0;
				if (playerEntity.world.getData().isHardcore()) {
					aa = 5;
				}

				this.drawTexture(y, z, 16 + w * 9, 9 * aa, 9, 9);
				if (bl) {
					if (u * 2 + 1 < j) {
						this.drawTexture(y, z, v + 54, 9 * aa, 9, 9);
					}

					if (u * 2 + 1 == j) {
						this.drawTexture(y, z, v + 63, 9 * aa, 9, 9);
					}
				}

				if (h > 0.0F) {
					if (h == g && g % 2.0F == 1.0F) {
						this.drawTexture(y, z, v + 153, 9 * aa, 9, 9);
					} else {
						this.drawTexture(y, z, v + 144, 9 * aa, 9, 9);
					}

					h -= 2.0F;
				} else {
					if (u * 2 + 1 < i) {
						this.drawTexture(y, z, v + 36, 9 * aa, 9, 9);
					}

					if (u * 2 + 1 == i) {
						this.drawTexture(y, z, v + 45, 9 * aa, 9, 9);
					}
				}
			}

			Entity entity = playerEntity.vehicle;
			if (entity == null) {
				this.minecraft.profiler.swap("food");

				for (int v = 0; v < 10; v++) {
					int w = o;
					int x = 16;
					int y = 0;
					if (playerEntity.hasStatusEffect(StatusEffect.HUNGER)) {
						x += 36;
						y = 13;
					}

					if (playerEntity.getHungerManager().getSaturationLevel() <= 0.0F && this.ticks % (k * 3 + 1) == 0) {
						w += this.random.nextInt(3) - 1;
					}

					if (bl2) {
						y = 1;
					}

					int z = n - v * 8 - 9;
					this.drawTexture(z, w, 16 + y * 9, 27, 9, 9);
					if (bl2) {
						if (v * 2 + 1 < l) {
							this.drawTexture(z, w, x + 54, 27, 9, 9);
						}

						if (v * 2 + 1 == l) {
							this.drawTexture(z, w, x + 63, 27, 9, 9);
						}
					}

					if (v * 2 + 1 < k) {
						this.drawTexture(z, w, x + 36, 27, 9, 9);
					}

					if (v * 2 + 1 == k) {
						this.drawTexture(z, w, x + 45, 27, 9, 9);
					}
				}
			} else if (entity instanceof LivingEntity) {
				this.minecraft.profiler.swap("mountHealth");
				LivingEntity livingEntity = (LivingEntity)entity;
				int w = (int)Math.ceil(livingEntity.getHealth());
				float ab = livingEntity.getMaxHealth();
				int y = (int)(ab + 0.5F) / 2;
				if (y > 30) {
					y = 30;
				}

				int z = o;

				for (int aa = 0; y > 0; aa += 20) {
					int ac = Math.min(y, 10);
					y -= ac;

					for (int ad = 0; ad < ac; ad++) {
						int ae = 52;
						int af = 0;
						if (bl2) {
							af = 1;
						}

						int ag = n - ad * 8 - 9;
						this.drawTexture(ag, z, ae + af * 9, 9, 9, 9);
						if (ad * 2 + 1 + aa < w) {
							this.drawTexture(ag, z, ae + 36, 9, 9, 9);
						}

						if (ad * 2 + 1 + aa == w) {
							this.drawTexture(ag, z, ae + 45, 9, 9, 9);
						}
					}

					z -= 10;
				}
			}

			this.minecraft.profiler.swap("air");
			if (playerEntity.isSubmergedIn(Material.WATER)) {
				int v = this.minecraft.player.getBreath();
				int w = MathHelper.ceil((v - 2) * 10.0 / 300.0);
				int x = MathHelper.ceil(v * 10.0 / 300.0) - w;

				for (int y = 0; y < w + x; y++) {
					if (y < w) {
						this.drawTexture(n - y * 8 - 9, r, 16, 18, 9, 9);
					} else {
						this.drawTexture(n - y * 8 - 9, r, 25, 18, 9, 9);
					}
				}
			}

			this.minecraft.profiler.pop();
		}
	}

	private void renderBossBars() {
		if (BossBar.name != null && BossBar.timer > 0) {
			BossBar.timer--;
			TextRenderer textRenderer = this.minecraft.textRenderer;
			Window window = new Window(this.minecraft);
			int i = window.getWidth();
			int j = 182;
			int k = i / 2 - j / 2;
			int l = (int)(BossBar.health * (j + 1));
			int m = 12;
			this.drawTexture(k, m, 0, 74, j, 5);
			this.drawTexture(k, m, 0, 74, j, 5);
			if (l > 0) {
				this.drawTexture(k, m, 0, 79, l, 5);
			}

			String string = BossBar.name;
			this.getTextRenderer().drawWithShadow(string, i / 2 - this.getTextRenderer().getWidth(string) / 2, m - 10, 16777215);
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			this.minecraft.getTextureManager().bind(ICONS_LOCATION);
		}
	}

	private void renderPumpkinOverlay(Window width) {
		GlStateManager.disableDepthTest();
		GlStateManager.depthMask(false);
		GlStateManager.blendFuncSeparate(770, 771, 1, 0);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.disableAlphaTest();
		this.minecraft.getTextureManager().bind(PUMPKIN_BLUR_LOCATION);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
		bufferBuilder.vertex(0.0, width.getHeight(), -90.0).texture(0.0, 1.0).nextVertex();
		bufferBuilder.vertex(width.getWidth(), width.getHeight(), -90.0).texture(1.0, 1.0).nextVertex();
		bufferBuilder.vertex(width.getWidth(), 0.0, -90.0).texture(1.0, 0.0).nextVertex();
		bufferBuilder.vertex(0.0, 0.0, -90.0).texture(0.0, 0.0).nextVertex();
		tesselator.end();
		GlStateManager.depthMask(true);
		GlStateManager.enableDepthTest();
		GlStateManager.enableAlphaTest();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
	}

	private void renderVignette(float brightnessAtEyes, Window width) {
		brightnessAtEyes = 1.0F - brightnessAtEyes;
		brightnessAtEyes = MathHelper.clamp(brightnessAtEyes, 0.0F, 1.0F);
		WorldBorder worldBorder = this.minecraft.world.getWorldBorder();
		float f = (float)worldBorder.getDistanceFrom(this.minecraft.player);
		double d = Math.min(
			worldBorder.getSizeChangeSpeed() * worldBorder.getWarningTime() * 1000.0, Math.abs(worldBorder.getSizeLerpTarget() - worldBorder.getLerpSize())
		);
		double e = Math.max(worldBorder.getWarningDistance(), d);
		if (f < e) {
			f = 1.0F - (float)(f / e);
		} else {
			f = 0.0F;
		}

		this.vignetteBrightness = (float)(this.vignetteBrightness + (brightnessAtEyes - this.vignetteBrightness) * 0.01);
		GlStateManager.disableDepthTest();
		GlStateManager.depthMask(false);
		GlStateManager.blendFuncSeparate(0, 769, 1, 0);
		if (f > 0.0F) {
			GlStateManager.color4f(0.0F, f, f, 1.0F);
		} else {
			GlStateManager.color4f(this.vignetteBrightness, this.vignetteBrightness, this.vignetteBrightness, 1.0F);
		}

		this.minecraft.getTextureManager().bind(VIGNETTE_LOCATION);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
		bufferBuilder.vertex(0.0, width.getHeight(), -90.0).texture(0.0, 1.0).nextVertex();
		bufferBuilder.vertex(width.getWidth(), width.getHeight(), -90.0).texture(1.0, 1.0).nextVertex();
		bufferBuilder.vertex(width.getWidth(), 0.0, -90.0).texture(1.0, 0.0).nextVertex();
		bufferBuilder.vertex(0.0, 0.0, -90.0).texture(0.0, 0.0).nextVertex();
		tesselator.end();
		GlStateManager.depthMask(true);
		GlStateManager.enableDepthTest();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.blendFuncSeparate(770, 771, 1, 0);
	}

	private void renderNauseaOverlay(float portalTime, Window width) {
		if (portalTime < 1.0F) {
			portalTime *= portalTime;
			portalTime *= portalTime;
			portalTime = portalTime * 0.8F + 0.2F;
		}

		GlStateManager.disableAlphaTest();
		GlStateManager.disableDepthTest();
		GlStateManager.depthMask(false);
		GlStateManager.blendFuncSeparate(770, 771, 1, 0);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, portalTime);
		this.minecraft.getTextureManager().bind(TextureAtlas.BLOCKS_LOCATION);
		TextureAtlasSprite textureAtlasSprite = this.minecraft.getBlockRenderDispatcher().getModelShaper().getParticleIcon(Blocks.NETHER_PORTAL.defaultState());
		float f = textureAtlasSprite.getUMin();
		float g = textureAtlasSprite.getVMin();
		float h = textureAtlasSprite.getUMax();
		float i = textureAtlasSprite.getVMax();
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
		bufferBuilder.vertex(0.0, width.getHeight(), -90.0).texture(f, i).nextVertex();
		bufferBuilder.vertex(width.getWidth(), width.getHeight(), -90.0).texture(h, i).nextVertex();
		bufferBuilder.vertex(width.getWidth(), 0.0, -90.0).texture(h, g).nextVertex();
		bufferBuilder.vertex(0.0, 0.0, -90.0).texture(f, g).nextVertex();
		tesselator.end();
		GlStateManager.depthMask(true);
		GlStateManager.enableDepthTest();
		GlStateManager.enableAlphaTest();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
	}

	private void renderItemSlot(int slot, int x, int z, float tickDelta, PlayerEntity player) {
		ItemStack itemStack = player.inventory.items[slot];
		if (itemStack != null) {
			float f = itemStack.popAnimationTime - tickDelta;
			if (f > 0.0F) {
				GlStateManager.pushMatrix();
				float g = 1.0F + f / 5.0F;
				GlStateManager.translatef(x + 8, z + 12, 0.0F);
				GlStateManager.scalef(1.0F / g, (g + 1.0F) / 2.0F, 1.0F);
				GlStateManager.translatef(-(x + 8), -(z + 12), 0.0F);
			}

			this.itemRenderer.renderGuiItem(itemStack, x, z);
			if (f > 0.0F) {
				GlStateManager.popMatrix();
			}

			this.itemRenderer.renderGuiItemDecoration(this.minecraft.textRenderer, itemStack, x, z);
		}
	}

	public void tick() {
		if (this.overlayMessageCooldown > 0) {
			this.overlayMessageCooldown--;
		}

		if (this.titleTime > 0) {
			this.titleTime--;
			if (this.titleTime <= 0) {
				this.title = "";
				this.subtitle = "";
			}
		}

		this.ticks++;
		this.streamOverlay.m_61253298();
		if (this.minecraft.player != null) {
			ItemStack itemStack = this.minecraft.player.inventory.getSelectedItem();
			if (itemStack == null) {
				this.itemSelectedTimer = 0;
			} else if (this.selectedItem != null
				&& itemStack.getItem() == this.selectedItem.getItem()
				&& ItemStack.matchesNbt(itemStack, this.selectedItem)
				&& (itemStack.isDamageable() || itemStack.getMetadata() == this.selectedItem.getMetadata())) {
				if (this.itemSelectedTimer > 0) {
					this.itemSelectedTimer--;
				}
			} else {
				this.itemSelectedTimer = 40;
			}

			this.selectedItem = itemStack;
		}
	}

	public void setRecordPlayingOverlay(String record) {
		this.setOverlayMessage(I18n.translate("record.nowPlaying", record), true);
	}

	public void setOverlayMessage(String overlayMessage, boolean tinted) {
		this.overlayMessage = overlayMessage;
		this.overlayMessageCooldown = 60;
		this.overlayMessageTinted = tinted;
	}

	public void setTitles(String title, String subtitle, int titleFadeInTime, int titleDuration, int titleFadeOutTime) {
		if (title == null && subtitle == null && titleFadeInTime < 0 && titleDuration < 0 && titleFadeOutTime < 0) {
			this.title = "";
			this.subtitle = "";
			this.titleTime = 0;
		} else if (title != null) {
			this.title = title;
			this.titleTime = this.titleFadeInTime + this.titleDuration + this.titleFadeOutTime;
		} else if (subtitle != null) {
			this.subtitle = subtitle;
		} else {
			if (titleFadeInTime >= 0) {
				this.titleFadeInTime = titleFadeInTime;
			}

			if (titleDuration >= 0) {
				this.titleDuration = titleDuration;
			}

			if (titleFadeOutTime >= 0) {
				this.titleFadeOutTime = titleFadeOutTime;
			}

			if (this.titleTime > 0) {
				this.titleTime = this.titleFadeInTime + this.titleDuration + this.titleFadeOutTime;
			}
		}
	}

	public void setOverlayMessage(Text message, boolean tinted) {
		this.setOverlayMessage(message.getString(), tinted);
	}

	public ChatGui getChat() {
		return this.chat;
	}

	public int getTicks() {
		return this.ticks;
	}

	public TextRenderer getTextRenderer() {
		return this.minecraft.textRenderer;
	}

	public SpectatorGui getSpectatorGui() {
		return this.spectatorGui;
	}

	public PlayerTabOverlay getPlayerTabOverlay() {
		return this.playerTabOverlay;
	}

	public void resetPlayerTabOverlay() {
		this.playerTabOverlay.reset();
	}
}

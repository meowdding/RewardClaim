package net.minecraft.client.entity.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.LiquidBlock;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

@Environment(EnvType.CLIENT)
public class RainSplashParticle extends Particle {
	protected RainSplashParticle(World world, double x, double y, double z) {
		super(world, x, y, z, 0.0, 0.0, 0.0);
		this.velocityX *= 0.3F;
		this.velocityY = Math.random() * 0.2F + 0.1F;
		this.velocityZ *= 0.3F;
		this.red = 1.0F;
		this.green = 1.0F;
		this.blue = 1.0F;
		this.setTextureCoordinates(19 + this.random.nextInt(4));
		this.setSize(0.01F, 0.01F);
		this.gravity = 0.06F;
		this.lifetime = (int)(8.0 / (Math.random() * 0.8 + 0.2));
	}

	@Override
	public void tick() {
		this.lastX = this.x;
		this.lastY = this.y;
		this.lastZ = this.z;
		this.velocityY = this.velocityY - this.gravity;
		this.move(this.velocityX, this.velocityY, this.velocityZ);
		this.velocityX *= 0.98F;
		this.velocityY *= 0.98F;
		this.velocityZ *= 0.98F;
		if (this.lifetime-- <= 0) {
			this.remove();
		}

		if (this.onGround) {
			if (Math.random() < 0.5) {
				this.remove();
			}

			this.velocityX *= 0.7F;
			this.velocityZ *= 0.7F;
		}

		BlockPos blockPos = new BlockPos(this);
		BlockState blockState = this.world.getBlockState(blockPos);
		Block block = blockState.getBlock();
		block.updateShape(this.world, blockPos);
		Material material = blockState.getBlock().getMaterial();
		if (material.isLiquid() || material.isSolid()) {
			double d = 0.0;
			if (blockState.getBlock() instanceof LiquidBlock) {
				d = 1.0F - LiquidBlock.getHeightLoss(blockState.get(LiquidBlock.LEVEL));
			} else {
				d = block.getMaxY();
			}

			double e = MathHelper.floor(this.y) + d;
			if (this.y < e) {
				this.remove();
			}
		}
	}

	@Environment(EnvType.CLIENT)
	public static class Factory implements ParticleFactory {
		@Override
		public Particle create(int type, World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, int... parameters) {
			return new RainSplashParticle(world, x, y, z);
		}
	}
}

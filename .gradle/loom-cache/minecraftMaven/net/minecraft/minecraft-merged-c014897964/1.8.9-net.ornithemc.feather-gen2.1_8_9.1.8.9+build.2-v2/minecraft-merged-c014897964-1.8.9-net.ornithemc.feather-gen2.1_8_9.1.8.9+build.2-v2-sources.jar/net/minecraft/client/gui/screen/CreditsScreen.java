package net.minecraft.client.gui.screen;

import com.google.common.collect.Lists;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiElement;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.client.sound.MusicManager;
import net.minecraft.client.sound.system.SoundManager;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import net.minecraft.resource.Identifier;
import net.minecraft.text.Formatting;
import org.apache.commons.io.Charsets;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Environment(EnvType.CLIENT)
public class CreditsScreen extends Screen {
	private static final Logger LOGGER = LogManager.getLogger();
	private static final Identifier TITLE_LOCATION = new Identifier("textures/gui/title/minecraft.png");
	private static final Identifier VIGNETTE_LOCATION = new Identifier("textures/misc/vignette.png");
	private int ticksOpen;
	private List<String> creditTextLines;
	private int creditsHeight;
	private float speed = 0.5F;

	@Override
	public void tick() {
		MusicManager musicManager = this.minecraft.getMusicManager();
		SoundManager soundManager = this.minecraft.getSoundManager();
		if (this.ticksOpen == 0) {
			musicManager.stopPlaying();
			musicManager.startPlaying(MusicManager.Music.CREDITS);
			soundManager.resume();
		}

		soundManager.tick();
		this.ticksOpen++;
		float f = (this.creditsHeight + this.height + this.height + 24) / this.speed;
		if (this.ticksOpen > f) {
			this.respawn();
		}
	}

	@Override
	protected void keyPressed(char chr, int key) {
		if (key == 1) {
			this.respawn();
		}
	}

	private void respawn() {
		this.minecraft.player.networkHandler.sendPacket(new ClientStatusC2SPacket(ClientStatusC2SPacket.Status.PERFORM_RESPAWN));
		this.minecraft.openScreen(null);
	}

	@Override
	public boolean shouldPauseGame() {
		return true;
	}

	@Override
	public void init() {
		if (this.creditTextLines == null) {
			this.creditTextLines = Lists.newArrayList();

			try {
				String string = "";
				String string2 = "" + Formatting.WHITE + Formatting.OBFUSCATED + Formatting.GREEN + Formatting.AQUA;
				int i = 274;
				InputStream inputStream = this.minecraft.getResourceManager().getResource(new Identifier("texts/end.txt")).asStream();
				BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, Charsets.UTF_8));
				Random random = new Random(8124371L);

				while ((string = bufferedReader.readLine()) != null) {
					string = string.replaceAll("PLAYERNAME", this.minecraft.getSession().getUsername());

					while (string.contains(string2)) {
						int j = string.indexOf(string2);
						String string3 = string.substring(0, j);
						String string4 = string.substring(j + string2.length());
						string = string3 + Formatting.WHITE + Formatting.OBFUSCATED + "XXXXXXXX".substring(0, random.nextInt(4) + 3) + string4;
					}

					this.creditTextLines.addAll(this.minecraft.textRenderer.split(string, i));
					this.creditTextLines.add("");
				}

				inputStream.close();

				for (int j = 0; j < 8; j++) {
					this.creditTextLines.add("");
				}

				inputStream = this.minecraft.getResourceManager().getResource(new Identifier("texts/credits.txt")).asStream();
				bufferedReader = new BufferedReader(new InputStreamReader(inputStream, Charsets.UTF_8));

				while ((string = bufferedReader.readLine()) != null) {
					string = string.replaceAll("PLAYERNAME", this.minecraft.getSession().getUsername());
					string = string.replaceAll("\t", "    ");
					this.creditTextLines.addAll(this.minecraft.textRenderer.split(string, i));
					this.creditTextLines.add("");
				}

				inputStream.close();
				this.creditsHeight = this.creditTextLines.size() * 12;
			} catch (Exception exception) {
				LOGGER.error("Couldn't load credits", exception);
			}
		}
	}

	private void renderBackground(int mouseX, int mouseY, float tickDelta) {
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		this.minecraft.getTextureManager().bind(GuiElement.BACKGROUND_LOCATION);
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
		int i = this.width;
		float f = 0.0F - (this.ticksOpen + tickDelta) * 0.5F * this.speed;
		float g = this.height - (this.ticksOpen + tickDelta) * 0.5F * this.speed;
		float h = 0.015625F;
		float j = (this.ticksOpen + tickDelta - 0.0F) * 0.02F;
		float k = (this.creditsHeight + this.height + this.height + 24) / this.speed;
		float l = (k - 20.0F - (this.ticksOpen + tickDelta)) * 0.005F;
		if (l < j) {
			j = l;
		}

		if (j > 1.0F) {
			j = 1.0F;
		}

		j *= j;
		j = j * 96.0F / 255.0F;
		bufferBuilder.vertex(0.0, this.height, this.drawOffset).texture(0.0, f * h).color(j, j, j, 1.0F).nextVertex();
		bufferBuilder.vertex(i, this.height, this.drawOffset).texture(i * h, f * h).color(j, j, j, 1.0F).nextVertex();
		bufferBuilder.vertex(i, 0.0, this.drawOffset).texture(i * h, g * h).color(j, j, j, 1.0F).nextVertex();
		bufferBuilder.vertex(0.0, 0.0, this.drawOffset).texture(0.0, g * h).color(j, j, j, 1.0F).nextVertex();
		tesselator.end();
	}

	@Override
	public void render(int mouseX, int mouseY, float tickDelta) {
		this.renderBackground(mouseX, mouseY, tickDelta);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		int i = 274;
		int j = this.width / 2 - i / 2;
		int k = this.height + 50;
		float f = -(this.ticksOpen + tickDelta) * this.speed;
		GlStateManager.pushMatrix();
		GlStateManager.translatef(0.0F, f, 0.0F);
		this.minecraft.getTextureManager().bind(TITLE_LOCATION);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.drawTexture(j, k, 0, 0, 155, 44);
		this.drawTexture(j + 155, k, 0, 45, 155, 44);
		int l = k + 200;

		for (int m = 0; m < this.creditTextLines.size(); m++) {
			if (m == this.creditTextLines.size() - 1) {
				float g = l + f - (this.height / 2 - 6);
				if (g < 0.0F) {
					GlStateManager.translatef(0.0F, -g, 0.0F);
				}
			}

			if (l + f + 12.0F + 8.0F > 0.0F && l + f < this.height) {
				String string = this.creditTextLines.get(m);
				if (string.startsWith("[C]")) {
					this.textRenderer.drawWithShadow(string.substring(3), j + (i - this.textRenderer.getWidth(string.substring(3))) / 2, l, 16777215);
				} else {
					this.textRenderer.random.setSeed(m * 4238972211L + this.ticksOpen / 4);
					this.textRenderer.drawWithShadow(string, j, l, 16777215);
				}
			}

			l += 12;
		}

		GlStateManager.popMatrix();
		this.minecraft.getTextureManager().bind(VIGNETTE_LOCATION);
		GlStateManager.enableBlend();
		GlStateManager.blendFunc(0, 769);
		int m = this.width;
		int n = this.height;
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
		bufferBuilder.vertex(0.0, n, this.drawOffset).texture(0.0, 1.0).color(1.0F, 1.0F, 1.0F, 1.0F).nextVertex();
		bufferBuilder.vertex(m, n, this.drawOffset).texture(1.0, 1.0).color(1.0F, 1.0F, 1.0F, 1.0F).nextVertex();
		bufferBuilder.vertex(m, 0.0, this.drawOffset).texture(1.0, 0.0).color(1.0F, 1.0F, 1.0F, 1.0F).nextVertex();
		bufferBuilder.vertex(0.0, 0.0, this.drawOffset).texture(0.0, 0.0).color(1.0F, 1.0F, 1.0F, 1.0F).nextVertex();
		tesselator.end();
		GlStateManager.disableBlend();
		super.render(mouseX, mouseY, tickDelta);
	}
}

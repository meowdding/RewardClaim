package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.layer.WolfCollarLayer;
import net.minecraft.client.render.model.Model;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.passive.animal.tameable.WolfEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class WolfRenderer extends MobRenderer<WolfEntity> {
	private static final Identifier WOLF_LOCATION = new Identifier("textures/entity/wolf/wolf.png");
	private static final Identifier TAME_WOLF_LOCATION = new Identifier("textures/entity/wolf/wolf_tame.png");
	private static final Identifier ANGRY_WOLF_LOCATION = new Identifier("textures/entity/wolf/wolf_angry.png");

	public WolfRenderer(EntityRenderDispatcher entityRenderDispatcher, Model model, float f) {
		super(entityRenderDispatcher, model, f);
		this.addLayer(new WolfCollarLayer(this));
	}

	protected float getBob(WolfEntity entity, float tickDelta) {
		return entity.getTailBob();
	}

	public void render(WolfEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		if (entity.isWet()) {
			float f = entity.getBrightness(tickDelta) * entity.getShakeProgress(tickDelta);
			GlStateManager.color3f(f, f, f);
		}

		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(WolfEntity entity) {
		if (entity.isTamed()) {
			return TAME_WOLF_LOCATION;
		} else {
			return entity.isAngry() ? ANGRY_WOLF_LOCATION : WOLF_LOCATION;
		}
	}
}

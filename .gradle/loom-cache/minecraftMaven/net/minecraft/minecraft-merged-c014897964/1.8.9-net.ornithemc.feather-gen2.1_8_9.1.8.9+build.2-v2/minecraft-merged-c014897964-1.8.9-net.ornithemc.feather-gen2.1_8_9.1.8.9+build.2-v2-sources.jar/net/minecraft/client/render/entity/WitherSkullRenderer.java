package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.model.block.entity.SkullModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class WitherSkullRenderer extends EntityRenderer<WitherSkullEntity> {
	private static final Identifier WITHER_INVULNERABLE_LOCATION = new Identifier("textures/entity/wither/wither_invulnerable.png");
	private static final Identifier WITHER_LOCATION = new Identifier("textures/entity/wither/wither.png");
	private final SkullModel model = new SkullModel();

	public WitherSkullRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
	}

	private float getYaw(float prevYaw, float yaw, float tickDelta) {
		float f = yaw - prevYaw;

		while (f < -180.0F) {
			f += 360.0F;
		}

		while (f >= 180.0F) {
			f -= 360.0F;
		}

		return prevYaw + tickDelta * f;
	}

	public void render(WitherSkullEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		GlStateManager.pushMatrix();
		GlStateManager.disableCull();
		float f = this.getYaw(entity.lastYaw, entity.yaw, tickDelta);
		float g = entity.lastPitch + (entity.pitch - entity.lastPitch) * tickDelta;
		GlStateManager.translatef((float)dx, (float)dy, (float)dz);
		float h = 0.0625F;
		GlStateManager.enableRescaleNormal();
		GlStateManager.scalef(-1.0F, -1.0F, 1.0F);
		GlStateManager.enableAlphaTest();
		this.bindTexture(entity);
		this.model.render(entity, 0.0F, 0.0F, 0.0F, f, g, h);
		GlStateManager.popMatrix();
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(WitherSkullEntity entity) {
		return entity.isCharged() ? WITHER_INVULNERABLE_LOCATION : WITHER_LOCATION;
	}
}

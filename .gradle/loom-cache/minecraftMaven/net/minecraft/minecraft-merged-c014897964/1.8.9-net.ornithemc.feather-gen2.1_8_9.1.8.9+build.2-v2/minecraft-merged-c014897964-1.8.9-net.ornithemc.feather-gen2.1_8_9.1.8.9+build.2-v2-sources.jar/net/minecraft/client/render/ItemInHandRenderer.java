package net.minecraft.client.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.living.player.ClientPlayerEntity;
import net.minecraft.client.entity.living.player.LocalClientPlayerEntity;
import net.minecraft.client.render.block.BlockLayer;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.ItemRenderer;
import net.minecraft.client.render.entity.PlayerRenderer;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.render.texture.TextureAtlasSprite;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.client.resource.model.ModelTransformations;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.UseAction;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.map.SavedMapData;
import org.lwjgl.opengl.GL11;

@Environment(EnvType.CLIENT)
public class ItemInHandRenderer {
	private static final Identifier MAP_BACKGROUND_LOCATION = new Identifier("textures/map/map_background.png");
	private static final Identifier UNDERWATER_LOCATION = new Identifier("textures/misc/underwater.png");
	private final Minecraft minecraft;
	private ItemStack itemInHand;
	private float handHeight;
	private float lastHandHeight;
	private final EntityRenderDispatcher dispatcher;
	private final ItemRenderer renderer;
	private int selectedSlot = -1;

	public ItemInHandRenderer(Minecraft minecraft) {
		this.minecraft = minecraft;
		this.dispatcher = minecraft.getEntityRenderDispatcher();
		this.renderer = minecraft.getItemRenderer();
	}

	public void render(LivingEntity entity, ItemStack item, ModelTransformations.Type transform) {
		if (item != null) {
			Item item2 = item.getItem();
			Block block = Block.byItem(item2);
			GlStateManager.pushMatrix();
			if (this.renderer.isGui3d(item)) {
				GlStateManager.scalef(2.0F, 2.0F, 2.0F);
				if (this.isTranslucent(block)) {
					GlStateManager.depthMask(false);
				}
			}

			this.renderer.renderItemInHand(item, entity, transform);
			if (this.isTranslucent(block)) {
				GlStateManager.depthMask(true);
			}

			GlStateManager.popMatrix();
		}
	}

	private boolean isTranslucent(Block block) {
		return block != null && block.getRenderLayer() == BlockLayer.TRANSLUCENT;
	}

	private void rotate(float x, float y) {
		GlStateManager.pushMatrix();
		GlStateManager.rotatef(x, 1.0F, 0.0F, 0.0F);
		GlStateManager.rotatef(y, 0.0F, 1.0F, 0.0F);
		Lighting.turnOn();
		GlStateManager.popMatrix();
	}

	private void setHandLightColor(ClientPlayerEntity player) {
		int i = this.minecraft.world.getLightColor(new BlockPos(player.x, player.y + player.getEyeHeight(), player.z), 0);
		float f = i & 65535;
		float g = i >> 16;
		GLX.multiTexCoord2f(GLX.GL_TEXTURE1, f, g);
	}

	private void applyHandSway(LocalClientPlayerEntity player, float tickDelta) {
		float f = player.lastEasedPitch + (player.easedPitch - player.lastEasedPitch) * tickDelta;
		float g = player.lastEasedYaw + (player.easedYaw - player.lastEasedYaw) * tickDelta;
		GlStateManager.rotatef((player.pitch - f) * 0.1F, 1.0F, 0.0F, 0.0F);
		GlStateManager.rotatef((player.yaw - g) * 0.1F, 0.0F, 1.0F, 0.0F);
	}

	private float getMapPitch(float pitch) {
		float f = 1.0F - pitch / 45.0F + 0.1F;
		f = MathHelper.clamp(f, 0.0F, 1.0F);
		return -MathHelper.cos(f * (float) Math.PI) * 0.5F + 0.5F;
	}

	private void renderRightArm(PlayerRenderer player) {
		GlStateManager.pushMatrix();
		GlStateManager.rotatef(54.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(64.0F, 1.0F, 0.0F, 0.0F);
		GlStateManager.rotatef(-62.0F, 0.0F, 0.0F, 1.0F);
		GlStateManager.translatef(0.25F, -0.85F, 0.75F);
		player.renderRightArm(this.minecraft.player);
		GlStateManager.popMatrix();
	}

	private void renderLeftArm(PlayerRenderer player) {
		GlStateManager.pushMatrix();
		GlStateManager.rotatef(92.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(45.0F, 1.0F, 0.0F, 0.0F);
		GlStateManager.rotatef(41.0F, 0.0F, 0.0F, 1.0F);
		GlStateManager.translatef(-0.3F, -1.1F, 0.45F);
		player.renderLeftArm(this.minecraft.player);
		GlStateManager.popMatrix();
	}

	private void renderArms(ClientPlayerEntity player) {
		this.minecraft.getTextureManager().bind(player.getSkinTextureLocation());
		EntityRenderer<ClientPlayerEntity> entityRenderer = this.dispatcher.getRenderer(this.minecraft.player);
		PlayerRenderer playerRenderer = (PlayerRenderer)entityRenderer;
		if (!player.isInvisible()) {
			GlStateManager.disableCull();
			this.renderRightArm(playerRenderer);
			this.renderLeftArm(playerRenderer);
			GlStateManager.enableCull();
		}
	}

	private void renderMap(ClientPlayerEntity player, float pitch, float swapProgress, float swingProgress) {
		float f = -0.4F * MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
		float g = 0.2F * MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI * 2.0F);
		float h = -0.2F * MathHelper.sin(swingProgress * (float) Math.PI);
		GlStateManager.translatef(f, g, h);
		float i = this.getMapPitch(pitch);
		GlStateManager.translatef(0.0F, 0.04F, -0.72F);
		GlStateManager.translatef(0.0F, swapProgress * -1.2F, 0.0F);
		GlStateManager.translatef(0.0F, i * -0.5F, 0.0F);
		GlStateManager.rotatef(90.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(i * -85.0F, 0.0F, 0.0F, 1.0F);
		GlStateManager.rotatef(0.0F, 1.0F, 0.0F, 0.0F);
		this.renderArms(player);
		float j = MathHelper.sin(swingProgress * swingProgress * (float) Math.PI);
		float k = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
		GlStateManager.rotatef(j * -20.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(k * -20.0F, 0.0F, 0.0F, 1.0F);
		GlStateManager.rotatef(k * -80.0F, 1.0F, 0.0F, 0.0F);
		GlStateManager.scalef(0.38F, 0.38F, 0.38F);
		GlStateManager.rotatef(90.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(180.0F, 0.0F, 0.0F, 1.0F);
		GlStateManager.rotatef(0.0F, 1.0F, 0.0F, 0.0F);
		GlStateManager.translatef(-1.0F, -1.0F, 0.0F);
		GlStateManager.scalef(0.015625F, 0.015625F, 0.015625F);
		this.minecraft.getTextureManager().bind(MAP_BACKGROUND_LOCATION);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		GL11.glNormal3f(0.0F, 0.0F, -1.0F);
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
		bufferBuilder.vertex(-7.0, 135.0, 0.0).texture(0.0, 1.0).nextVertex();
		bufferBuilder.vertex(135.0, 135.0, 0.0).texture(1.0, 1.0).nextVertex();
		bufferBuilder.vertex(135.0, -7.0, 0.0).texture(1.0, 0.0).nextVertex();
		bufferBuilder.vertex(-7.0, -7.0, 0.0).texture(0.0, 0.0).nextVertex();
		tesselator.end();
		SavedMapData savedMapData = Items.FILLED_MAP.getSavedMapData(this.itemInHand, this.minecraft.world);
		if (savedMapData != null) {
			this.minecraft.gameRenderer.getMapRenderer().draw(savedMapData, false);
		}
	}

	private void renderHand(ClientPlayerEntity player, float swapProgress, float swingProgress) {
		float f = -0.3F * MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
		float g = 0.4F * MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI * 2.0F);
		float h = -0.4F * MathHelper.sin(swingProgress * (float) Math.PI);
		GlStateManager.translatef(f, g, h);
		GlStateManager.translatef(0.64000005F, -0.6F, -0.71999997F);
		GlStateManager.translatef(0.0F, swapProgress * -0.6F, 0.0F);
		GlStateManager.rotatef(45.0F, 0.0F, 1.0F, 0.0F);
		float i = MathHelper.sin(swingProgress * swingProgress * (float) Math.PI);
		float j = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
		GlStateManager.rotatef(j * 70.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(i * -20.0F, 0.0F, 0.0F, 1.0F);
		this.minecraft.getTextureManager().bind(player.getSkinTextureLocation());
		GlStateManager.translatef(-1.0F, 3.6F, 3.5F);
		GlStateManager.rotatef(120.0F, 0.0F, 0.0F, 1.0F);
		GlStateManager.rotatef(200.0F, 1.0F, 0.0F, 0.0F);
		GlStateManager.rotatef(-135.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.scalef(1.0F, 1.0F, 1.0F);
		GlStateManager.translatef(5.6F, 0.0F, 0.0F);
		EntityRenderer<ClientPlayerEntity> entityRenderer = this.dispatcher.getRenderer(this.minecraft.player);
		GlStateManager.disableCull();
		PlayerRenderer playerRenderer = (PlayerRenderer)entityRenderer;
		playerRenderer.renderRightArm(this.minecraft.player);
		GlStateManager.enableCull();
	}

	private void applyArmSwing(float swingProgress) {
		float f = -0.4F * MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
		float g = 0.2F * MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI * 2.0F);
		float h = -0.2F * MathHelper.sin(swingProgress * (float) Math.PI);
		GlStateManager.translatef(f, g, h);
	}

	private void applyConsuming(ClientPlayerEntity player, float tickDelta) {
		float f = player.getItemUseTimer() - tickDelta + 1.0F;
		float g = f / this.itemInHand.getUseDuration();
		float h = MathHelper.abs(MathHelper.cos(f / 4.0F * (float) Math.PI) * 0.1F);
		if (g >= 0.8F) {
			h = 0.0F;
		}

		GlStateManager.translatef(0.0F, h, 0.0F);
		float i = 1.0F - (float)Math.pow(g, 27.0);
		GlStateManager.translatef(i * 0.6F, i * -0.5F, i * 0.0F);
		GlStateManager.rotatef(i * 90.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(i * 10.0F, 1.0F, 0.0F, 0.0F);
		GlStateManager.rotatef(i * 30.0F, 0.0F, 0.0F, 1.0F);
	}

	private void applyFirstPersonTransform(float xU, float yU) {
		GlStateManager.translatef(0.56F, -0.52F, -0.71999997F);
		GlStateManager.translatef(0.0F, xU * -0.6F, 0.0F);
		GlStateManager.rotatef(45.0F, 0.0F, 1.0F, 0.0F);
		float f = MathHelper.sin(yU * yU * (float) Math.PI);
		float g = MathHelper.sin(MathHelper.sqrt(yU) * (float) Math.PI);
		GlStateManager.rotatef(f * -20.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(g * -20.0F, 0.0F, 0.0F, 1.0F);
		GlStateManager.rotatef(g * -80.0F, 1.0F, 0.0F, 0.0F);
		GlStateManager.scalef(0.4F, 0.4F, 0.4F);
	}

	private void applyBowNocking(float tickDelta, ClientPlayerEntity player) {
		GlStateManager.rotatef(-18.0F, 0.0F, 0.0F, 1.0F);
		GlStateManager.rotatef(-12.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(-8.0F, 1.0F, 0.0F, 0.0F);
		GlStateManager.translatef(-0.9F, 0.2F, 0.0F);
		float f = this.itemInHand.getUseDuration() - (player.getItemUseTimer() - tickDelta + 1.0F);
		float g = f / 20.0F;
		g = (g * g + g * 2.0F) / 3.0F;
		if (g > 1.0F) {
			g = 1.0F;
		}

		if (g > 0.1F) {
			float h = MathHelper.sin((f - 0.1F) * 1.3F);
			float i = g - 0.1F;
			float j = h * i;
			GlStateManager.translatef(j * 0.0F, j * 0.01F, j * 0.0F);
		}

		GlStateManager.translatef(g * 0.0F, g * 0.0F, g * 0.1F);
		GlStateManager.scalef(1.0F, 1.0F, 1.0F + g * 0.2F);
	}

	private void applySwordBlocking() {
		GlStateManager.translatef(-0.5F, 0.2F, 0.0F);
		GlStateManager.rotatef(30.0F, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(-80.0F, 1.0F, 0.0F, 0.0F);
		GlStateManager.rotatef(60.0F, 0.0F, 1.0F, 0.0F);
	}

	public void renderInFirstPerson(float tickDelta) {
		float f = 1.0F - (this.lastHandHeight + (this.handHeight - this.lastHandHeight) * tickDelta);
		ClientPlayerEntity clientPlayerEntity = this.minecraft.player;
		float g = clientPlayerEntity.getAttackAnimationProgress(tickDelta);
		float h = clientPlayerEntity.lastPitch + (clientPlayerEntity.pitch - clientPlayerEntity.lastPitch) * tickDelta;
		float i = clientPlayerEntity.lastYaw + (clientPlayerEntity.yaw - clientPlayerEntity.lastYaw) * tickDelta;
		this.rotate(h, i);
		this.setHandLightColor(clientPlayerEntity);
		this.applyHandSway((LocalClientPlayerEntity)clientPlayerEntity, tickDelta);
		GlStateManager.enableRescaleNormal();
		GlStateManager.pushMatrix();
		if (this.itemInHand != null) {
			if (this.itemInHand.getItem() == Items.FILLED_MAP) {
				this.renderMap(clientPlayerEntity, h, f, g);
			} else if (clientPlayerEntity.getItemUseTimer() > 0) {
				UseAction useAction = this.itemInHand.getUseAction();
				switch (useAction) {
					case NONE:
						this.applyFirstPersonTransform(f, 0.0F);
						break;
					case EAT:
					case DRINK:
						this.applyConsuming(clientPlayerEntity, tickDelta);
						this.applyFirstPersonTransform(f, 0.0F);
						break;
					case BLOCK:
						this.applyFirstPersonTransform(f, 0.0F);
						this.applySwordBlocking();
						break;
					case BOW:
						this.applyFirstPersonTransform(f, 0.0F);
						this.applyBowNocking(tickDelta, clientPlayerEntity);
				}
			} else {
				this.applyArmSwing(g);
				this.applyFirstPersonTransform(f, g);
			}

			this.render(clientPlayerEntity, this.itemInHand, ModelTransformations.Type.FIRST_PERSON);
		} else if (!clientPlayerEntity.isInvisible()) {
			this.renderHand(clientPlayerEntity, f, g);
		}

		GlStateManager.popMatrix();
		GlStateManager.disableRescaleNormal();
		Lighting.turnOff();
	}

	public void renderScreenEffects(float tickDelta) {
		GlStateManager.disableAlphaTest();
		if (this.minecraft.player.isInWall()) {
			BlockState blockState = this.minecraft.world.getBlockState(new BlockPos(this.minecraft.player));
			PlayerEntity playerEntity = this.minecraft.player;

			for (int i = 0; i < 8; i++) {
				double d = playerEntity.x + ((i >> 0) % 2 - 0.5F) * playerEntity.width * 0.8F;
				double e = playerEntity.y + ((i >> 1) % 2 - 0.5F) * 0.1F;
				double f = playerEntity.z + ((i >> 2) % 2 - 0.5F) * playerEntity.width * 0.8F;
				BlockPos blockPos = new BlockPos(d, e + playerEntity.getEyeHeight(), f);
				BlockState blockState2 = this.minecraft.world.getBlockState(blockPos);
				if (blockState2.getBlock().isViewBlocking()) {
					blockState = blockState2;
				}
			}

			if (blockState.getBlock().getRenderType() != -1) {
				this.renderInWallEffect(tickDelta, this.minecraft.getBlockRenderDispatcher().getModelShaper().getParticleIcon(blockState));
			}
		}

		if (!this.minecraft.player.isSpectator()) {
			if (this.minecraft.player.isSubmergedIn(Material.WATER)) {
				this.renderInWaterEffect(tickDelta);
			}

			if (this.minecraft.player.isOnFire()) {
				this.renderOnFireEffect(tickDelta);
			}
		}

		GlStateManager.enableAlphaTest();
	}

	private void renderInWallEffect(float tickDelta, TextureAtlasSprite sprite) {
		this.minecraft.getTextureManager().bind(TextureAtlas.BLOCKS_LOCATION);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		float f = 0.1F;
		GlStateManager.color4f(0.1F, 0.1F, 0.1F, 0.5F);
		GlStateManager.pushMatrix();
		float g = -1.0F;
		float h = 1.0F;
		float i = -1.0F;
		float j = 1.0F;
		float k = -0.5F;
		float l = sprite.getUMin();
		float m = sprite.getUMax();
		float n = sprite.getVMin();
		float o = sprite.getVMax();
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
		bufferBuilder.vertex(-1.0, -1.0, -0.5).texture(m, o).nextVertex();
		bufferBuilder.vertex(1.0, -1.0, -0.5).texture(l, o).nextVertex();
		bufferBuilder.vertex(1.0, 1.0, -0.5).texture(l, n).nextVertex();
		bufferBuilder.vertex(-1.0, 1.0, -0.5).texture(m, n).nextVertex();
		tesselator.end();
		GlStateManager.popMatrix();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
	}

	private void renderInWaterEffect(float tickDelta) {
		this.minecraft.getTextureManager().bind(UNDERWATER_LOCATION);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		float f = this.minecraft.player.getBrightness(tickDelta);
		GlStateManager.color4f(f, f, f, 0.5F);
		GlStateManager.enableBlend();
		GlStateManager.blendFuncSeparate(770, 771, 1, 0);
		GlStateManager.pushMatrix();
		float g = 4.0F;
		float h = -1.0F;
		float i = 1.0F;
		float j = -1.0F;
		float k = 1.0F;
		float l = -0.5F;
		float m = -this.minecraft.player.yaw / 64.0F;
		float n = this.minecraft.player.pitch / 64.0F;
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
		bufferBuilder.vertex(-1.0, -1.0, -0.5).texture(4.0F + m, 4.0F + n).nextVertex();
		bufferBuilder.vertex(1.0, -1.0, -0.5).texture(0.0F + m, 4.0F + n).nextVertex();
		bufferBuilder.vertex(1.0, 1.0, -0.5).texture(0.0F + m, 0.0F + n).nextVertex();
		bufferBuilder.vertex(-1.0, 1.0, -0.5).texture(4.0F + m, 0.0F + n).nextVertex();
		tesselator.end();
		GlStateManager.popMatrix();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.disableBlend();
	}

	private void renderOnFireEffect(float tickDelta) {
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 0.9F);
		GlStateManager.depthFunc(519);
		GlStateManager.depthMask(false);
		GlStateManager.enableBlend();
		GlStateManager.blendFuncSeparate(770, 771, 1, 0);
		float f = 1.0F;

		for (int i = 0; i < 2; i++) {
			GlStateManager.pushMatrix();
			TextureAtlasSprite textureAtlasSprite = this.minecraft.getBlocksAtlas().getSprite("minecraft:blocks/fire_layer_1");
			this.minecraft.getTextureManager().bind(TextureAtlas.BLOCKS_LOCATION);
			float g = textureAtlasSprite.getUMin();
			float h = textureAtlasSprite.getUMax();
			float j = textureAtlasSprite.getVMin();
			float k = textureAtlasSprite.getVMax();
			float l = (0.0F - f) / 2.0F;
			float m = l + f;
			float n = 0.0F - f / 2.0F;
			float o = n + f;
			float p = -0.5F;
			GlStateManager.translatef(-(i * 2 - 1) * 0.24F, -0.3F, 0.0F);
			GlStateManager.rotatef((i * 2 - 1) * 10.0F, 0.0F, 1.0F, 0.0F);
			bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
			bufferBuilder.vertex(l, n, p).texture(h, k).nextVertex();
			bufferBuilder.vertex(m, n, p).texture(g, k).nextVertex();
			bufferBuilder.vertex(m, o, p).texture(g, j).nextVertex();
			bufferBuilder.vertex(l, o, p).texture(h, j).nextVertex();
			tesselator.end();
			GlStateManager.popMatrix();
		}

		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.disableBlend();
		GlStateManager.depthMask(true);
		GlStateManager.depthFunc(515);
	}

	public void tick() {
		this.lastHandHeight = this.handHeight;
		PlayerEntity playerEntity = this.minecraft.player;
		ItemStack itemStack = playerEntity.inventory.getSelectedItem();
		boolean bl = false;
		if (this.itemInHand != null && itemStack != null) {
			if (!this.itemInHand.isEqualForHoldAnimation(itemStack)) {
				bl = true;
			}
		} else if (this.itemInHand == null && itemStack == null) {
			bl = false;
		} else {
			bl = true;
		}

		float f = 0.4F;
		float g = bl ? 0.0F : 1.0F;
		float h = MathHelper.clamp(g - this.handHeight, -f, f);
		this.handHeight += h;
		if (this.handHeight < 0.1F) {
			this.itemInHand = itemStack;
			this.selectedSlot = playerEntity.inventory.selectedSlot;
		}
	}

	public void onBlockUsed() {
		this.handHeight = 0.0F;
	}

	public void onItemUsed() {
		this.handHeight = 0.0F;
	}
}

package net.minecraft.block;

import com.google.common.base.Predicate;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.block.pattern.BlockPattern;
import net.minecraft.block.pattern.BlockPatternBuilder;
import net.minecraft.block.pattern.BlockPointer;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.predicate.BlockStatePredicate;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.block.state.property.DirectionProperty;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.mob.monster.boss.WitherEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.entity.particle.ParticleType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.locale.I18n;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.stat.achievement.Achievements;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.Difficulty;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.ornithemc.feather.constants.SetBlockFlags;

public class SkullBlock extends BlockWithBlockEntity {
	public static final DirectionProperty FACING = DirectionProperty.of("facing");
	public static final BooleanProperty NODROP = BooleanProperty.of("nodrop");
	private static final Predicate<BlockPointer> WITHER_SKULL_PREDICATE = new Predicate<BlockPointer>() {
		public boolean apply(BlockPointer block) {
			return block.getState() != null
				&& block.getState().getBlock() == Blocks.SKULL
				&& block.getBlockEntity() instanceof SkullBlockEntity
				&& ((SkullBlockEntity)block.getBlockEntity()).getType() == 1;
		}
	};
	private BlockPattern basePattern;
	private BlockPattern pattern;

	protected SkullBlock() {
		super(Material.DECORATION);
		this.setDefaultState(this.stateDefinition.any().set(FACING, Direction.NORTH).set(NODROP, false));
		this.setShape(0.25F, 0.0F, 0.25F, 0.75F, 0.5F, 0.75F);
	}

	@Override
	public String getName() {
		return I18n.translate("tile.skull.skeleton.name");
	}

	@Override
	public boolean isSolidRender() {
		return false;
	}

	@Override
	public boolean isCube() {
		return false;
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		switch ((Direction)world.getBlockState(pos).get(FACING)) {
			case UP:
			default:
				this.setShape(0.25F, 0.0F, 0.25F, 0.75F, 0.5F, 0.75F);
				break;
			case NORTH:
				this.setShape(0.25F, 0.25F, 0.5F, 0.75F, 0.75F, 1.0F);
				break;
			case SOUTH:
				this.setShape(0.25F, 0.25F, 0.0F, 0.75F, 0.75F, 0.5F);
				break;
			case WEST:
				this.setShape(0.5F, 0.25F, 0.25F, 1.0F, 0.75F, 0.75F);
				break;
			case EAST:
				this.setShape(0.0F, 0.25F, 0.25F, 0.5F, 0.75F, 0.75F);
		}
	}

	@Override
	public Box getCollisionShape(World world, BlockPos pos, BlockState state) {
		this.updateShape(world, pos);
		return super.getCollisionShape(world, pos, state);
	}

	@Override
	public BlockState getPlacementState(World world, BlockPos pos, Direction dir, float dx, float dy, float dz, int metadata, LivingEntity entity) {
		return this.defaultState().set(FACING, entity.getHorizontalFacing()).set(NODROP, false);
	}

	@Override
	public BlockEntity createBlockEntity(World world, int metadata) {
		return new SkullBlockEntity();
	}

	@Environment(EnvType.CLIENT)
	@Override
	public Item getPickItem(World world, BlockPos pos) {
		return Items.SKULL;
	}

	@Override
	public int getPickItemMetadata(World world, BlockPos pos) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		return blockEntity instanceof SkullBlockEntity ? ((SkullBlockEntity)blockEntity).getType() : super.getPickItemMetadata(world, pos);
	}

	@Override
	public void dropItems(World world, BlockPos pos, BlockState state, float luck, int fortuneLevel) {
	}

	@Override
	public void beforeMinedByPlayer(World world, BlockPos pos, BlockState state, PlayerEntity player) {
		if (player.abilities.creativeMode) {
			state = state.set(NODROP, true);
			world.setBlockState(pos, state, SetBlockFlags.NO_REDRAW);
		}

		super.beforeMinedByPlayer(world, pos, state, player);
	}

	@Override
	public void onRemoved(World world, BlockPos pos, BlockState state) {
		if (!world.isClient) {
			if (!state.get(NODROP)) {
				BlockEntity blockEntity = world.getBlockEntity(pos);
				if (blockEntity instanceof SkullBlockEntity) {
					SkullBlockEntity skullBlockEntity = (SkullBlockEntity)blockEntity;
					ItemStack itemStack = new ItemStack(Items.SKULL, 1, this.getPickItemMetadata(world, pos));
					if (skullBlockEntity.getType() == 3 && skullBlockEntity.getProfile() != null) {
						itemStack.setNbt(new NbtCompound());
						NbtCompound nbtCompound = new NbtCompound();
						NbtUtils.writeProfile(nbtCompound, skullBlockEntity.getProfile());
						itemStack.getNbt().put("SkullOwner", nbtCompound);
					}

					dropItem(world, pos, itemStack);
				}
			}

			super.onRemoved(world, pos, state);
		}
	}

	@Override
	public Item getDropItem(BlockState state, Random random, int fortuneLevel) {
		return Items.SKULL;
	}

	public boolean canSpawn(World world, BlockPos pos, ItemStack item) {
		return item.getMetadata() == 1 && pos.getY() >= 2 && world.getDifficulty() != Difficulty.PEACEFUL && !world.isClient
			? this.getBasePattern().find(world, pos) != null
			: false;
	}

	public void trySpawn(World world, BlockPos pos, SkullBlockEntity skull) {
		if (skull.getType() == 1 && pos.getY() >= 2 && world.getDifficulty() != Difficulty.PEACEFUL && !world.isClient) {
			BlockPattern blockPattern = this.getPattern();
			BlockPattern.Match match = blockPattern.find(world, pos);
			if (match != null) {
				for (int i = 0; i < 3; i++) {
					BlockPointer blockPointer = match.getBlock(i, 0, 0);
					world.setBlockState(blockPointer.getPos(), blockPointer.getState().set(NODROP, true), SetBlockFlags.NOTIFY_LISTENERS);
				}

				for (int i = 0; i < blockPattern.getHeight(); i++) {
					for (int j = 0; j < blockPattern.getWidth(); j++) {
						BlockPointer blockPointer2 = match.getBlock(i, j, 0);
						world.setBlockState(blockPointer2.getPos(), Blocks.AIR.defaultState(), SetBlockFlags.NOTIFY_LISTENERS);
					}
				}

				BlockPos blockPos = match.getBlock(1, 0, 0).getPos();
				WitherEntity witherEntity = new WitherEntity(world);
				BlockPos blockPos2 = match.getBlock(1, 2, 0).getPos();
				witherEntity.setPositionAndAngles(
					blockPos2.getX() + 0.5, blockPos2.getY() + 0.55, blockPos2.getZ() + 0.5, match.getForward().getAxis() == Direction.Axis.X ? 0.0F : 90.0F, 0.0F
				);
				witherEntity.bodyYaw = match.getForward().getAxis() == Direction.Axis.X ? 0.0F : 90.0F;
				witherEntity.onSummoned();

				for (PlayerEntity playerEntity : world.getEntitiesOfType(PlayerEntity.class, witherEntity.getShape().grown(50.0, 50.0, 50.0))) {
					playerEntity.incrementStat(Achievements.SUMMON_WITHER);
				}

				world.addEntity(witherEntity);

				for (int k = 0; k < 120; k++) {
					world.addParticle(
						ParticleType.SNOWBALL,
						blockPos.getX() + world.random.nextDouble(),
						blockPos.getY() - 2 + world.random.nextDouble() * 3.9,
						blockPos.getZ() + world.random.nextDouble(),
						0.0,
						0.0,
						0.0
					);
				}

				for (int k = 0; k < blockPattern.getHeight(); k++) {
					for (int l = 0; l < blockPattern.getWidth(); l++) {
						BlockPointer blockPointer3 = match.getBlock(k, l, 0);
						world.onBlockChanged(blockPointer3.getPos(), Blocks.AIR);
					}
				}
			}
		}
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		return this.defaultState().set(FACING, Direction.byId(metadata & 7)).set(NODROP, (metadata & 8) > 0);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		int i = 0;
		i |= state.get(FACING).getId();
		if (state.get(NODROP)) {
			i |= 8;
		}

		return i;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, FACING, NODROP);
	}

	protected BlockPattern getBasePattern() {
		if (this.basePattern == null) {
			this.basePattern = BlockPatternBuilder.start()
				.aisle("   ", "###", "~#~")
				.with('#', BlockPointer.hasState(BlockStatePredicate.of(Blocks.SOUL_SAND)))
				.with('~', BlockPointer.hasState(BlockStatePredicate.of(Blocks.AIR)))
				.build();
		}

		return this.basePattern;
	}

	protected BlockPattern getPattern() {
		if (this.pattern == null) {
			this.pattern = BlockPatternBuilder.start()
				.aisle("^^^", "###", "~#~")
				.with('#', BlockPointer.hasState(BlockStatePredicate.of(Blocks.SOUL_SAND)))
				.with('^', WITHER_SKULL_PREDICATE)
				.with('~', BlockPointer.hasState(BlockStatePredicate.of(Blocks.AIR)))
				.build();
		}

		return this.pattern;
	}
}

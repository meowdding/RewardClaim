package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.model.Model;
import net.minecraft.entity.living.mob.passive.animal.ChickenEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class ChickenRenderer extends MobRenderer<ChickenEntity> {
	private static final Identifier CHICKEN_LOCATION = new Identifier("textures/entity/chicken.png");

	public ChickenRenderer(EntityRenderDispatcher entityRenderDispatcher, Model model, float f) {
		super(entityRenderDispatcher, model, f);
	}

	protected Identifier getTextureLocation(ChickenEntity entity) {
		return CHICKEN_LOCATION;
	}

	protected float getBob(ChickenEntity entity, float tickDelta) {
		float f = entity.lastFlapProgress + (entity.flapProgress - entity.lastFlapProgress) * tickDelta;
		float g = entity.lastFlapSpeed + (entity.flapSpeed - entity.lastFlapSpeed) * tickDelta;
		return (MathHelper.sin(f) + 1.0F) * g;
	}
}

package net.minecraft.block;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.client.render.block.BlockLayer;
import net.minecraft.client.world.color.BiomeColors;
import net.minecraft.client.world.color.FoliageColors;
import net.minecraft.entity.particle.ParticleType;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.ornithemc.feather.constants.SetBlockFlags;

public abstract class AbstractLeavesBlock extends TranslucentBlock {
	public static final BooleanProperty DECAYABLE = BooleanProperty.of("decayable");
	public static final BooleanProperty CHECK_DECAY = BooleanProperty.of("check_decay");
	int[] decayRegion;
	@Environment(EnvType.CLIENT)
	protected int spriteIndex;
	@Environment(EnvType.CLIENT)
	protected boolean renderCutout;

	public AbstractLeavesBlock() {
		super(Material.LEAVES, false);
		this.setTicksRandomly(true);
		this.setCreativeModeTab(CreativeModeTab.DECORATIONS);
		this.setStrength(0.2F);
		this.setOpacity(1);
		this.setSounds(GRASS_SOUNDS);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public int getColor() {
		return FoliageColors.get(0.5, 1.0);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public int getColor(BlockState state) {
		return FoliageColors.getDefaultColor();
	}

	@Environment(EnvType.CLIENT)
	@Override
	public int getColorTint(WorldView world, BlockPos pos, int tint) {
		return BiomeColors.getFoliageColor(world, pos);
	}

	@Override
	public void onRemoved(World world, BlockPos pos, BlockState state) {
		int i = 1;
		int j = i + 1;
		int k = pos.getX();
		int l = pos.getY();
		int m = pos.getZ();
		if (world.isAreaLoaded(new BlockPos(k - j, l - j, m - j), new BlockPos(k + j, l + j, m + j))) {
			for (int n = -i; n <= i; n++) {
				for (int o = -i; o <= i; o++) {
					for (int p = -i; p <= i; p++) {
						BlockPos blockPos = pos.add(n, o, p);
						BlockState blockState = world.getBlockState(blockPos);
						if (blockState.getBlock().getMaterial() == Material.LEAVES && !blockState.get(CHECK_DECAY)) {
							world.setBlockState(blockPos, blockState.set(CHECK_DECAY, true), SetBlockFlags.NO_REDRAW);
						}
					}
				}
			}
		}
	}

	@Override
	public void tick(World world, BlockPos pos, BlockState state, Random random) {
		if (!world.isClient) {
			if (state.get(CHECK_DECAY) && state.get(DECAYABLE)) {
				int i = 4;
				int j = i + 1;
				int k = pos.getX();
				int l = pos.getY();
				int m = pos.getZ();
				int n = 32;
				int o = n * n;
				int p = n / 2;
				if (this.decayRegion == null) {
					this.decayRegion = new int[n * n * n];
				}

				if (world.isAreaLoaded(new BlockPos(k - j, l - j, m - j), new BlockPos(k + j, l + j, m + j))) {
					BlockPos.Mutable mutable = new BlockPos.Mutable();

					for (int q = -i; q <= i; q++) {
						for (int r = -i; r <= i; r++) {
							for (int s = -i; s <= i; s++) {
								Block block = world.getBlockState(mutable.set(k + q, l + r, m + s)).getBlock();
								if (block != Blocks.LOG && block != Blocks.LOG2) {
									if (block.getMaterial() == Material.LEAVES) {
										this.decayRegion[(q + p) * o + (r + p) * n + s + p] = -2;
									} else {
										this.decayRegion[(q + p) * o + (r + p) * n + s + p] = -1;
									}
								} else {
									this.decayRegion[(q + p) * o + (r + p) * n + s + p] = 0;
								}
							}
						}
					}

					for (int q = 1; q <= 4; q++) {
						for (int r = -i; r <= i; r++) {
							for (int s = -i; s <= i; s++) {
								for (int t = -i; t <= i; t++) {
									if (this.decayRegion[(r + p) * o + (s + p) * n + t + p] == q - 1) {
										if (this.decayRegion[(r + p - 1) * o + (s + p) * n + t + p] == -2) {
											this.decayRegion[(r + p - 1) * o + (s + p) * n + t + p] = q;
										}

										if (this.decayRegion[(r + p + 1) * o + (s + p) * n + t + p] == -2) {
											this.decayRegion[(r + p + 1) * o + (s + p) * n + t + p] = q;
										}

										if (this.decayRegion[(r + p) * o + (s + p - 1) * n + t + p] == -2) {
											this.decayRegion[(r + p) * o + (s + p - 1) * n + t + p] = q;
										}

										if (this.decayRegion[(r + p) * o + (s + p + 1) * n + t + p] == -2) {
											this.decayRegion[(r + p) * o + (s + p + 1) * n + t + p] = q;
										}

										if (this.decayRegion[(r + p) * o + (s + p) * n + (t + p - 1)] == -2) {
											this.decayRegion[(r + p) * o + (s + p) * n + (t + p - 1)] = q;
										}

										if (this.decayRegion[(r + p) * o + (s + p) * n + t + p + 1] == -2) {
											this.decayRegion[(r + p) * o + (s + p) * n + t + p + 1] = q;
										}
									}
								}
							}
						}
					}
				}

				int u = this.decayRegion[p * o + p * n + p];
				if (u >= 0) {
					world.setBlockState(pos, state.set(CHECK_DECAY, false), SetBlockFlags.NO_REDRAW);
				} else {
					this.breakLeaves(world, pos);
				}
			}
		}
	}

	@Environment(EnvType.CLIENT)
	@Override
	public void randomDisplayTick(World world, BlockPos pos, BlockState state, Random random) {
		if (world.isRaining(pos.up()) && !World.hasSolidTop(world, pos.down()) && random.nextInt(15) == 1) {
			double d = pos.getX() + random.nextFloat();
			double e = pos.getY() - 0.05;
			double f = pos.getZ() + random.nextFloat();
			world.addParticle(ParticleType.DRIP_WATER, d, e, f, 0.0, 0.0, 0.0);
		}
	}

	private void breakLeaves(World world, BlockPos pos) {
		this.dropItems(world, pos, world.getBlockState(pos), 0);
		world.removeBlock(pos);
	}

	@Override
	public int getBaseDropCount(Random random) {
		return random.nextInt(20) == 0 ? 1 : 0;
	}

	@Override
	public Item getDropItem(BlockState state, Random random, int fortuneLevel) {
		return Item.byBlock(Blocks.SAPLING);
	}

	@Override
	public void dropItems(World world, BlockPos pos, BlockState state, float luck, int fortuneLevel) {
		if (!world.isClient) {
			int i = this.getSaplingDropChance(state);
			if (fortuneLevel > 0) {
				i -= 2 << fortuneLevel;
				if (i < 10) {
					i = 10;
				}
			}

			if (world.random.nextInt(i) == 0) {
				Item item = this.getDropItem(state, world.random, fortuneLevel);
				dropItem(world, pos, new ItemStack(item, 1, this.getDropItemMetadata(state)));
			}

			i = 200;
			if (fortuneLevel > 0) {
				i -= 10 << fortuneLevel;
				if (i < 40) {
					i = 40;
				}
			}

			this.dropAppleWithChance(world, pos, state, i);
		}
	}

	/**
	 * If leaf block has correct metadata, then drop an apple item with 1/chance probability
	 */
	protected void dropAppleWithChance(World world, BlockPos pos, BlockState state, int chance) {
	}

	/**
	 * Returns the base chance for the block to drop a sapling when broken
	 */
	protected int getSaplingDropChance(BlockState state) {
		return 20;
	}

	@Override
	public boolean isSolidRender() {
		return !this.culling;
	}

	@Environment(EnvType.CLIENT)
	public void setCulling(boolean culling) {
		this.renderCutout = culling;
		this.culling = culling;
		this.spriteIndex = culling ? 0 : 1;
	}

	@Environment(EnvType.CLIENT)
	@Override
	public BlockLayer getRenderLayer() {
		return this.renderCutout ? BlockLayer.CUTOUT_MIPPED : BlockLayer.SOLID;
	}

	@Override
	public boolean isViewBlocking() {
		return false;
	}

	public abstract PlanksBlock.Variant getVariant(int metadata);
}

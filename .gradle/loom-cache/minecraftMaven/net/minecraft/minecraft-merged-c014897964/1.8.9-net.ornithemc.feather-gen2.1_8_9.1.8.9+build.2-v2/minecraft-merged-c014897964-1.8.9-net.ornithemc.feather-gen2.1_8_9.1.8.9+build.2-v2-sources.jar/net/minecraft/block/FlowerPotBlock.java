package net.minecraft.block;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.FlowerPotBlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.EnumProperty;
import net.minecraft.block.state.property.IntegerProperty;
import net.minecraft.block.state.property.StringSerializable;
import net.minecraft.client.render.block.BlockLayer;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.locale.I18n;
import net.minecraft.stat.Stats;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

public class FlowerPotBlock extends BlockWithBlockEntity {
	public static final IntegerProperty LEGACY_DATA = IntegerProperty.of("legacy_data", 0, 15);
	public static final EnumProperty<FlowerPotBlock.Contents> CONTENTS = EnumProperty.of("contents", FlowerPotBlock.Contents.class);

	public FlowerPotBlock() {
		super(Material.DECORATION);
		this.setDefaultState(this.stateDefinition.any().set(CONTENTS, FlowerPotBlock.Contents.EMPTY).set(LEGACY_DATA, 0));
		this.resetShape();
	}

	@Override
	public String getName() {
		return I18n.translate("item.flowerPot.name");
	}

	@Override
	public void resetShape() {
		float f = 0.375F;
		float g = f / 2.0F;
		this.setShape(0.5F - g, 0.0F, 0.5F - g, 0.5F + g, f, 0.5F + g);
	}

	@Override
	public boolean isSolidRender() {
		return false;
	}

	@Override
	public int getRenderType() {
		return 3;
	}

	@Override
	public boolean isCube() {
		return false;
	}

	@Environment(EnvType.CLIENT)
	@Override
	public int getColorTint(WorldView world, BlockPos pos, int tint) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof FlowerPotBlockEntity) {
			Item item = ((FlowerPotBlockEntity)blockEntity).getPlant();
			if (item instanceof BlockItem) {
				return Block.byItem(item).getColorTint(world, pos, tint);
			}
		}

		return 16777215;
	}

	@Override
	public boolean use(World world, BlockPos pos, BlockState state, PlayerEntity player, Direction face, float faceX, float faceY, float faceZ) {
		ItemStack itemStack = player.inventory.getSelectedItem();
		if (itemStack != null && itemStack.getItem() instanceof BlockItem) {
			FlowerPotBlockEntity flowerPotBlockEntity = this.getFlowerPotBlockEntity(world, pos);
			if (flowerPotBlockEntity == null) {
				return false;
			}

			if (flowerPotBlockEntity.getPlant() != null) {
				return false;
			}

			Block block = Block.byItem(itemStack.getItem());
			if (!this.isPottablePlant(block, itemStack.getMetadata())) {
				return false;
			}

			flowerPotBlockEntity.setPlant(itemStack.getItem(), itemStack.getMetadata());
			flowerPotBlockEntity.markDirty();
			world.notifyBlockChanged(pos);
			player.incrementStat(Stats.FLOWERS_POTTED);
			if (!player.abilities.creativeMode && --itemStack.size <= 0) {
				player.inventory.setItem(player.inventory.selectedSlot, null);
			}

			return true;
		} else {
			return false;
		}
	}

	private boolean isPottablePlant(Block block, int metadata) {
		return block == Blocks.YELLOW_FLOWER
				|| block == Blocks.RED_FLOWER
				|| block == Blocks.CACTUS
				|| block == Blocks.BROWN_MUSHROOM
				|| block == Blocks.RED_MUSHROOM
				|| block == Blocks.SAPLING
				|| block == Blocks.DEADBUSH
			? true
			: block == Blocks.TALLGRASS && metadata == TallPlantBlock.Type.FERN.getId();
	}

	@Environment(EnvType.CLIENT)
	@Override
	public Item getPickItem(World world, BlockPos pos) {
		FlowerPotBlockEntity flowerPotBlockEntity = this.getFlowerPotBlockEntity(world, pos);
		return flowerPotBlockEntity != null && flowerPotBlockEntity.getPlant() != null ? flowerPotBlockEntity.getPlant() : Items.FLOWER_POT;
	}

	@Override
	public int getPickItemMetadata(World world, BlockPos pos) {
		FlowerPotBlockEntity flowerPotBlockEntity = this.getFlowerPotBlockEntity(world, pos);
		return flowerPotBlockEntity != null && flowerPotBlockEntity.getPlant() != null ? flowerPotBlockEntity.getMetadata() : 0;
	}

	@Environment(EnvType.CLIENT)
	@Override
	public boolean hasPickItemMetadata() {
		return true;
	}

	@Override
	public boolean canBePlaced(World world, BlockPos pos) {
		return super.canBePlaced(world, pos) && World.hasSolidTop(world, pos.down());
	}

	@Override
	public void neighborChanged(World world, BlockPos pos, BlockState state, Block neighborBlock) {
		if (!World.hasSolidTop(world, pos.down())) {
			this.dropItems(world, pos, state, 0);
			world.removeBlock(pos);
		}
	}

	@Override
	public void onRemoved(World world, BlockPos pos, BlockState state) {
		FlowerPotBlockEntity flowerPotBlockEntity = this.getFlowerPotBlockEntity(world, pos);
		if (flowerPotBlockEntity != null && flowerPotBlockEntity.getPlant() != null) {
			dropItem(world, pos, new ItemStack(flowerPotBlockEntity.getPlant(), 1, flowerPotBlockEntity.getMetadata()));
		}

		super.onRemoved(world, pos, state);
	}

	@Override
	public void beforeMinedByPlayer(World world, BlockPos pos, BlockState state, PlayerEntity player) {
		super.beforeMinedByPlayer(world, pos, state, player);
		if (player.abilities.creativeMode) {
			FlowerPotBlockEntity flowerPotBlockEntity = this.getFlowerPotBlockEntity(world, pos);
			if (flowerPotBlockEntity != null) {
				flowerPotBlockEntity.setPlant(null, 0);
			}
		}
	}

	@Override
	public Item getDropItem(BlockState state, Random random, int fortuneLevel) {
		return Items.FLOWER_POT;
	}

	private FlowerPotBlockEntity getFlowerPotBlockEntity(World world, BlockPos x) {
		BlockEntity blockEntity = world.getBlockEntity(x);
		return blockEntity instanceof FlowerPotBlockEntity ? (FlowerPotBlockEntity)blockEntity : null;
	}

	@Override
	public BlockEntity createBlockEntity(World world, int metadata) {
		Block block = null;
		int i = 0;
		switch (metadata) {
			case 1:
				block = Blocks.RED_FLOWER;
				i = FlowerBlock.Type.POPPY.getId();
				break;
			case 2:
				block = Blocks.YELLOW_FLOWER;
				break;
			case 3:
				block = Blocks.SAPLING;
				i = PlanksBlock.Variant.OAK.getId();
				break;
			case 4:
				block = Blocks.SAPLING;
				i = PlanksBlock.Variant.SPRUCE.getId();
				break;
			case 5:
				block = Blocks.SAPLING;
				i = PlanksBlock.Variant.BIRCH.getId();
				break;
			case 6:
				block = Blocks.SAPLING;
				i = PlanksBlock.Variant.JUNGLE.getId();
				break;
			case 7:
				block = Blocks.RED_MUSHROOM;
				break;
			case 8:
				block = Blocks.BROWN_MUSHROOM;
				break;
			case 9:
				block = Blocks.CACTUS;
				break;
			case 10:
				block = Blocks.DEADBUSH;
				break;
			case 11:
				block = Blocks.TALLGRASS;
				i = TallPlantBlock.Type.FERN.getId();
				break;
			case 12:
				block = Blocks.SAPLING;
				i = PlanksBlock.Variant.ACACIA.getId();
				break;
			case 13:
				block = Blocks.SAPLING;
				i = PlanksBlock.Variant.DARK_OAK.getId();
		}

		return new FlowerPotBlockEntity(Item.byBlock(block), i);
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, CONTENTS, LEGACY_DATA);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		return state.get(LEGACY_DATA);
	}

	@Override
	public BlockState resolveVirtualProperties(BlockState state, WorldView world, BlockPos pos) {
		FlowerPotBlock.Contents contents = FlowerPotBlock.Contents.EMPTY;
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof FlowerPotBlockEntity) {
			FlowerPotBlockEntity flowerPotBlockEntity = (FlowerPotBlockEntity)blockEntity;
			Item item = flowerPotBlockEntity.getPlant();
			if (item instanceof BlockItem) {
				int i = flowerPotBlockEntity.getMetadata();
				Block block = Block.byItem(item);
				if (block == Blocks.SAPLING) {
					switch (PlanksBlock.Variant.byId(i)) {
						case OAK:
							contents = FlowerPotBlock.Contents.OAK_SAPLING;
							break;
						case SPRUCE:
							contents = FlowerPotBlock.Contents.SPRUCE_SAPLING;
							break;
						case BIRCH:
							contents = FlowerPotBlock.Contents.BIRCH_SAPLING;
							break;
						case JUNGLE:
							contents = FlowerPotBlock.Contents.JUNGLE_SAPLING;
							break;
						case ACACIA:
							contents = FlowerPotBlock.Contents.ACACIA_SAPLING;
							break;
						case DARK_OAK:
							contents = FlowerPotBlock.Contents.DARK_OAK_SAPLING;
							break;
						default:
							contents = FlowerPotBlock.Contents.EMPTY;
					}
				} else if (block == Blocks.TALLGRASS) {
					switch (i) {
						case 0:
							contents = FlowerPotBlock.Contents.DEAD_BUSH;
							break;
						case 2:
							contents = FlowerPotBlock.Contents.FERN;
							break;
						default:
							contents = FlowerPotBlock.Contents.EMPTY;
					}
				} else if (block == Blocks.YELLOW_FLOWER) {
					contents = FlowerPotBlock.Contents.DANDELION;
				} else if (block == Blocks.RED_FLOWER) {
					switch (FlowerBlock.Type.byId(FlowerBlock.Group.RED, i)) {
						case POPPY:
							contents = FlowerPotBlock.Contents.POPPY;
							break;
						case BLUE_ORCHID:
							contents = FlowerPotBlock.Contents.BLUE_ORCHID;
							break;
						case ALLIUM:
							contents = FlowerPotBlock.Contents.ALLIUM;
							break;
						case HOUSTONIA:
							contents = FlowerPotBlock.Contents.HOUSTONIA;
							break;
						case RED_TULIP:
							contents = FlowerPotBlock.Contents.RED_TULIP;
							break;
						case ORANGE_TULIP:
							contents = FlowerPotBlock.Contents.ORANGE_TULIP;
							break;
						case WHITE_TULIP:
							contents = FlowerPotBlock.Contents.WHITE_TULIP;
							break;
						case PINK_TULIP:
							contents = FlowerPotBlock.Contents.PINK_TULIP;
							break;
						case OXEY_DAISY:
							contents = FlowerPotBlock.Contents.OXEYE_DAISY;
							break;
						default:
							contents = FlowerPotBlock.Contents.EMPTY;
					}
				} else if (block == Blocks.RED_MUSHROOM) {
					contents = FlowerPotBlock.Contents.MUSHROOM_RED;
				} else if (block == Blocks.BROWN_MUSHROOM) {
					contents = FlowerPotBlock.Contents.MUSHROOM_BROWN;
				} else if (block == Blocks.DEADBUSH) {
					contents = FlowerPotBlock.Contents.DEAD_BUSH;
				} else if (block == Blocks.CACTUS) {
					contents = FlowerPotBlock.Contents.CACTUS;
				}
			}
		}

		return state.set(CONTENTS, contents);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public BlockLayer getRenderLayer() {
		return BlockLayer.CUTOUT;
	}

	public enum Contents implements StringSerializable {
		EMPTY("empty"),
		POPPY("rose"),
		BLUE_ORCHID("blue_orchid"),
		ALLIUM("allium"),
		HOUSTONIA("houstonia"),
		RED_TULIP("red_tulip"),
		ORANGE_TULIP("orange_tulip"),
		WHITE_TULIP("white_tulip"),
		PINK_TULIP("pink_tulip"),
		OXEYE_DAISY("oxeye_daisy"),
		DANDELION("dandelion"),
		OAK_SAPLING("oak_sapling"),
		SPRUCE_SAPLING("spruce_sapling"),
		BIRCH_SAPLING("birch_sapling"),
		JUNGLE_SAPLING("jungle_sapling"),
		ACACIA_SAPLING("acacia_sapling"),
		DARK_OAK_SAPLING("dark_oak_sapling"),
		MUSHROOM_RED("mushroom_red"),
		MUSHROOM_BROWN("mushroom_brown"),
		DEAD_BUSH("dead_bush"),
		FERN("fern"),
		CACTUS("cactus");

		private final String name;

		Contents(String name) {
			this.name = name;
		}

		@Override
		public String toString() {
			return this.name;
		}

		@Override
		public String getSerializedName() {
			return this.name;
		}
	}
}

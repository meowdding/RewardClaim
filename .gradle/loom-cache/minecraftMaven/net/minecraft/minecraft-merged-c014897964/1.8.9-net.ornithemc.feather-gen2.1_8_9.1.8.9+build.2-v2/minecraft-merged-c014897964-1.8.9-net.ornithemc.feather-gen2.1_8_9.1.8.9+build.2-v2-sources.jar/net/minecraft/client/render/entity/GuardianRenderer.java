package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Culler;
import net.minecraft.client.render.model.entity.GuardianModel;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.mob.monster.GuardianEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

@Environment(EnvType.CLIENT)
public class GuardianRenderer extends MobRenderer<GuardianEntity> {
	private static final Identifier GUARDIAN_LOCATION = new Identifier("textures/entity/guardian.png");
	private static final Identifier ELDER_GUARDIAN_TEXTURE = new Identifier("textures/entity/guardian_elder.png");
	private static final Identifier GUARDIAN_BEAM_LOCATION = new Identifier("textures/entity/guardian_beam.png");
	int version = ((GuardianModel)this.model).getVersion();

	public GuardianRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher, new GuardianModel(), 0.5F);
	}

	public boolean shouldRender(GuardianEntity entity, Culler view, double cameraX, double cameraY, double cameraZ) {
		if (super.shouldRender(entity, view, cameraX, cameraY, cameraZ)) {
			return true;
		}

		if (entity.hasBeamTarget()) {
			LivingEntity livingEntity = entity.getLaserTarget();
			if (livingEntity != null) {
				Vec3d vec3d = this.getLerpedPos(livingEntity, livingEntity.height * 0.5, 1.0F);
				Vec3d vec3d2 = this.getLerpedPos(entity, entity.getEyeHeight(), 1.0F);
				if (view.isVisible(Box.of(vec3d2.x, vec3d2.y, vec3d2.z, vec3d.x, vec3d.y, vec3d.z))) {
					return true;
				}
			}
		}

		return false;
	}

	private Vec3d getLerpedPos(LivingEntity entity, double heightOffset, float tickDelta) {
		double d = entity.prevX + (entity.x - entity.prevX) * tickDelta;
		double e = heightOffset + entity.prevY + (entity.y - entity.prevY) * tickDelta;
		double f = entity.prevZ + (entity.z - entity.prevZ) * tickDelta;
		return new Vec3d(d, e, f);
	}

	public void render(GuardianEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		if (this.version != ((GuardianModel)this.model).getVersion()) {
			this.model = new GuardianModel();
			this.version = ((GuardianModel)this.model).getVersion();
		}

		super.render(entity, dx, dy, dz, yaw, tickDelta);
		LivingEntity livingEntity = entity.getLaserTarget();
		if (livingEntity != null) {
			float f = entity.getBeamProgress(tickDelta);
			Tesselator tesselator = Tesselator.getInstance();
			BufferBuilder bufferBuilder = tesselator.getBuffer();
			this.bindTexture(GUARDIAN_BEAM_LOCATION);
			GL11.glTexParameterf(3553, 10242, 10497.0F);
			GL11.glTexParameterf(3553, 10243, 10497.0F);
			GlStateManager.disableLighting();
			GlStateManager.disableCull();
			GlStateManager.disableBlend();
			GlStateManager.depthMask(true);
			float g = 240.0F;
			GLX.multiTexCoord2f(GLX.GL_TEXTURE1, g, g);
			GlStateManager.blendFuncSeparate(770, 1, 1, 0);
			float h = (float)entity.world.getTime() + tickDelta;
			float i = h * 0.5F % 1.0F;
			float j = entity.getEyeHeight();
			GlStateManager.pushMatrix();
			GlStateManager.translatef((float)dx, (float)dy + j, (float)dz);
			Vec3d vec3d = this.getLerpedPos(livingEntity, livingEntity.height * 0.5, tickDelta);
			Vec3d vec3d2 = this.getLerpedPos(entity, j, tickDelta);
			Vec3d vec3d3 = vec3d.subtract(vec3d2);
			double d = vec3d3.length() + 1.0;
			vec3d3 = vec3d3.normalize();
			float k = (float)Math.acos(vec3d3.y);
			float l = (float)Math.atan2(vec3d3.z, vec3d3.x);
			GlStateManager.rotatef(((float) (Math.PI / 2) + -l) * (180.0F / (float)Math.PI), 0.0F, 1.0F, 0.0F);
			GlStateManager.rotatef(k * (180.0F / (float)Math.PI), 1.0F, 0.0F, 0.0F);
			int m = 1;
			double e = h * 0.05 * (1.0 - (m & 1) * 2.5);
			bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
			float n = f * f;
			int o = 64 + (int)(n * 240.0F);
			int p = 32 + (int)(n * 192.0F);
			int q = 128 - (int)(n * 64.0F);
			double r = m * 0.2;
			double s = r * 1.41;
			double t = 0.0 + Math.cos(e + (Math.PI * 3.0 / 4.0)) * s;
			double u = 0.0 + Math.sin(e + (Math.PI * 3.0 / 4.0)) * s;
			double v = 0.0 + Math.cos(e + (Math.PI / 4)) * s;
			double w = 0.0 + Math.sin(e + (Math.PI / 4)) * s;
			double x = 0.0 + Math.cos(e + (Math.PI * 5.0 / 4.0)) * s;
			double y = 0.0 + Math.sin(e + (Math.PI * 5.0 / 4.0)) * s;
			double z = 0.0 + Math.cos(e + (Math.PI * 7.0 / 4.0)) * s;
			double aa = 0.0 + Math.sin(e + (Math.PI * 7.0 / 4.0)) * s;
			double ab = 0.0 + Math.cos(e + Math.PI) * r;
			double ac = 0.0 + Math.sin(e + Math.PI) * r;
			double ad = 0.0 + Math.cos(e + 0.0) * r;
			double ae = 0.0 + Math.sin(e + 0.0) * r;
			double af = 0.0 + Math.cos(e + (Math.PI / 2)) * r;
			double ag = 0.0 + Math.sin(e + (Math.PI / 2)) * r;
			double ah = 0.0 + Math.cos(e + (Math.PI * 3.0 / 2.0)) * r;
			double ai = 0.0 + Math.sin(e + (Math.PI * 3.0 / 2.0)) * r;
			double aj = d;
			double ak = 0.0;
			double al = 0.4999;
			double am = -1.0F + i;
			double an = d * (0.5 / r) + am;
			bufferBuilder.vertex(ab, aj, ac).texture(0.4999, an).color(o, p, q, 255).nextVertex();
			bufferBuilder.vertex(ab, 0.0, ac).texture(0.4999, am).color(o, p, q, 255).nextVertex();
			bufferBuilder.vertex(ad, 0.0, ae).texture(0.0, am).color(o, p, q, 255).nextVertex();
			bufferBuilder.vertex(ad, aj, ae).texture(0.0, an).color(o, p, q, 255).nextVertex();
			bufferBuilder.vertex(af, aj, ag).texture(0.4999, an).color(o, p, q, 255).nextVertex();
			bufferBuilder.vertex(af, 0.0, ag).texture(0.4999, am).color(o, p, q, 255).nextVertex();
			bufferBuilder.vertex(ah, 0.0, ai).texture(0.0, am).color(o, p, q, 255).nextVertex();
			bufferBuilder.vertex(ah, aj, ai).texture(0.0, an).color(o, p, q, 255).nextVertex();
			double ao = 0.0;
			if (entity.ticks % 2 == 0) {
				ao = 0.5;
			}

			bufferBuilder.vertex(t, aj, u).texture(0.5, ao + 0.5).color(o, p, q, 255).nextVertex();
			bufferBuilder.vertex(v, aj, w).texture(1.0, ao + 0.5).color(o, p, q, 255).nextVertex();
			bufferBuilder.vertex(z, aj, aa).texture(1.0, ao).color(o, p, q, 255).nextVertex();
			bufferBuilder.vertex(x, aj, y).texture(0.5, ao).color(o, p, q, 255).nextVertex();
			tesselator.end();
			GlStateManager.popMatrix();
		}
	}

	protected void applyScale(GuardianEntity entity, float scale) {
		if (entity.isElder()) {
			GlStateManager.scalef(2.35F, 2.35F, 2.35F);
		}
	}

	protected Identifier getTextureLocation(GuardianEntity entity) {
		return entity.isElder() ? ELDER_GUARDIAN_TEXTURE : GUARDIAN_LOCATION;
	}
}

package net.minecraft.client.render;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.LiquidBlock;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.MemoryTracker;
import net.minecraft.entity.Entity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

@Environment(EnvType.CLIENT)
public class Camera {
	private static final IntBuffer VIEWPORT_BUFFER = MemoryTracker.createIntBuffer(16);
	private static final FloatBuffer MODELVIEW_MATRIX_BUFFER = MemoryTracker.createFloatBuffer(16);
	private static final FloatBuffer PROJECTION_MATRIX_BUFFER = MemoryTracker.createFloatBuffer(16);
	private static final FloatBuffer POSITION_BUFFER = MemoryTracker.createFloatBuffer(3);
	private static Vec3d offset = new Vec3d(0.0, 0.0, 0.0);
	private static float dx;
	private static float dy;
	private static float dz;
	private static float forwards;
	private static float sideways;

	public static void setup(PlayerEntity camera, boolean thirdPerson) {
		GlStateManager.getFloat(2982, MODELVIEW_MATRIX_BUFFER);
		GlStateManager.getFloat(2983, PROJECTION_MATRIX_BUFFER);
		GL11.glGetInteger(2978, VIEWPORT_BUFFER);
		float f = (VIEWPORT_BUFFER.get(0) + VIEWPORT_BUFFER.get(2)) / 2;
		float g = (VIEWPORT_BUFFER.get(1) + VIEWPORT_BUFFER.get(3)) / 2;
		GLU.gluUnProject(f, g, 0.0F, MODELVIEW_MATRIX_BUFFER, PROJECTION_MATRIX_BUFFER, VIEWPORT_BUFFER, POSITION_BUFFER);
		offset = new Vec3d(POSITION_BUFFER.get(0), POSITION_BUFFER.get(1), POSITION_BUFFER.get(2));
		int i = thirdPerson ? 1 : 0;
		float h = camera.pitch;
		float j = camera.yaw;
		dx = MathHelper.cos(j * (float) Math.PI / 180.0F) * (1 - i * 2);
		dz = MathHelper.sin(j * (float) Math.PI / 180.0F) * (1 - i * 2);
		forwards = -dz * MathHelper.sin(h * (float) Math.PI / 180.0F) * (1 - i * 2);
		sideways = dx * MathHelper.sin(h * (float) Math.PI / 180.0F) * (1 - i * 2);
		dy = MathHelper.cos(h * (float) Math.PI / 180.0F);
	}

	public static Vec3d getPos(Entity camera, double tickDelta) {
		double d = camera.lastX + (camera.x - camera.lastX) * tickDelta;
		double e = camera.lastY + (camera.y - camera.lastY) * tickDelta;
		double f = camera.lastZ + (camera.z - camera.lastZ) * tickDelta;
		double g = d + offset.x;
		double h = e + offset.y;
		double i = f + offset.z;
		return new Vec3d(g, h, i);
	}

	public static Block getBlockInside(World world, Entity camera, float tickDelta) {
		Vec3d vec3d = getPos(camera, tickDelta);
		BlockPos blockPos = new BlockPos(vec3d);
		BlockState blockState = world.getBlockState(blockPos);
		Block block = blockState.getBlock();
		if (block.getMaterial().isLiquid()) {
			float f = 0.0F;
			if (blockState.getBlock() instanceof LiquidBlock) {
				f = LiquidBlock.getHeightLoss(blockState.get(LiquidBlock.LEVEL)) - 0.11111111F;
			}

			float g = blockPos.getY() + 1 - f;
			if (vec3d.y >= g) {
				block = world.getBlockState(blockPos.up()).getBlock();
			}
		}

		return block;
	}

	public static Vec3d offset() {
		return offset;
	}

	public static float dx() {
		return dx;
	}

	public static float dy() {
		return dy;
	}

	public static float dz() {
		return dz;
	}

	public static float forwards() {
		return forwards;
	}

	public static float sideways() {
		return sideways;
	}
}

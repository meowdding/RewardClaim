package net.minecraft.client.gui.screen.game;

import com.google.common.collect.Lists;
import com.google.gson.JsonParseException;
import io.netty.buffer.Unpooled;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.TextRenderUtils;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.WrittenBookItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.c2s.play.CustomPayloadC2SPacket;
import net.minecraft.resource.Identifier;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Formatting;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.ornithemc.feather.constants.NbtTypes;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;

@Environment(EnvType.CLIENT)
public class BookEditScreen extends Screen {
	private static final Logger LOGGER = LogManager.getLogger();
	private static final Identifier BACKGROUND_LOCATION = new Identifier("textures/gui/book.png");
	private final PlayerEntity reader;
	private final ItemStack book;
	private final boolean unsigned;
	private boolean dirty;
	private boolean signing;
	private int tickCounter;
	private int widthOffset = 192;
	private int horizontalMargin = 192;
	private int verticalMargin = 1;
	private int currentPage;
	private NbtList pagesNbt;
	private String title = "";
	private List<Text> lines;
	private int loadedPage = -1;
	private BookEditScreen.BookButton nextPageButton;
	private BookEditScreen.BookButton previousPageButton;
	private ButtonWidget doneButton;
	private ButtonWidget signButton;
	private ButtonWidget finalizeButton;
	private ButtonWidget cancelButton;

	public BookEditScreen(PlayerEntity reader, ItemStack book, boolean unsigned) {
		this.reader = reader;
		this.book = book;
		this.unsigned = unsigned;
		if (book.hasNbt()) {
			NbtCompound nbtCompound = book.getNbt();
			this.pagesNbt = nbtCompound.getList("pages", NbtTypes.STRING);
			if (this.pagesNbt != null) {
				this.pagesNbt = (NbtList)this.pagesNbt.copy();
				this.verticalMargin = this.pagesNbt.size();
				if (this.verticalMargin < 1) {
					this.verticalMargin = 1;
				}
			}
		}

		if (this.pagesNbt == null && unsigned) {
			this.pagesNbt = new NbtList();
			this.pagesNbt.addElement(new NbtString(""));
			this.verticalMargin = 1;
		}
	}

	@Override
	public void tick() {
		super.tick();
		this.tickCounter++;
	}

	@Override
	public void init() {
		this.buttons.clear();
		Keyboard.enableRepeatEvents(true);
		if (this.unsigned) {
			this.buttons.add(this.signButton = new ButtonWidget(3, this.width / 2 - 100, 4 + this.horizontalMargin, 98, 20, I18n.translate("book.signButton")));
			this.buttons.add(this.doneButton = new ButtonWidget(0, this.width / 2 + 2, 4 + this.horizontalMargin, 98, 20, I18n.translate("gui.done")));
			this.buttons.add(this.finalizeButton = new ButtonWidget(5, this.width / 2 - 100, 4 + this.horizontalMargin, 98, 20, I18n.translate("book.finalizeButton")));
			this.buttons.add(this.cancelButton = new ButtonWidget(4, this.width / 2 + 2, 4 + this.horizontalMargin, 98, 20, I18n.translate("gui.cancel")));
		} else {
			this.buttons.add(this.doneButton = new ButtonWidget(0, this.width / 2 - 100, 4 + this.horizontalMargin, 200, 20, I18n.translate("gui.done")));
		}

		int i = (this.width - this.widthOffset) / 2;
		int j = 2;
		this.buttons.add(this.nextPageButton = new BookEditScreen.BookButton(1, i + 120, j + 154, true));
		this.buttons.add(this.previousPageButton = new BookEditScreen.BookButton(2, i + 38, j + 154, false));
		this.updateButtons();
	}

	@Override
	public void removed() {
		Keyboard.enableRepeatEvents(false);
	}

	private void updateButtons() {
		this.nextPageButton.visible = !this.signing && (this.currentPage < this.verticalMargin - 1 || this.unsigned);
		this.previousPageButton.visible = !this.signing && this.currentPage > 0;
		this.doneButton.visible = !this.unsigned || !this.signing;
		if (this.unsigned) {
			this.signButton.visible = !this.signing;
			this.cancelButton.visible = this.signing;
			this.finalizeButton.visible = this.signing;
			this.finalizeButton.active = this.title.trim().length() > 0;
		}
	}

	private void finalizeBook(boolean signBook) {
		if (this.unsigned && this.dirty) {
			if (this.pagesNbt != null) {
				while (this.pagesNbt.size() > 1) {
					String string = this.pagesNbt.getString(this.pagesNbt.size() - 1);
					if (string.length() != 0) {
						break;
					}

					this.pagesNbt.removeElement(this.pagesNbt.size() - 1);
				}

				if (this.book.hasNbt()) {
					NbtCompound nbtCompound = this.book.getNbt();
					nbtCompound.put("pages", this.pagesNbt);
				} else {
					this.book.addToNbt("pages", this.pagesNbt);
				}

				String string = "MC|BEdit";
				if (signBook) {
					string = "MC|BSign";
					this.book.addToNbt("author", new NbtString(this.reader.getName()));
					this.book.addToNbt("title", new NbtString(this.title.trim()));

					for (int i = 0; i < this.pagesNbt.size(); i++) {
						String string2 = this.pagesNbt.getString(i);
						Text text = new LiteralText(string2);
						string2 = Text.Serializer.toJson(text);
						this.pagesNbt.setElement(i, new NbtString(string2));
					}

					this.book.setItem(Items.WRITTEN_BOOK);
				}

				PacketByteBuf packetByteBuf = new PacketByteBuf(Unpooled.buffer());
				packetByteBuf.writeItem(this.book);
				this.minecraft.getNetworkHandler().sendPacket(new CustomPayloadC2SPacket(string, packetByteBuf));
			}
		}
	}

	@Override
	protected void buttonClicked(ButtonWidget button) {
		if (button.active) {
			if (button.id == 0) {
				this.minecraft.openScreen(null);
				this.finalizeBook(false);
			} else if (button.id == 3 && this.unsigned) {
				this.signing = true;
			} else if (button.id == 1) {
				if (this.currentPage < this.verticalMargin - 1) {
					this.currentPage++;
				} else if (this.unsigned) {
					this.appendNewPage();
					if (this.currentPage < this.verticalMargin - 1) {
						this.currentPage++;
					}
				}
			} else if (button.id == 2) {
				if (this.currentPage > 0) {
					this.currentPage--;
				}
			} else if (button.id == 5 && this.signing) {
				this.finalizeBook(true);
				this.minecraft.openScreen(null);
			} else if (button.id == 4 && this.signing) {
				this.signing = false;
			}

			this.updateButtons();
		}
	}

	private void appendNewPage() {
		if (this.pagesNbt != null && this.pagesNbt.size() < 50) {
			this.pagesNbt.addElement(new NbtString(""));
			this.verticalMargin++;
			this.dirty = true;
		}
	}

	@Override
	protected void keyPressed(char chr, int key) {
		super.keyPressed(chr, key);
		if (this.unsigned) {
			if (this.signing) {
				this.keyPressedOnTitlePage(chr, key);
			} else {
				this.keyPressedInBook(chr, key);
			}
		}
	}

	private void keyPressedInBook(char chr, int key) {
		if (Screen.isPaste(key)) {
			this.write(Screen.getClipboard());
		} else {
			switch (key) {
				case 14:
					String string = this.getCurrentPageContent();
					if (string.length() > 0) {
						this.setPageContent(string.substring(0, string.length() - 1));
					}

					return;
				case 28:
				case 156:
					this.write("\n");
					return;
				default:
					if (SharedConstants.isValidChatChar(chr)) {
						this.write(Character.toString(chr));
					}
			}
		}
	}

	private void keyPressedOnTitlePage(char chr, int key) {
		switch (key) {
			case 14:
				if (!this.title.isEmpty()) {
					this.title = this.title.substring(0, this.title.length() - 1);
					this.updateButtons();
				}

				return;
			case 28:
			case 156:
				if (!this.title.isEmpty()) {
					this.finalizeBook(true);
					this.minecraft.openScreen(null);
				}

				return;
			default:
				if (this.title.length() < 16 && SharedConstants.isValidChatChar(chr)) {
					this.title = this.title + Character.toString(chr);
					this.updateButtons();
					this.dirty = true;
				}
		}
	}

	private String getCurrentPageContent() {
		return this.pagesNbt != null && this.currentPage >= 0 && this.currentPage < this.pagesNbt.size() ? this.pagesNbt.getString(this.currentPage) : "";
	}

	private void setPageContent(String pageContent) {
		if (this.pagesNbt != null && this.currentPage >= 0 && this.currentPage < this.pagesNbt.size()) {
			this.pagesNbt.setElement(this.currentPage, new NbtString(pageContent));
			this.dirty = true;
		}
	}

	private void write(String text) {
		String string = this.getCurrentPageContent();
		String string2 = string + text;
		int i = this.textRenderer.splitAndGetHeight(string2 + "" + Formatting.BLACK + "_", 118);
		if (i <= 128 && string2.length() < 256) {
			this.setPageContent(string2);
		}
	}

	@Override
	public void render(int mouseX, int mouseY, float tickDelta) {
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.minecraft.getTextureManager().bind(BACKGROUND_LOCATION);
		int i = (this.width - this.widthOffset) / 2;
		int j = 2;
		this.drawTexture(i, j, 0, 0, this.widthOffset, this.horizontalMargin);
		if (this.signing) {
			String string = this.title;
			if (this.unsigned) {
				if (this.tickCounter / 6 % 2 == 0) {
					string = string + "" + Formatting.BLACK + "_";
				} else {
					string = string + "" + Formatting.GRAY + "_";
				}
			}

			String string2 = I18n.translate("book.editTitle");
			int k = this.textRenderer.getWidth(string2);
			this.textRenderer.draw(string2, i + 36 + (116 - k) / 2, j + 16 + 16, 0);
			int l = this.textRenderer.getWidth(string);
			this.textRenderer.draw(string, i + 36 + (116 - l) / 2, j + 48, 0);
			String string3 = I18n.translate("book.byAuthor", this.reader.getName());
			int m = this.textRenderer.getWidth(string3);
			this.textRenderer.draw(Formatting.DARK_GRAY + string3, i + 36 + (116 - m) / 2, j + 48 + 10, 0);
			String string4 = I18n.translate("book.finalizeWarning");
			this.textRenderer.splitAndDraw(string4, i + 36, j + 80, 116, 0);
		} else {
			String string = I18n.translate("book.pageIndicator", this.currentPage + 1, this.verticalMargin);
			String string2 = "";
			if (this.pagesNbt != null && this.currentPage >= 0 && this.currentPage < this.pagesNbt.size()) {
				string2 = this.pagesNbt.getString(this.currentPage);
			}

			if (this.unsigned) {
				if (this.textRenderer.isBidirectional()) {
					string2 = string2 + "_";
				} else if (this.tickCounter / 6 % 2 == 0) {
					string2 = string2 + "" + Formatting.BLACK + "_";
				} else {
					string2 = string2 + "" + Formatting.GRAY + "_";
				}
			} else if (this.loadedPage != this.currentPage) {
				if (WrittenBookItem.isValid(this.book.getNbt())) {
					try {
						Text text = Text.Serializer.fromJson(string2);
						this.lines = text != null ? TextRenderUtils.wrapText(text, 116, this.textRenderer, true, true) : null;
					} catch (JsonParseException jsonParseException) {
						this.lines = null;
					}
				} else {
					LiteralText literalText = new LiteralText(Formatting.DARK_RED.toString() + "* Invalid book tag *");
					this.lines = Lists.newArrayList(literalText);
				}

				this.loadedPage = this.currentPage;
			}

			int k = this.textRenderer.getWidth(string);
			this.textRenderer.draw(string, i - k + this.widthOffset - 44, j + 16, 0);
			if (this.lines == null) {
				this.textRenderer.splitAndDraw(string2, i + 36, j + 16 + 16, 116, 0);
			} else {
				int l = Math.min(128 / this.textRenderer.fontHeight, this.lines.size());

				for (int n = 0; n < l; n++) {
					Text text2 = this.lines.get(n);
					this.textRenderer.draw(text2.getString(), i + 36, j + 16 + 16 + n * this.textRenderer.fontHeight, 0);
				}

				Text text3 = this.getHoveredText(mouseX, mouseY);
				if (text3 != null) {
					this.renderTextHoverEffect(text3, mouseX, mouseY);
				}
			}
		}

		super.render(mouseX, mouseY, tickDelta);
	}

	@Override
	protected void mouseClicked(int mouseX, int mouseY, int button) {
		if (button == 0) {
			Text text = this.getHoveredText(mouseX, mouseY);
			if (this.handleClickEvent(text)) {
				return;
			}
		}

		super.mouseClicked(mouseX, mouseY, button);
	}

	@Override
	protected boolean handleClickEvent(Text text) {
		ClickEvent clickEvent = text == null ? null : text.getStyle().getClickEvent();
		if (clickEvent == null) {
			return false;
		}

		if (clickEvent.getAction() == ClickEvent.Action.CHANGE_PAGE) {
			String string = clickEvent.getValue();

			try {
				int i = Integer.parseInt(string) - 1;
				if (i >= 0 && i < this.verticalMargin && i != this.currentPage) {
					this.currentPage = i;
					this.updateButtons();
					return true;
				}
			} catch (Throwable var5) {
			}

			return false;
		} else {
			boolean bl = super.handleClickEvent(text);
			if (bl && clickEvent.getAction() == ClickEvent.Action.RUN_COMMAND) {
				this.minecraft.openScreen(null);
			}

			return bl;
		}
	}

	public Text getHoveredText(int mouseX, int mouseY) {
		if (this.lines == null) {
			return null;
		}

		int i = mouseX - (this.width - this.widthOffset) / 2 - 36;
		int j = mouseY - 2 - 16 - 16;
		if (i >= 0 && j >= 0) {
			int k = Math.min(128 / this.textRenderer.fontHeight, this.lines.size());
			if (i <= 116 && j < this.minecraft.textRenderer.fontHeight * k + k) {
				int l = j / this.minecraft.textRenderer.fontHeight;
				if (l >= 0 && l < this.lines.size()) {
					Text text = this.lines.get(l);
					int m = 0;

					for (Text text2 : text) {
						if (text2 instanceof LiteralText) {
							m += this.minecraft.textRenderer.getWidth(((LiteralText)text2).getRawString());
							if (m > i) {
								return text2;
							}
						}
					}
				}

				return null;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	@Environment(EnvType.CLIENT)
	static class BookButton extends ButtonWidget {
		private final boolean clickable;

		public BookButton(int id, int x, int y, boolean clickable) {
			super(id, x, y, 23, 13, "");
			this.clickable = clickable;
		}

		@Override
		public void render(Minecraft minecraft, int mouseX, int mouseY) {
			if (this.visible) {
				boolean bl = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;
				GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
				minecraft.getTextureManager().bind(BookEditScreen.BACKGROUND_LOCATION);
				int i = 0;
				int j = 192;
				if (bl) {
					i += 23;
				}

				if (!this.clickable) {
					j += 13;
				}

				this.drawTexture(this.x, this.y, i, j, 23, 13);
			}
		}
	}
}

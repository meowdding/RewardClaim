package net.minecraft.block.dispenser;

import net.minecraft.block.DispenserBlock;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.IPosition;
import net.minecraft.world.IBlockSource;
import net.minecraft.world.World;

public class DispenseItemBehavior implements DispenseBehavior {
	@Override
	public final ItemStack dispense(IBlockSource source, ItemStack item) {
		ItemStack itemStack = this.dispenseItem(source, item);
		this.playSound(source);
		this.doWorldEvent(source, DispenserBlock.getDirection(source.getBlockMetadata()));
		return itemStack;
	}

	protected ItemStack dispenseItem(IBlockSource source, ItemStack item) {
		Direction direction = DispenserBlock.getDirection(source.getBlockMetadata());
		IPosition iPosition = DispenserBlock.getDispensePos(source);
		ItemStack itemStack = item.split(1);
		spawnItem(source.getWorld(), itemStack, 6, direction, iPosition);
		return item;
	}

	public static void spawnItem(World world, ItemStack item, int offset, Direction facing, IPosition pos) {
		double d = pos.getX();
		double e = pos.getY();
		double f = pos.getZ();
		if (facing.getAxis() == Direction.Axis.Y) {
			e -= 0.125;
		} else {
			e -= 0.15625;
		}

		ItemEntity itemEntity = new ItemEntity(world, d, e, f, item);
		double g = world.random.nextDouble() * 0.1 + 0.2;
		itemEntity.velocityX = facing.getOffsetX() * g;
		itemEntity.velocityY = 0.2F;
		itemEntity.velocityZ = facing.getOffsetZ() * g;
		itemEntity.velocityX = itemEntity.velocityX + world.random.nextGaussian() * 0.0075F * offset;
		itemEntity.velocityY = itemEntity.velocityY + world.random.nextGaussian() * 0.0075F * offset;
		itemEntity.velocityZ = itemEntity.velocityZ + world.random.nextGaussian() * 0.0075F * offset;
		world.addEntity(itemEntity);
	}

	protected void playSound(IBlockSource source) {
		source.getWorld().doEvent(1000, source.getPos(), 0);
	}

	protected void doWorldEvent(IBlockSource source, Direction facing) {
		source.getWorld().doEvent(2000, source.getPos(), this.toInt(facing));
	}

	private int toInt(Direction dir) {
		return dir.getOffsetX() + 1 + (dir.getOffsetZ() + 1) * 3;
	}
}

package net.minecraft.block;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.dispenser.DispenseBehavior;
import net.minecraft.block.dispenser.DispenseItemBehavior;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.DropperBlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.block.state.property.DirectionProperty;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.inventory.InventoryUtils;
import net.minecraft.inventory.menu.InventoryMenu;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stat.Stats;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.IPosition;
import net.minecraft.util.math.Position;
import net.minecraft.util.registry.DefaultedRegistry;
import net.minecraft.world.BlockSource;
import net.minecraft.world.IBlockSource;
import net.minecraft.world.World;
import net.ornithemc.feather.constants.SetBlockFlags;

public class DispenserBlock extends BlockWithBlockEntity {
	public static final DirectionProperty FACING = DirectionProperty.of("facing");
	public static final BooleanProperty TRIGGERED = BooleanProperty.of("triggered");
	public static final DefaultedRegistry<Item, DispenseBehavior> BEHAVIORS = new DefaultedRegistry<>(new DispenseItemBehavior());
	protected Random random = new Random();

	protected DispenserBlock() {
		super(Material.STONE);
		this.setDefaultState(this.stateDefinition.any().set(FACING, Direction.NORTH).set(TRIGGERED, false));
		this.setCreativeModeTab(CreativeModeTab.REDSTONE);
	}

	@Override
	public int getTickRate(World world) {
		return 4;
	}

	@Override
	public void onAdded(World world, BlockPos pos, BlockState state) {
		super.onAdded(world, pos, state);
		this.updateFacing(world, pos, state);
	}

	private void updateFacing(World world, BlockPos pos, BlockState state) {
		if (!world.isClient) {
			Direction direction = state.get(FACING);
			boolean bl = world.getBlockState(pos.north()).getBlock().isOpaque();
			boolean bl2 = world.getBlockState(pos.south()).getBlock().isOpaque();
			if (direction == Direction.NORTH && bl && !bl2) {
				direction = Direction.SOUTH;
			} else if (direction == Direction.SOUTH && bl2 && !bl) {
				direction = Direction.NORTH;
			} else {
				boolean bl3 = world.getBlockState(pos.west()).getBlock().isOpaque();
				boolean bl4 = world.getBlockState(pos.east()).getBlock().isOpaque();
				if (direction == Direction.WEST && bl3 && !bl4) {
					direction = Direction.EAST;
				} else if (direction == Direction.EAST && bl4 && !bl3) {
					direction = Direction.WEST;
				}
			}

			world.setBlockState(pos, state.set(FACING, direction).set(TRIGGERED, false), SetBlockFlags.NOTIFY_LISTENERS);
		}
	}

	@Override
	public boolean use(World world, BlockPos pos, BlockState state, PlayerEntity player, Direction face, float faceX, float faceY, float faceZ) {
		if (world.isClient) {
			return true;
		}

		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof DispenserBlockEntity) {
			player.openChestMenu((DispenserBlockEntity)blockEntity);
			if (blockEntity instanceof DropperBlockEntity) {
				player.incrementStat(Stats.DROPPERS_INSPECTED);
			} else {
				player.incrementStat(Stats.DISPENSERS_INSPECTED);
			}
		}

		return true;
	}

	protected void dispense(World world, BlockPos pos) {
		BlockSource blockSource = new BlockSource(world, pos);
		DispenserBlockEntity dispenserBlockEntity = blockSource.getBlockEntity();
		if (dispenserBlockEntity != null) {
			int i = dispenserBlockEntity.pickNonEmptySlot();
			if (i < 0) {
				world.doEvent(1001, pos, 0);
			} else {
				ItemStack itemStack = dispenserBlockEntity.getItem(i);
				DispenseBehavior dispenseBehavior = this.getDispenseBehavior(itemStack);
				if (dispenseBehavior != DispenseBehavior.NONE) {
					ItemStack itemStack2 = dispenseBehavior.dispense(blockSource, itemStack);
					dispenserBlockEntity.setItem(i, itemStack2.size <= 0 ? null : itemStack2);
				}
			}
		}
	}

	protected DispenseBehavior getDispenseBehavior(ItemStack item) {
		return BEHAVIORS.get(item == null ? null : item.getItem());
	}

	@Override
	public void neighborChanged(World world, BlockPos pos, BlockState state, Block neighborBlock) {
		boolean bl = world.hasNeighborSignal(pos) || world.hasNeighborSignal(pos.up());
		boolean bl2 = state.get(TRIGGERED);
		if (bl && !bl2) {
			world.scheduleTick(pos, this, this.getTickRate(world));
			world.setBlockState(pos, state.set(TRIGGERED, true), SetBlockFlags.NO_REDRAW);
		} else if (!bl && bl2) {
			world.setBlockState(pos, state.set(TRIGGERED, false), SetBlockFlags.NO_REDRAW);
		}
	}

	@Override
	public void tick(World world, BlockPos pos, BlockState state, Random random) {
		if (!world.isClient) {
			this.dispense(world, pos);
		}
	}

	@Override
	public BlockEntity createBlockEntity(World world, int metadata) {
		return new DispenserBlockEntity();
	}

	@Override
	public BlockState getPlacementState(World world, BlockPos pos, Direction dir, float dx, float dy, float dz, int metadata, LivingEntity entity) {
		return this.defaultState().set(FACING, PistonBaseBlock.getFacingForPlacement(world, pos, entity)).set(TRIGGERED, false);
	}

	@Override
	public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity entity, ItemStack item) {
		world.setBlockState(pos, state.set(FACING, PistonBaseBlock.getFacingForPlacement(world, pos, entity)), SetBlockFlags.NOTIFY_LISTENERS);
		if (item.hasCustomHoverName()) {
			BlockEntity blockEntity = world.getBlockEntity(pos);
			if (blockEntity instanceof DispenserBlockEntity) {
				((DispenserBlockEntity)blockEntity).setCustomName(item.getHoverName());
			}
		}
	}

	@Override
	public void onRemoved(World world, BlockPos pos, BlockState state) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof DispenserBlockEntity) {
			InventoryUtils.dropItems(world, pos, (DispenserBlockEntity)blockEntity);
			world.updateNeighborComparators(pos, this);
		}

		super.onRemoved(world, pos, state);
	}

	public static IPosition getDispensePos(IBlockSource block) {
		Direction direction = getDirection(block.getBlockMetadata());
		double d = block.getX() + 0.7 * direction.getOffsetX();
		double e = block.getY() + 0.7 * direction.getOffsetY();
		double f = block.getZ() + 0.7 * direction.getOffsetZ();
		return new Position(d, e, f);
	}

	public static Direction getDirection(int id) {
		return Direction.byId(id & 7);
	}

	@Override
	public boolean isAnalogSignalSource() {
		return true;
	}

	@Override
	public int getAnalogSignal(World world, BlockPos pos) {
		return InventoryMenu.getAnalogSignal(world.getBlockEntity(pos));
	}

	@Override
	public int getRenderType() {
		return 3;
	}

	@Environment(EnvType.CLIENT)
	@Override
	public BlockState getStateForItemModel(BlockState state) {
		return this.defaultState().set(FACING, Direction.SOUTH);
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		return this.defaultState().set(FACING, getDirection(metadata)).set(TRIGGERED, (metadata & 8) > 0);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		int i = 0;
		i |= state.get(FACING).getId();
		if (state.get(TRIGGERED)) {
			i |= 8;
		}

		return i;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, FACING, TRIGGERED);
	}
}

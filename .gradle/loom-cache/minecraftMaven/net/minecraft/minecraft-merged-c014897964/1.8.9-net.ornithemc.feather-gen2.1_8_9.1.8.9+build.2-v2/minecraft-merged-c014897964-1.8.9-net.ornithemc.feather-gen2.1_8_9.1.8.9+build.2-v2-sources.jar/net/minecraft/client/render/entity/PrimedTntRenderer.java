package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Blocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.block.BlockRenderDispatcher;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.entity.PrimedTntEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class PrimedTntRenderer extends EntityRenderer<PrimedTntEntity> {
	public PrimedTntRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
		this.shadowSize = 0.5F;
	}

	public void render(PrimedTntEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		BlockRenderDispatcher blockRenderDispatcher = Minecraft.getInstance().getBlockRenderDispatcher();
		GlStateManager.pushMatrix();
		GlStateManager.translatef((float)dx, (float)dy + 0.5F, (float)dz);
		if (entity.fuseTimer - tickDelta + 1.0F < 10.0F) {
			float f = 1.0F - (entity.fuseTimer - tickDelta + 1.0F) / 10.0F;
			f = MathHelper.clamp(f, 0.0F, 1.0F);
			f *= f;
			f *= f;
			float g = 1.0F + f * 0.3F;
			GlStateManager.scalef(g, g, g);
		}

		float f = (1.0F - (entity.fuseTimer - tickDelta + 1.0F) / 100.0F) * 0.8F;
		this.bindTexture(entity);
		GlStateManager.translatef(-0.5F, -0.5F, 0.5F);
		blockRenderDispatcher.renderAsItem(Blocks.TNT.defaultState(), entity.getBrightness(tickDelta));
		GlStateManager.translatef(0.0F, 0.0F, 1.0F);
		if (entity.fuseTimer / 5 % 2 == 0) {
			GlStateManager.disableTexture();
			GlStateManager.disableLighting();
			GlStateManager.enableBlend();
			GlStateManager.blendFunc(770, 772);
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, f);
			GlStateManager.polygonOffset(-3.0F, -3.0F);
			GlStateManager.enablePolygonOffset();
			blockRenderDispatcher.renderAsItem(Blocks.TNT.defaultState(), 1.0F);
			GlStateManager.polygonOffset(0.0F, 0.0F);
			GlStateManager.disablePolygonOffset();
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			GlStateManager.disableBlend();
			GlStateManager.enableLighting();
			GlStateManager.enableTexture();
		}

		GlStateManager.popMatrix();
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(PrimedTntEntity entity) {
		return TextureAtlas.BLOCKS_LOCATION;
	}
}

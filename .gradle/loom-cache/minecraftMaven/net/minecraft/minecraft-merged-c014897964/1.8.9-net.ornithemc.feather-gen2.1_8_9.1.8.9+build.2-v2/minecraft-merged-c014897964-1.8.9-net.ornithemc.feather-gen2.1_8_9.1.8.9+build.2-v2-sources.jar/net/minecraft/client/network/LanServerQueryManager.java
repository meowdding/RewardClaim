package net.minecraft.client.network;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketTimeoutException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.server.integrated.LanServerPinger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Environment(EnvType.CLIENT)
public class LanServerQueryManager {
	private static final AtomicInteger threadId = new AtomicInteger(0);
	private static final Logger LOGGER = LogManager.getLogger();

	@Environment(EnvType.CLIENT)
	public static class LanServer {
		private String motd;
		private String port;
		private long lastTickTime;

		public LanServer(String motd, String port) {
			this.motd = motd;
			this.port = port;
			this.lastTickTime = Minecraft.getTime();
		}

		public String getMotd() {
			return this.motd;
		}

		public String getPort() {
			return this.port;
		}

		public void tick() {
			this.lastTickTime = Minecraft.getTime();
		}
	}

	@Environment(EnvType.CLIENT)
	public static class LanServerDetector extends Thread {
		private final LanServerQueryManager.LanServerList serverList;
		private final InetAddress address;
		private final MulticastSocket socket;

		public LanServerDetector(LanServerQueryManager.LanServerList serverList) throws IOException {
			super("LanServerDetector #" + LanServerQueryManager.threadId.incrementAndGet());
			this.serverList = serverList;
			this.setDaemon(true);
			this.socket = new MulticastSocket(4445);
			this.address = InetAddress.getByName("224.0.2.60");
			this.socket.setSoTimeout(5000);
			this.socket.joinGroup(this.address);
		}

		@Override
		public void run() {
			byte[] bs = new byte[1024];

			while (!this.isInterrupted()) {
				DatagramPacket datagramPacket = new DatagramPacket(bs, bs.length);

				try {
					this.socket.receive(datagramPacket);
				} catch (SocketTimeoutException socketTimeoutException) {
					continue;
				} catch (IOException iOException) {
					LanServerQueryManager.LOGGER.error("Couldn't ping server", iOException);
					break;
				}

				String string = new String(datagramPacket.getData(), datagramPacket.getOffset(), datagramPacket.getLength());
				LanServerQueryManager.LOGGER.debug(datagramPacket.getAddress() + ": " + string);
				this.serverList.addServer(string, datagramPacket.getAddress());
			}

			try {
				this.socket.leaveGroup(this.address);
			} catch (IOException var4) {
			}

			this.socket.close();
		}
	}

	@Environment(EnvType.CLIENT)
	public static class LanServerList {
		private List<LanServerQueryManager.LanServer> servers = Lists.newArrayList();
		boolean dirty;

		public synchronized boolean needsUpdate() {
			return this.dirty;
		}

		public synchronized void markClean() {
			this.dirty = false;
		}

		public synchronized List<LanServerQueryManager.LanServer> getServers() {
			return Collections.unmodifiableList(this.servers);
		}

		public synchronized void addServer(String metadata, InetAddress address) {
			String string = LanServerPinger.parseMotd(metadata);
			String string2 = LanServerPinger.parsePort(metadata);
			if (string2 != null) {
				string2 = address.getHostAddress() + ":" + string2;
				boolean bl = false;

				for (LanServerQueryManager.LanServer lanServer : this.servers) {
					if (lanServer.getPort().equals(string2)) {
						lanServer.tick();
						bl = true;
						break;
					}
				}

				if (!bl) {
					this.servers.add(new LanServerQueryManager.LanServer(string, string2));
					this.dirty = true;
				}
			}
		}
	}
}

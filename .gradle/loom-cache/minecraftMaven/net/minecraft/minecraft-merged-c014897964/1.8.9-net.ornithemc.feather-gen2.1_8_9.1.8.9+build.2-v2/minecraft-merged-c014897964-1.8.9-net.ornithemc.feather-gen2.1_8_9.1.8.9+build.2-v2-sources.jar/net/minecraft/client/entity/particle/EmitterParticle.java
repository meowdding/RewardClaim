package net.minecraft.client.entity.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.entity.particle.ParticleType;
import net.minecraft.world.World;

@Environment(EnvType.CLIENT)
public class EmitterParticle extends Particle {
	private Entity target;
	private int age;
	private int lifetime;
	private ParticleType type;

	public EmitterParticle(World world, Entity target, ParticleType type) {
		super(world, target.x, target.getShape().minY + target.height / 2.0F, target.z, target.velocityX, target.velocityY, target.velocityZ);
		this.target = target;
		this.lifetime = 3;
		this.type = type;
		this.tick();
	}

	@Override
	public void render(BufferBuilder bufferBuilder, Entity camera, float tickDelta, float dx, float dy, float dz, float forwards, float sideways) {
	}

	@Override
	public void tick() {
		for (int i = 0; i < 16; i++) {
			double d = this.random.nextFloat() * 2.0F - 1.0F;
			double e = this.random.nextFloat() * 2.0F - 1.0F;
			double f = this.random.nextFloat() * 2.0F - 1.0F;
			if (!(d * d + e * e + f * f > 1.0)) {
				double g = this.target.x + d * this.target.width / 4.0;
				double h = this.target.getShape().minY + this.target.height / 2.0F + e * this.target.height / 4.0;
				double j = this.target.z + f * this.target.width / 4.0;
				this.world.addParticle(this.type, false, g, h, j, d, e + 0.2, f);
			}
		}

		this.age++;
		if (this.age >= this.lifetime) {
			this.remove();
		}
	}

	@Override
	public int getAtlasType() {
		return 3;
	}
}

package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.model.Model;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.passive.animal.tameable.OcelotEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class OcelotRenderer extends MobRenderer<OcelotEntity> {
	private static final Identifier BLACK_CAT_LOCATION = new Identifier("textures/entity/cat/black.png");
	private static final Identifier OCELOT_LOCATION = new Identifier("textures/entity/cat/ocelot.png");
	private static final Identifier RED_CAT_LOCATION = new Identifier("textures/entity/cat/red.png");
	private static final Identifier SIAMESE_CAT_LOCATION = new Identifier("textures/entity/cat/siamese.png");

	public OcelotRenderer(EntityRenderDispatcher entityRenderDispatcher, Model model, float f) {
		super(entityRenderDispatcher, model, f);
	}

	protected Identifier getTextureLocation(OcelotEntity entity) {
		switch (entity.getVariant()) {
			case 0:
			default:
				return OCELOT_LOCATION;
			case 1:
				return BLACK_CAT_LOCATION;
			case 2:
				return RED_CAT_LOCATION;
			case 3:
				return SIAMESE_CAT_LOCATION;
		}
	}

	protected void applyScale(OcelotEntity entity, float scale) {
		super.applyScale(entity, scale);
		if (entity.isTamed()) {
			GlStateManager.scalef(0.8F, 0.8F, 0.8F);
		}
	}
}

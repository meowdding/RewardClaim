package net.minecraft.client.gui.screen.menu.resourcepacks;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resource.language.I18n;

@Environment(EnvType.CLIENT)
public class SelectedResourcePackListWidget extends ResourcePackListWidget {
	public SelectedResourcePackListWidget(Minecraft minecraft, int i, int j, List<ResourcePackEntry> list) {
		super(minecraft, i, j, list);
	}

	@Override
	protected String getTitle() {
		return I18n.translate("resourcePack.selected.title");
	}
}

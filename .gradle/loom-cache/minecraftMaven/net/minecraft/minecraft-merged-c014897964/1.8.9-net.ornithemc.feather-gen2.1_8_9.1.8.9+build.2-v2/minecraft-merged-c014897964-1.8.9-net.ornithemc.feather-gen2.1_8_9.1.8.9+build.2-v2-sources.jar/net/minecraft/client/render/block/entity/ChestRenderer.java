package net.minecraft.client.render.block.entity;

import java.util.Calendar;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.client.render.model.block.entity.ChestModel;
import net.minecraft.client.render.model.block.entity.LargeChestModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class ChestRenderer extends BlockEntityRenderer<ChestBlockEntity> {
	private static final Identifier TRAPPED_DOUBLE_CHEST_LOCATION = new Identifier("textures/entity/chest/trapped_double.png");
	private static final Identifier CHRISTMAS_DOUBLE_CHEST_LOCATION = new Identifier("textures/entity/chest/christmas_double.png");
	private static final Identifier DOUBLE_CHEST_LOCATION = new Identifier("textures/entity/chest/normal_double.png");
	private static final Identifier TRAPPED_CHEST_LOCATION = new Identifier("textures/entity/chest/trapped.png");
	private static final Identifier CHRISTMAS_CHEST_LOCATION = new Identifier("textures/entity/chest/christmas.png");
	private static final Identifier CHEST_LOCATION = new Identifier("textures/entity/chest/normal.png");
	private ChestModel singleChestModel = new ChestModel();
	private ChestModel doubleChestModel = new LargeChestModel();
	private boolean isChristmas;

	public ChestRenderer() {
		Calendar calendar = Calendar.getInstance();
		if (calendar.get(2) + 1 == 12 && calendar.get(5) >= 24 && calendar.get(5) <= 26) {
			this.isChristmas = true;
		}
	}

	public void render(ChestBlockEntity blockEntity, double dx, double dy, double dz, float tickDelta, int blockMiningProgress) {
		GlStateManager.enableDepthTest();
		GlStateManager.depthFunc(515);
		GlStateManager.depthMask(true);
		int i;
		if (!blockEntity.hasWorld()) {
			i = 0;
		} else {
			Block block = blockEntity.getBlock();
			i = blockEntity.getBlockMetadata();
			if (block instanceof ChestBlock && i == 0) {
				((ChestBlock)block).updateState(blockEntity.getWorld(), blockEntity.getPos(), blockEntity.getWorld().getBlockState(blockEntity.getPos()));
				i = blockEntity.getBlockMetadata();
			}

			blockEntity.updateShape();
		}

		if (blockEntity.northNeighbor == null && blockEntity.westNeighbor == null) {
			ChestModel chestModel;
			if (blockEntity.eastNeighbor == null && blockEntity.southNeighbor == null) {
				chestModel = this.singleChestModel;
				if (blockMiningProgress >= 0) {
					this.bindTexture(MINING_PROGRESS_LOCATIONS[blockMiningProgress]);
					GlStateManager.matrixMode(5890);
					GlStateManager.pushMatrix();
					GlStateManager.scalef(4.0F, 4.0F, 1.0F);
					GlStateManager.translatef(0.0625F, 0.0625F, 0.0625F);
					GlStateManager.matrixMode(5888);
				} else if (this.isChristmas) {
					this.bindTexture(CHRISTMAS_CHEST_LOCATION);
				} else if (blockEntity.getChestType() == 1) {
					this.bindTexture(TRAPPED_CHEST_LOCATION);
				} else {
					this.bindTexture(CHEST_LOCATION);
				}
			} else {
				chestModel = this.doubleChestModel;
				if (blockMiningProgress >= 0) {
					this.bindTexture(MINING_PROGRESS_LOCATIONS[blockMiningProgress]);
					GlStateManager.matrixMode(5890);
					GlStateManager.pushMatrix();
					GlStateManager.scalef(8.0F, 4.0F, 1.0F);
					GlStateManager.translatef(0.0625F, 0.0625F, 0.0625F);
					GlStateManager.matrixMode(5888);
				} else if (this.isChristmas) {
					this.bindTexture(CHRISTMAS_DOUBLE_CHEST_LOCATION);
				} else if (blockEntity.getChestType() == 1) {
					this.bindTexture(TRAPPED_DOUBLE_CHEST_LOCATION);
				} else {
					this.bindTexture(DOUBLE_CHEST_LOCATION);
				}
			}

			GlStateManager.pushMatrix();
			GlStateManager.enableRescaleNormal();
			if (blockMiningProgress < 0) {
				GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			}

			GlStateManager.translatef((float)dx, (float)dy + 1.0F, (float)dz + 1.0F);
			GlStateManager.scalef(1.0F, -1.0F, -1.0F);
			GlStateManager.translatef(0.5F, 0.5F, 0.5F);
			int j = 0;
			if (i == 2) {
				j = 180;
			}

			if (i == 3) {
				j = 0;
			}

			if (i == 4) {
				j = 90;
			}

			if (i == 5) {
				j = -90;
			}

			if (i == 2 && blockEntity.eastNeighbor != null) {
				GlStateManager.translatef(1.0F, 0.0F, 0.0F);
			}

			if (i == 5 && blockEntity.southNeighbor != null) {
				GlStateManager.translatef(0.0F, 0.0F, -1.0F);
			}

			GlStateManager.rotatef(j, 0.0F, 1.0F, 0.0F);
			GlStateManager.translatef(-0.5F, -0.5F, -0.5F);
			float f = blockEntity.lastAnimationProgress + (blockEntity.animationProgress - blockEntity.lastAnimationProgress) * tickDelta;
			if (blockEntity.northNeighbor != null) {
				float g = blockEntity.northNeighbor.lastAnimationProgress
					+ (blockEntity.northNeighbor.animationProgress - blockEntity.northNeighbor.lastAnimationProgress) * tickDelta;
				if (g > f) {
					f = g;
				}
			}

			if (blockEntity.westNeighbor != null) {
				float g = blockEntity.westNeighbor.lastAnimationProgress
					+ (blockEntity.westNeighbor.animationProgress - blockEntity.westNeighbor.lastAnimationProgress) * tickDelta;
				if (g > f) {
					f = g;
				}
			}

			f = 1.0F - f;
			f = 1.0F - f * f * f;
			chestModel.lid.rotationX = -(f * (float) Math.PI / 2.0F);
			chestModel.renderParts();
			GlStateManager.disableRescaleNormal();
			GlStateManager.popMatrix();
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			if (blockMiningProgress >= 0) {
				GlStateManager.matrixMode(5890);
				GlStateManager.popMatrix();
				GlStateManager.matrixMode(5888);
			}
		}
	}
}

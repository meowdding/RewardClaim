package net.minecraft.client.entity.living.player;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class Input {
	public float movementSideways;
	public float movementForward;
	public boolean jumping;
	public boolean sneaking;

	public void tick() {
	}
}

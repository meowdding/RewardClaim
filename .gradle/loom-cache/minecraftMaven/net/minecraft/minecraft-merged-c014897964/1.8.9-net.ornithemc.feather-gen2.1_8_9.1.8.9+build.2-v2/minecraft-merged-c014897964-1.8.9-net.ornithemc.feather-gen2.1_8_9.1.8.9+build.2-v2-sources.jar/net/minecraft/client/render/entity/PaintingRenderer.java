package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.decoration.PaintingEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class PaintingRenderer extends EntityRenderer<PaintingEntity> {
	private static final Identifier PAINTINGS_LOCATION = new Identifier("textures/painting/paintings_kristoffer_zetterstrand.png");

	public PaintingRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
	}

	public void render(PaintingEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		GlStateManager.pushMatrix();
		GlStateManager.translated(dx, dy, dz);
		GlStateManager.rotatef(180.0F - yaw, 0.0F, 1.0F, 0.0F);
		GlStateManager.enableRescaleNormal();
		this.bindTexture(entity);
		PaintingEntity.Motive motive = entity.motive;
		float f = 0.0625F;
		GlStateManager.scalef(f, f, f);
		this.renderPainting(entity, motive.width, motive.height, motive.u, motive.v);
		GlStateManager.disableRescaleNormal();
		GlStateManager.popMatrix();
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(PaintingEntity entity) {
		return PAINTINGS_LOCATION;
	}

	private void renderPainting(PaintingEntity painting, int width, int height, int u, int v) {
		float f = -width / 2.0F;
		float g = -height / 2.0F;
		float h = 0.5F;
		float i = 0.75F;
		float j = 0.8125F;
		float k = 0.0F;
		float l = 0.0625F;
		float m = 0.75F;
		float n = 0.8125F;
		float o = 0.001953125F;
		float p = 0.001953125F;
		float q = 0.7519531F;
		float r = 0.7519531F;
		float s = 0.0F;
		float t = 0.0625F;

		for (int w = 0; w < width / 16; w++) {
			for (int x = 0; x < height / 16; x++) {
				float y = f + (w + 1) * 16;
				float z = f + w * 16;
				float aa = g + (x + 1) * 16;
				float ab = g + x * 16;
				this.applyBrightness(painting, (y + z) / 2.0F, (aa + ab) / 2.0F);
				float ac = (u + width - w * 16) / 256.0F;
				float ad = (u + width - (w + 1) * 16) / 256.0F;
				float ae = (v + height - x * 16) / 256.0F;
				float af = (v + height - (x + 1) * 16) / 256.0F;
				Tesselator tesselator = Tesselator.getInstance();
				BufferBuilder bufferBuilder = tesselator.getBuffer();
				bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_NORMAL);
				bufferBuilder.vertex(y, ab, -h).texture(ad, ae).normal(0.0F, 0.0F, -1.0F).nextVertex();
				bufferBuilder.vertex(z, ab, -h).texture(ac, ae).normal(0.0F, 0.0F, -1.0F).nextVertex();
				bufferBuilder.vertex(z, aa, -h).texture(ac, af).normal(0.0F, 0.0F, -1.0F).nextVertex();
				bufferBuilder.vertex(y, aa, -h).texture(ad, af).normal(0.0F, 0.0F, -1.0F).nextVertex();
				bufferBuilder.vertex(y, aa, h).texture(i, k).normal(0.0F, 0.0F, 1.0F).nextVertex();
				bufferBuilder.vertex(z, aa, h).texture(j, k).normal(0.0F, 0.0F, 1.0F).nextVertex();
				bufferBuilder.vertex(z, ab, h).texture(j, l).normal(0.0F, 0.0F, 1.0F).nextVertex();
				bufferBuilder.vertex(y, ab, h).texture(i, l).normal(0.0F, 0.0F, 1.0F).nextVertex();
				bufferBuilder.vertex(y, aa, -h).texture(m, o).normal(0.0F, 1.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(z, aa, -h).texture(n, o).normal(0.0F, 1.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(z, aa, h).texture(n, p).normal(0.0F, 1.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(y, aa, h).texture(m, p).normal(0.0F, 1.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(y, ab, h).texture(m, o).normal(0.0F, -1.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(z, ab, h).texture(n, o).normal(0.0F, -1.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(z, ab, -h).texture(n, p).normal(0.0F, -1.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(y, ab, -h).texture(m, p).normal(0.0F, -1.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(y, aa, h).texture(r, s).normal(-1.0F, 0.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(y, ab, h).texture(r, t).normal(-1.0F, 0.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(y, ab, -h).texture(q, t).normal(-1.0F, 0.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(y, aa, -h).texture(q, s).normal(-1.0F, 0.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(z, aa, -h).texture(r, s).normal(1.0F, 0.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(z, ab, -h).texture(r, t).normal(1.0F, 0.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(z, ab, h).texture(q, t).normal(1.0F, 0.0F, 0.0F).nextVertex();
				bufferBuilder.vertex(z, aa, h).texture(q, s).normal(1.0F, 0.0F, 0.0F).nextVertex();
				tesselator.end();
			}
		}
	}

	private void applyBrightness(PaintingEntity painting, float u, float v) {
		int i = MathHelper.floor(painting.x);
		int j = MathHelper.floor(painting.y + v / 16.0F);
		int k = MathHelper.floor(painting.z);
		Direction direction = painting.dir;
		if (direction == Direction.NORTH) {
			i = MathHelper.floor(painting.x + u / 16.0F);
		}

		if (direction == Direction.WEST) {
			k = MathHelper.floor(painting.z - u / 16.0F);
		}

		if (direction == Direction.SOUTH) {
			i = MathHelper.floor(painting.x - u / 16.0F);
		}

		if (direction == Direction.EAST) {
			k = MathHelper.floor(painting.z + u / 16.0F);
		}

		int l = this.dispatcher.world.getLightColor(new BlockPos(i, j, k), 0);
		int m = l % 65536;
		int n = l / 65536;
		GLX.multiTexCoord2f(GLX.GL_TEXTURE1, m, n);
		GlStateManager.color3f(1.0F, 1.0F, 1.0F);
	}
}

package net.minecraft.client.gui.overlay;

import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Ordering;
import com.mojang.authlib.GameProfile;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GameGui;
import net.minecraft.client.gui.GuiElement;
import net.minecraft.client.network.PlayerInfo;
import net.minecraft.client.network.handler.ClientPlayNetworkHandler;
import net.minecraft.client.render.model.PlayerModelPart;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.criterion.ScoreboardCriterion;
import net.minecraft.scoreboard.team.Team;
import net.minecraft.text.Formatting;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.WorldSettings;

@Environment(EnvType.CLIENT)
public class PlayerTabOverlay extends GuiElement {
	private static final Ordering<PlayerInfo> PLAYER_ORDERING = Ordering.from(new PlayerTabOverlay.PlayerInfoComparator());
	private final Minecraft minecraft;
	private final GameGui gui;
	private Text footer;
	private Text header;
	private long visibility;
	private boolean visible;

	public PlayerTabOverlay(Minecraft minecraft, GameGui gui) {
		this.minecraft = minecraft;
		this.gui = gui;
	}

	public String getDisplayName(PlayerInfo player) {
		return player.getDisplayName() != null
			? player.getDisplayName().getFormattedString()
			: Team.getMemberDisplayName(player.getTeam(), player.getProfile().getName());
	}

	public void setVisible(boolean visible) {
		if (visible && !this.visible) {
			this.visibility = Minecraft.getTime();
		}

		this.visible = visible;
	}

	public void render(int width, Scoreboard scoreboard, ScoreboardObjective displayObjective) {
		ClientPlayNetworkHandler clientPlayNetworkHandler = this.minecraft.player.networkHandler;
		List<PlayerInfo> list = PLAYER_ORDERING.sortedCopy(clientPlayNetworkHandler.getOnlinePlayers());
		int i = 0;
		int j = 0;

		for (PlayerInfo playerInfo : list) {
			int k = this.minecraft.textRenderer.getWidth(this.getDisplayName(playerInfo));
			i = Math.max(i, k);
			if (displayObjective != null && displayObjective.getRenderType() != ScoreboardCriterion.RenderType.HEARTS) {
				k = this.minecraft.textRenderer.getWidth(" " + scoreboard.getScore(playerInfo.getProfile().getName(), displayObjective).get());
				j = Math.max(j, k);
			}
		}

		list = list.subList(0, Math.min(list.size(), 80));
		int l = list.size();
		int m = l;

		int k;
		for (k = 1; m > 20; m = (l + k - 1) / k) {
			k++;
		}

		boolean bl = this.minecraft.isIntegratedServerRunning() || this.minecraft.getNetworkHandler().getConnection().isEncrypted();
		int n;
		if (displayObjective != null) {
			if (displayObjective.getRenderType() == ScoreboardCriterion.RenderType.HEARTS) {
				n = 90;
			} else {
				n = j;
			}
		} else {
			n = 0;
		}

		int o = Math.min(k * ((bl ? 9 : 0) + i + n + 13), width - 50) / k;
		int p = width / 2 - (o * k + (k - 1) * 5) / 2;
		int q = 10;
		int r = o * k + (k - 1) * 5;
		List<String> list2 = null;
		List<String> list3 = null;
		if (this.header != null) {
			list2 = this.minecraft.textRenderer.split(this.header.getFormattedString(), width - 50);

			for (String string : list2) {
				r = Math.max(r, this.minecraft.textRenderer.getWidth(string));
			}
		}

		if (this.footer != null) {
			list3 = this.minecraft.textRenderer.split(this.footer.getFormattedString(), width - 50);

			for (String string : list3) {
				r = Math.max(r, this.minecraft.textRenderer.getWidth(string));
			}
		}

		if (list2 != null) {
			fill(width / 2 - r / 2 - 1, q - 1, width / 2 + r / 2 + 1, q + list2.size() * this.minecraft.textRenderer.fontHeight, Integer.MIN_VALUE);

			for (String string : list2) {
				int s = this.minecraft.textRenderer.getWidth(string);
				this.minecraft.textRenderer.drawWithShadow(string, width / 2 - s / 2, q, -1);
				q += this.minecraft.textRenderer.fontHeight;
			}

			q++;
		}

		fill(width / 2 - r / 2 - 1, q - 1, width / 2 + r / 2 + 1, q + m * 9, Integer.MIN_VALUE);

		for (int t = 0; t < l; t++) {
			int u = t / m;
			int s = t % m;
			int v = p + u * o + u * 5;
			int w = q + s * 9;
			fill(v, w, v + o, w + 8, 553648127);
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			GlStateManager.enableAlphaTest();
			GlStateManager.enableBlend();
			GlStateManager.blendFuncSeparate(770, 771, 1, 0);
			if (t < list.size()) {
				PlayerInfo playerInfo2 = list.get(t);
				String string2 = this.getDisplayName(playerInfo2);
				GameProfile gameProfile = playerInfo2.getProfile();
				if (bl) {
					PlayerEntity playerEntity = this.minecraft.world.getPlayer(gameProfile.getId());
					boolean bl2 = playerEntity != null
						&& playerEntity.isModelPartVisible(PlayerModelPart.CAPE)
						&& (gameProfile.getName().equals("Dinnerbone") || gameProfile.getName().equals("Grumm"));
					this.minecraft.getTextureManager().bind(playerInfo2.getSkinTexture());
					int x = 8 + (bl2 ? 8 : 0);
					int y = 8 * (bl2 ? -1 : 1);
					GuiElement.drawTexture(v, w, 8.0F, x, 8, y, 8, 8, 64.0F, 64.0F);
					if (playerEntity != null && playerEntity.isModelPartVisible(PlayerModelPart.HAT)) {
						int z = 8 + (bl2 ? 8 : 0);
						int aa = 8 * (bl2 ? -1 : 1);
						GuiElement.drawTexture(v, w, 40.0F, z, 8, aa, 8, 8, 64.0F, 64.0F);
					}

					v += 9;
				}

				if (playerInfo2.getGameMode() == WorldSettings.GameMode.SPECTATOR) {
					string2 = Formatting.ITALIC + string2;
					this.minecraft.textRenderer.drawWithShadow(string2, v, w, -1862270977);
				} else {
					this.minecraft.textRenderer.drawWithShadow(string2, v, w, -1);
				}

				if (displayObjective != null && playerInfo2.getGameMode() != WorldSettings.GameMode.SPECTATOR) {
					int ab = v + i + 1;
					int ac = ab + n;
					if (ac - ab > 5) {
						this.renderDisplayScore(displayObjective, w, gameProfile.getName(), ab, ac, playerInfo2);
					}
				}

				this.renderPing(o, v - (bl ? 9 : 0), w, playerInfo2);
			}
		}

		if (list3 != null) {
			q += m * 9 + 1;
			fill(width / 2 - r / 2 - 1, q - 1, width / 2 + r / 2 + 1, q + list3.size() * this.minecraft.textRenderer.fontHeight, Integer.MIN_VALUE);

			for (String string : list3) {
				int s = this.minecraft.textRenderer.getWidth(string);
				this.minecraft.textRenderer.drawWithShadow(string, width / 2 - s / 2, q, -1);
				q += this.minecraft.textRenderer.fontHeight;
			}
		}
	}

	protected void renderPing(int width, int x, int y, PlayerInfo player) {
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.minecraft.getTextureManager().bind(ICONS_LOCATION);
		int i = 0;
		int j = 0;
		byte var7;
		if (player.getPing() < 0) {
			var7 = 5;
		} else if (player.getPing() < 150) {
			var7 = 0;
		} else if (player.getPing() < 300) {
			var7 = 1;
		} else if (player.getPing() < 600) {
			var7 = 2;
		} else if (player.getPing() < 1000) {
			var7 = 3;
		} else {
			var7 = 4;
		}

		this.drawOffset += 100.0F;
		this.drawTexture(x + width - 11, y, 0 + i * 10, 176 + var7 * 8, 10, 8);
		this.drawOffset -= 100.0F;
	}

	private void renderDisplayScore(ScoreboardObjective displayObjective, int width, String owner, int x, int y, PlayerInfo player) {
		int i = displayObjective.getScoreboard().getScore(owner, displayObjective).get();
		if (displayObjective.getRenderType() == ScoreboardCriterion.RenderType.HEARTS) {
			this.minecraft.getTextureManager().bind(ICONS_LOCATION);
			if (this.visibility == player.getRenderVisibility()) {
				if (i < player.getLastHealth()) {
					player.setLastHealthUpdateTime(Minecraft.getTime());
					player.setLastHealthAnimationTime(this.gui.getTicks() + 20);
				} else if (i > player.getLastHealth()) {
					player.setLastHealthUpdateTime(Minecraft.getTime());
					player.setLastHealthAnimationTime(this.gui.getTicks() + 10);
				}
			}

			if (Minecraft.getTime() - player.getLastHealthUpdateTime() > 1000L || this.visibility != player.getRenderVisibility()) {
				player.setLastHealth(i);
				player.setHealth(i);
				player.setLastHealthUpdateTime(Minecraft.getTime());
			}

			player.setRenderVisibility(this.visibility);
			player.setLastHealth(i);
			int j = MathHelper.ceil(Math.max(i, player.getHealth()) / 2.0F);
			int k = Math.max(MathHelper.ceil(i / 2), Math.max(MathHelper.ceil(player.getHealth() / 2), 10));
			boolean bl = player.getLastHealthAnimationTime() > this.gui.getTicks() && (player.getLastHealthAnimationTime() - this.gui.getTicks()) / 3L % 2L == 1L;
			if (j > 0) {
				float f = Math.min((float)(y - x - 4) / k, 9.0F);
				if (f > 3.0F) {
					for (int l = j; l < k; l++) {
						this.drawTexture(x + l * f, width, bl ? 25 : 16, 0, 9, 9);
					}

					for (int l = 0; l < j; l++) {
						this.drawTexture(x + l * f, width, bl ? 25 : 16, 0, 9, 9);
						if (bl) {
							if (l * 2 + 1 < player.getHealth()) {
								this.drawTexture(x + l * f, width, 70, 0, 9, 9);
							}

							if (l * 2 + 1 == player.getHealth()) {
								this.drawTexture(x + l * f, width, 79, 0, 9, 9);
							}
						}

						if (l * 2 + 1 < i) {
							this.drawTexture(x + l * f, width, l >= 10 ? 160 : 52, 0, 9, 9);
						}

						if (l * 2 + 1 == i) {
							this.drawTexture(x + l * f, width, l >= 10 ? 169 : 61, 0, 9, 9);
						}
					}
				} else {
					float g = MathHelper.clamp(i / 20.0F, 0.0F, 1.0F);
					int m = (int)((1.0F - g) * 255.0F) << 16 | (int)(g * 255.0F) << 8;
					String string = "" + i / 2.0F;
					if (y - this.minecraft.textRenderer.getWidth(string + "hp") >= x) {
						string = string + "hp";
					}

					this.minecraft.textRenderer.drawWithShadow(string, (y + x) / 2 - this.minecraft.textRenderer.getWidth(string) / 2, width, m);
				}
			}
		} else {
			String string2 = Formatting.YELLOW + "" + i;
			this.minecraft.textRenderer.drawWithShadow(string2, y - this.minecraft.textRenderer.getWidth(string2), width, 16777215);
		}
	}

	public void setFooter(Text footer) {
		this.footer = footer;
	}

	public void setHeader(Text header) {
		this.header = header;
	}

	public void reset() {
		this.header = null;
		this.footer = null;
	}

	@Environment(EnvType.CLIENT)
	static class PlayerInfoComparator implements Comparator<PlayerInfo> {
		private PlayerInfoComparator() {
		}

		public int compare(PlayerInfo playerInfo, PlayerInfo playerInfo2) {
			Team team = playerInfo.getTeam();
			Team team2 = playerInfo2.getTeam();
			return ComparisonChain.start()
				.compareTrueFirst(playerInfo.getGameMode() != WorldSettings.GameMode.SPECTATOR, playerInfo2.getGameMode() != WorldSettings.GameMode.SPECTATOR)
				.compare(team != null ? team.getName() : "", team2 != null ? team2.getName() : "")
				.compare(playerInfo.getProfile().getName(), playerInfo2.getProfile().getName())
				.result();
		}
	}
}

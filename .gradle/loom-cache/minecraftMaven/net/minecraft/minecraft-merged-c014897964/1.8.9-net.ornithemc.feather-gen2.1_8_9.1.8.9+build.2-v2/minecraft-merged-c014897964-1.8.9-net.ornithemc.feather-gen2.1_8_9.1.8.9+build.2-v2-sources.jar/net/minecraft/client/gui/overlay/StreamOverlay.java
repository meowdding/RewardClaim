package net.minecraft.client.gui.overlay;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class StreamOverlay {
	private static final Identifier STREAM_INDICATOR_TEXTURE = new Identifier("textures/gui/stream_indicator.png");
	private final Minecraft minecraft;
	private float f_38568307 = 1.0F;
	private int f_41291574 = 1;

	public StreamOverlay(Minecraft minecraft) {
		this.minecraft = minecraft;
	}

	public void render(int x, int y) {
		if (this.minecraft.getTwitchStream().isBroadcasting()) {
			GlStateManager.enableBlend();
			int i = this.minecraft.getTwitchStream().getViewerCount();
			if (i > 0) {
				String string = "" + i;
				int j = this.minecraft.textRenderer.getWidth(string);
				int k = 20;
				int l = x - j - 1;
				int m = y + 20 - 1;
				int n = x;
				int o = y + 20 + this.minecraft.textRenderer.fontHeight - 1;
				GlStateManager.disableTexture();
				Tesselator tesselator = Tesselator.getInstance();
				BufferBuilder bufferBuilder = tesselator.getBuffer();
				GlStateManager.color4f(0.0F, 0.0F, 0.0F, (0.65F + 0.35000002F * this.f_38568307) / 2.0F);
				bufferBuilder.begin(7, DefaultVertexFormat.POSITION);
				bufferBuilder.vertex(l, o, 0.0).nextVertex();
				bufferBuilder.vertex(n, o, 0.0).nextVertex();
				bufferBuilder.vertex(n, m, 0.0).nextVertex();
				bufferBuilder.vertex(l, m, 0.0).nextVertex();
				tesselator.end();
				GlStateManager.enableTexture();
				this.minecraft.textRenderer.draw(string, x - j, y + 20, 16777215);
			}

			this.m_17429747(x, y, this.m_81856840(), 0);
			this.m_17429747(x, y, this.m_83289373(), 17);
		}
	}

	private void m_17429747(int i, int j, int k, int l) {
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 0.65F + 0.35000002F * this.f_38568307);
		this.minecraft.getTextureManager().bind(STREAM_INDICATOR_TEXTURE);
		float f = 150.0F;
		float g = 0.0F;
		float h = k * 0.015625F;
		float m = 1.0F;
		float n = (k + 16) * 0.015625F;
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
		bufferBuilder.vertex(i - 16 - l, j + 16, f).texture(g, n).nextVertex();
		bufferBuilder.vertex(i - l, j + 16, f).texture(m, n).nextVertex();
		bufferBuilder.vertex(i - l, j + 0, f).texture(m, h).nextVertex();
		bufferBuilder.vertex(i - 16 - l, j + 0, f).texture(g, h).nextVertex();
		tesselator.end();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
	}

	private int m_81856840() {
		return this.minecraft.getTwitchStream().isPaused() ? 16 : 0;
	}

	private int m_83289373() {
		return this.minecraft.getTwitchStream().m_45342130() ? 48 : 32;
	}

	public void m_61253298() {
		if (this.minecraft.getTwitchStream().isBroadcasting()) {
			this.f_38568307 = this.f_38568307 + 0.025F * this.f_41291574;
			if (this.f_38568307 < 0.0F) {
				this.f_41291574 *= -1;
				this.f_38568307 = 0.0F;
			} else if (this.f_38568307 > 1.0F) {
				this.f_41291574 *= -1;
				this.f_38568307 = 1.0F;
			}
		} else {
			this.f_38568307 = 1.0F;
			this.f_41291574 = 1;
		}
	}
}

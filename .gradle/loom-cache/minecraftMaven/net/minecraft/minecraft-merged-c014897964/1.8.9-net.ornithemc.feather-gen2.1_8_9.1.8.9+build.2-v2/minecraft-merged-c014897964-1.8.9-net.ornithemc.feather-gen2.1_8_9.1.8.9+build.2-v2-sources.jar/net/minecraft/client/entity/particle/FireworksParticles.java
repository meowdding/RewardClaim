package net.minecraft.client.entity.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.item.DyeItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.ornithemc.feather.constants.NbtTypes;

@Environment(EnvType.CLIENT)
public class FireworksParticles {
	@Environment(EnvType.CLIENT)
	public static class Factory implements ParticleFactory {
		@Override
		public Particle create(int type, World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, int... parameters) {
			FireworksParticles.Spark spark = new FireworksParticles.Spark(world, x, y, z, velocityX, velocityY, velocityZ, Minecraft.getInstance().particleManager);
			spark.setAlpha(0.99F);
			return spark;
		}
	}

	@Environment(EnvType.CLIENT)
	public static class Overlay extends Particle {
		protected Overlay(World world, double d, double e, double f) {
			super(world, d, e, f);
			this.lifetime = 4;
		}

		@Override
		public void render(BufferBuilder bufferBuilder, Entity camera, float tickDelta, float dx, float dy, float dz, float forwards, float sideways) {
			float f = 0.25F;
			float g = 0.5F;
			float h = 0.125F;
			float i = 0.375F;
			float j = 7.1F * MathHelper.sin((this.age + tickDelta - 1.0F) * 0.25F * (float) Math.PI);
			this.alpha = 0.6F - (this.age + tickDelta - 1.0F) * 0.25F * 0.5F;
			float k = (float)(this.lastX + (this.x - this.lastX) * tickDelta - cameraX);
			float l = (float)(this.lastY + (this.y - this.lastY) * tickDelta - cameraY);
			float m = (float)(this.lastZ + (this.z - this.lastZ) * tickDelta - cameraZ);
			int n = this.getLightLevel(tickDelta);
			int o = n >> 16 & 65535;
			int p = n & 65535;
			bufferBuilder.vertex(k - dx * j - forwards * j, l - dy * j, m - dz * j - sideways * j)
				.texture(0.5, 0.375)
				.color(this.red, this.green, this.blue, this.alpha)
				.texture(o, p)
				.nextVertex();
			bufferBuilder.vertex(k - dx * j + forwards * j, l + dy * j, m - dz * j + sideways * j)
				.texture(0.5, 0.125)
				.color(this.red, this.green, this.blue, this.alpha)
				.texture(o, p)
				.nextVertex();
			bufferBuilder.vertex(k + dx * j + forwards * j, l + dy * j, m + dz * j + sideways * j)
				.texture(0.25, 0.125)
				.color(this.red, this.green, this.blue, this.alpha)
				.texture(o, p)
				.nextVertex();
			bufferBuilder.vertex(k + dx * j - forwards * j, l - dy * j, m + dz * j - sideways * j)
				.texture(0.25, 0.375)
				.color(this.red, this.green, this.blue, this.alpha)
				.texture(o, p)
				.nextVertex();
		}
	}

	@Environment(EnvType.CLIENT)
	public static class Spark extends Particle {
		private int texture = 160;
		private boolean trail;
		private boolean flicker;
		private final ParticleManager manager;
		private float fadeRed;
		private float fadeGreen;
		private float fadeBlue;
		private boolean fade;

		public Spark(World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, ParticleManager manager) {
			super(world, x, y, z);
			this.velocityX = velocityX;
			this.velocityY = velocityY;
			this.velocityZ = velocityZ;
			this.manager = manager;
			this.size *= 0.75F;
			this.lifetime = 48 + this.random.nextInt(12);
			this.noClip = false;
		}

		public void setTrail(boolean trail) {
			this.trail = trail;
		}

		public void setFlicker(boolean flicker) {
			this.flicker = flicker;
		}

		public void setColor(int color) {
			float f = ((color & 0xFF0000) >> 16) / 255.0F;
			float g = ((color & 0xFF00) >> 8) / 255.0F;
			float h = ((color & 0xFF) >> 0) / 255.0F;
			float i = 1.0F;
			this.setColor(f * i, g * i, h * i);
		}

		public void setFade(int color) {
			this.fadeRed = ((color & 0xFF0000) >> 16) / 255.0F;
			this.fadeGreen = ((color & 0xFF00) >> 8) / 255.0F;
			this.fadeBlue = ((color & 0xFF) >> 0) / 255.0F;
			this.fade = true;
		}

		@Override
		public Box getCollisionShape() {
			return null;
		}

		@Override
		public boolean isPushable() {
			return false;
		}

		@Override
		public void render(BufferBuilder bufferBuilder, Entity camera, float tickDelta, float dx, float dy, float dz, float forwards, float sideways) {
			if (!this.flicker || this.age < this.lifetime / 3 || (this.age + this.lifetime) / 3 % 2 == 0) {
				super.render(bufferBuilder, camera, tickDelta, dx, dy, dz, forwards, sideways);
			}
		}

		@Override
		public void tick() {
			this.lastX = this.x;
			this.lastY = this.y;
			this.lastZ = this.z;
			if (this.age++ >= this.lifetime) {
				this.remove();
			}

			if (this.age > this.lifetime / 2) {
				this.setAlpha(1.0F - ((float)this.age - this.lifetime / 2) / this.lifetime);
				if (this.fade) {
					this.red = this.red + (this.fadeRed - this.red) * 0.2F;
					this.green = this.green + (this.fadeGreen - this.green) * 0.2F;
					this.blue = this.blue + (this.fadeBlue - this.blue) * 0.2F;
				}
			}

			this.setTextureCoordinates(this.texture + (7 - this.age * 8 / this.lifetime));
			this.velocityY -= 0.004;
			this.move(this.velocityX, this.velocityY, this.velocityZ);
			this.velocityX *= 0.91F;
			this.velocityY *= 0.91F;
			this.velocityZ *= 0.91F;
			if (this.onGround) {
				this.velocityX *= 0.7F;
				this.velocityZ *= 0.7F;
			}

			if (this.trail && this.age < this.lifetime / 2 && (this.age + this.lifetime) % 2 == 0) {
				FireworksParticles.Spark spark = new FireworksParticles.Spark(this.world, this.x, this.y, this.z, 0.0, 0.0, 0.0, this.manager);
				spark.setAlpha(0.99F);
				spark.setColor(this.red, this.green, this.blue);
				spark.age = spark.lifetime / 2;
				if (this.fade) {
					spark.fade = true;
					spark.fadeRed = this.fadeRed;
					spark.fadeGreen = this.fadeGreen;
					spark.fadeBlue = this.fadeBlue;
				}

				spark.flicker = this.flicker;
				this.manager.add(spark);
			}
		}

		@Override
		public int getLightLevel(float tickDelta) {
			return 15728880;
		}

		@Override
		public float getBrightness(float tickDelta) {
			return 1.0F;
		}
	}

	@Environment(EnvType.CLIENT)
	public static class Starter extends Particle {
		private int life;
		private final ParticleManager manager;
		private NbtList explosions;
		boolean twinkleDelay;

		public Starter(
			World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, ParticleManager manager, NbtCompound explosions
		) {
			super(world, x, y, z, 0.0, 0.0, 0.0);
			this.velocityX = velocityX;
			this.velocityY = velocityY;
			this.velocityZ = velocityZ;
			this.manager = manager;
			this.lifetime = 8;
			if (explosions != null) {
				this.explosions = explosions.getList("Explosions", NbtTypes.COMPOUND);
				if (this.explosions.size() == 0) {
					this.explosions = null;
				} else {
					this.lifetime = this.explosions.size() * 2 - 1;

					for (int i = 0; i < this.explosions.size(); i++) {
						NbtCompound nbtCompound = this.explosions.getCompound(i);
						if (nbtCompound.getBoolean("Flicker")) {
							this.twinkleDelay = true;
							this.lifetime += 15;
							break;
						}
					}
				}
			}
		}

		@Override
		public void render(BufferBuilder bufferBuilder, Entity camera, float tickDelta, float dx, float dy, float dz, float forwards, float sideways) {
		}

		@Override
		public void tick() {
			if (this.life == 0 && this.explosions != null) {
				boolean bl = this.isFarAway();
				boolean bl2 = false;
				if (this.explosions.size() >= 3) {
					bl2 = true;
				} else {
					for (int i = 0; i < this.explosions.size(); i++) {
						NbtCompound nbtCompound = this.explosions.getCompound(i);
						if (nbtCompound.getByte("Type") == 1) {
							bl2 = true;
							break;
						}
					}
				}

				String string = "fireworks." + (bl2 ? "largeBlast" : "blast") + (bl ? "_far" : "");
				this.world.playSound(this.x, this.y, this.z, string, 20.0F, 0.95F + this.random.nextFloat() * 0.1F, true);
			}

			if (this.life % 2 == 0 && this.explosions != null && this.life / 2 < this.explosions.size()) {
				int j = this.life / 2;
				NbtCompound nbtCompound2 = this.explosions.getCompound(j);
				int i = nbtCompound2.getByte("Type");
				boolean bl3 = nbtCompound2.getBoolean("Trail");
				boolean bl4 = nbtCompound2.getBoolean("Flicker");
				int[] is = nbtCompound2.getIntArray("Colors");
				int[] js = nbtCompound2.getIntArray("FadeColors");
				if (is.length == 0) {
					is = new int[]{DyeItem.COLORS[0]};
				}

				if (i == 1) {
					this.createBall(0.5, 4, is, js, bl3, bl4);
				} else if (i == 2) {
					this.createShape(
						0.5,
						new double[][]{
							{0.0, 1.0},
							{0.3455, 0.309},
							{0.9511, 0.309},
							{0.3795918367346939, -0.12653061224489795},
							{0.6122448979591837, -0.8040816326530612},
							{0.0, -0.35918367346938773}
						},
						is,
						js,
						bl3,
						bl4,
						false
					);
				} else if (i == 3) {
					this.createShape(
						0.5,
						new double[][]{
							{0.0, 0.2}, {0.2, 0.2}, {0.2, 0.6}, {0.6, 0.6}, {0.6, 0.2}, {0.2, 0.2}, {0.2, 0.0}, {0.4, 0.0}, {0.4, -0.6}, {0.2, -0.6}, {0.2, -0.4}, {0.0, -0.4}
						},
						is,
						js,
						bl3,
						bl4,
						true
					);
				} else if (i == 4) {
					this.createBurst(is, js, bl3, bl4);
				} else {
					this.createBall(0.25, 2, is, js, bl3, bl4);
				}

				int k = is[0];
				float f = ((k & 0xFF0000) >> 16) / 255.0F;
				float g = ((k & 0xFF00) >> 8) / 255.0F;
				float h = ((k & 0xFF) >> 0) / 255.0F;
				FireworksParticles.Overlay overlay = new FireworksParticles.Overlay(this.world, this.x, this.y, this.z);
				overlay.setColor(f, g, h);
				this.manager.add(overlay);
			}

			this.life++;
			if (this.life > this.lifetime) {
				if (this.twinkleDelay) {
					boolean bl = this.isFarAway();
					String string2 = "fireworks." + (bl ? "twinkle_far" : "twinkle");
					this.world.playSound(this.x, this.y, this.z, string2, 20.0F, 0.9F + this.random.nextFloat() * 0.15F, true);
				}

				this.remove();
			}
		}

		private boolean isFarAway() {
			Minecraft minecraft = Minecraft.getInstance();
			return minecraft == null || minecraft.getCamera() == null || !(minecraft.getCamera().squaredDistanceTo(this.x, this.y, this.z) < 256.0);
		}

		private void create(
			double x, double y, double z, double velocityX, double velocityY, double velocityZ, int[] colors, int[] fadeColors, boolean trail, boolean flicker
		) {
			FireworksParticles.Spark spark = new FireworksParticles.Spark(this.world, x, y, z, velocityX, velocityY, velocityZ, this.manager);
			spark.setAlpha(0.99F);
			spark.setTrail(trail);
			spark.setFlicker(flicker);
			int i = this.random.nextInt(colors.length);
			spark.setColor(colors[i]);
			if (fadeColors != null && fadeColors.length > 0) {
				spark.setFade(fadeColors[this.random.nextInt(fadeColors.length)]);
			}

			this.manager.add(spark);
		}

		private void createBall(double size, int amount, int[] colors, int[] fadeColors, boolean trail, boolean flicker) {
			double d = this.x;
			double e = this.y;
			double f = this.z;

			for (int i = -amount; i <= amount; i++) {
				for (int j = -amount; j <= amount; j++) {
					for (int k = -amount; k <= amount; k++) {
						double g = j + (this.random.nextDouble() - this.random.nextDouble()) * 0.5;
						double h = i + (this.random.nextDouble() - this.random.nextDouble()) * 0.5;
						double l = k + (this.random.nextDouble() - this.random.nextDouble()) * 0.5;
						double m = MathHelper.sqrt(g * g + h * h + l * l) / size + this.random.nextGaussian() * 0.05;
						this.create(d, e, f, g / m, h / m, l / m, colors, fadeColors, trail, flicker);
						if (i != -amount && i != amount && j != -amount && j != amount) {
							k += amount * 2 - 1;
						}
					}
				}
			}
		}

		private void createShape(double size, double[][] pattern, int[] colors, int[] fadeColors, boolean trail, boolean flicker, boolean keepShape) {
			double d = pattern[0][0];
			double e = pattern[0][1];
			this.create(this.x, this.y, this.z, d * size, e * size, 0.0, colors, fadeColors, trail, flicker);
			float f = this.random.nextFloat() * (float) Math.PI;
			double g = keepShape ? 0.034 : 0.34;

			for (int i = 0; i < 3; i++) {
				double h = f + i * (float) Math.PI * g;
				double j = d;
				double k = e;

				for (int l = 1; l < pattern.length; l++) {
					double m = pattern[l][0];
					double n = pattern[l][1];

					for (double o = 0.25; o <= 1.0; o += 0.25) {
						double p = (j + (m - j) * o) * size;
						double q = (k + (n - k) * o) * size;
						double r = p * Math.sin(h);
						p *= Math.cos(h);

						for (double s = -1.0; s <= 1.0; s += 2.0) {
							this.create(this.x, this.y, this.z, p * s, q, r * s, colors, fadeColors, trail, flicker);
						}
					}

					j = m;
					k = n;
				}
			}
		}

		private void createBurst(int[] colors, int[] fadeColors, boolean trail, boolean flicker) {
			double d = this.random.nextGaussian() * 0.05;
			double e = this.random.nextGaussian() * 0.05;

			for (int i = 0; i < 70; i++) {
				double f = this.velocityX * 0.5 + this.random.nextGaussian() * 0.15 + d;
				double g = this.velocityZ * 0.5 + this.random.nextGaussian() * 0.15 + e;
				double h = this.velocityY * 0.5 + this.random.nextDouble() * 0.5;
				this.create(this.x, this.y, this.z, f, h, g, colors, fadeColors, trail, flicker);
			}
		}

		@Override
		public int getAtlasType() {
			return 0;
		}
	}
}

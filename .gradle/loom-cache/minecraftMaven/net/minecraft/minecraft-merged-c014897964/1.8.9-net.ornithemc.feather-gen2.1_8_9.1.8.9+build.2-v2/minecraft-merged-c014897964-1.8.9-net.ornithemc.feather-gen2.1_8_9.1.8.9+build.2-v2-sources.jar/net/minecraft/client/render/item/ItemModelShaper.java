package net.minecraft.client.render.item;

import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.model.block.BakedModel;
import net.minecraft.client.render.texture.TextureAtlasSprite;
import net.minecraft.client.resource.model.ItemModelLocationProvider;
import net.minecraft.client.resource.model.ModelIdentifier;
import net.minecraft.client.resource.model.ModelManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

@Environment(EnvType.CLIENT)
public class ItemModelShaper {
	private final Map<Integer, ModelIdentifier> modelLocations = Maps.newHashMap();
	private final Map<Integer, BakedModel> bakedModels = Maps.newHashMap();
	private final Map<Item, ItemModelLocationProvider> modelProviders = Maps.newHashMap();
	private final ModelManager modelManager;

	public ItemModelShaper(ModelManager modelManager) {
		this.modelManager = modelManager;
	}

	public TextureAtlasSprite getParticleIcon(Item item) {
		return this.getParticleIcon(item, 0);
	}

	public TextureAtlasSprite getParticleIcon(Item item, int metadata) {
		return this.getModel(new ItemStack(item, 1, metadata)).getParticleIcon();
	}

	public BakedModel getModel(ItemStack item) {
		Item item2 = item.getItem();
		BakedModel bakedModel = this.getModel(item2, this.getModelMetadata(item));
		if (bakedModel == null) {
			ItemModelLocationProvider itemModelLocationProvider = this.modelProviders.get(item2);
			if (itemModelLocationProvider != null) {
				bakedModel = this.modelManager.getModel(itemModelLocationProvider.getModelLocation(item));
			}
		}

		if (bakedModel == null) {
			bakedModel = this.modelManager.getMissingModel();
		}

		return bakedModel;
	}

	protected int getModelMetadata(ItemStack item) {
		return item.isDamageable() ? 0 : item.getMetadata();
	}

	protected BakedModel getModel(Item item, int metadata) {
		return this.bakedModels.get(this.index(item, metadata));
	}

	private int index(Item item, int metadata) {
		return Item.getId(item) << 16 | metadata;
	}

	public void register(Item item, int metadata, ModelIdentifier location) {
		this.modelLocations.put(this.index(item, metadata), location);
		this.bakedModels.put(this.index(item, metadata), this.modelManager.getModel(location));
	}

	public void register(Item item, ItemModelLocationProvider provider) {
		this.modelProviders.put(item, provider);
	}

	public ModelManager getManager() {
		return this.modelManager;
	}

	public void rebuildCache() {
		this.bakedModels.clear();

		for (Entry<Integer, ModelIdentifier> entry : this.modelLocations.entrySet()) {
			this.bakedModels.put(entry.getKey(), this.modelManager.getModel(entry.getValue()));
		}
	}
}

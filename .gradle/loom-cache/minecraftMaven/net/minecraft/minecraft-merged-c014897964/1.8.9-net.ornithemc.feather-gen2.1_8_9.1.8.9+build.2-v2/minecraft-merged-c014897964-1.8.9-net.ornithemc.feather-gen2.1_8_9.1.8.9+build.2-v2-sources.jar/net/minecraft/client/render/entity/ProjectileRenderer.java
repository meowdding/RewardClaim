package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.render.texture.TextureAtlasSprite;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.Items;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class ProjectileRenderer extends EntityRenderer<ProjectileEntity> {
	private float speed;

	public ProjectileRenderer(EntityRenderDispatcher dispatcher, float speed) {
		super(dispatcher);
		this.speed = speed;
	}

	public void render(ProjectileEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		GlStateManager.pushMatrix();
		this.bindTexture(entity);
		GlStateManager.translatef((float)dx, (float)dy, (float)dz);
		GlStateManager.enableRescaleNormal();
		GlStateManager.scalef(this.speed, this.speed, this.speed);
		TextureAtlasSprite textureAtlasSprite = Minecraft.getInstance().getItemRenderer().getModelShaper().getParticleIcon(Items.FIRE_CHARGE);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		float f = textureAtlasSprite.getUMin();
		float g = textureAtlasSprite.getUMax();
		float h = textureAtlasSprite.getVMin();
		float i = textureAtlasSprite.getVMax();
		float j = 1.0F;
		float k = 0.5F;
		float l = 0.25F;
		GlStateManager.rotatef(180.0F - this.dispatcher.cameraYaw, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(-this.dispatcher.cameraPitch, 1.0F, 0.0F, 0.0F);
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_NORMAL);
		bufferBuilder.vertex(-0.5, -0.25, 0.0).texture(f, i).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(0.5, -0.25, 0.0).texture(g, i).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(0.5, 0.75, 0.0).texture(g, h).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(-0.5, 0.75, 0.0).texture(f, h).normal(0.0F, 1.0F, 0.0F).nextVertex();
		tesselator.end();
		GlStateManager.disableRescaleNormal();
		GlStateManager.popMatrix();
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(ProjectileEntity entity) {
		return TextureAtlas.BLOCKS_LOCATION;
	}
}

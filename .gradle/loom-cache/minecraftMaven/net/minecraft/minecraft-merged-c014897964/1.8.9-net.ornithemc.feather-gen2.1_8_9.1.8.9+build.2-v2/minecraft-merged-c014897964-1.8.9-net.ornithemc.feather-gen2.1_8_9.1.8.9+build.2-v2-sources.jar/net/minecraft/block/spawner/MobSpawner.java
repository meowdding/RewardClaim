package net.minecraft.block.spawner;

import com.google.common.collect.Lists;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entities;
import net.minecraft.entity.Entity;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.mob.MobEntity;
import net.minecraft.entity.particle.ParticleType;
import net.minecraft.entity.vehicle.MinecartEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.text.StringUtils;
import net.minecraft.util.WeightedPicker;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import net.ornithemc.feather.constants.NbtTypes;

public abstract class MobSpawner {
	private int delay = 20;
	private String type = "Pig";
	private final List<MobSpawner.Entry> spawnPotentials = Lists.newArrayList();
	private MobSpawner.Entry nextEntry;
	private double rotation;
	private double lastRotation;
	private int minSpawnDelay = 200;
	private int maxSpawnDelay = 800;
	private int spawnCount = 4;
	private Entity displayEntity;
	private int maxNearbyEntities = 6;
	private int requiredPlayerRange = 16;
	private int spawnRange = 4;

	private String getType() {
		if (this.getNextEntry() == null) {
			if (this.type != null && this.type.equals("Minecart")) {
				this.type = "MinecartRideable";
			}

			return this.type;
		} else {
			return this.getNextEntry().type;
		}
	}

	public void setType(String type) {
		this.type = type;
	}

	private boolean isNearPlayer() {
		BlockPos blockPos = this.getPos();
		return this.getWorld().isPlayerWithinRange(blockPos.getX() + 0.5, blockPos.getY() + 0.5, blockPos.getZ() + 0.5, this.requiredPlayerRange);
	}

	public void tick() {
		if (this.isNearPlayer()) {
			BlockPos blockPos = this.getPos();
			if (this.getWorld().isClient) {
				double d = blockPos.getX() + this.getWorld().random.nextFloat();
				double e = blockPos.getY() + this.getWorld().random.nextFloat();
				double f = blockPos.getZ() + this.getWorld().random.nextFloat();
				this.getWorld().addParticle(ParticleType.SMOKE_NORMAL, d, e, f, 0.0, 0.0, 0.0);
				this.getWorld().addParticle(ParticleType.FLAME, d, e, f, 0.0, 0.0, 0.0);
				if (this.delay > 0) {
					this.delay--;
				}

				this.lastRotation = this.rotation;
				this.rotation = (this.rotation + 1000.0F / (this.delay + 200.0F)) % 360.0;
			} else {
				if (this.delay == -1) {
					this.delay();
				}

				if (this.delay > 0) {
					this.delay--;
					return;
				}

				boolean bl = false;

				for (int i = 0; i < this.spawnCount; i++) {
					Entity entity = Entities.createSilently(this.getType(), this.getWorld());
					if (entity == null) {
						return;
					}

					int j = this.getWorld()
						.getEntitiesOfType(
							entity.getClass(),
							new Box(blockPos.getX(), blockPos.getY(), blockPos.getZ(), blockPos.getX() + 1, blockPos.getY() + 1, blockPos.getZ() + 1)
								.grown(this.spawnRange, this.spawnRange, this.spawnRange)
						)
						.size();
					if (j >= this.maxNearbyEntities) {
						this.delay();
						return;
					}

					double f = blockPos.getX() + (this.getWorld().random.nextDouble() - this.getWorld().random.nextDouble()) * this.spawnRange + 0.5;
					double g = blockPos.getY() + this.getWorld().random.nextInt(3) - 1;
					double h = blockPos.getZ() + (this.getWorld().random.nextDouble() - this.getWorld().random.nextDouble()) * this.spawnRange + 0.5;
					MobEntity mobEntity = entity instanceof MobEntity ? (MobEntity)entity : null;
					entity.setPositionAndAngles(f, g, h, this.getWorld().random.nextFloat() * 360.0F, 0.0F);
					if (mobEntity == null || mobEntity.canSpawn() && mobEntity.isUnobstructed()) {
						this.prepareEntityForSpawning(entity, true);
						this.getWorld().doEvent(2004, blockPos, 0);
						if (mobEntity != null) {
							mobEntity.animateSpawn();
						}

						bl = true;
					}
				}

				if (bl) {
					this.delay();
				}
			}
		}
	}

	private Entity prepareEntityForSpawning(Entity entity, boolean doSpawn) {
		if (this.getNextEntry() != null) {
			NbtCompound nbtCompound = new NbtCompound();
			entity.writeNbtIfNotMount(nbtCompound);

			for (String string : this.getNextEntry().properties.getKeys()) {
				NbtElement nbtElement = this.getNextEntry().properties.get(string);
				nbtCompound.put(string, nbtElement.copy());
			}

			entity.readNbt(nbtCompound);
			if (entity.world != null && doSpawn) {
				entity.world.addEntity(entity);
			}

			Entity entity2 = entity;

			while (nbtCompound.contains("Riding", NbtTypes.COMPOUND)) {
				NbtCompound nbtCompound2 = nbtCompound.getCompound("Riding");
				Entity entity3 = Entities.createSilently(nbtCompound2.getString("id"), entity.world);
				if (entity3 != null) {
					NbtCompound nbtCompound3 = new NbtCompound();
					entity3.writeNbtIfNotMount(nbtCompound3);

					for (String string2 : nbtCompound2.getKeys()) {
						NbtElement nbtElement2 = nbtCompound2.get(string2);
						nbtCompound3.put(string2, nbtElement2.copy());
					}

					entity3.readNbt(nbtCompound3);
					entity3.setPositionAndAngles(entity2.x, entity2.y, entity2.z, entity2.yaw, entity2.pitch);
					if (entity.world != null && doSpawn) {
						entity.world.addEntity(entity3);
					}

					entity2.startRiding(entity3);
				}

				entity2 = entity3;
				nbtCompound = nbtCompound2;
			}
		} else if (entity instanceof LivingEntity && entity.world != null && doSpawn) {
			if (entity instanceof MobEntity) {
				((MobEntity)entity).initialize(entity.world.getLocalDifficulty(new BlockPos(entity)), null);
			}

			entity.world.addEntity(entity);
		}

		return entity;
	}

	private void delay() {
		if (this.maxSpawnDelay <= this.minSpawnDelay) {
			this.delay = this.minSpawnDelay;
		} else {
			this.delay = this.minSpawnDelay + this.getWorld().random.nextInt(this.maxSpawnDelay - this.minSpawnDelay);
		}

		if (this.spawnPotentials.size() > 0) {
			this.setNextEntry(WeightedPicker.pick(this.getWorld().random, this.spawnPotentials));
		}

		this.broacastEvent(1);
	}

	public void readNbt(NbtCompound nbt) {
		this.type = nbt.getString("EntityId");
		this.delay = nbt.getShort("Delay");
		this.spawnPotentials.clear();
		if (nbt.contains("SpawnPotentials", NbtTypes.LIST)) {
			NbtList nbtList = nbt.getList("SpawnPotentials", NbtTypes.COMPOUND);

			for (int i = 0; i < nbtList.size(); i++) {
				this.spawnPotentials.add(new MobSpawner.Entry(nbtList.getCompound(i)));
			}
		}

		if (nbt.contains("SpawnData", NbtTypes.COMPOUND)) {
			this.setNextEntry(new MobSpawner.Entry(nbt.getCompound("SpawnData"), this.type));
		} else {
			this.setNextEntry(null);
		}

		if (nbt.contains("MinSpawnDelay", 99)) {
			this.minSpawnDelay = nbt.getShort("MinSpawnDelay");
			this.maxSpawnDelay = nbt.getShort("MaxSpawnDelay");
			this.spawnCount = nbt.getShort("SpawnCount");
		}

		if (nbt.contains("MaxNearbyEntities", 99)) {
			this.maxNearbyEntities = nbt.getShort("MaxNearbyEntities");
			this.requiredPlayerRange = nbt.getShort("RequiredPlayerRange");
		}

		if (nbt.contains("SpawnRange", 99)) {
			this.spawnRange = nbt.getShort("SpawnRange");
		}

		if (this.getWorld() != null) {
			this.displayEntity = null;
		}
	}

	public void writeNbt(NbtCompound nbt) {
		String string = this.getType();
		if (!StringUtils.isStringEmpty(string)) {
			nbt.putString("EntityId", string);
			nbt.putShort("Delay", (short)this.delay);
			nbt.putShort("MinSpawnDelay", (short)this.minSpawnDelay);
			nbt.putShort("MaxSpawnDelay", (short)this.maxSpawnDelay);
			nbt.putShort("SpawnCount", (short)this.spawnCount);
			nbt.putShort("MaxNearbyEntities", (short)this.maxNearbyEntities);
			nbt.putShort("RequiredPlayerRange", (short)this.requiredPlayerRange);
			nbt.putShort("SpawnRange", (short)this.spawnRange);
			if (this.getNextEntry() != null) {
				nbt.put("SpawnData", this.getNextEntry().properties.copy());
			}

			if (this.getNextEntry() != null || this.spawnPotentials.size() > 0) {
				NbtList nbtList = new NbtList();
				if (this.spawnPotentials.size() > 0) {
					for (MobSpawner.Entry entry : this.spawnPotentials) {
						nbtList.addElement(entry.toNbt());
					}
				} else {
					nbtList.addElement(this.getNextEntry().toNbt());
				}

				nbt.put("SpawnPotentials", nbtList);
			}
		}
	}

	@Environment(EnvType.CLIENT)
	public Entity getDisplayEntity(World world) {
		if (this.displayEntity == null) {
			Entity entity = Entities.createSilently(this.getType(), world);
			if (entity != null) {
				entity = this.prepareEntityForSpawning(entity, false);
				this.displayEntity = entity;
			}
		}

		return this.displayEntity;
	}

	public boolean doEvent(int event) {
		if (event == 1 && this.getWorld().isClient) {
			this.delay = this.minSpawnDelay;
			return true;
		} else {
			return false;
		}
	}

	private MobSpawner.Entry getNextEntry() {
		return this.nextEntry;
	}

	public void setNextEntry(MobSpawner.Entry entry) {
		this.nextEntry = entry;
	}

	public abstract void broacastEvent(int event);

	public abstract World getWorld();

	public abstract BlockPos getPos();

	@Environment(EnvType.CLIENT)
	public double getRotation() {
		return this.rotation;
	}

	@Environment(EnvType.CLIENT)
	public double getLastRotation() {
		return this.lastRotation;
	}

	public class Entry extends WeightedPicker.Entry {
		private final NbtCompound properties;
		private final String type;

		public Entry(NbtCompound properties) {
			this(properties.getCompound("Properties"), properties.getString("Type"), properties.getInt("Weight"));
		}

		public Entry(NbtCompound nbt, String type) {
			this(nbt, type, 1);
		}

		private Entry(NbtCompound properties, String type, int weight) {
			super(weight);
			if (type.equals("Minecart")) {
				if (properties != null) {
					type = MinecartEntity.Type.byIndex(properties.getInt("Type")).getName();
				} else {
					type = "MinecartRideable";
				}
			}

			this.properties = properties;
			this.type = type;
		}

		public NbtCompound toNbt() {
			NbtCompound nbtCompound = new NbtCompound();
			nbtCompound.put("Properties", this.properties);
			nbtCompound.putString("Type", this.type);
			nbtCompound.putInt("Weight", this.weight);
			return nbtCompound;
		}
	}
}

package net.minecraft.client.render.entity.layer;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.block.entity.SkullRenderer;
import net.minecraft.client.render.model.ModelPart;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.resource.model.ModelTransformations;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.mob.monster.ZombieEntity;
import net.minecraft.entity.living.mob.passive.VillagerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.text.StringUtils;
import net.minecraft.util.math.Direction;
import net.ornithemc.feather.constants.NbtTypes;

@Environment(EnvType.CLIENT)
public class WornSkullLayer implements EntityRenderLayer<LivingEntity> {
	private final ModelPart model;

	public WornSkullLayer(ModelPart model) {
		this.model = model;
	}

	@Override
	public void render(LivingEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale) {
		ItemStack itemStack = entity.getArmor(3);
		if (itemStack != null && itemStack.getItem() != null) {
			Item item = itemStack.getItem();
			Minecraft minecraft = Minecraft.getInstance();
			GlStateManager.pushMatrix();
			if (entity.isSneaking()) {
				GlStateManager.translatef(0.0F, 0.2F, 0.0F);
			}

			boolean bl = entity instanceof VillagerEntity || entity instanceof ZombieEntity && ((ZombieEntity)entity).isVillager();
			if (!bl && entity.isBaby()) {
				float f = 2.0F;
				float g = 1.4F;
				GlStateManager.scalef(g / f, g / f, g / f);
				GlStateManager.translatef(0.0F, 16.0F * scale, 0.0F);
			}

			this.model.transform(0.0625F);
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			if (item instanceof BlockItem) {
				float f = 0.625F;
				GlStateManager.translatef(0.0F, -0.25F, 0.0F);
				GlStateManager.rotatef(180.0F, 0.0F, 1.0F, 0.0F);
				GlStateManager.scalef(f, -f, -f);
				if (bl) {
					GlStateManager.translatef(0.0F, 0.1875F, 0.0F);
				}

				minecraft.getItemInHandRenderer().render(entity, itemStack, ModelTransformations.Type.HEAD);
			} else if (item == Items.SKULL) {
				float f = 1.1875F;
				GlStateManager.scalef(f, -f, -f);
				if (bl) {
					GlStateManager.translatef(0.0F, 0.0625F, 0.0F);
				}

				GameProfile gameProfile = null;
				if (itemStack.hasNbt()) {
					NbtCompound nbtCompound = itemStack.getNbt();
					if (nbtCompound.contains("SkullOwner", NbtTypes.COMPOUND)) {
						gameProfile = NbtUtils.readProfile(nbtCompound.getCompound("SkullOwner"));
					} else if (nbtCompound.contains("SkullOwner", NbtTypes.STRING)) {
						String string = nbtCompound.getString("SkullOwner");
						if (!StringUtils.isStringEmpty(string)) {
							gameProfile = SkullBlockEntity.updateProfile(new GameProfile(null, string));
							nbtCompound.put("SkullOwner", NbtUtils.writeProfile(new NbtCompound(), gameProfile));
						}
					}
				}

				SkullRenderer.INSTANCE.render(-0.5F, 0.0F, -0.5F, Direction.UP, 180.0F, itemStack.getMetadata(), gameProfile, -1);
			}

			GlStateManager.popMatrix();
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return true;
	}
}

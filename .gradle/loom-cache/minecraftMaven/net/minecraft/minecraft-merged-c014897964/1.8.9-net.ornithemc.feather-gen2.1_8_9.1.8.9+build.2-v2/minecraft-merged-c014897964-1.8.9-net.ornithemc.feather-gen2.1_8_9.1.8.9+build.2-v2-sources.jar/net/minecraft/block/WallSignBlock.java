package net.minecraft.block;

import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.DirectionProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

public class WallSignBlock extends SignBlock {
	public static final DirectionProperty FACING = DirectionProperty.of("facing", Direction.Plane.HORIZONTAL);

	public WallSignBlock() {
		this.setDefaultState(this.stateDefinition.any().set(FACING, Direction.NORTH));
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		Direction direction = world.getBlockState(pos).get(FACING);
		float f = 0.28125F;
		float g = 0.78125F;
		float h = 0.0F;
		float i = 1.0F;
		float j = 0.125F;
		this.setShape(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		switch (direction) {
			case NORTH:
				this.setShape(h, f, 1.0F - j, i, g, 1.0F);
				break;
			case SOUTH:
				this.setShape(h, f, 0.0F, i, g, j);
				break;
			case WEST:
				this.setShape(1.0F - j, f, h, 1.0F, g, i);
				break;
			case EAST:
				this.setShape(0.0F, f, h, j, g, i);
		}
	}

	@Override
	public void neighborChanged(World world, BlockPos pos, BlockState state, Block neighborBlock) {
		Direction direction = state.get(FACING);
		if (!world.getBlockState(pos.offset(direction.getOpposite())).getBlock().getMaterial().isSolid()) {
			this.dropItems(world, pos, state, 0);
			world.removeBlock(pos);
		}

		super.neighborChanged(world, pos, state, neighborBlock);
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		Direction direction = Direction.byId(metadata);
		if (direction.getAxis() == Direction.Axis.Y) {
			direction = Direction.NORTH;
		}

		return this.defaultState().set(FACING, direction);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		return state.get(FACING).getId();
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, FACING);
	}
}

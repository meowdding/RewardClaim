package net.minecraft.client.render.entity;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.global.LightningBoltEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class LightningBoltRenderer extends EntityRenderer<LightningBoltEntity> {
	public LightningBoltRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
	}

	public void render(LightningBoltEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		GlStateManager.disableTexture();
		GlStateManager.disableLighting();
		GlStateManager.enableBlend();
		GlStateManager.blendFunc(770, 1);
		double[] ds = new double[8];
		double[] es = new double[8];
		double d = 0.0;
		double e = 0.0;
		Random random = new Random(entity.seed);

		for (int i = 7; i >= 0; i--) {
			ds[i] = d;
			es[i] = e;
			d += random.nextInt(11) - 5;
			e += random.nextInt(11) - 5;
		}

		for (int j = 0; j < 4; j++) {
			Random random2 = new Random(entity.seed);

			for (int k = 0; k < 3; k++) {
				int l = 7;
				int m = 0;
				if (k > 0) {
					l = 7 - k;
				}

				if (k > 0) {
					m = l - 2;
				}

				double f = ds[l] - d;
				double g = es[l] - e;

				for (int n = l; n >= m; n--) {
					double h = f;
					double o = g;
					if (k == 0) {
						f += random2.nextInt(11) - 5;
						g += random2.nextInt(11) - 5;
					} else {
						f += random2.nextInt(31) - 15;
						g += random2.nextInt(31) - 15;
					}

					bufferBuilder.begin(5, DefaultVertexFormat.POSITION_COLOR);
					float p = 0.5F;
					float q = 0.45F;
					float r = 0.45F;
					float s = 0.5F;
					double t = 0.1 + j * 0.2;
					if (k == 0) {
						t *= n * 0.1 + 1.0;
					}

					double u = 0.1 + j * 0.2;
					if (k == 0) {
						u *= (n - 1) * 0.1 + 1.0;
					}

					for (int v = 0; v < 5; v++) {
						double w = dx + 0.5 - t;
						double x = dz + 0.5 - t;
						if (v == 1 || v == 2) {
							w += t * 2.0;
						}

						if (v == 2 || v == 3) {
							x += t * 2.0;
						}

						double y = dx + 0.5 - u;
						double z = dz + 0.5 - u;
						if (v == 1 || v == 2) {
							y += u * 2.0;
						}

						if (v == 2 || v == 3) {
							z += u * 2.0;
						}

						bufferBuilder.vertex(y + f, dy + n * 16, z + g).color(0.45F, 0.45F, 0.5F, 0.3F).nextVertex();
						bufferBuilder.vertex(w + h, dy + (n + 1) * 16, x + o).color(0.45F, 0.45F, 0.5F, 0.3F).nextVertex();
					}

					tesselator.end();
				}
			}
		}

		GlStateManager.disableBlend();
		GlStateManager.enableLighting();
		GlStateManager.enableTexture();
	}

	protected Identifier getTextureLocation(LightningBoltEntity entity) {
		return null;
	}
}

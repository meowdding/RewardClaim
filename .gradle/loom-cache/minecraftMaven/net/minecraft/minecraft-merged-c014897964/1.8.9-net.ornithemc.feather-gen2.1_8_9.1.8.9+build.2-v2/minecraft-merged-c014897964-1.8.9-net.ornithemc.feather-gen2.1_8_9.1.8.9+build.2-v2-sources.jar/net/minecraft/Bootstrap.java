package net.minecraft;

import com.mojang.authlib.GameProfile;
import java.io.PrintStream;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.FireBlock;
import net.minecraft.block.LiquidBlock;
import net.minecraft.block.PumpkinBlock;
import net.minecraft.block.SkullBlock;
import net.minecraft.block.TntBlock;
import net.minecraft.block.dispenser.DispenseBehavior;
import net.minecraft.block.dispenser.DispenseItemBehavior;
import net.minecraft.block.dispenser.DispenseProjectileBehavior;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.entity.Dispensable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.FireworksEntity;
import net.minecraft.entity.PrimedTntEntity;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.mob.MobEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.EggEntity;
import net.minecraft.entity.projectile.ExperienceBottleEntity;
import net.minecraft.entity.projectile.PotionEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.entity.projectile.SnowballEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.item.BucketItem;
import net.minecraft.item.DyeColor;
import net.minecraft.item.DyeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PotionItem;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.stat.Stats;
import net.minecraft.text.StringUtils;
import net.minecraft.util.PrintStreamLogger;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.IPosition;
import net.minecraft.world.IBlockSource;
import net.minecraft.world.World;
import net.ornithemc.feather.constants.NbtTypes;
import net.ornithemc.feather.constants.SetBlockFlags;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Bootstrap {
	private static final PrintStream SYSOUT = System.out;
	private static boolean initialized = false;
	private static final Logger LOGGER = LogManager.getLogger();

	public static boolean isInitialized() {
		return initialized;
	}

	static void registerDispenseBehaviors() {
		DispenserBlock.BEHAVIORS.put(Items.ARROW, new DispenseProjectileBehavior() {
			@Override
			protected Dispensable createProjectile(World world, IPosition pos) {
				ArrowEntity arrowEntity = new ArrowEntity(world, pos.getX(), pos.getY(), pos.getZ());
				arrowEntity.pickup = 1;
				return arrowEntity;
			}
		});
		DispenserBlock.BEHAVIORS.put(Items.EGG, new DispenseProjectileBehavior() {
			@Override
			protected Dispensable createProjectile(World world, IPosition pos) {
				return new EggEntity(world, pos.getX(), pos.getY(), pos.getZ());
			}
		});
		DispenserBlock.BEHAVIORS.put(Items.SNOWBALL, new DispenseProjectileBehavior() {
			@Override
			protected Dispensable createProjectile(World world, IPosition pos) {
				return new SnowballEntity(world, pos.getX(), pos.getY(), pos.getZ());
			}
		});
		DispenserBlock.BEHAVIORS.put(Items.EXPERIENCE_BOTTLE, new DispenseProjectileBehavior() {
			@Override
			protected Dispensable createProjectile(World world, IPosition pos) {
				return new ExperienceBottleEntity(world, pos.getX(), pos.getY(), pos.getZ());
			}

			@Override
			protected float getVariation() {
				return super.getVariation() * 0.5F;
			}

			@Override
			protected float getForce() {
				return super.getForce() * 1.25F;
			}
		});
		DispenserBlock.BEHAVIORS.put(Items.POTION, new DispenseBehavior() {
			private final DispenseItemBehavior fallback = new DispenseItemBehavior();

			@Override
			public ItemStack dispense(IBlockSource source, ItemStack item) {
				return PotionItem.isSplashPotion(item.getMetadata()) ? (new DispenseProjectileBehavior() {
					@Override
					protected Dispensable createProjectile(World world, IPosition pos) {
						return new PotionEntity(world, pos.getX(), pos.getY(), pos.getZ(), item.copy());
					}

					@Override
					protected float getVariation() {
						return super.getVariation() * 0.5F;
					}

					@Override
					protected float getForce() {
						return super.getForce() * 1.25F;
					}
				}).dispense(source, item) : this.fallback.dispense(source, item);
			}
		});
		DispenserBlock.BEHAVIORS.put(Items.SPAWN_EGG, new DispenseItemBehavior() {
			@Override
			public ItemStack dispenseItem(IBlockSource source, ItemStack item) {
				Direction direction = DispenserBlock.getDirection(source.getBlockMetadata());
				double d = source.getX() + direction.getOffsetX();
				double e = source.getPos().getY() + 0.2F;
				double f = source.getZ() + direction.getOffsetZ();
				Entity entity = SpawnEggItem.spawnEntity(source.getWorld(), item.getMetadata(), d, e, f);
				if (entity instanceof LivingEntity && item.hasCustomHoverName()) {
					((MobEntity)entity).setCustomName(item.getHoverName());
				}

				item.split(1);
				return item;
			}
		});
		DispenserBlock.BEHAVIORS.put(Items.FIREWORKS, new DispenseItemBehavior() {
			@Override
			public ItemStack dispenseItem(IBlockSource source, ItemStack item) {
				Direction direction = DispenserBlock.getDirection(source.getBlockMetadata());
				double d = source.getX() + direction.getOffsetX();
				double e = source.getPos().getY() + 0.2F;
				double f = source.getZ() + direction.getOffsetZ();
				FireworksEntity fireworksEntity = new FireworksEntity(source.getWorld(), d, e, f, item);
				source.getWorld().addEntity(fireworksEntity);
				item.split(1);
				return item;
			}

			@Override
			protected void playSound(IBlockSource source) {
				source.getWorld().doEvent(1002, source.getPos(), 0);
			}
		});
		DispenserBlock.BEHAVIORS.put(Items.FIRE_CHARGE, new DispenseItemBehavior() {
			@Override
			public ItemStack dispenseItem(IBlockSource source, ItemStack item) {
				Direction direction = DispenserBlock.getDirection(source.getBlockMetadata());
				IPosition iPosition = DispenserBlock.getDispensePos(source);
				double d = iPosition.getX() + direction.getOffsetX() * 0.3F;
				double e = iPosition.getY() + direction.getOffsetY() * 0.3F;
				double f = iPosition.getZ() + direction.getOffsetZ() * 0.3F;
				World world = source.getWorld();
				Random random = world.random;
				double g = random.nextGaussian() * 0.05 + direction.getOffsetX();
				double h = random.nextGaussian() * 0.05 + direction.getOffsetY();
				double i = random.nextGaussian() * 0.05 + direction.getOffsetZ();
				world.addEntity(new SmallFireballEntity(world, d, e, f, g, h, i));
				item.split(1);
				return item;
			}

			@Override
			protected void playSound(IBlockSource source) {
				source.getWorld().doEvent(1009, source.getPos(), 0);
			}
		});
		DispenserBlock.BEHAVIORS.put(Items.BOAT, new DispenseItemBehavior() {
			private final DispenseItemBehavior fallback = new DispenseItemBehavior();

			@Override
			public ItemStack dispenseItem(IBlockSource source, ItemStack item) {
				Direction direction = DispenserBlock.getDirection(source.getBlockMetadata());
				World world = source.getWorld();
				double d = source.getX() + direction.getOffsetX() * 1.125F;
				double e = source.getY() + direction.getOffsetY() * 1.125F;
				double f = source.getZ() + direction.getOffsetZ() * 1.125F;
				BlockPos blockPos = source.getPos().offset(direction);
				Material material = world.getBlockState(blockPos).getBlock().getMaterial();
				double g;
				if (Material.WATER.equals(material)) {
					g = 1.0;
				} else {
					if (!Material.AIR.equals(material) || !Material.WATER.equals(world.getBlockState(blockPos.down()).getBlock().getMaterial())) {
						return this.fallback.dispense(source, item);
					}

					g = 0.0;
				}

				BoatEntity boatEntity = new BoatEntity(world, d, e + g, f);
				world.addEntity(boatEntity);
				item.split(1);
				return item;
			}

			@Override
			protected void playSound(IBlockSource source) {
				source.getWorld().doEvent(1000, source.getPos(), 0);
			}
		});
		DispenseBehavior dispenseBehavior = new DispenseItemBehavior() {
			private final DispenseItemBehavior fallback = new DispenseItemBehavior();

			@Override
			public ItemStack dispenseItem(IBlockSource source, ItemStack item) {
				BucketItem bucketItem = (BucketItem)item.getItem();
				BlockPos blockPos = source.getPos().offset(DispenserBlock.getDirection(source.getBlockMetadata()));
				if (bucketItem.place(source.getWorld(), blockPos)) {
					item.setItem(Items.BUCKET);
					item.size = 1;
					return item;
				} else {
					return this.fallback.dispense(source, item);
				}
			}
		};
		DispenserBlock.BEHAVIORS.put(Items.LAVA_BUCKET, dispenseBehavior);
		DispenserBlock.BEHAVIORS.put(Items.WATER_BUCKET, dispenseBehavior);
		DispenserBlock.BEHAVIORS.put(Items.BUCKET, new DispenseItemBehavior() {
			private final DispenseItemBehavior fallback = new DispenseItemBehavior();

			@Override
			public ItemStack dispenseItem(IBlockSource source, ItemStack item) {
				World world = source.getWorld();
				BlockPos blockPos = source.getPos().offset(DispenserBlock.getDirection(source.getBlockMetadata()));
				BlockState blockState = world.getBlockState(blockPos);
				Block block = blockState.getBlock();
				Material material = block.getMaterial();
				Item item2;
				if (Material.WATER.equals(material) && block instanceof LiquidBlock && blockState.get(LiquidBlock.LEVEL) == 0) {
					item2 = Items.WATER_BUCKET;
				} else {
					if (!Material.LAVA.equals(material) || !(block instanceof LiquidBlock) || blockState.get(LiquidBlock.LEVEL) != 0) {
						return super.dispenseItem(source, item);
					}

					item2 = Items.LAVA_BUCKET;
				}

				world.removeBlock(blockPos);
				if (--item.size == 0) {
					item.setItem(item2);
					item.size = 1;
				} else if (source.<DispenserBlockEntity>getBlockEntity().insertItem(new ItemStack(item2)) < 0) {
					this.fallback.dispense(source, new ItemStack(item2));
				}

				return item;
			}
		});
		DispenserBlock.BEHAVIORS.put(Items.FLINT_AND_STEEL, new DispenseItemBehavior() {
			private boolean ignited = true;

			@Override
			protected ItemStack dispenseItem(IBlockSource source, ItemStack item) {
				World world = source.getWorld();
				BlockPos blockPos = source.getPos().offset(DispenserBlock.getDirection(source.getBlockMetadata()));
				if (world.isAir(blockPos)) {
					world.setBlockState(blockPos, Blocks.FIRE.defaultState());
					if (item.takeDamage(1, world.random)) {
						item.size = 0;
					}
				} else if (world.getBlockState(blockPos).getBlock() == Blocks.TNT) {
					Blocks.TNT.onBroken(world, blockPos, Blocks.TNT.defaultState().set(TntBlock.EXPLODE, true));
					world.removeBlock(blockPos);
				} else {
					this.ignited = false;
				}

				return item;
			}

			@Override
			protected void playSound(IBlockSource source) {
				if (this.ignited) {
					source.getWorld().doEvent(1000, source.getPos(), 0);
				} else {
					source.getWorld().doEvent(1001, source.getPos(), 0);
				}
			}
		});
		DispenserBlock.BEHAVIORS.put(Items.DYE, new DispenseItemBehavior() {
			private boolean dyed = true;

			@Override
			protected ItemStack dispenseItem(IBlockSource source, ItemStack item) {
				if (DyeColor.WHITE == DyeColor.byMetadata(item.getMetadata())) {
					World world = source.getWorld();
					BlockPos blockPos = source.getPos().offset(DispenserBlock.getDirection(source.getBlockMetadata()));
					if (DyeItem.fertilize(item, world, blockPos)) {
						if (!world.isClient) {
							world.doEvent(2005, blockPos, 0);
						}
					} else {
						this.dyed = false;
					}

					return item;
				} else {
					return super.dispenseItem(source, item);
				}
			}

			@Override
			protected void playSound(IBlockSource source) {
				if (this.dyed) {
					source.getWorld().doEvent(1000, source.getPos(), 0);
				} else {
					source.getWorld().doEvent(1001, source.getPos(), 0);
				}
			}
		});
		DispenserBlock.BEHAVIORS.put(Item.byBlock(Blocks.TNT), new DispenseItemBehavior() {
			@Override
			protected ItemStack dispenseItem(IBlockSource source, ItemStack item) {
				World world = source.getWorld();
				BlockPos blockPos = source.getPos().offset(DispenserBlock.getDirection(source.getBlockMetadata()));
				PrimedTntEntity primedTntEntity = new PrimedTntEntity(world, blockPos.getX() + 0.5, blockPos.getY(), blockPos.getZ() + 0.5, null);
				world.addEntity(primedTntEntity);
				world.playSound(primedTntEntity, "game.tnt.primed", 1.0F, 1.0F);
				item.size--;
				return item;
			}
		});
		DispenserBlock.BEHAVIORS
			.put(
				Items.SKULL,
				new DispenseItemBehavior() {
					private boolean spawnedWither = true;

					@Override
					protected ItemStack dispenseItem(IBlockSource source, ItemStack item) {
						World world = source.getWorld();
						Direction direction = DispenserBlock.getDirection(source.getBlockMetadata());
						BlockPos blockPos = source.getPos().offset(direction);
						SkullBlock skullBlock = Blocks.SKULL;
						if (!world.isAir(blockPos) || !skullBlock.canSpawn(world, blockPos, item)) {
							this.spawnedWither = false;
						} else if (!world.isClient) {
							world.setBlockState(
								blockPos, skullBlock.defaultState().set(SkullBlock.FACING, Direction.UP), SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS
							);
							BlockEntity blockEntity = world.getBlockEntity(blockPos);
							if (blockEntity instanceof SkullBlockEntity) {
								if (item.getMetadata() == 3) {
									GameProfile gameProfile = null;
									if (item.hasNbt()) {
										NbtCompound nbtCompound = item.getNbt();
										if (nbtCompound.contains("SkullOwner", NbtTypes.COMPOUND)) {
											gameProfile = NbtUtils.readProfile(nbtCompound.getCompound("SkullOwner"));
										} else if (nbtCompound.contains("SkullOwner", NbtTypes.STRING)) {
											String string = nbtCompound.getString("SkullOwner");
											if (!StringUtils.isStringEmpty(string)) {
												gameProfile = new GameProfile(null, string);
											}
										}
									}

									((SkullBlockEntity)blockEntity).setProfile(gameProfile);
								} else {
									((SkullBlockEntity)blockEntity).setSkullType(item.getMetadata());
								}

								((SkullBlockEntity)blockEntity).setRotation(direction.getOpposite().getIdHorizontal() * 4);
								Blocks.SKULL.trySpawn(world, blockPos, (SkullBlockEntity)blockEntity);
							}

							item.size--;
						}

						return item;
					}

					@Override
					protected void playSound(IBlockSource source) {
						if (this.spawnedWither) {
							source.getWorld().doEvent(1000, source.getPos(), 0);
						} else {
							source.getWorld().doEvent(1001, source.getPos(), 0);
						}
					}
				}
			);
		DispenserBlock.BEHAVIORS.put(Item.byBlock(Blocks.PUMPKIN), new DispenseItemBehavior() {
			private boolean spawnedGolem = true;

			@Override
			protected ItemStack dispenseItem(IBlockSource source, ItemStack item) {
				World world = source.getWorld();
				BlockPos blockPos = source.getPos().offset(DispenserBlock.getDirection(source.getBlockMetadata()));
				PumpkinBlock pumpkinBlock = (PumpkinBlock)Blocks.PUMPKIN;
				if (world.isAir(blockPos) && pumpkinBlock.canSpawnGolem(world, blockPos)) {
					if (!world.isClient) {
						world.setBlockState(blockPos, pumpkinBlock.defaultState(), SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
					}

					item.size--;
				} else {
					this.spawnedGolem = false;
				}

				return item;
			}

			@Override
			protected void playSound(IBlockSource source) {
				if (this.spawnedGolem) {
					source.getWorld().doEvent(1000, source.getPos(), 0);
				} else {
					source.getWorld().doEvent(1001, source.getPos(), 0);
				}
			}
		});
	}

	public static void init() {
		if (!initialized) {
			initialized = true;
			if (LOGGER.isDebugEnabled()) {
				wrapPrintStreams();
			}

			Block.init();
			FireBlock.init();
			Item.init();
			Stats.init();
			registerDispenseBehaviors();
		}
	}

	private static void wrapPrintStreams() {
		System.setErr(new PrintStreamLogger("STDERR", System.err));
		System.setOut(new PrintStreamLogger("STDOUT", SYSOUT));
	}

	@Environment(EnvType.CLIENT)
	public static void sysout(String x) {
		SYSOUT.println(x);
	}
}

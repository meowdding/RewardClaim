package net.minecraft.client.gui.screen.game.inventory;

import com.google.common.collect.Sets;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.render.texture.TextureAtlasSprite;
import net.minecraft.entity.living.player.PlayerInventory;
import net.minecraft.inventory.menu.InventoryMenu;
import net.minecraft.inventory.slot.InventorySlot;
import net.minecraft.item.ItemStack;
import net.minecraft.resource.Identifier;
import net.minecraft.text.Formatting;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.input.Keyboard;

@Environment(EnvType.CLIENT)
public abstract class InventoryMenuScreen extends Screen {
	protected static final Identifier MENU_LOCATION = new Identifier("textures/gui/container/inventory.png");
	protected int backgroundWidth = 176;
	protected int backgroundHeight = 166;
	public InventoryMenu menu;
	protected int x;
	protected int y;
	private InventorySlot hoveredSlot;
	private InventorySlot touchDragSlotStart;
	private boolean touchIsRightClickDrag;
	private ItemStack touchDraggedItem;
	private int touchDropX;
	private int touchDropY;
	private InventorySlot touchDropOriginSlot;
	private long touchDropTime;
	private ItemStack touchDropReturningItem;
	private InventorySlot draggedInvSlot;
	private long touchDropTimer;
	protected final Set<InventorySlot> draggedInvSlots = Sets.newHashSet();
	protected boolean isDraggingItem;
	/**
	 * The mode of dragging the item stack.
	 * <br>0: split evenly across all slots
	 * <br>1: add 1 item to every slot
	 */
	private int clickDragMode;
	/**
	 * The mouse button that is used to drag the item stack
	 */
	private int clickDragButton;
	private boolean cancelNextMouseRelease;
	private int draggedItemRemainder;
	private long lastButtonClickTime;
	private InventorySlot clickedInvSlot;
	private int lastClickedButton;
	private boolean isDoubleClicking;
	private ItemStack shiftClickedItem;

	public InventoryMenuScreen(InventoryMenu menu) {
		this.menu = menu;
		this.cancelNextMouseRelease = true;
	}

	@Override
	public void init() {
		super.init();
		this.minecraft.player.menu = this.menu;
		this.x = (this.width - this.backgroundWidth) / 2;
		this.y = (this.height - this.backgroundHeight) / 2;
	}

	@Override
	public void render(int mouseX, int mouseY, float tickDelta) {
		this.renderBackground();
		int i = this.x;
		int j = this.y;
		this.renderMenuBackground(tickDelta, mouseX, mouseY);
		GlStateManager.disableRescaleNormal();
		Lighting.turnOff();
		GlStateManager.disableLighting();
		GlStateManager.disableDepthTest();
		super.render(mouseX, mouseY, tickDelta);
		Lighting.turnOnGui();
		GlStateManager.pushMatrix();
		GlStateManager.translatef(i, j, 0.0F);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.enableRescaleNormal();
		this.hoveredSlot = null;
		int k = 240;
		int l = 240;
		GLX.multiTexCoord2f(GLX.GL_TEXTURE1, k / 1.0F, l / 1.0F);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);

		for (int m = 0; m < this.menu.slots.size(); m++) {
			InventorySlot inventorySlot = this.menu.slots.get(m);
			this.renderSlot(inventorySlot);
			if (this.isMouseOverSlot(inventorySlot, mouseX, mouseY) && inventorySlot.isActive()) {
				this.hoveredSlot = inventorySlot;
				GlStateManager.disableLighting();
				GlStateManager.disableDepthTest();
				int n = inventorySlot.x;
				int o = inventorySlot.y;
				GlStateManager.colorMask(true, true, true, false);
				this.fillGradient(n, o, n + 16, o + 16, -2130706433, -2130706433);
				GlStateManager.colorMask(true, true, true, true);
				GlStateManager.enableLighting();
				GlStateManager.enableDepthTest();
			}
		}

		Lighting.turnOff();
		this.renderLabels(mouseX, mouseY);
		Lighting.turnOnGui();
		PlayerInventory playerInventory = this.minecraft.player.inventory;
		ItemStack itemStack = this.touchDraggedItem == null ? playerInventory.getCursorItem() : this.touchDraggedItem;
		if (itemStack != null) {
			int n = 8;
			int o = this.touchDraggedItem == null ? 8 : 16;
			String string = null;
			if (this.touchDraggedItem != null && this.touchIsRightClickDrag) {
				itemStack = itemStack.copy();
				itemStack.size = MathHelper.ceil(itemStack.size / 2.0F);
			} else if (this.isDraggingItem && this.draggedInvSlots.size() > 1) {
				itemStack = itemStack.copy();
				itemStack.size = this.draggedItemRemainder;
				if (itemStack.size == 0) {
					string = "" + Formatting.YELLOW + "0";
				}
			}

			this.drawItem(itemStack, mouseX - i - n, mouseY - j - o, string);
		}

		if (this.touchDropReturningItem != null) {
			float f = (float)(Minecraft.getTime() - this.touchDropTime) / 100.0F;
			if (f >= 1.0F) {
				f = 1.0F;
				this.touchDropReturningItem = null;
			}

			int o = this.touchDropOriginSlot.x - this.touchDropX;
			int p = this.touchDropOriginSlot.y - this.touchDropY;
			int q = this.touchDropX + (int)(o * f);
			int r = this.touchDropY + (int)(p * f);
			this.drawItem(this.touchDropReturningItem, q, r, null);
		}

		GlStateManager.popMatrix();
		if (playerInventory.getCursorItem() == null && this.hoveredSlot != null && this.hoveredSlot.hasItem()) {
			ItemStack itemStack2 = this.hoveredSlot.getItem();
			this.renderTooltip(itemStack2, mouseX, mouseY);
		}

		GlStateManager.enableLighting();
		GlStateManager.enableDepthTest();
		Lighting.turnOn();
	}

	private void drawItem(ItemStack item, int x, int y, String itemInfo) {
		GlStateManager.translatef(0.0F, 0.0F, 32.0F);
		this.drawOffset = 200.0F;
		this.itemRenderer.zOffset = 200.0F;
		this.itemRenderer.renderGuiItem(item, x, y);
		this.itemRenderer.renderGuiItemDecorations(this.textRenderer, item, x, y - (this.touchDraggedItem == null ? 0 : 8), itemInfo);
		this.drawOffset = 0.0F;
		this.itemRenderer.zOffset = 0.0F;
	}

	protected void renderLabels(int mouseX, int mouseY) {
	}

	protected abstract void renderMenuBackground(float tickDelta, int mouseX, int mouseY);

	private void renderSlot(InventorySlot slot) {
		int i = slot.x;
		int j = slot.y;
		ItemStack itemStack = slot.getItem();
		boolean bl = false;
		boolean bl2 = slot == this.touchDragSlotStart && this.touchDraggedItem != null && !this.touchIsRightClickDrag;
		ItemStack itemStack2 = this.minecraft.player.inventory.getCursorItem();
		String string = null;
		if (slot == this.touchDragSlotStart && this.touchDraggedItem != null && this.touchIsRightClickDrag && itemStack != null) {
			itemStack = itemStack.copy();
			itemStack.size /= 2;
		} else if (this.isDraggingItem && this.draggedInvSlots.contains(slot) && itemStack2 != null) {
			if (this.draggedInvSlots.size() == 1) {
				return;
			}

			if (InventoryMenu.canClickDragInto(slot, itemStack2, true) && this.menu.canClickDragInto(slot)) {
				itemStack = itemStack2.copy();
				bl = true;
				InventoryMenu.updateClickDragStackSize(this.draggedInvSlots, this.clickDragMode, itemStack, slot.getItem() == null ? 0 : slot.getItem().size);
				if (itemStack.size > itemStack.getMaxSize()) {
					string = Formatting.YELLOW + "" + itemStack.getMaxSize();
					itemStack.size = itemStack.getMaxSize();
				}

				if (itemStack.size > slot.getMaxStackSize(itemStack)) {
					string = Formatting.YELLOW + "" + slot.getMaxStackSize(itemStack);
					itemStack.size = slot.getMaxStackSize(itemStack);
				}
			} else {
				this.draggedInvSlots.remove(slot);
				this.updateDraggedStackRemainder();
			}
		}

		this.drawOffset = 100.0F;
		this.itemRenderer.zOffset = 100.0F;
		if (itemStack == null) {
			String string2 = slot.getTexture();
			if (string2 != null) {
				TextureAtlasSprite textureAtlasSprite = this.minecraft.getBlocksAtlas().getSprite(string2);
				GlStateManager.disableLighting();
				this.minecraft.getTextureManager().bind(TextureAtlas.BLOCKS_LOCATION);
				this.drawSprite(i, j, textureAtlasSprite, 16, 16);
				GlStateManager.enableLighting();
				bl2 = true;
			}
		}

		if (!bl2) {
			if (bl) {
				fill(i, j, i + 16, j + 16, -2130706433);
			}

			GlStateManager.enableDepthTest();
			this.itemRenderer.renderGuiItem(itemStack, i, j);
			this.itemRenderer.renderGuiItemDecorations(this.textRenderer, itemStack, i, j, string);
		}

		this.itemRenderer.zOffset = 0.0F;
		this.drawOffset = 0.0F;
	}

	private void updateDraggedStackRemainder() {
		ItemStack itemStack = this.minecraft.player.inventory.getCursorItem();
		if (itemStack != null && this.isDraggingItem) {
			this.draggedItemRemainder = itemStack.size;

			for (InventorySlot inventorySlot : this.draggedInvSlots) {
				ItemStack itemStack2 = itemStack.copy();
				int i = inventorySlot.getItem() == null ? 0 : inventorySlot.getItem().size;
				InventoryMenu.updateClickDragStackSize(this.draggedInvSlots, this.clickDragMode, itemStack2, i);
				if (itemStack2.size > itemStack2.getMaxSize()) {
					itemStack2.size = itemStack2.getMaxSize();
				}

				if (itemStack2.size > inventorySlot.getMaxStackSize(itemStack2)) {
					itemStack2.size = inventorySlot.getMaxStackSize(itemStack2);
				}

				this.draggedItemRemainder = this.draggedItemRemainder - (itemStack2.size - i);
			}
		}
	}

	private InventorySlot getSlot(int x, int y) {
		for (int i = 0; i < this.menu.slots.size(); i++) {
			InventorySlot inventorySlot = this.menu.slots.get(i);
			if (this.isMouseOverSlot(inventorySlot, x, y)) {
				return inventorySlot;
			}
		}

		return null;
	}

	@Override
	protected void mouseClicked(int mouseX, int mouseY, int button) {
		super.mouseClicked(mouseX, mouseY, button);
		boolean bl = button == this.minecraft.options.pickItemKey.getKeyCode() + 100;
		InventorySlot inventorySlot = this.getSlot(mouseX, mouseY);
		long l = Minecraft.getTime();
		this.isDoubleClicking = this.clickedInvSlot == inventorySlot && l - this.lastButtonClickTime < 250L && this.lastClickedButton == button;
		this.cancelNextMouseRelease = false;
		if (button == 0 || button == 1 || bl) {
			int i = this.x;
			int j = this.y;
			boolean bl2 = mouseX < i || mouseY < j || mouseX >= i + this.backgroundWidth || mouseY >= j + this.backgroundHeight;
			int k = -1;
			if (inventorySlot != null) {
				k = inventorySlot.index;
			}

			if (bl2) {
				k = -999;
			}

			if (this.minecraft.options.touchscreen && bl2 && this.minecraft.player.inventory.getCursorItem() == null) {
				this.minecraft.openScreen(null);
				return;
			}

			if (k != -1) {
				if (this.minecraft.options.touchscreen) {
					if (inventorySlot != null && inventorySlot.hasItem()) {
						this.touchDragSlotStart = inventorySlot;
						this.touchDraggedItem = null;
						this.touchIsRightClickDrag = button == 1;
					} else {
						this.touchDragSlotStart = null;
					}
				} else if (!this.isDraggingItem) {
					if (this.minecraft.player.inventory.getCursorItem() == null) {
						if (button == this.minecraft.options.pickItemKey.getKeyCode() + 100) {
							this.clickSlot(inventorySlot, k, button, 3);
						} else {
							boolean bl3 = k != -999 && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54));
							int m = 0;
							if (bl3) {
								this.shiftClickedItem = inventorySlot != null && inventorySlot.hasItem() ? inventorySlot.getItem() : null;
								m = 1;
							} else if (k == -999) {
								m = 4;
							}

							this.clickSlot(inventorySlot, k, button, m);
						}

						this.cancelNextMouseRelease = true;
					} else {
						this.isDraggingItem = true;
						this.clickDragButton = button;
						this.draggedInvSlots.clear();
						if (button == 0) {
							this.clickDragMode = 0;
						} else if (button == 1) {
							this.clickDragMode = 1;
						} else if (button == this.minecraft.options.pickItemKey.getKeyCode() + 100) {
							this.clickDragMode = 2;
						}
					}
				}
			}
		}

		this.clickedInvSlot = inventorySlot;
		this.lastButtonClickTime = l;
		this.lastClickedButton = button;
	}

	@Override
	protected void mouseDragged(int mouseX, int mouseY, int button, long duration) {
		InventorySlot inventorySlot = this.getSlot(mouseX, mouseY);
		ItemStack itemStack = this.minecraft.player.inventory.getCursorItem();
		if (this.touchDragSlotStart != null && this.minecraft.options.touchscreen) {
			if (button == 0 || button == 1) {
				if (this.touchDraggedItem == null) {
					if (inventorySlot != this.touchDragSlotStart && this.touchDragSlotStart.getItem() != null) {
						this.touchDraggedItem = this.touchDragSlotStart.getItem().copy();
					}
				} else if (this.touchDraggedItem.size > 1 && inventorySlot != null && InventoryMenu.canClickDragInto(inventorySlot, this.touchDraggedItem, false)) {
					long l = Minecraft.getTime();
					if (this.draggedInvSlot == inventorySlot) {
						if (l - this.touchDropTimer > 500L) {
							this.clickSlot(this.touchDragSlotStart, this.touchDragSlotStart.index, 0, 0);
							this.clickSlot(inventorySlot, inventorySlot.index, 1, 0);
							this.clickSlot(this.touchDragSlotStart, this.touchDragSlotStart.index, 0, 0);
							this.touchDropTimer = l + 750L;
							this.touchDraggedItem.size--;
						}
					} else {
						this.draggedInvSlot = inventorySlot;
						this.touchDropTimer = l;
					}
				}
			}
		} else if (this.isDraggingItem
			&& inventorySlot != null
			&& itemStack != null
			&& itemStack.size > this.draggedInvSlots.size()
			&& InventoryMenu.canClickDragInto(inventorySlot, itemStack, true)
			&& inventorySlot.isItemAllowed(itemStack)
			&& this.menu.canClickDragInto(inventorySlot)) {
			this.draggedInvSlots.add(inventorySlot);
			this.updateDraggedStackRemainder();
		}
	}

	@Override
	protected void mouseReleased(int mouseX, int mouseY, int button) {
		InventorySlot inventorySlot = this.getSlot(mouseX, mouseY);
		int i = this.x;
		int j = this.y;
		boolean bl = mouseX < i || mouseY < j || mouseX >= i + this.backgroundWidth || mouseY >= j + this.backgroundHeight;
		int k = -1;
		if (inventorySlot != null) {
			k = inventorySlot.index;
		}

		if (bl) {
			k = -999;
		}

		if (this.isDoubleClicking && inventorySlot != null && button == 0 && this.menu.canRemoveForPickupAll(null, inventorySlot)) {
			if (isShiftDown()) {
				if (inventorySlot != null && inventorySlot.inventory != null && this.shiftClickedItem != null) {
					for (InventorySlot inventorySlot2 : this.menu.slots) {
						if (inventorySlot2 != null
							&& inventorySlot2.canPickUp(this.minecraft.player)
							&& inventorySlot2.hasItem()
							&& inventorySlot2.inventory == inventorySlot.inventory
							&& InventoryMenu.canClickDragInto(inventorySlot2, this.shiftClickedItem, true)) {
							this.clickSlot(inventorySlot2, inventorySlot2.index, button, 1);
						}
					}
				}
			} else {
				this.clickSlot(inventorySlot, k, button, 6);
			}

			this.isDoubleClicking = false;
			this.lastButtonClickTime = 0L;
		} else {
			if (this.isDraggingItem && this.clickDragButton != button) {
				this.isDraggingItem = false;
				this.draggedInvSlots.clear();
				this.cancelNextMouseRelease = true;
				return;
			}

			if (this.cancelNextMouseRelease) {
				this.cancelNextMouseRelease = false;
				return;
			}

			if (this.touchDragSlotStart != null && this.minecraft.options.touchscreen) {
				if (button == 0 || button == 1) {
					if (this.touchDraggedItem == null && inventorySlot != this.touchDragSlotStart) {
						this.touchDraggedItem = this.touchDragSlotStart.getItem();
					}

					boolean bl2 = InventoryMenu.canClickDragInto(inventorySlot, this.touchDraggedItem, false);
					if (k != -1 && this.touchDraggedItem != null && bl2) {
						this.clickSlot(this.touchDragSlotStart, this.touchDragSlotStart.index, button, 0);
						this.clickSlot(inventorySlot, k, 0, 0);
						if (this.minecraft.player.inventory.getCursorItem() != null) {
							this.clickSlot(this.touchDragSlotStart, this.touchDragSlotStart.index, button, 0);
							this.touchDropX = mouseX - i;
							this.touchDropY = mouseY - j;
							this.touchDropOriginSlot = this.touchDragSlotStart;
							this.touchDropReturningItem = this.touchDraggedItem;
							this.touchDropTime = Minecraft.getTime();
						} else {
							this.touchDropReturningItem = null;
						}
					} else if (this.touchDraggedItem != null) {
						this.touchDropX = mouseX - i;
						this.touchDropY = mouseY - j;
						this.touchDropOriginSlot = this.touchDragSlotStart;
						this.touchDropReturningItem = this.touchDraggedItem;
						this.touchDropTime = Minecraft.getTime();
					}

					this.touchDraggedItem = null;
					this.touchDragSlotStart = null;
				}
			} else if (this.isDraggingItem && !this.draggedInvSlots.isEmpty()) {
				this.clickSlot(null, -999, InventoryMenu.packClickData(0, this.clickDragMode), 5);

				for (InventorySlot inventorySlot2 : this.draggedInvSlots) {
					this.clickSlot(inventorySlot2, inventorySlot2.index, InventoryMenu.packClickData(1, this.clickDragMode), 5);
				}

				this.clickSlot(null, -999, InventoryMenu.packClickData(2, this.clickDragMode), 5);
			} else if (this.minecraft.player.inventory.getCursorItem() != null) {
				if (button == this.minecraft.options.pickItemKey.getKeyCode() + 100) {
					this.clickSlot(inventorySlot, k, button, 3);
				} else {
					boolean bl2 = k != -999 && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54));
					if (bl2) {
						this.shiftClickedItem = inventorySlot != null && inventorySlot.hasItem() ? inventorySlot.getItem() : null;
					}

					this.clickSlot(inventorySlot, k, button, bl2 ? 1 : 0);
				}
			}
		}

		if (this.minecraft.player.inventory.getCursorItem() == null) {
			this.lastButtonClickTime = 0L;
		}

		this.isDraggingItem = false;
	}

	private boolean isMouseOverSlot(InventorySlot slot, int mouseX, int mouseY) {
		return this.isMouseInRegion(slot.x, slot.y, 16, 16, mouseX, mouseY);
	}

	/**
	 * Determine if the mouse is within the region defined by x, y, width, and height.
	 * The dimensions of the region are relative to this screen.
	 */
	protected boolean isMouseInRegion(int x, int y, int width, int height, int mouseX, int mouseY) {
		int i = this.x;
		int j = this.y;
		mouseX -= i;
		mouseY -= j;
		return mouseX >= x - 1 && mouseX < x + width + 1 && mouseY >= y - 1 && mouseY < y + height + 1;
	}

	protected void clickSlot(InventorySlot actualSlot, int slot, int clickData, int actionType) {
		if (actualSlot != null) {
			slot = actualSlot.index;
		}

		this.minecraft.interactionManager.clickSlot(this.menu.networkId, slot, clickData, actionType, this.minecraft.player);
	}

	@Override
	protected void keyPressed(char chr, int key) {
		if (key == 1 || key == this.minecraft.options.inventoryKey.getKeyCode()) {
			this.minecraft.player.closeMenu();
		}

		this.moveHoveredSlotToHotbar(key);
		if (this.hoveredSlot != null && this.hoveredSlot.hasItem()) {
			if (key == this.minecraft.options.pickItemKey.getKeyCode()) {
				this.clickSlot(this.hoveredSlot, this.hoveredSlot.index, 0, 3);
			} else if (key == this.minecraft.options.dropKey.getKeyCode()) {
				this.clickSlot(this.hoveredSlot, this.hoveredSlot.index, isControlDown() ? 1 : 0, 4);
			}
		}
	}

	protected boolean moveHoveredSlotToHotbar(int key) {
		if (this.minecraft.player.inventory.getCursorItem() == null && this.hoveredSlot != null) {
			for (int i = 0; i < 9; i++) {
				if (key == this.minecraft.options.hotbarKeyBindings[i].getKeyCode()) {
					this.clickSlot(this.hoveredSlot, this.hoveredSlot.index, i, 2);
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public void removed() {
		if (this.minecraft.player != null) {
			this.menu.close(this.minecraft.player);
		}
	}

	@Override
	public boolean shouldPauseGame() {
		return false;
	}

	@Override
	public void tick() {
		super.tick();
		if (!this.minecraft.player.isAlive() || this.minecraft.player.removed) {
			this.minecraft.player.closeMenu();
		}
	}
}

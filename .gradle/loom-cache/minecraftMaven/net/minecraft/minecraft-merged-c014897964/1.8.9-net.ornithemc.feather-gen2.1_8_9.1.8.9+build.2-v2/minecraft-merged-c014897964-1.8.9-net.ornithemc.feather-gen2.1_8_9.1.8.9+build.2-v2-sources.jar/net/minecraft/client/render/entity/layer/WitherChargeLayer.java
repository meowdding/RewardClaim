package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.WitherRenderer;
import net.minecraft.client.render.model.entity.WitherModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.monster.boss.WitherEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class WitherChargeLayer implements EntityRenderLayer<WitherEntity> {
	private static final Identifier WITHER_CHARGE_LOCATION = new Identifier("textures/entity/wither/wither_armor.png");
	private final WitherRenderer parent;
	private final WitherModel model = new WitherModel(0.5F);

	public WitherChargeLayer(WitherRenderer parent) {
		this.parent = parent;
	}

	public void render(WitherEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale) {
		if (entity.isAtHalfHealth()) {
			GlStateManager.depthMask(!entity.isInvisible());
			this.parent.bindTexture(WITHER_CHARGE_LOCATION);
			GlStateManager.matrixMode(5890);
			GlStateManager.loadIdentity();
			float f = entity.ticks + tickDelta;
			float g = MathHelper.cos(f * 0.02F) * 3.0F;
			float h = f * 0.01F;
			GlStateManager.translatef(g, h, 0.0F);
			GlStateManager.matrixMode(5888);
			GlStateManager.enableBlend();
			float i = 0.5F;
			GlStateManager.color4f(i, i, i, 1.0F);
			GlStateManager.disableLighting();
			GlStateManager.blendFunc(1, 1);
			this.model.prepare(entity, walkAnimationProgress, walkAnimationSpeed, tickDelta);
			this.model.copyPropertiesFrom(this.parent.getModel());
			this.model.render(entity, walkAnimationProgress, walkAnimationSpeed, bob, yaw, pitch, scale);
			GlStateManager.matrixMode(5890);
			GlStateManager.loadIdentity();
			GlStateManager.matrixMode(5888);
			GlStateManager.enableLighting();
			GlStateManager.disableBlend();
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.model.Model;
import net.minecraft.client.render.model.entity.MinecartModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.entity.vehicle.MinecartEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class MinecartRenderer<T extends MinecartEntity> extends EntityRenderer<T> {
	private static final Identifier MINECART_LOCATION = new Identifier("textures/entity/minecart.png");
	protected Model model = new MinecartModel();

	public MinecartRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
		this.shadowSize = 0.5F;
	}

	public void render(T entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		GlStateManager.pushMatrix();
		this.bindTexture(entity);
		long l = entity.getNetworkId() * 493286711L;
		l = l * l * 4392167121L + l * 98761L;
		float f = (((float)(l >> 16 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
		float g = (((float)(l >> 20 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
		float h = (((float)(l >> 24 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
		GlStateManager.translatef(f, g, h);
		double d = entity.prevX + (entity.x - entity.prevX) * tickDelta;
		double e = entity.prevY + (entity.y - entity.prevY) * tickDelta;
		double i = entity.prevZ + (entity.z - entity.prevZ) * tickDelta;
		double j = 0.3F;
		Vec3d vec3d = entity.snapPositionToRail(d, e, i);
		float k = entity.lastPitch + (entity.pitch - entity.lastPitch) * tickDelta;
		if (vec3d != null) {
			Vec3d vec3d2 = entity.snapPositionToRailWithOffset(d, e, i, j);
			Vec3d vec3d3 = entity.snapPositionToRailWithOffset(d, e, i, -j);
			if (vec3d2 == null) {
				vec3d2 = vec3d;
			}

			if (vec3d3 == null) {
				vec3d3 = vec3d;
			}

			dx += vec3d.x - d;
			dy += (vec3d2.y + vec3d3.y) / 2.0 - e;
			dz += vec3d.z - i;
			Vec3d vec3d4 = vec3d3.add(-vec3d2.x, -vec3d2.y, -vec3d2.z);
			if (vec3d4.length() != 0.0) {
				vec3d4 = vec3d4.normalize();
				yaw = (float)(Math.atan2(vec3d4.z, vec3d4.x) * 180.0 / Math.PI);
				k = (float)(Math.atan(vec3d4.y) * 73.0);
			}
		}

		GlStateManager.translatef((float)dx, (float)dy + 0.375F, (float)dz);
		GlStateManager.rotatef(180.0F - yaw, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(-k, 0.0F, 0.0F, 1.0F);
		float m = entity.getDamagedTimer() - tickDelta;
		float n = entity.getDamage() - tickDelta;
		if (n < 0.0F) {
			n = 0.0F;
		}

		if (m > 0.0F) {
			GlStateManager.rotatef(MathHelper.sin(m) * m * n / 10.0F * entity.getDamagedSwingDirection(), 1.0F, 0.0F, 0.0F);
		}

		int o = entity.getDisplayBlockOffset();
		BlockState blockState = entity.getDisplayBlock();
		if (blockState.getBlock().getRenderType() != -1) {
			GlStateManager.pushMatrix();
			this.bindTexture(TextureAtlas.BLOCKS_LOCATION);
			float p = 0.75F;
			GlStateManager.scalef(p, p, p);
			GlStateManager.translatef(-0.5F, (o - 8) / 16.0F, 0.5F);
			this.renderBlockInMinecart(entity, tickDelta, blockState);
			GlStateManager.popMatrix();
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			this.bindTexture(entity);
		}

		GlStateManager.scalef(-1.0F, -1.0F, 1.0F);
		this.model.render(entity, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0625F);
		GlStateManager.popMatrix();
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(T entity) {
		return MINECART_LOCATION;
	}

	protected void renderBlockInMinecart(T minecart, float tickDelta, BlockState state) {
		GlStateManager.pushMatrix();
		Minecraft.getInstance().getBlockRenderDispatcher().renderAsItem(state, minecart.getBrightness(tickDelta));
		GlStateManager.popMatrix();
	}
}

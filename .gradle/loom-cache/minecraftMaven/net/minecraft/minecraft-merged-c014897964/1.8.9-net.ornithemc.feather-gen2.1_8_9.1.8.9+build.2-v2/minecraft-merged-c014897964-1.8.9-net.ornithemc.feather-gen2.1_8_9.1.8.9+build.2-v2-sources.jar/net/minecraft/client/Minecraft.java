package net.minecraft.client;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Queues;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListenableFutureTask;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.properties.PropertyMap;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.Proxy;
import java.net.SocketAddress;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import javax.imageio.ImageIO;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.Bootstrap;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.client.entity.living.player.KeyboardInput;
import net.minecraft.client.entity.living.player.LocalClientPlayerEntity;
import net.minecraft.client.gui.BossBar;
import net.minecraft.client.gui.GameGui;
import net.minecraft.client.gui.ToastGui;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.ConfirmationListener;
import net.minecraft.client.gui.screen.OutOfMemoryScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.game.ChatScreen;
import net.minecraft.client.gui.screen.game.DeathScreen;
import net.minecraft.client.gui.screen.game.SleepingChatScreen;
import net.minecraft.client.gui.screen.game.inventory.SurvivalInventoryScreen;
import net.minecraft.client.gui.screen.menu.GameMenuScreen;
import net.minecraft.client.gui.screen.menu.TitleScreen;
import net.minecraft.client.gui.screen.menu.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.menu.options.ControlsOptionsScreen;
import net.minecraft.client.gui.screen.menu.twitch.StreamUnavailableScreen;
import net.minecraft.client.main.RunArgs;
import net.minecraft.client.network.handler.ClientLoginNetworkHandler;
import net.minecraft.client.network.handler.ClientPlayNetworkHandler;
import net.minecraft.client.options.GameOptions;
import net.minecraft.client.options.KeyBinding;
import net.minecraft.client.options.ServerListEntry;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.ItemInHandRenderer;
import net.minecraft.client.render.ProgressRenderError;
import net.minecraft.client.render.ProgressRenderer;
import net.minecraft.client.render.TextRenderer;
import net.minecraft.client.render.Window;
import net.minecraft.client.render.block.BlockRenderDispatcher;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.ItemRenderer;
import net.minecraft.client.render.pipeline.RenderTarget;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.texture.DynamicTexture;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.render.texture.TextureManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.client.render.world.RenderChunk;
import net.minecraft.client.render.world.WorldRenderer;
import net.minecraft.client.resource.AssetIndex;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.resource.language.LanguageManager;
import net.minecraft.client.resource.manager.ReloadableResourceManager;
import net.minecraft.client.resource.manager.ResourceManager;
import net.minecraft.client.resource.manager.SimpleReloadableResourceManager;
import net.minecraft.client.resource.metadata.AnimationMetadata;
import net.minecraft.client.resource.metadata.FontMetadata;
import net.minecraft.client.resource.metadata.LanguageMetadata;
import net.minecraft.client.resource.metadata.ResourceMetadataSerializers;
import net.minecraft.client.resource.metadata.ResourcePackMetadata;
import net.minecraft.client.resource.metadata.TextureMetadata;
import net.minecraft.client.resource.metadata.serializer.AnimationMetadataSerializer;
import net.minecraft.client.resource.metadata.serializer.FontMetadataSerializer;
import net.minecraft.client.resource.metadata.serializer.LanguageMetadataSerializer;
import net.minecraft.client.resource.metadata.serializer.PackMetadataSerializer;
import net.minecraft.client.resource.metadata.serializer.TextureMetadataSerializer;
import net.minecraft.client.resource.model.ModelManager;
import net.minecraft.client.resource.pack.BuiltInResourcePack;
import net.minecraft.client.resource.pack.ResourcePack;
import net.minecraft.client.resource.pack.ResourcePacks;
import net.minecraft.client.resource.skin.SkinManager;
import net.minecraft.client.sound.MusicManager;
import net.minecraft.client.sound.system.SoundManager;
import net.minecraft.client.twitch.ErrorTwitchStream;
import net.minecraft.client.twitch.Twitch;
import net.minecraft.client.twitch.TwitchStream;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.world.color.FoliageColorReloader;
import net.minecraft.client.world.color.GrassColorReloader;
import net.minecraft.entity.Entities;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.decoration.LeadKnotEntity;
import net.minecraft.entity.decoration.PaintingEntity;
import net.minecraft.entity.living.ArmorStandEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.entity.living.player.PlayerInventory;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.entity.vehicle.MinecartEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.network.Connection;
import net.minecraft.network.NetworkProtocol;
import net.minecraft.network.packet.c2s.handshake.HandshakeC2SPacket;
import net.minecraft.network.packet.c2s.login.HelloC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import net.minecraft.resource.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.snooper.Snooper;
import net.minecraft.snooper.SnooperPopulator;
import net.minecraft.stat.PlayerStats;
import net.minecraft.stat.achievement.AchievementStatFormatter;
import net.minecraft.stat.achievement.Achievements;
import net.minecraft.text.LiteralText;
import net.minecraft.util.BlockableEventLoop;
import net.minecraft.util.Utils;
import net.minecraft.util.crash.CrashException;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.world.Difficulty;
import net.minecraft.world.HitResult;
import net.minecraft.world.WorldData;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.dimension.NetherDimension;
import net.minecraft.world.dimension.TheEndDimension;
import net.minecraft.world.storage.AnvilWorldStorageSource;
import net.minecraft.world.storage.WorldStorage;
import net.minecraft.world.storage.WorldStorageSource;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.opengl.OpenGLException;
import org.lwjgl.opengl.PixelFormat;
import org.lwjgl.util.glu.GLU;

@Environment(EnvType.CLIENT)
public class Minecraft implements BlockableEventLoop, SnooperPopulator {
	private static final Logger LOGGER = LogManager.getLogger();
	private static final Identifier MOJANG_LOGO_LOCATION = new Identifier("textures/gui/title/mojang.png");
	public static final boolean IS_MAC = Utils.getOS() == Utils.OS.MACOS;
	public static byte[] MEMORY_RESERVED_FOR_CRASH = new byte[10485760];
	private static final List<DisplayMode> DISPLAY_MODES = Lists.newArrayList(new DisplayMode(2560, 1600), new DisplayMode(2880, 1800));
	private final File resourcePacksDir;
	private final PropertyMap userProperties;
	private final PropertyMap profileProperties;
	private ServerListEntry currentServerEntry;
	private TextureManager textureManager;
	private static Minecraft INSTANCE;
	public ClientPlayerInteractionManager interactionManager;
	private boolean fullscreen;
	private boolean logGlErrors = true;
	private boolean crashed;
	private CrashReport crashReport;
	public int width;
	public int height;
	private boolean connectedToRealms = false;
	private TickTimer timer = new TickTimer(20.0F);
	private Snooper snooper = new Snooper("client", this, MinecraftServer.getTimeMillis());
	public ClientWorld world;
	public WorldRenderer worldRenderer;
	private EntityRenderDispatcher entityRenderDispatcher;
	private ItemRenderer itemRenderer;
	private ItemInHandRenderer itemInHandRenderer;
	public LocalClientPlayerEntity player;
	private Entity camera;
	public Entity targetEntity;
	public ParticleManager particleManager;
	private final Session session;
	private boolean paused;
	public TextRenderer textRenderer;
	public TextRenderer enchantingPhraseRenderer;
	public Screen screen;
	public ProgressRenderer progressRenderer;
	public GameRenderer gameRenderer;
	/**
	 * This field is set to 10 when the player swings and misses.
	 * When it is greater than 0, attacks are not processed.
	 * Attack cooldown is decremented down every tick.
	 * However, if the attack button is not held down at the time tick() is called, it is reset to 0.
	 */
	private int attackCooldown;
	private int initWidth;
	private int initHeight;
	private IntegratedServer server;
	public ToastGui toast;
	public GameGui gui;
	public boolean skipGameRender;
	public HitResult crosshairTarget;
	public GameOptions options;
	public Mouse mouse;
	public final File gameDir;
	private final File assetsDir;
	private final String gameVersion;
	private final Proxy proxy;
	private WorldStorageSource worldStorageSource;
	private static int currentFps;
	private int useKeyCooldown;
	private String startupServerAddress;
	private int startupServerPort;
	public boolean focused;
	long lastTickTime = getTime();
	private int joinPlayerCounter;
	public final FrameTimeLogger frameTimeLogger = new FrameTimeLogger();
	long lastNanoTime = System.nanoTime();
	private final boolean is64Bit;
	private final boolean demo;
	private Connection connection;
	private boolean isIntegratedServerRunning;
	public final Profiler profiler = new Profiler();
	private long f3CTime = -1L;
	private ReloadableResourceManager resourceManager;
	private final ResourceMetadataSerializers resourceMetadataSerializers = new ResourceMetadataSerializers();
	private final List<ResourcePack> requiredResourcePacks = Lists.newArrayList();
	private final BuiltInResourcePack defaultResourcePack;
	private ResourcePacks resourcePacks;
	private LanguageManager languageManager;
	private TwitchStream twitchStream;
	private RenderTarget renderTarget;
	private TextureAtlas blocksAtlas;
	private SoundManager soundManager;
	private MusicManager musicManager;
	private Identifier logoLocation;
	private final MinecraftSessionService sessionService;
	private SkinManager skinManager;
	private final Queue<FutureTask<?>> tasks = Queues.newArrayDeque();
	private long f_10473752 = 0L;
	private final Thread thread = Thread.currentThread();
	private ModelManager modelManager;
	private BlockRenderDispatcher blockRenderer;
	volatile boolean running = true;
	public String fpsDebugInfo = "";
	public boolean f_68391016 = false;
	public boolean f_63838485 = false;
	public boolean f_89931322 = false;
	public boolean smartCull = true;
	/**
	 * Time in miliseconds - only updates every second.
	 */
	long timeAtLastSecond = getTime();
	int fpsCounter;
	long timeAfterLastTick = -1L;
	private String openProfilerSection = "root";

	public Minecraft(RunArgs session) {
		INSTANCE = this;
		this.gameDir = session.location.gameDir;
		this.assetsDir = session.location.assetsDir;
		this.resourcePacksDir = session.location.resourcePacksDir;
		this.gameVersion = session.game.version;
		this.userProperties = session.user.userProperties;
		this.profileProperties = session.user.profileProperties;
		this.defaultResourcePack = new BuiltInResourcePack(new AssetIndex(session.location.assetsDir, session.location.assetIndex).getIndex());
		this.proxy = session.user.proxy == null ? Proxy.NO_PROXY : session.user.proxy;
		this.sessionService = new YggdrasilAuthenticationService(session.user.proxy, UUID.randomUUID().toString()).createMinecraftSessionService();
		this.session = session.user.session;
		LOGGER.info("Setting user: " + this.session.getUsername());
		LOGGER.info("(Session ID is " + this.session.getSessionId() + ")");
		this.demo = session.game.demo;
		this.width = session.display.width > 0 ? session.display.width : 1;
		this.height = session.display.height > 0 ? session.display.height : 1;
		this.initWidth = session.display.width;
		this.initHeight = session.display.height;
		this.fullscreen = session.display.fullscreen;
		this.is64Bit = checkIs64Bit();
		this.server = new IntegratedServer(this);
		if (session.server.ip != null) {
			this.startupServerAddress = session.server.ip;
			this.startupServerPort = session.server.port;
		}

		ImageIO.setUseCache(false);
		Bootstrap.init();
	}

	public void run() {
		this.running = true;

		try {
			this.init();
		} catch (Throwable throwable) {
			CrashReport crashReport = CrashReport.of(throwable, "Initializing game");
			crashReport.addCategory("Initialization");
			this.gameCrashed(this.populateCrashReport(crashReport));
			return;
		}

		try {
			try {
				while (this.running) {
					if (this.crashed && this.crashReport != null) {
						this.gameCrashed(this.crashReport);
						return;
					}

					try {
						this.runGame();
					} catch (OutOfMemoryError outOfMemoryError) {
						this.cleanHeap();
						this.openScreen(new OutOfMemoryScreen());
						System.gc();
					}
				}

				return;
			} catch (ProgressRenderError var12) {
			} catch (CrashException crashException) {
				this.populateCrashReport(crashException.getReport());
				this.cleanHeap();
				LOGGER.fatal("Reported exception thrown!", crashException);
				this.gameCrashed(crashException.getReport());
			} catch (Throwable throwable) {
				CrashReport crashReport = this.populateCrashReport(new CrashReport("Unexpected error", throwable));
				this.cleanHeap();
				LOGGER.fatal("Unreported exception thrown!", throwable);
				this.gameCrashed(crashReport);
			}
		} finally {
			this.shutdown();
		}
	}

	private void init() throws LWJGLException, IOException {
		this.options = new GameOptions(this, this.gameDir);
		this.requiredResourcePacks.add(this.defaultResourcePack);
		this.initTimerHackThread();
		if (this.options.overrideHeight > 0 && this.options.overrideWidth > 0) {
			this.width = this.options.overrideWidth;
			this.height = this.options.overrideHeight;
		}

		LOGGER.info("LWJGL Version: " + Sys.getVersion());
		this.initIcon();
		this.initDisplayMode();
		this.initDisplay();
		GLX.init();
		this.renderTarget = new RenderTarget(this.width, this.height, true);
		this.renderTarget.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
		this.initResourceMetadataSerializers();
		this.resourcePacks = new ResourcePacks(
			this.resourcePacksDir, new File(this.gameDir, "server-resource-packs"), this.defaultResourcePack, this.resourceMetadataSerializers, this.options
		);
		this.resourceManager = new SimpleReloadableResourceManager(this.resourceMetadataSerializers);
		this.languageManager = new LanguageManager(this.resourceMetadataSerializers, this.options.language);
		this.resourceManager.addListener(this.languageManager);
		this.reloadResources();
		this.textureManager = new TextureManager(this.resourceManager);
		this.resourceManager.addListener(this.textureManager);
		this.renderLoadingScreen(this.textureManager);
		this.initTwitchStream();
		this.skinManager = new SkinManager(this.textureManager, new File(this.assetsDir, "skins"), this.sessionService);
		this.worldStorageSource = new AnvilWorldStorageSource(new File(this.gameDir, "saves"));
		this.soundManager = new SoundManager(this.resourceManager, this.options);
		this.resourceManager.addListener(this.soundManager);
		this.musicManager = new MusicManager(this);
		this.textRenderer = new TextRenderer(this.options, new Identifier("textures/font/ascii.png"), this.textureManager, false);
		if (this.options.language != null) {
			this.textRenderer.setUnicode(this.isUnicode());
			this.textRenderer.setBidirectional(this.languageManager.isBidirectional());
		}

		this.enchantingPhraseRenderer = new TextRenderer(this.options, new Identifier("textures/font/ascii_sga.png"), this.textureManager, false);
		this.resourceManager.addListener(this.textRenderer);
		this.resourceManager.addListener(this.enchantingPhraseRenderer);
		this.resourceManager.addListener(new GrassColorReloader());
		this.resourceManager.addListener(new FoliageColorReloader());
		Achievements.OPEN_INVENTORY.setFormatter(new AchievementStatFormatter() {
			@Override
			public String format(String value) {
				try {
					return String.format(value, GameOptions.getKeyName(Minecraft.this.options.inventoryKey.getKeyCode()));
				} catch (Exception exception) {
					return "Error: " + exception.getLocalizedMessage();
				}
			}
		});
		this.mouse = new Mouse();
		this.logGlError("Pre startup");
		GlStateManager.enableTexture();
		GlStateManager.shadeModel(7425);
		GlStateManager.clearDepth(1.0);
		GlStateManager.enableDepthTest();
		GlStateManager.depthFunc(515);
		GlStateManager.enableAlphaTest();
		GlStateManager.alphaFunc(516, 0.1F);
		GlStateManager.cullFace(1029);
		GlStateManager.matrixMode(5889);
		GlStateManager.loadIdentity();
		GlStateManager.matrixMode(5888);
		this.logGlError("Startup");
		this.blocksAtlas = new TextureAtlas("textures");
		this.blocksAtlas.setMaxMipLevel(this.options.mipmapLevels);
		this.textureManager.register(TextureAtlas.BLOCKS_LOCATION, this.blocksAtlas);
		this.textureManager.bind(TextureAtlas.BLOCKS_LOCATION);
		this.blocksAtlas.setFilter(false, this.options.mipmapLevels > 0);
		this.modelManager = new ModelManager(this.blocksAtlas);
		this.resourceManager.addListener(this.modelManager);
		this.itemRenderer = new ItemRenderer(this.textureManager, this.modelManager);
		this.entityRenderDispatcher = new EntityRenderDispatcher(this.textureManager, this.itemRenderer);
		this.itemInHandRenderer = new ItemInHandRenderer(this);
		this.resourceManager.addListener(this.itemRenderer);
		this.gameRenderer = new GameRenderer(this, this.resourceManager);
		this.resourceManager.addListener(this.gameRenderer);
		this.blockRenderer = new BlockRenderDispatcher(this.modelManager.getModelShaper(), this.options);
		this.resourceManager.addListener(this.blockRenderer);
		this.worldRenderer = new WorldRenderer(this);
		this.resourceManager.addListener(this.worldRenderer);
		this.toast = new ToastGui(this);
		GlStateManager.viewport(0, 0, this.width, this.height);
		this.particleManager = new ParticleManager(this.world, this.textureManager);
		this.logGlError("Post startup");
		this.gui = new GameGui(this);
		if (this.startupServerAddress != null) {
			this.openScreen(new ConnectScreen(new TitleScreen(), this, this.startupServerAddress, this.startupServerPort));
		} else {
			this.openScreen(new TitleScreen());
		}

		this.textureManager.close(this.logoLocation);
		this.logoLocation = null;
		this.progressRenderer = new ProgressRenderer(this);
		if (this.options.fullscreen && !this.fullscreen) {
			this.toggleFullscreen();
		}

		try {
			Display.setVSyncEnabled(this.options.vsync);
		} catch (OpenGLException openGLException) {
			this.options.vsync = false;
			this.options.save();
		}

		this.worldRenderer.loadEntityOutline();
	}

	private void initResourceMetadataSerializers() {
		this.resourceMetadataSerializers.register(new TextureMetadataSerializer(), TextureMetadata.class);
		this.resourceMetadataSerializers.register(new FontMetadataSerializer(), FontMetadata.class);
		this.resourceMetadataSerializers.register(new AnimationMetadataSerializer(), AnimationMetadata.class);
		this.resourceMetadataSerializers.register(new PackMetadataSerializer(), ResourcePackMetadata.class);
		this.resourceMetadataSerializers.register(new LanguageMetadataSerializer(), LanguageMetadata.class);
	}

	private void initTwitchStream() {
		try {
			this.twitchStream = new Twitch(this, Iterables.getFirst(this.userProperties.get("twitch_access_token"), null));
		} catch (Throwable throwable) {
			this.twitchStream = new ErrorTwitchStream(throwable);
			LOGGER.error("Couldn't initialize twitch stream");
		}
	}

	private void initDisplay() throws LWJGLException {
		Display.setResizable(true);
		Display.setTitle("Minecraft 1.8.9");

		try {
			Display.create(new PixelFormat().withDepthBits(24));
		} catch (LWJGLException lWJGLException) {
			LOGGER.error("Couldn't set pixel format", lWJGLException);

			try {
				Thread.sleep(1000L);
			} catch (InterruptedException var3) {
			}

			if (this.fullscreen) {
				this.updateDisplayMode();
			}

			Display.create();
		}
	}

	private void initDisplayMode() throws LWJGLException {
		if (this.fullscreen) {
			Display.setFullscreen(true);
			DisplayMode displayMode = Display.getDisplayMode();
			this.width = Math.max(1, displayMode.getWidth());
			this.height = Math.max(1, displayMode.getHeight());
		} else {
			Display.setDisplayMode(new DisplayMode(this.width, this.height));
		}
	}

	private void initIcon() {
		Utils.OS oS = Utils.getOS();
		if (oS != Utils.OS.MACOS) {
			InputStream inputStream = null;
			InputStream inputStream2 = null;

			try {
				inputStream = this.defaultResourcePack.getAsset(new Identifier("icons/icon_16x16.png"));
				inputStream2 = this.defaultResourcePack.getAsset(new Identifier("icons/icon_32x32.png"));
				if (inputStream != null && inputStream2 != null) {
					Display.setIcon(new ByteBuffer[]{this.readImageBuffer(inputStream), this.readImageBuffer(inputStream2)});
				}
			} catch (IOException iOException) {
				LOGGER.error("Couldn't set icon", iOException);
			} finally {
				IOUtils.closeQuietly(inputStream);
				IOUtils.closeQuietly(inputStream2);
			}
		}
	}

	private static boolean checkIs64Bit() {
		String[] strings = new String[]{"sun.arch.data.model", "com.ibm.vm.bitmode", "os.arch"};

		for (String string : strings) {
			String string2 = System.getProperty(string);
			if (string2 != null && string2.contains("64")) {
				return true;
			}
		}

		return false;
	}

	public RenderTarget getRenderTarget() {
		return this.renderTarget;
	}

	public String getGameVersion() {
		return this.gameVersion;
	}

	private void initTimerHackThread() {
		Thread thread = new Thread("Timer hack thread") {
			@Override
			public void run() {
				while (Minecraft.this.running) {
					try {
						Thread.sleep(2147483647L);
					} catch (InterruptedException var2) {
					}
				}
			}
		};
		thread.setDaemon(true);
		thread.start();
	}

	public void integratedServerCrashed(CrashReport crashReport) {
		this.crashed = true;
		this.crashReport = crashReport;
	}

	public void gameCrashed(CrashReport report) {
		File file = new File(getInstance().gameDir, "crash-reports");
		File file2 = new File(file, "crash-" + new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss").format(new Date()) + "-client.txt");
		Bootstrap.sysout(report.build());
		if (report.getFile() != null) {
			Bootstrap.sysout("#@!@# Game crashed! Crash report saved to: #@!@# " + report.getFile());
			System.exit(-1);
		} else if (report.writeToFile(file2)) {
			Bootstrap.sysout("#@!@# Game crashed! Crash report saved to: #@!@# " + file2.getAbsolutePath());
			System.exit(-1);
		} else {
			Bootstrap.sysout("#@?@# Game crashed! Crash report could not be saved. #@?@#");
			System.exit(-2);
		}
	}

	public boolean isUnicode() {
		return this.languageManager.isUnicode() || this.options.forceUnicodeFont;
	}

	public void reloadResources() {
		List<ResourcePack> list = Lists.newArrayList(this.requiredResourcePacks);

		for (ResourcePacks.UnopenedPack unopenedPack : this.resourcePacks.getSelectedPacks()) {
			list.add(unopenedPack.open());
		}

		if (this.resourcePacks.getServerResourcePack() != null) {
			list.add(this.resourcePacks.getServerResourcePack());
		}

		try {
			this.resourceManager.reload(list);
		} catch (RuntimeException runtimeException) {
			LOGGER.info("Caught error stitching, removing all assigned resourcepacks", runtimeException);
			list.clear();
			list.addAll(this.requiredResourcePacks);
			this.resourcePacks.setSelectedPacks(Collections.emptyList());
			this.resourceManager.reload(list);
			this.options.resourcePacks.clear();
			this.options.incompatibleResourcePacks.clear();
			this.options.save();
		}

		this.languageManager.reload(list);
		if (this.worldRenderer != null) {
			this.worldRenderer.reload();
		}
	}

	private ByteBuffer readImageBuffer(InputStream file) throws IOException {
		BufferedImage bufferedImage = ImageIO.read(file);
		int[] is = bufferedImage.getRGB(0, 0, bufferedImage.getWidth(), bufferedImage.getHeight(), null, 0, bufferedImage.getWidth());
		ByteBuffer byteBuffer = ByteBuffer.allocate(4 * is.length);

		for (int k : is) {
			byteBuffer.putInt(k << 8 | k >> 24 & 0xFF);
		}

		((Buffer)byteBuffer).flip();
		return byteBuffer;
	}

	private void updateDisplayMode() throws LWJGLException {
		Set<DisplayMode> set = Sets.newHashSet();
		Collections.addAll(set, Display.getAvailableDisplayModes());
		DisplayMode displayMode = Display.getDesktopDisplayMode();
		if (!set.contains(displayMode) && Utils.getOS() == Utils.OS.MACOS) {
			for (DisplayMode displayMode2 : DISPLAY_MODES) {
				boolean bl = true;

				for (DisplayMode displayMode3 : set) {
					if (displayMode3.getBitsPerPixel() == 32 && displayMode3.getWidth() == displayMode2.getWidth() && displayMode3.getHeight() == displayMode2.getHeight()) {
						bl = false;
						break;
					}
				}

				if (!bl) {
					for (DisplayMode displayMode3 : set) {
						if (displayMode3.getBitsPerPixel() == 32
							&& displayMode3.getWidth() == displayMode2.getWidth() / 2
							&& displayMode3.getHeight() == displayMode2.getHeight() / 2) {
							displayMode = displayMode3;
							break;
						}
					}
				}
			}
		}

		Display.setDisplayMode(displayMode);
		this.width = displayMode.getWidth();
		this.height = displayMode.getHeight();
	}

	private void renderLoadingScreen(TextureManager textureManager) throws LWJGLException {
		Window window = new Window(this);
		int i = window.getScale();
		RenderTarget renderTarget = new RenderTarget(window.getWidth() * i, window.getHeight() * i, true);
		renderTarget.bindWrite(false);
		GlStateManager.matrixMode(5889);
		GlStateManager.loadIdentity();
		GlStateManager.ortho(0.0, window.getWidth(), window.getHeight(), 0.0, 1000.0, 3000.0);
		GlStateManager.matrixMode(5888);
		GlStateManager.loadIdentity();
		GlStateManager.translatef(0.0F, 0.0F, -2000.0F);
		GlStateManager.disableLighting();
		GlStateManager.disableFog();
		GlStateManager.disableDepthTest();
		GlStateManager.enableTexture();
		InputStream inputStream = null;

		try {
			inputStream = this.defaultResourcePack.getResource(MOJANG_LOGO_LOCATION);
			this.logoLocation = textureManager.register("logo", new DynamicTexture(ImageIO.read(inputStream)));
			textureManager.bind(this.logoLocation);
		} catch (IOException iOException) {
			LOGGER.error("Unable to load logo: " + MOJANG_LOGO_LOCATION, iOException);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
		bufferBuilder.vertex(0.0, this.height, 0.0).texture(0.0, 0.0).color(255, 255, 255, 255).nextVertex();
		bufferBuilder.vertex(this.width, this.height, 0.0).texture(0.0, 0.0).color(255, 255, 255, 255).nextVertex();
		bufferBuilder.vertex(this.width, 0.0, 0.0).texture(0.0, 0.0).color(255, 255, 255, 255).nextVertex();
		bufferBuilder.vertex(0.0, 0.0, 0.0).texture(0.0, 0.0).color(255, 255, 255, 255).nextVertex();
		tesselator.end();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		int j = 256;
		int k = 256;
		this.draw((window.getWidth() - j) / 2, (window.getHeight() - k) / 2, 0, 0, j, k, 255, 255, 255, 255);
		GlStateManager.disableLighting();
		GlStateManager.disableFog();
		renderTarget.unbindWrite();
		renderTarget.draw(window.getWidth() * i, window.getHeight() * i);
		GlStateManager.enableAlphaTest();
		GlStateManager.alphaFunc(516, 0.1F);
		this.updateDisplay();
	}

	public void draw(int x, int y, int u, int v, int width, int height, int r, int g, int b, int a) {
		float f = 0.00390625F;
		float h = 0.00390625F;
		BufferBuilder bufferBuilder = Tesselator.getInstance().getBuffer();
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_COLOR);
		bufferBuilder.vertex(x, y + height, 0.0).texture(u * f, (v + height) * h).color(r, g, b, a).nextVertex();
		bufferBuilder.vertex(x + width, y + height, 0.0).texture((u + width) * f, (v + height) * h).color(r, g, b, a).nextVertex();
		bufferBuilder.vertex(x + width, y, 0.0).texture((u + width) * f, v * h).color(r, g, b, a).nextVertex();
		bufferBuilder.vertex(x, y, 0.0).texture(u * f, v * h).color(r, g, b, a).nextVertex();
		Tesselator.getInstance().end();
	}

	public WorldStorageSource getWorldStorageSource() {
		return this.worldStorageSource;
	}

	public void openScreen(Screen screen) {
		if (this.screen != null) {
			this.screen.removed();
		}

		if (screen == null && this.world == null) {
			screen = new TitleScreen();
		} else if (screen == null && this.player.getHealth() <= 0.0F) {
			screen = new DeathScreen();
		}

		if (screen instanceof TitleScreen) {
			this.options.debugEnabled = false;
			this.gui.getChat().clear();
		}

		this.screen = screen;
		if (screen != null) {
			this.unlockMouse();
			Window window = new Window(this);
			int i = window.getWidth();
			int j = window.getHeight();
			screen.init(this, i, j);
			this.skipGameRender = false;
		} else {
			this.soundManager.resume();
			this.lockMouse();
		}
	}

	private void logGlError(String message) {
		if (this.logGlErrors) {
			int i = GL11.glGetError();
			if (i != 0) {
				String string = GLU.gluErrorString(i);
				LOGGER.error("########## GL ERROR ##########");
				LOGGER.error("@ " + message);
				LOGGER.error(i + ": " + string);
			}
		}
	}

	public void shutdown() {
		try {
			this.twitchStream.shutdown();
			LOGGER.info("Stopping!");

			try {
				this.setWorld(null);
			} catch (Throwable var5) {
			}

			this.soundManager.close();
		} finally {
			Display.destroy();
			if (!this.crashed) {
				System.exit(0);
			}
		}

		System.gc();
	}

	private void runGame() {
		long l = System.nanoTime();
		this.profiler.push("root");
		if (Display.isCreated() && Display.isCloseRequested()) {
			this.stop();
		}

		if (this.paused && this.world != null) {
			float f = this.timer.partialTick;
			this.timer.advance();
			this.timer.partialTick = f;
		} else {
			this.timer.advance();
		}

		this.profiler.push("scheduledExecutables");
		synchronized (this.tasks) {
			while (!this.tasks.isEmpty()) {
				Utils.run(this.tasks.poll(), LOGGER);
			}
		}

		this.profiler.pop();
		long m = System.nanoTime();
		this.profiler.push("tick");

		for (int i = 0; i < this.timer.ticksThisFrame; i++) {
			this.tick();
		}

		this.profiler.swap("preRenderErrors");
		long n = System.nanoTime() - m;
		this.logGlError("Pre render");
		this.profiler.swap("sound");
		this.soundManager.updateListener(this.player, this.timer.partialTick);
		this.profiler.pop();
		this.profiler.push("render");
		GlStateManager.pushMatrix();
		GlStateManager.clear(16640);
		this.renderTarget.bindWrite(true);
		this.profiler.push("display");
		GlStateManager.enableTexture();
		if (this.player != null && this.player.isInWall()) {
			this.options.perspective = 0;
		}

		this.profiler.pop();
		if (!this.skipGameRender) {
			this.profiler.swap("gameRenderer");
			this.gameRenderer.render(this.timer.partialTick, l);
			this.profiler.pop();
		}

		this.profiler.pop();
		if (this.options.debugEnabled && this.options.debugProfilerEnabled && !this.options.hideGui) {
			if (!this.profiler.profiling) {
				this.profiler.reset();
			}

			this.profiler.profiling = true;
			this.renderProfilerChart(n);
		} else {
			this.profiler.profiling = false;
			this.timeAfterLastTick = System.nanoTime();
		}

		this.toast.render();
		this.renderTarget.unbindWrite();
		GlStateManager.popMatrix();
		GlStateManager.pushMatrix();
		this.renderTarget.draw(this.width, this.height);
		GlStateManager.popMatrix();
		GlStateManager.pushMatrix();
		this.gameRenderer.renderStreamOverlay(this.timer.partialTick);
		GlStateManager.popMatrix();
		this.profiler.push("root");
		this.updateDisplay();
		Thread.yield();
		this.profiler.push("stream");
		this.profiler.push("update");
		this.twitchStream.update();
		this.profiler.swap("submit");
		this.twitchStream.submit();
		this.profiler.pop();
		this.profiler.pop();
		this.logGlError("Post render");
		this.fpsCounter++;
		this.paused = this.isSingleplayer() && this.screen != null && this.screen.shouldPauseGame() && !this.server.isPublished();
		long o = System.nanoTime();
		this.frameTimeLogger.log(o - this.lastNanoTime);
		this.lastNanoTime = o;

		while (getTime() >= this.timeAtLastSecond + 1000L) {
			currentFps = this.fpsCounter;
			this.fpsDebugInfo = String.format(
				"%d fps (%d chunk update%s) T: %s%s%s%s%s",
				currentFps,
				RenderChunk.updateCounter,
				RenderChunk.updateCounter != 1 ? "s" : "",
				this.options.fpsLimit == GameOptions.Option.FRAMERATE_LIMIT.getMax() ? "inf" : this.options.fpsLimit,
				this.options.vsync ? " vsync" : "",
				this.options.fancyGraphics ? "" : " fast",
				this.options.cloudRenderMode == 0 ? "" : (this.options.cloudRenderMode == 1 ? " fast-clouds" : " fancy-clouds"),
				GLX.useVbo() ? " vbo" : ""
			);
			RenderChunk.updateCounter = 0;
			this.timeAtLastSecond += 1000L;
			this.fpsCounter = 0;
			this.snooper.populate();
			if (!this.snooper.isInitialized()) {
				this.snooper.init();
			}
		}

		if (this.isFramerateValid()) {
			this.profiler.push("fpslimit_wait");
			Display.sync(this.getMaxFramerate());
			this.profiler.pop();
		}

		this.profiler.pop();
	}

	public void updateDisplay() {
		this.profiler.push("display_update");
		Display.update();
		this.profiler.pop();
		this.updateWindow();
	}

	protected void updateWindow() {
		if (!this.fullscreen && Display.wasResized()) {
			int i = this.width;
			int j = this.height;
			this.width = Display.getWidth();
			this.height = Display.getHeight();
			if (this.width != i || this.height != j) {
				if (this.width <= 0) {
					this.width = 1;
				}

				if (this.height <= 0) {
					this.height = 1;
				}

				this.resize(this.width, this.height);
			}
		}
	}

	public int getMaxFramerate() {
		return this.world == null && this.screen != null ? 30 : this.options.fpsLimit;
	}

	public boolean isFramerateValid() {
		return this.getMaxFramerate() < GameOptions.Option.FRAMERATE_LIMIT.getMax();
	}

	public void cleanHeap() {
		try {
			MEMORY_RESERVED_FOR_CRASH = new byte[0];
			this.worldRenderer.releaseGlLists();
		} catch (Throwable var3) {
		}

		try {
			System.gc();
			this.setWorld(null);
		} catch (Throwable var2) {
		}

		System.gc();
	}

	private void selectProfilerChartSection(int section) {
		List<Profiler.Result> list = this.profiler.getResults(this.openProfilerSection);
		if (list != null && !list.isEmpty()) {
			Profiler.Result result = list.remove(0);
			if (section == 0) {
				if (result.location.length() > 0) {
					int i = this.openProfilerSection.lastIndexOf(".");
					if (i >= 0) {
						this.openProfilerSection = this.openProfilerSection.substring(0, i);
					}
				}
			} else {
				section--;
				if (section < list.size() && !list.get(section).location.equals("unspecified")) {
					if (this.openProfilerSection.length() > 0) {
						this.openProfilerSection = this.openProfilerSection + ".";
					}

					this.openProfilerSection = this.openProfilerSection + list.get(section).location;
				}
			}
		}
	}

	private void renderProfilerChart(long tickTime) {
		if (this.profiler.profiling) {
			List<Profiler.Result> list = this.profiler.getResults(this.openProfilerSection);
			Profiler.Result result = list.remove(0);
			GlStateManager.clear(256);
			GlStateManager.matrixMode(5889);
			GlStateManager.enableColorMaterial();
			GlStateManager.loadIdentity();
			GlStateManager.ortho(0.0, this.width, this.height, 0.0, 1000.0, 3000.0);
			GlStateManager.matrixMode(5888);
			GlStateManager.loadIdentity();
			GlStateManager.translatef(0.0F, 0.0F, -2000.0F);
			GL11.glLineWidth(1.0F);
			GlStateManager.disableTexture();
			Tesselator tesselator = Tesselator.getInstance();
			BufferBuilder bufferBuilder = tesselator.getBuffer();
			int i = 160;
			int j = this.width - i - 10;
			int k = this.height - i * 2;
			GlStateManager.enableBlend();
			bufferBuilder.begin(7, DefaultVertexFormat.POSITION_COLOR);
			bufferBuilder.vertex(j - i * 1.1F, k - i * 0.6F - 16.0F, 0.0).color(200, 0, 0, 0).nextVertex();
			bufferBuilder.vertex(j - i * 1.1F, k + i * 2, 0.0).color(200, 0, 0, 0).nextVertex();
			bufferBuilder.vertex(j + i * 1.1F, k + i * 2, 0.0).color(200, 0, 0, 0).nextVertex();
			bufferBuilder.vertex(j + i * 1.1F, k - i * 0.6F - 16.0F, 0.0).color(200, 0, 0, 0).nextVertex();
			tesselator.end();
			GlStateManager.disableBlend();
			double d = 0.0;

			for (int l = 0; l < list.size(); l++) {
				Profiler.Result result2 = list.get(l);
				int m = MathHelper.floor(result2.percentageOfParent / 4.0) + 1;
				bufferBuilder.begin(6, DefaultVertexFormat.POSITION_COLOR);
				int n = result2.getColor();
				int o = n >> 16 & 0xFF;
				int p = n >> 8 & 0xFF;
				int q = n & 0xFF;
				bufferBuilder.vertex(j, k, 0.0).color(o, p, q, 255).nextVertex();

				for (int r = m; r >= 0; r--) {
					float f = (float)((d + result2.percentageOfParent * r / m) * (float) Math.PI * 2.0 / 100.0);
					float g = MathHelper.sin(f) * i;
					float h = MathHelper.cos(f) * i * 0.5F;
					bufferBuilder.vertex(j + g, k - h, 0.0).color(o, p, q, 255).nextVertex();
				}

				tesselator.end();
				bufferBuilder.begin(5, DefaultVertexFormat.POSITION_COLOR);

				for (int r = m; r >= 0; r--) {
					float f = (float)((d + result2.percentageOfParent * r / m) * (float) Math.PI * 2.0 / 100.0);
					float g = MathHelper.sin(f) * i;
					float h = MathHelper.cos(f) * i * 0.5F;
					bufferBuilder.vertex(j + g, k - h, 0.0).color(o >> 1, p >> 1, q >> 1, 255).nextVertex();
					bufferBuilder.vertex(j + g, k - h + 10.0F, 0.0).color(o >> 1, p >> 1, q >> 1, 255).nextVertex();
				}

				tesselator.end();
				d += result2.percentageOfParent;
			}

			DecimalFormat decimalFormat = new DecimalFormat("##0.00");
			GlStateManager.enableTexture();
			String string = "";
			if (!result.location.equals("unspecified")) {
				string = string + "[0] ";
			}

			if (result.location.length() == 0) {
				string = string + "ROOT ";
			} else {
				string = string + result.location + " ";
			}

			int m = 16777215;
			this.textRenderer.drawWithShadow(string, j - i, k - i / 2 - 16, m);
			this.textRenderer
				.drawWithShadow(string = decimalFormat.format(result.percentageOfTotal) + "%", j + i - this.textRenderer.getWidth(string), k - i / 2 - 16, m);

			for (int s = 0; s < list.size(); s++) {
				Profiler.Result result3 = list.get(s);
				String string2 = "";
				if (result3.location.equals("unspecified")) {
					string2 = string2 + "[?] ";
				} else {
					string2 = string2 + "[" + (s + 1) + "] ";
				}

				string2 = string2 + result3.location;
				this.textRenderer.drawWithShadow(string2, j - i, k + i / 2 + s * 8 + 20, result3.getColor());
				this.textRenderer
					.drawWithShadow(
						string2 = decimalFormat.format(result3.percentageOfParent) + "%",
						j + i - 50 - this.textRenderer.getWidth(string2),
						k + i / 2 + s * 8 + 20,
						result3.getColor()
					);
				this.textRenderer
					.drawWithShadow(
						string2 = decimalFormat.format(result3.percentageOfTotal) + "%", j + i - this.textRenderer.getWidth(string2), k + i / 2 + s * 8 + 20, result3.getColor()
					);
			}
		}
	}

	public void stop() {
		this.running = false;
	}

	public void lockMouse() {
		if (Display.isActive()) {
			if (!this.focused) {
				this.focused = true;
				this.mouse.lock();
				this.openScreen(null);
				this.attackCooldown = 10000;
			}
		}
	}

	public void unlockMouse() {
		if (this.focused) {
			KeyBinding.releaseAll();
			this.focused = false;
			this.mouse.unlock();
		}
	}

	public void pauseGame() {
		if (this.screen == null) {
			this.openScreen(new GameMenuScreen());
			if (this.isSingleplayer() && !this.server.isPublished()) {
				this.soundManager.pause();
			}
		}
	}

	private void handleMouseDown(boolean holdingAttack) {
		if (!holdingAttack) {
			this.attackCooldown = 0;
		}

		if (this.attackCooldown <= 0 && !this.player.hasItemInUse()) {
			if (holdingAttack && this.crosshairTarget != null && this.crosshairTarget.type == HitResult.Type.BLOCK) {
				BlockPos blockPos = this.crosshairTarget.getPos();
				if (this.world.getBlockState(blockPos).getBlock().getMaterial() != Material.AIR
					&& this.interactionManager.tickBlockMining(blockPos, this.crosshairTarget.face)) {
					this.particleManager.addBlockMiningParticles(blockPos, this.crosshairTarget.face);
					this.player.swingArm();
				}
			} else {
				this.interactionManager.stopMiningBlock();
			}
		}
	}

	private void doAttack() {
		if (this.attackCooldown <= 0) {
			this.player.swingArm();
			if (this.crosshairTarget == null) {
				LOGGER.error("Null returned as 'hitResult', this shouldn't happen!");
				if (this.interactionManager.hasAttackCooldown()) {
					this.attackCooldown = 10;
				}
			} else {
				switch (this.crosshairTarget.type) {
					case ENTITY:
						this.interactionManager.attackEntity(this.player, this.crosshairTarget.entity);
						break;
					case BLOCK:
						BlockPos blockPos = this.crosshairTarget.getPos();
						if (this.world.getBlockState(blockPos).getBlock().getMaterial() != Material.AIR) {
							this.interactionManager.startMiningBlock(blockPos, this.crosshairTarget.face);
							break;
						}
					case MISS:
					default:
						if (this.interactionManager.hasAttackCooldown()) {
							this.attackCooldown = 10;
						}
				}
			}
		}
	}

	private void doUse() {
		if (!this.interactionManager.isMiningBlock()) {
			this.useKeyCooldown = 4;
			boolean bl = true;
			ItemStack itemStack = this.player.inventory.getSelectedItem();
			if (this.crosshairTarget == null) {
				LOGGER.warn("Null returned as 'hitResult', this shouldn't happen!");
			} else {
				switch (this.crosshairTarget.type) {
					case ENTITY:
						if (this.interactionManager.interactEntityAt(this.player, this.crosshairTarget.entity, this.crosshairTarget)) {
							bl = false;
						} else if (this.interactionManager.interactEntity(this.player, this.crosshairTarget.entity)) {
							bl = false;
						}
						break;
					case BLOCK:
						BlockPos blockPos = this.crosshairTarget.getPos();
						if (this.world.getBlockState(blockPos).getBlock().getMaterial() != Material.AIR) {
							int i = itemStack != null ? itemStack.size : 0;
							if (this.interactionManager.useBlock(this.player, this.world, itemStack, blockPos, this.crosshairTarget.face, this.crosshairTarget.facePos)) {
								bl = false;
								this.player.swingArm();
							}

							if (itemStack == null) {
								return;
							}

							if (itemStack.size == 0) {
								this.player.inventory.items[this.player.inventory.selectedSlot] = null;
							} else if (itemStack.size != i || this.interactionManager.hasCreativeInventory()) {
								this.gameRenderer.itemInHandRenderer.onBlockUsed();
							}
						}
				}
			}

			if (bl) {
				ItemStack itemStack2 = this.player.inventory.getSelectedItem();
				if (itemStack2 != null && this.interactionManager.useItem(this.player, this.world, itemStack2)) {
					this.gameRenderer.itemInHandRenderer.onItemUsed();
				}
			}
		}
	}

	public void toggleFullscreen() {
		try {
			this.fullscreen = !this.fullscreen;
			this.options.fullscreen = this.fullscreen;
			if (this.fullscreen) {
				this.updateDisplayMode();
				this.width = Display.getDisplayMode().getWidth();
				this.height = Display.getDisplayMode().getHeight();
				if (this.width <= 0) {
					this.width = 1;
				}

				if (this.height <= 0) {
					this.height = 1;
				}
			} else {
				Display.setDisplayMode(new DisplayMode(this.initWidth, this.initHeight));
				this.width = this.initWidth;
				this.height = this.initHeight;
				if (this.width <= 0) {
					this.width = 1;
				}

				if (this.height <= 0) {
					this.height = 1;
				}
			}

			if (this.screen != null) {
				this.resize(this.width, this.height);
			} else {
				this.onResolutionChanged();
			}

			Display.setFullscreen(this.fullscreen);
			Display.setVSyncEnabled(this.options.vsync);
			this.updateDisplay();
		} catch (Exception exception) {
			LOGGER.error("Couldn't toggle fullscreen", exception);
		}
	}

	private void resize(int width, int height) {
		this.width = Math.max(1, width);
		this.height = Math.max(1, height);
		if (this.screen != null) {
			Window window = new Window(this);
			this.screen.resize(this, window.getWidth(), window.getHeight());
		}

		this.progressRenderer = new ProgressRenderer(this);
		this.onResolutionChanged();
	}

	private void onResolutionChanged() {
		this.renderTarget.resize(this.width, this.height);
		if (this.gameRenderer != null) {
			this.gameRenderer.onResolutionChanged(this.width, this.height);
		}
	}

	public MusicManager getMusicManager() {
		return this.musicManager;
	}

	public void tick() {
		if (this.useKeyCooldown > 0) {
			this.useKeyCooldown--;
		}

		this.profiler.push("gui");
		if (!this.paused) {
			this.gui.tick();
		}

		this.profiler.pop();
		this.gameRenderer.pick(1.0F);
		this.profiler.push("gameMode");
		if (!this.paused && this.world != null) {
			this.interactionManager.tick();
		}

		this.profiler.swap("textures");
		if (!this.paused) {
			this.textureManager.tick();
		}

		if (this.screen == null && this.player != null) {
			if (this.player.getHealth() <= 0.0F) {
				this.openScreen(null);
			} else if (this.player.isSleeping() && this.world != null) {
				this.openScreen(new SleepingChatScreen());
			}
		} else if (this.screen != null && this.screen instanceof SleepingChatScreen && !this.player.isSleeping()) {
			this.openScreen(null);
		}

		if (this.screen != null) {
			this.attackCooldown = 10000;
		}

		if (this.screen != null) {
			try {
				this.screen.handleInputs();
			} catch (Throwable throwable) {
				CrashReport crashReport = CrashReport.of(throwable, "Updating screen events");
				CrashReportCategory crashReportCategory = crashReport.addCategory("Affected screen");
				crashReportCategory.add("Screen name", new Callable<String>() {
					public String call() throws Exception {
						return Minecraft.this.screen.getClass().getCanonicalName();
					}
				});
				throw new CrashException(crashReport);
			}

			if (this.screen != null) {
				try {
					this.screen.tick();
				} catch (Throwable throwable) {
					CrashReport crashReport = CrashReport.of(throwable, "Ticking screen");
					CrashReportCategory crashReportCategory = crashReport.addCategory("Affected screen");
					crashReportCategory.add("Screen name", new Callable<String>() {
						public String call() throws Exception {
							return Minecraft.this.screen.getClass().getCanonicalName();
						}
					});
					throw new CrashException(crashReport);
				}
			}
		}

		if (this.screen == null || this.screen.passEvents) {
			this.profiler.swap("mouse");

			while (org.lwjgl.input.Mouse.next()) {
				int i = org.lwjgl.input.Mouse.getEventButton();
				KeyBinding.set(i - 100, org.lwjgl.input.Mouse.getEventButtonState());
				if (org.lwjgl.input.Mouse.getEventButtonState()) {
					if (this.player.isSpectator() && i == 2) {
						this.gui.getSpectatorGui().mouseMiddleClicked();
					} else {
						KeyBinding.click(i - 100);
					}
				}

				long l = getTime() - this.lastTickTime;
				if (l <= 200L) {
					int j = org.lwjgl.input.Mouse.getEventDWheel();
					if (j != 0) {
						if (this.player.isSpectator()) {
							j = j < 0 ? -1 : 1;
							if (this.gui.getSpectatorGui().isMenuActive()) {
								this.gui.getSpectatorGui().mouseScrolled(-j);
							} else {
								float f = MathHelper.clamp(this.player.abilities.getFlySpeed() + j * 0.005F, 0.0F, 0.2F);
								this.player.abilities.setFlySpeed(f);
							}
						} else {
							this.player.inventory.scrollInHotbar(j);
						}
					}

					if (this.screen == null) {
						if (!this.focused && org.lwjgl.input.Mouse.getEventButtonState()) {
							this.lockMouse();
						}
					} else if (this.screen != null) {
						this.screen.handleMouse();
					}
				}
			}

			if (this.attackCooldown > 0) {
				this.attackCooldown--;
			}

			this.profiler.swap("keyboard");

			while (Keyboard.next()) {
				int i = Keyboard.getEventKey() == 0 ? Keyboard.getEventCharacter() + 256 : Keyboard.getEventKey();
				KeyBinding.set(i, Keyboard.getEventKeyState());
				if (Keyboard.getEventKeyState()) {
					KeyBinding.click(i);
				}

				if (this.f3CTime > 0L) {
					if (getTime() - this.f3CTime >= 6000L) {
						throw new CrashException(new CrashReport("Manually triggered debug crash", new Throwable()));
					}

					if (!Keyboard.isKeyDown(46) || !Keyboard.isKeyDown(61)) {
						this.f3CTime = -1L;
					}
				} else if (Keyboard.isKeyDown(46) && Keyboard.isKeyDown(61)) {
					this.f3CTime = getTime();
				}

				this.handleGuiKeyBindings();
				if (Keyboard.getEventKeyState()) {
					if (i == 62 && this.gameRenderer != null) {
						this.gameRenderer.disableShader();
					}

					if (this.screen != null) {
						this.screen.handleKeyboard();
					} else {
						if (i == 1) {
							this.pauseGame();
						}

						if (i == 32 && Keyboard.isKeyDown(61) && this.gui != null) {
							this.gui.getChat().clear();
						}

						if (i == 31 && Keyboard.isKeyDown(61)) {
							this.reloadResources();
						}

						if (i == 17 && Keyboard.isKeyDown(61)) {
						}

						if (i == 18 && Keyboard.isKeyDown(61)) {
						}

						if (i == 47 && Keyboard.isKeyDown(61)) {
						}

						if (i == 38 && Keyboard.isKeyDown(61)) {
						}

						if (i == 22 && Keyboard.isKeyDown(61)) {
						}

						if (i == 20 && Keyboard.isKeyDown(61)) {
							this.reloadResources();
						}

						if (i == 33 && Keyboard.isKeyDown(61)) {
							this.options.set(GameOptions.Option.RENDER_DISTANCE, Screen.isShiftDown() ? -1 : 1);
						}

						if (i == 30 && Keyboard.isKeyDown(61)) {
							this.worldRenderer.reload();
						}

						if (i == 35 && Keyboard.isKeyDown(61)) {
							this.options.advancedItemTooltips = !this.options.advancedItemTooltips;
							this.options.save();
						}

						if (i == 48 && Keyboard.isKeyDown(61)) {
							this.entityRenderDispatcher.setRenderHitboxes(!this.entityRenderDispatcher.shouldRenderHitboxes());
						}

						if (i == 25 && Keyboard.isKeyDown(61)) {
							this.options.pauseOnUnfocus = !this.options.pauseOnUnfocus;
							this.options.save();
						}

						if (i == 59) {
							this.options.hideGui = !this.options.hideGui;
						}

						if (i == 61) {
							this.options.debugEnabled = !this.options.debugEnabled;
							this.options.debugProfilerEnabled = Screen.isShiftDown();
							this.options.debugTpsEnabled = Screen.isAltDown();
						}

						if (this.options.togglePerspectiveKey.consumeClick()) {
							this.options.perspective++;
							if (this.options.perspective > 2) {
								this.options.perspective = 0;
							}

							if (this.options.perspective == 0) {
								this.gameRenderer.updateShader(this.getCamera());
							} else if (this.options.perspective == 1) {
								this.gameRenderer.updateShader(null);
							}

							this.worldRenderer.onViewChanged();
						}

						if (this.options.smoothCameraKey.consumeClick()) {
							this.options.smoothCamera = !this.options.smoothCamera;
						}
					}

					if (this.options.debugEnabled && this.options.debugProfilerEnabled) {
						if (i == 11) {
							this.selectProfilerChartSection(0);
						}

						for (int k = 0; k < 9; k++) {
							if (i == 2 + k) {
								this.selectProfilerChartSection(k + 1);
							}
						}
					}
				}
			}

			for (int i = 0; i < 9; i++) {
				if (this.options.hotbarKeyBindings[i].consumeClick()) {
					if (this.player.isSpectator()) {
						this.gui.getSpectatorGui().selectSlot(i);
					} else {
						this.player.inventory.selectedSlot = i;
					}
				}
			}

			boolean bl = this.options.chatVisibility != PlayerEntity.ChatVisibility.HIDDEN;

			while (this.options.inventoryKey.consumeClick()) {
				if (this.interactionManager.hasRidingInventory()) {
					this.player.openRidingInventory();
				} else {
					this.getNetworkHandler().sendPacket(new ClientStatusC2SPacket(ClientStatusC2SPacket.Status.OPEN_INVENTORY_ACHIEVEMENT));
					this.openScreen(new SurvivalInventoryScreen(this.player));
				}
			}

			while (this.options.dropKey.consumeClick()) {
				if (!this.player.isSpectator()) {
					this.player.dropItem(Screen.isControlDown());
				}
			}

			while (this.options.chatKey.consumeClick() && bl) {
				this.openScreen(new ChatScreen());
			}

			if (this.screen == null && this.options.commandKey.consumeClick() && bl) {
				this.openScreen(new ChatScreen("/"));
			}

			if (this.player.hasItemInUse()) {
				if (!this.options.useKey.isPressed()) {
					this.interactionManager.stopUsingHand(this.player);
				}

				while (this.options.attackKey.consumeClick()) {
				}

				while (this.options.useKey.consumeClick()) {
				}

				while (this.options.pickItemKey.consumeClick()) {
				}
			} else {
				while (this.options.attackKey.consumeClick()) {
					this.doAttack();
				}

				while (this.options.useKey.consumeClick()) {
					this.doUse();
				}

				while (this.options.pickItemKey.consumeClick()) {
					this.doPick();
				}
			}

			if (this.options.useKey.isPressed() && this.useKeyCooldown == 0 && !this.player.hasItemInUse()) {
				this.doUse();
			}

			this.handleMouseDown(this.screen == null && this.options.attackKey.isPressed() && this.focused);
		}

		if (this.world != null) {
			if (this.player != null) {
				this.joinPlayerCounter++;
				if (this.joinPlayerCounter == 30) {
					this.joinPlayerCounter = 0;
					this.world.addEntityAlways(this.player);
				}
			}

			this.profiler.swap("gameRenderer");
			if (!this.paused) {
				this.gameRenderer.tick();
			}

			this.profiler.swap("levelRenderer");
			if (!this.paused) {
				this.worldRenderer.tick();
			}

			this.profiler.swap("level");
			if (!this.paused) {
				if (this.world.getLightningCooldown() > 0) {
					this.world.setLightningCooldown(this.world.getLightningCooldown() - 1);
				}

				this.world.tickEntities();
			}
		} else if (this.gameRenderer.hasShader()) {
			this.gameRenderer.closeShader();
		}

		if (!this.paused) {
			this.musicManager.tick();
			this.soundManager.tick();
		}

		if (this.world != null) {
			if (!this.paused) {
				this.world.setAllowedMobSpawns(this.world.getDifficulty() != Difficulty.PEACEFUL, true);

				try {
					this.world.tick();
				} catch (Throwable throwable) {
					CrashReport crashReport = CrashReport.of(throwable, "Exception in world tick");
					if (this.world == null) {
						CrashReportCategory crashReportCategory = crashReport.addCategory("Affected level");
						crashReportCategory.add("Problem", "Level is null!");
					} else {
						this.world.populateCrashReport(crashReport);
					}

					throw new CrashException(crashReport);
				}
			}

			this.profiler.swap("animateTick");
			if (!this.paused && this.world != null) {
				this.world.doRandomDisplayTicks(MathHelper.floor(this.player.x), MathHelper.floor(this.player.y), MathHelper.floor(this.player.z));
			}

			this.profiler.swap("particles");
			if (!this.paused) {
				this.particleManager.tick();
			}
		} else if (this.connection != null) {
			this.profiler.swap("pendingConnection");
			this.connection.tick();
		}

		this.profiler.pop();
		this.lastTickTime = getTime();
	}

	public void startGame(String saveName, String name, WorldSettings settings) {
		this.setWorld(null);
		System.gc();
		WorldStorage worldStorage = this.worldStorageSource.get(saveName, false);
		WorldData worldData = worldStorage.loadData();
		if (worldData == null && settings != null) {
			worldData = new WorldData(settings, saveName);
			worldStorage.saveData(worldData);
		}

		if (settings == null) {
			settings = new WorldSettings(worldData);
		}

		try {
			this.server = new IntegratedServer(this, saveName, name, settings);
			this.server.start();
			this.isIntegratedServerRunning = true;
		} catch (Throwable throwable) {
			CrashReport crashReport = CrashReport.of(throwable, "Starting integrated server");
			CrashReportCategory crashReportCategory = crashReport.addCategory("Starting integrated server");
			crashReportCategory.add("Level ID", saveName);
			crashReportCategory.add("Level Name", name);
			throw new CrashException(crashReport);
		}

		this.progressRenderer.progressStartNoAbort(I18n.translate("menu.loadingLevel"));

		while (!this.server.isLoading()) {
			String string = this.server.getLoadingStage();
			if (string != null) {
				this.progressRenderer.progressStage(I18n.translate(string));
			} else {
				this.progressRenderer.progressStage("");
			}

			try {
				Thread.sleep(200L);
			} catch (InterruptedException var9) {
			}
		}

		this.openScreen(null);
		SocketAddress socketAddress = this.server.getConnection().bindLocal();
		Connection connection = Connection.connectLocal(socketAddress);
		connection.setListener(new ClientLoginNetworkHandler(connection, this, null));
		connection.send(new HandshakeC2SPacket(47, socketAddress.toString(), 0, NetworkProtocol.LOGIN));
		connection.send(new HelloC2SPacket(this.getSession().getProfile()));
		this.connection = connection;
	}

	public void setWorld(ClientWorld world) {
		this.setWorld(world, "");
	}

	public void setWorld(ClientWorld world, String message) {
		if (world == null) {
			ClientPlayNetworkHandler clientPlayNetworkHandler = this.getNetworkHandler();
			if (clientPlayNetworkHandler != null) {
				clientPlayNetworkHandler.closeWorld();
			}

			if (this.server != null && this.server.hasGameDirectory()) {
				this.server.stop();
				this.server.resetInstance();
			}

			this.server = null;
			this.toast.clear();
			this.gameRenderer.getMapRenderer().clearStateTextures();
		}

		this.camera = null;
		this.connection = null;
		if (this.progressRenderer != null) {
			this.progressRenderer.updateTitle(message);
			this.progressRenderer.progressStage("");
		}

		if (world == null && this.world != null) {
			this.resourcePacks.removeServerPack();
			this.gui.resetPlayerTabOverlay();
			this.setCurrentServerEntry(null);
			this.isIntegratedServerRunning = false;
		}

		this.soundManager.stop();
		this.world = world;
		if (world != null) {
			if (this.worldRenderer != null) {
				this.worldRenderer.setWorld(world);
			}

			if (this.particleManager != null) {
				this.particleManager.setWorld(world);
			}

			if (this.player == null) {
				this.player = this.interactionManager.createPlayer(world, new PlayerStats());
				this.interactionManager.initPlayer(this.player);
			}

			this.player.resetPos();
			world.addEntity(this.player);
			this.player.input = new KeyboardInput(this.options);
			this.interactionManager.adjustPlayer(this.player);
			this.camera = this.player;
		} else {
			this.worldStorageSource.flush();
			this.player = null;
		}

		System.gc();
		this.lastTickTime = 0L;
	}

	public void respawnPlayer(int dimension) {
		this.world.resetSpawnPoint();
		this.world.unloadEntities();
		int i = 0;
		String string = null;
		if (this.player != null) {
			i = this.player.getNetworkId();
			this.world.removeEntity(this.player);
			string = this.player.getServerBrand();
		}

		this.camera = null;
		LocalClientPlayerEntity localClientPlayerEntity = this.player;
		this.player = this.interactionManager.createPlayer(this.world, this.player == null ? new PlayerStats() : this.player.getStats());
		this.player.getSyncedData().update(localClientPlayerEntity.getSyncedData().getAll());
		this.player.dimension = dimension;
		this.camera = this.player;
		this.player.resetPos();
		this.player.setServerBrand(string);
		this.world.addEntity(this.player);
		this.interactionManager.initPlayer(this.player);
		this.player.input = new KeyboardInput(this.options);
		this.player.setNetworkId(i);
		this.interactionManager.adjustPlayer(this.player);
		this.player.setReducedDebugInfo(localClientPlayerEntity.hasReducedDebugInfo());
		if (this.screen instanceof DeathScreen) {
			this.openScreen(null);
		}
	}

	public final boolean isDemo() {
		return this.demo;
	}

	public ClientPlayNetworkHandler getNetworkHandler() {
		return this.player != null ? this.player.networkHandler : null;
	}

	public static boolean isDisplayGui() {
		return INSTANCE == null || !INSTANCE.options.hideGui;
	}

	public static boolean isFancyGraphicsEnabled() {
		return INSTANCE != null && INSTANCE.options.fancyGraphics;
	}

	public static boolean isAmbientOcclusionEnabled() {
		return INSTANCE != null && INSTANCE.options.ambientOcclusion != 0;
	}

	private void doPick() {
		if (this.crosshairTarget != null) {
			boolean bl = this.player.abilities.creativeMode;
			int i = 0;
			boolean bl2 = false;
			BlockEntity blockEntity = null;
			Item item;
			if (this.crosshairTarget.type == HitResult.Type.BLOCK) {
				BlockPos blockPos = this.crosshairTarget.getPos();
				Block block = this.world.getBlockState(blockPos).getBlock();
				if (block.getMaterial() == Material.AIR) {
					return;
				}

				item = block.getPickItem(this.world, blockPos);
				if (item == null) {
					return;
				}

				if (bl && Screen.isControlDown()) {
					blockEntity = this.world.getBlockEntity(blockPos);
				}

				Block block2 = item instanceof BlockItem && !block.hasPickItemMetadata() ? Block.byItem(item) : block;
				i = block2.getPickItemMetadata(this.world, blockPos);
				bl2 = item.hasCustomData();
			} else {
				if (this.crosshairTarget.type != HitResult.Type.ENTITY || this.crosshairTarget.entity == null || !bl) {
					return;
				}

				if (this.crosshairTarget.entity instanceof PaintingEntity) {
					item = Items.PAINTING;
				} else if (this.crosshairTarget.entity instanceof LeadKnotEntity) {
					item = Items.LEAD;
				} else if (this.crosshairTarget.entity instanceof ItemFrameEntity) {
					ItemFrameEntity itemFrameEntity = (ItemFrameEntity)this.crosshairTarget.entity;
					ItemStack itemStack = itemFrameEntity.getDisplayItem();
					if (itemStack == null) {
						item = Items.ITEM_FRAME;
					} else {
						item = itemStack.getItem();
						i = itemStack.getMetadata();
						bl2 = true;
					}
				} else if (this.crosshairTarget.entity instanceof MinecartEntity) {
					MinecartEntity minecartEntity = (MinecartEntity)this.crosshairTarget.entity;
					switch (minecartEntity.getMinecartType()) {
						case FURNACE:
							item = Items.FURNACE_MINECART;
							break;
						case CHEST:
							item = Items.CHEST_MINECART;
							break;
						case TNT:
							item = Items.TNT_MINECART;
							break;
						case HOPPER:
							item = Items.HOPPER_MINECART;
							break;
						case COMMAND_BLOCK:
							item = Items.COMMAND_BLOCK_MINECART;
							break;
						default:
							item = Items.MINECART;
					}
				} else if (this.crosshairTarget.entity instanceof BoatEntity) {
					item = Items.BOAT;
				} else if (this.crosshairTarget.entity instanceof ArmorStandEntity) {
					item = Items.ARMOR_STAND;
				} else {
					item = Items.SPAWN_EGG;
					i = Entities.getId(this.crosshairTarget.entity);
					bl2 = true;
					if (!Entities.SPAWN_EGG_DATA.containsKey(i)) {
						return;
					}
				}
			}

			PlayerInventory playerInventory = this.player.inventory;
			if (blockEntity == null) {
				playerInventory.selectSlot(item, i, bl2, bl);
			} else {
				ItemStack itemStack = this.pickBlockEntity(item, i, blockEntity);
				playerInventory.setItem(playerInventory.selectedSlot, itemStack);
			}

			if (bl) {
				int j = this.player.playerMenu.slots.size() - 9 + playerInventory.selectedSlot;
				this.interactionManager.addItemToCreativeMenu(playerInventory.getItem(playerInventory.selectedSlot), j);
			}
		}
	}

	private ItemStack pickBlockEntity(Item item, int metadata, BlockEntity blockEntity) {
		ItemStack itemStack = new ItemStack(item, 1, metadata);
		NbtCompound nbtCompound = new NbtCompound();
		blockEntity.writeNbt(nbtCompound);
		if (item == Items.SKULL && nbtCompound.contains("Owner")) {
			NbtCompound nbtCompound2 = nbtCompound.getCompound("Owner");
			NbtCompound nbtCompound3 = new NbtCompound();
			nbtCompound3.put("SkullOwner", nbtCompound2);
			itemStack.setNbt(nbtCompound3);
			return itemStack;
		} else {
			itemStack.addToNbt("BlockEntityTag", nbtCompound);
			NbtCompound nbtCompound2 = new NbtCompound();
			NbtList nbtList = new NbtList();
			nbtList.addElement(new NbtString("(+NBT)"));
			nbtCompound2.put("Lore", nbtList);
			itemStack.addToNbt("display", nbtCompound2);
			return itemStack;
		}
	}

	public CrashReport populateCrashReport(CrashReport report) {
		report.getSystemDetails().add("Launched Version", new Callable<String>() {
			public String call() {
				return Minecraft.this.gameVersion;
			}
		});
		report.getSystemDetails().add("LWJGL", new Callable<String>() {
			public String call() {
				return Sys.getVersion();
			}
		});
		report.getSystemDetails().add("OpenGL", new Callable<String>() {
			public String call() {
				return GL11.glGetString(7937) + " GL version " + GL11.glGetString(7938) + ", " + GL11.glGetString(7936);
			}
		});
		report.getSystemDetails().add("GL Caps", new Callable<String>() {
			public String call() {
				return GLX.getGlCapsInfo();
			}
		});
		report.getSystemDetails().add("Using VBOs", new Callable<String>() {
			public String call() {
				return Minecraft.this.options.useVbo ? "Yes" : "No";
			}
		});
		report.getSystemDetails()
			.add(
				"Is Modded",
				new Callable<String>() {
					public String call() throws Exception {
						String string = ClientBrandRetriever.getClientModName();
						if (!string.equals("vanilla")) {
							return "Definitely; Client brand changed to '" + string + "'";
						} else {
							return Minecraft.class.getSigners() == null
								? "Very likely; Jar signature invalidated"
								: "Probably not. Jar signature remains and client brand is untouched.";
						}
					}
				}
			);
		report.getSystemDetails().add("Type", new Callable<String>() {
			public String call() throws Exception {
				return "Client (map_client.txt)";
			}
		});
		report.getSystemDetails().add("Resource Packs", new Callable<String>() {
			public String call() throws Exception {
				StringBuilder stringBuilder = new StringBuilder();

				for (String string : Minecraft.this.options.resourcePacks) {
					if (stringBuilder.length() > 0) {
						stringBuilder.append(", ");
					}

					stringBuilder.append(string);
					if (Minecraft.this.options.incompatibleResourcePacks.contains(string)) {
						stringBuilder.append(" (incompatible)");
					}
				}

				return stringBuilder.toString();
			}
		});
		report.getSystemDetails().add("Current Language", new Callable<String>() {
			public String call() throws Exception {
				return Minecraft.this.languageManager.getLanguage().toString();
			}
		});
		report.getSystemDetails().add("Profiler Position", new Callable<String>() {
			public String call() throws Exception {
				return Minecraft.this.profiler.profiling ? Minecraft.this.profiler.getCurrentLocation() : "N/A (disabled)";
			}
		});
		report.getSystemDetails().add("CPU", new Callable<String>() {
			public String call() {
				return GLX.getCpuInfo();
			}
		});
		if (this.world != null) {
			this.world.populateCrashReport(report);
		}

		return report;
	}

	public static Minecraft getInstance() {
		return INSTANCE;
	}

	public ListenableFuture<Object> submitResourceReload() {
		return this.executeTask(new Runnable() {
			@Override
			public void run() {
				Minecraft.this.reloadResources();
			}
		});
	}

	@Override
	public void populateSnooper(Snooper snooper) {
		snooper.putDynamic("fps", currentFps);
		snooper.putDynamic("vsync_enabled", this.options.vsync);
		snooper.putDynamic("display_frequency", Display.getDisplayMode().getFrequency());
		snooper.putDynamic("display_type", this.fullscreen ? "fullscreen" : "windowed");
		snooper.putDynamic("run_time", (MinecraftServer.getTimeMillis() - snooper.getInitTime()) / 60L * 1000L);
		snooper.putDynamic("current_action", this.getCurrentAction());
		String string = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN ? "little" : "big";
		snooper.putDynamic("endianness", string);
		snooper.putDynamic("resource_packs", this.resourcePacks.getSelectedPacks().size());
		int i = 0;

		for (ResourcePacks.UnopenedPack unopenedPack : this.resourcePacks.getSelectedPacks()) {
			snooper.putDynamic("resource_pack[" + i++ + "]", unopenedPack.getName());
		}

		if (this.server != null && this.server.getSnooper() != null) {
			snooper.putDynamic("snooper_partner", this.server.getSnooper().getToken());
		}
	}

	private String getCurrentAction() {
		if (this.server != null) {
			return this.server.isPublished() ? "hosting_lan" : "singleplayer";
		} else if (this.currentServerEntry != null) {
			return this.currentServerEntry.isLocal() ? "playing_lan" : "multiplayer";
		} else {
			return "out_of_game";
		}
	}

	@Override
	public void initSnooper(Snooper snooper) {
		snooper.putFixed("opengl_version", GL11.glGetString(7938));
		snooper.putFixed("opengl_vendor", GL11.glGetString(7936));
		snooper.putFixed("client_brand", ClientBrandRetriever.getClientModName());
		snooper.putFixed("launched_version", this.gameVersion);
		ContextCapabilities contextCapabilities = GLContext.getCapabilities();
		snooper.putFixed("gl_caps[ARB_arrays_of_arrays]", contextCapabilities.GL_ARB_arrays_of_arrays);
		snooper.putFixed("gl_caps[ARB_base_instance]", contextCapabilities.GL_ARB_base_instance);
		snooper.putFixed("gl_caps[ARB_blend_func_extended]", contextCapabilities.GL_ARB_blend_func_extended);
		snooper.putFixed("gl_caps[ARB_clear_buffer_object]", contextCapabilities.GL_ARB_clear_buffer_object);
		snooper.putFixed("gl_caps[ARB_color_buffer_float]", contextCapabilities.GL_ARB_color_buffer_float);
		snooper.putFixed("gl_caps[ARB_compatibility]", contextCapabilities.GL_ARB_compatibility);
		snooper.putFixed("gl_caps[ARB_compressed_texture_pixel_storage]", contextCapabilities.GL_ARB_compressed_texture_pixel_storage);
		snooper.putFixed("gl_caps[ARB_compute_shader]", contextCapabilities.GL_ARB_compute_shader);
		snooper.putFixed("gl_caps[ARB_copy_buffer]", contextCapabilities.GL_ARB_copy_buffer);
		snooper.putFixed("gl_caps[ARB_copy_image]", contextCapabilities.GL_ARB_copy_image);
		snooper.putFixed("gl_caps[ARB_depth_buffer_float]", contextCapabilities.GL_ARB_depth_buffer_float);
		snooper.putFixed("gl_caps[ARB_compute_shader]", contextCapabilities.GL_ARB_compute_shader);
		snooper.putFixed("gl_caps[ARB_copy_buffer]", contextCapabilities.GL_ARB_copy_buffer);
		snooper.putFixed("gl_caps[ARB_copy_image]", contextCapabilities.GL_ARB_copy_image);
		snooper.putFixed("gl_caps[ARB_depth_buffer_float]", contextCapabilities.GL_ARB_depth_buffer_float);
		snooper.putFixed("gl_caps[ARB_depth_clamp]", contextCapabilities.GL_ARB_depth_clamp);
		snooper.putFixed("gl_caps[ARB_depth_texture]", contextCapabilities.GL_ARB_depth_texture);
		snooper.putFixed("gl_caps[ARB_draw_buffers]", contextCapabilities.GL_ARB_draw_buffers);
		snooper.putFixed("gl_caps[ARB_draw_buffers_blend]", contextCapabilities.GL_ARB_draw_buffers_blend);
		snooper.putFixed("gl_caps[ARB_draw_elements_base_vertex]", contextCapabilities.GL_ARB_draw_elements_base_vertex);
		snooper.putFixed("gl_caps[ARB_draw_indirect]", contextCapabilities.GL_ARB_draw_indirect);
		snooper.putFixed("gl_caps[ARB_draw_instanced]", contextCapabilities.GL_ARB_draw_instanced);
		snooper.putFixed("gl_caps[ARB_explicit_attrib_location]", contextCapabilities.GL_ARB_explicit_attrib_location);
		snooper.putFixed("gl_caps[ARB_explicit_uniform_location]", contextCapabilities.GL_ARB_explicit_uniform_location);
		snooper.putFixed("gl_caps[ARB_fragment_layer_viewport]", contextCapabilities.GL_ARB_fragment_layer_viewport);
		snooper.putFixed("gl_caps[ARB_fragment_program]", contextCapabilities.GL_ARB_fragment_program);
		snooper.putFixed("gl_caps[ARB_fragment_shader]", contextCapabilities.GL_ARB_fragment_shader);
		snooper.putFixed("gl_caps[ARB_fragment_program_shadow]", contextCapabilities.GL_ARB_fragment_program_shadow);
		snooper.putFixed("gl_caps[ARB_framebuffer_object]", contextCapabilities.GL_ARB_framebuffer_object);
		snooper.putFixed("gl_caps[ARB_framebuffer_sRGB]", contextCapabilities.GL_ARB_framebuffer_sRGB);
		snooper.putFixed("gl_caps[ARB_geometry_shader4]", contextCapabilities.GL_ARB_geometry_shader4);
		snooper.putFixed("gl_caps[ARB_gpu_shader5]", contextCapabilities.GL_ARB_gpu_shader5);
		snooper.putFixed("gl_caps[ARB_half_float_pixel]", contextCapabilities.GL_ARB_half_float_pixel);
		snooper.putFixed("gl_caps[ARB_half_float_vertex]", contextCapabilities.GL_ARB_half_float_vertex);
		snooper.putFixed("gl_caps[ARB_instanced_arrays]", contextCapabilities.GL_ARB_instanced_arrays);
		snooper.putFixed("gl_caps[ARB_map_buffer_alignment]", contextCapabilities.GL_ARB_map_buffer_alignment);
		snooper.putFixed("gl_caps[ARB_map_buffer_range]", contextCapabilities.GL_ARB_map_buffer_range);
		snooper.putFixed("gl_caps[ARB_multisample]", contextCapabilities.GL_ARB_multisample);
		snooper.putFixed("gl_caps[ARB_multitexture]", contextCapabilities.GL_ARB_multitexture);
		snooper.putFixed("gl_caps[ARB_occlusion_query2]", contextCapabilities.GL_ARB_occlusion_query2);
		snooper.putFixed("gl_caps[ARB_pixel_buffer_object]", contextCapabilities.GL_ARB_pixel_buffer_object);
		snooper.putFixed("gl_caps[ARB_seamless_cube_map]", contextCapabilities.GL_ARB_seamless_cube_map);
		snooper.putFixed("gl_caps[ARB_shader_objects]", contextCapabilities.GL_ARB_shader_objects);
		snooper.putFixed("gl_caps[ARB_shader_stencil_export]", contextCapabilities.GL_ARB_shader_stencil_export);
		snooper.putFixed("gl_caps[ARB_shader_texture_lod]", contextCapabilities.GL_ARB_shader_texture_lod);
		snooper.putFixed("gl_caps[ARB_shadow]", contextCapabilities.GL_ARB_shadow);
		snooper.putFixed("gl_caps[ARB_shadow_ambient]", contextCapabilities.GL_ARB_shadow_ambient);
		snooper.putFixed("gl_caps[ARB_stencil_texturing]", contextCapabilities.GL_ARB_stencil_texturing);
		snooper.putFixed("gl_caps[ARB_sync]", contextCapabilities.GL_ARB_sync);
		snooper.putFixed("gl_caps[ARB_tessellation_shader]", contextCapabilities.GL_ARB_tessellation_shader);
		snooper.putFixed("gl_caps[ARB_texture_border_clamp]", contextCapabilities.GL_ARB_texture_border_clamp);
		snooper.putFixed("gl_caps[ARB_texture_buffer_object]", contextCapabilities.GL_ARB_texture_buffer_object);
		snooper.putFixed("gl_caps[ARB_texture_cube_map]", contextCapabilities.GL_ARB_texture_cube_map);
		snooper.putFixed("gl_caps[ARB_texture_cube_map_array]", contextCapabilities.GL_ARB_texture_cube_map_array);
		snooper.putFixed("gl_caps[ARB_texture_non_power_of_two]", contextCapabilities.GL_ARB_texture_non_power_of_two);
		snooper.putFixed("gl_caps[ARB_uniform_buffer_object]", contextCapabilities.GL_ARB_uniform_buffer_object);
		snooper.putFixed("gl_caps[ARB_vertex_blend]", contextCapabilities.GL_ARB_vertex_blend);
		snooper.putFixed("gl_caps[ARB_vertex_buffer_object]", contextCapabilities.GL_ARB_vertex_buffer_object);
		snooper.putFixed("gl_caps[ARB_vertex_program]", contextCapabilities.GL_ARB_vertex_program);
		snooper.putFixed("gl_caps[ARB_vertex_shader]", contextCapabilities.GL_ARB_vertex_shader);
		snooper.putFixed("gl_caps[EXT_bindable_uniform]", contextCapabilities.GL_EXT_bindable_uniform);
		snooper.putFixed("gl_caps[EXT_blend_equation_separate]", contextCapabilities.GL_EXT_blend_equation_separate);
		snooper.putFixed("gl_caps[EXT_blend_func_separate]", contextCapabilities.GL_EXT_blend_func_separate);
		snooper.putFixed("gl_caps[EXT_blend_minmax]", contextCapabilities.GL_EXT_blend_minmax);
		snooper.putFixed("gl_caps[EXT_blend_subtract]", contextCapabilities.GL_EXT_blend_subtract);
		snooper.putFixed("gl_caps[EXT_draw_instanced]", contextCapabilities.GL_EXT_draw_instanced);
		snooper.putFixed("gl_caps[EXT_framebuffer_multisample]", contextCapabilities.GL_EXT_framebuffer_multisample);
		snooper.putFixed("gl_caps[EXT_framebuffer_object]", contextCapabilities.GL_EXT_framebuffer_object);
		snooper.putFixed("gl_caps[EXT_framebuffer_sRGB]", contextCapabilities.GL_EXT_framebuffer_sRGB);
		snooper.putFixed("gl_caps[EXT_geometry_shader4]", contextCapabilities.GL_EXT_geometry_shader4);
		snooper.putFixed("gl_caps[EXT_gpu_program_parameters]", contextCapabilities.GL_EXT_gpu_program_parameters);
		snooper.putFixed("gl_caps[EXT_gpu_shader4]", contextCapabilities.GL_EXT_gpu_shader4);
		snooper.putFixed("gl_caps[EXT_multi_draw_arrays]", contextCapabilities.GL_EXT_multi_draw_arrays);
		snooper.putFixed("gl_caps[EXT_packed_depth_stencil]", contextCapabilities.GL_EXT_packed_depth_stencil);
		snooper.putFixed("gl_caps[EXT_paletted_texture]", contextCapabilities.GL_EXT_paletted_texture);
		snooper.putFixed("gl_caps[EXT_rescale_normal]", contextCapabilities.GL_EXT_rescale_normal);
		snooper.putFixed("gl_caps[EXT_separate_shader_objects]", contextCapabilities.GL_EXT_separate_shader_objects);
		snooper.putFixed("gl_caps[EXT_shader_image_load_store]", contextCapabilities.GL_EXT_shader_image_load_store);
		snooper.putFixed("gl_caps[EXT_shadow_funcs]", contextCapabilities.GL_EXT_shadow_funcs);
		snooper.putFixed("gl_caps[EXT_shared_texture_palette]", contextCapabilities.GL_EXT_shared_texture_palette);
		snooper.putFixed("gl_caps[EXT_stencil_clear_tag]", contextCapabilities.GL_EXT_stencil_clear_tag);
		snooper.putFixed("gl_caps[EXT_stencil_two_side]", contextCapabilities.GL_EXT_stencil_two_side);
		snooper.putFixed("gl_caps[EXT_stencil_wrap]", contextCapabilities.GL_EXT_stencil_wrap);
		snooper.putFixed("gl_caps[EXT_texture_3d]", contextCapabilities.GL_EXT_texture_3d);
		snooper.putFixed("gl_caps[EXT_texture_array]", contextCapabilities.GL_EXT_texture_array);
		snooper.putFixed("gl_caps[EXT_texture_buffer_object]", contextCapabilities.GL_EXT_texture_buffer_object);
		snooper.putFixed("gl_caps[EXT_texture_integer]", contextCapabilities.GL_EXT_texture_integer);
		snooper.putFixed("gl_caps[EXT_texture_lod_bias]", contextCapabilities.GL_EXT_texture_lod_bias);
		snooper.putFixed("gl_caps[EXT_texture_sRGB]", contextCapabilities.GL_EXT_texture_sRGB);
		snooper.putFixed("gl_caps[EXT_vertex_shader]", contextCapabilities.GL_EXT_vertex_shader);
		snooper.putFixed("gl_caps[EXT_vertex_weighting]", contextCapabilities.GL_EXT_vertex_weighting);
		snooper.putFixed("gl_caps[gl_max_vertex_uniforms]", GL11.glGetInteger(35658));
		GL11.glGetError();
		snooper.putFixed("gl_caps[gl_max_fragment_uniforms]", GL11.glGetInteger(35657));
		GL11.glGetError();
		snooper.putFixed("gl_caps[gl_max_vertex_attribs]", GL11.glGetInteger(34921));
		GL11.glGetError();
		snooper.putFixed("gl_caps[gl_max_vertex_texture_image_units]", GL11.glGetInteger(35660));
		GL11.glGetError();
		snooper.putFixed("gl_caps[gl_max_texture_image_units]", GL11.glGetInteger(34930));
		GL11.glGetError();
		snooper.putFixed("gl_caps[gl_max_texture_image_units]", GL11.glGetInteger(35071));
		GL11.glGetError();
		snooper.putFixed("gl_max_texture_size", getMaxTextureSize());
	}

	public static int getMaxTextureSize() {
		for (int i = 16384; i > 0; i >>= 1) {
			GL11.glTexImage2D(32868, 0, 6408, i, i, 0, 6408, 5121, (ByteBuffer)null);
			int j = GL11.glGetTexLevelParameteri(32868, 0, 4096);
			if (j != 0) {
				return i;
			}
		}

		return -1;
	}

	@Override
	public boolean isSnooperEnabled() {
		return this.options.snooperEnabled;
	}

	public void setCurrentServerEntry(ServerListEntry serverEntry) {
		this.currentServerEntry = serverEntry;
	}

	public ServerListEntry getCurrentServerEntry() {
		return this.currentServerEntry;
	}

	public boolean isIntegratedServerRunning() {
		return this.isIntegratedServerRunning;
	}

	public boolean isSingleplayer() {
		return this.isIntegratedServerRunning && this.server != null;
	}

	public IntegratedServer getServer() {
		return this.server;
	}

	public static void stopServer() {
		if (INSTANCE != null) {
			IntegratedServer integratedServer = INSTANCE.getServer();
			if (integratedServer != null) {
				integratedServer.shutdown();
			}
		}
	}

	public Snooper getSnooper() {
		return this.snooper;
	}

	public static long getTime() {
		return Sys.getTime() * 1000L / Sys.getTimerResolution();
	}

	public boolean isFullscreen() {
		return this.fullscreen;
	}

	public Session getSession() {
		return this.session;
	}

	public PropertyMap getUserProperties() {
		return this.userProperties;
	}

	public PropertyMap getProfileProperties() {
		if (this.profileProperties.isEmpty()) {
			GameProfile gameProfile = this.getSessionService().fillProfileProperties(this.session.getProfile(), false);
			this.profileProperties.putAll(gameProfile.getProperties());
		}

		return this.profileProperties;
	}

	public Proxy getNetworkProxy() {
		return this.proxy;
	}

	public TextureManager getTextureManager() {
		return this.textureManager;
	}

	public ResourceManager getResourceManager() {
		return this.resourceManager;
	}

	public ResourcePacks getResourcePacks() {
		return this.resourcePacks;
	}

	public LanguageManager getLanguageManager() {
		return this.languageManager;
	}

	public TextureAtlas getBlocksAtlas() {
		return this.blocksAtlas;
	}

	public boolean is64Bit() {
		return this.is64Bit;
	}

	public boolean isPaused() {
		return this.paused;
	}

	public SoundManager getSoundManager() {
		return this.soundManager;
	}

	public MusicManager.Music getMusicEnvironment() {
		if (this.player != null) {
			if (this.player.world.dimension instanceof NetherDimension) {
				return MusicManager.Music.NETHER;
			} else if (this.player.world.dimension instanceof TheEndDimension) {
				return BossBar.name != null && BossBar.timer > 0 ? MusicManager.Music.END_BOSS : MusicManager.Music.END;
			} else {
				return this.player.abilities.creativeMode && this.player.abilities.canFly ? MusicManager.Music.CREATIVE : MusicManager.Music.GAME;
			}
		} else {
			return MusicManager.Music.MENU;
		}
	}

	public TwitchStream getTwitchStream() {
		return this.twitchStream;
	}

	public void handleGuiKeyBindings() {
		int i = Keyboard.getEventKey() == 0 ? Keyboard.getEventCharacter() : Keyboard.getEventKey();
		if (i != 0 && !Keyboard.isRepeatEvent()) {
			if (!(this.screen instanceof ControlsOptionsScreen) || ((ControlsOptionsScreen)this.screen).time <= getTime() - 20L) {
				if (Keyboard.getEventKeyState()) {
					if (i == this.options.streamStartStopKey.getKeyCode()) {
						if (this.getTwitchStream().isBroadcasting()) {
							this.getTwitchStream().stop();
						} else if (this.getTwitchStream().isReadyToBroadcast()) {
							this.openScreen(new ConfirmScreen(new ConfirmationListener() {
								@Override
								public void confirmResult(boolean result, int id) {
									if (result) {
										Minecraft.this.getTwitchStream().start();
									}

									Minecraft.this.openScreen(null);
								}
							}, I18n.translate("stream.confirm_start"), "", 0));
						} else if (!this.getTwitchStream().m_47846141() || !this.getTwitchStream().canBroadcast()) {
							StreamUnavailableScreen.m_90754652(this.screen);
						} else if (this.world != null) {
							this.gui.getChat().addMessage(new LiteralText("Not ready to start streaming yet!"));
						}
					} else if (i == this.options.streamPauseKey.getKeyCode()) {
						if (this.getTwitchStream().isBroadcasting()) {
							if (this.getTwitchStream().isPaused()) {
								this.getTwitchStream().resume();
							} else {
								this.getTwitchStream().pause();
							}
						}
					} else if (i == this.options.streamCommercialKey.getKeyCode()) {
						if (this.getTwitchStream().isBroadcasting()) {
							this.getTwitchStream().runCommercial();
						}
					} else if (i == this.options.streamToggleMicKey.getKeyCode()) {
						this.twitchStream.m_81426620(true);
					} else if (i == this.options.fullscreenKey.getKeyCode()) {
						this.toggleFullscreen();
					} else if (i == this.options.screenshotKey.getKeyCode()) {
						this.gui.getChat().addMessage(Screenshot.take(this.gameDir, this.width, this.height, this.renderTarget));
					}
				} else if (i == this.options.streamToggleMicKey.getKeyCode()) {
					this.twitchStream.m_81426620(false);
				}
			}
		}
	}

	public MinecraftSessionService getSessionService() {
		return this.sessionService;
	}

	public SkinManager getSkinManager() {
		return this.skinManager;
	}

	public Entity getCamera() {
		return this.camera;
	}

	public void setCamera(Entity camera) {
		this.camera = camera;
		this.gameRenderer.updateShader(camera);
	}

	public <V> ListenableFuture<V> executeTask(Callable<V> task) {
		Validate.notNull(task);
		if (!this.isOnSameThread()) {
			ListenableFutureTask<V> listenableFutureTask = ListenableFutureTask.create(task);
			synchronized (this.tasks) {
				this.tasks.add(listenableFutureTask);
				return listenableFutureTask;
			}
		} else {
			try {
				return Futures.immediateFuture(task.call());
			} catch (Exception exception) {
				return Futures.immediateFailedCheckedFuture(exception);
			}
		}
	}

	@Override
	public ListenableFuture<Object> executeTask(Runnable task) {
		Validate.notNull(task);
		return this.executeTask(Executors.callable(task));
	}

	@Override
	public boolean isOnSameThread() {
		return Thread.currentThread() == this.thread;
	}

	public BlockRenderDispatcher getBlockRenderDispatcher() {
		return this.blockRenderer;
	}

	public EntityRenderDispatcher getEntityRenderDispatcher() {
		return this.entityRenderDispatcher;
	}

	public ItemRenderer getItemRenderer() {
		return this.itemRenderer;
	}

	public ItemInHandRenderer getItemInHandRenderer() {
		return this.itemInHandRenderer;
	}

	public static int getCurrentFps() {
		return currentFps;
	}

	public FrameTimeLogger getFrameTimeLogger() {
		return this.frameTimeLogger;
	}

	public static Map<String, String> getHttpRequestProperties() {
		Map<String, String> map = Maps.newHashMap();
		map.put("X-Minecraft-Username", getInstance().getSession().getUsername());
		map.put("X-Minecraft-UUID", getInstance().getSession().getUuid());
		map.put("X-Minecraft-Version", "1.8.9");
		return map;
	}

	public boolean isConnectedToRealms() {
		return this.connectedToRealms;
	}

	public void setConnectedToRealms(boolean connectedToRealms) {
		this.connectedToRealms = connectedToRealms;
	}
}

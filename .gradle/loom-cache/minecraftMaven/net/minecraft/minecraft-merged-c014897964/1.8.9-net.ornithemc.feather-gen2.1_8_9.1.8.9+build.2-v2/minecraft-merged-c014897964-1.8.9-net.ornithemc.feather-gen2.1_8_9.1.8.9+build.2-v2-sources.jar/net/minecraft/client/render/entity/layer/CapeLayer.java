package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.entity.living.player.ClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerRenderer;
import net.minecraft.client.render.model.PlayerModelPart;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class CapeLayer implements EntityRenderLayer<ClientPlayerEntity> {
	private final PlayerRenderer parent;

	public CapeLayer(PlayerRenderer parent) {
		this.parent = parent;
	}

	public void render(
		ClientPlayerEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale
	) {
		if (entity.hasInfo() && !entity.isInvisible() && entity.isModelPartVisible(PlayerModelPart.CAPE) && entity.getCapeTextureLocation() != null) {
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			this.parent.bindTexture(entity.getCapeTextureLocation());
			GlStateManager.pushMatrix();
			GlStateManager.translatef(0.0F, 0.0F, 0.125F);
			double d = entity.lastCapeX + (entity.capeX - entity.lastCapeX) * tickDelta - (entity.lastX + (entity.x - entity.lastX) * tickDelta);
			double e = entity.lastCapeY + (entity.capeY - entity.lastCapeY) * tickDelta - (entity.lastY + (entity.y - entity.lastY) * tickDelta);
			double f = entity.lastCapeZ + (entity.capeZ - entity.lastCapeZ) * tickDelta - (entity.lastZ + (entity.z - entity.lastZ) * tickDelta);
			float g = entity.lastBodyYaw + (entity.bodyYaw - entity.lastBodyYaw) * tickDelta;
			double h = MathHelper.sin(g * (float) Math.PI / 180.0F);
			double i = -MathHelper.cos(g * (float) Math.PI / 180.0F);
			float j = (float)e * 10.0F;
			j = MathHelper.clamp(j, -6.0F, 32.0F);
			float k = (float)(d * h + f * i) * 100.0F;
			float l = (float)(d * i - f * h) * 100.0F;
			if (k < 0.0F) {
				k = 0.0F;
			}

			float m = entity.lastBob + (entity.bob - entity.lastBob) * tickDelta;
			j += MathHelper.sin((entity.lastWalkDistance + (entity.walkDistance - entity.lastWalkDistance) * tickDelta) * 6.0F) * 32.0F * m;
			if (entity.isSneaking()) {
				j += 25.0F;
			}

			GlStateManager.rotatef(6.0F + k / 2.0F + j, 1.0F, 0.0F, 0.0F);
			GlStateManager.rotatef(l / 2.0F, 0.0F, 0.0F, 1.0F);
			GlStateManager.rotatef(-l / 2.0F, 0.0F, 1.0F, 0.0F);
			GlStateManager.rotatef(180.0F, 0.0F, 1.0F, 0.0F);
			this.parent.getModel().renderCape(0.0625F);
			GlStateManager.popMatrix();
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

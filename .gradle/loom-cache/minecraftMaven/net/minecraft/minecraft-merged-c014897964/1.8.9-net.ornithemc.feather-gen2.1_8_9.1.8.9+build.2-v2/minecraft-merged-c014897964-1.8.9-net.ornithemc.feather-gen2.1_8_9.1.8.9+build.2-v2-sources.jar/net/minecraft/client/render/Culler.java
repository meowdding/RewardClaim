package net.minecraft.client.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.math.Box;

@Environment(EnvType.CLIENT)
public interface Culler {
	boolean isVisible(Box shape);

	void prepare(double offsetX, double offsetY, double offsetZ);
}

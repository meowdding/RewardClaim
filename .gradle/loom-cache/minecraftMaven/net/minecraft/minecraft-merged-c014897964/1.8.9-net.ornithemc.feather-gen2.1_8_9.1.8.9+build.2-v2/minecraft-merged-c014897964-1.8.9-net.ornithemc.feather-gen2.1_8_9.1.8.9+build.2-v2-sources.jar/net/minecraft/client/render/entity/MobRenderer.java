package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Culler;
import net.minecraft.client.render.model.Model;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.DecorationEntity;
import net.minecraft.entity.living.mob.MobEntity;

@Environment(EnvType.CLIENT)
public abstract class MobRenderer<T extends MobEntity> extends LivingEntityRenderer<T> {
	public MobRenderer(EntityRenderDispatcher entityRenderDispatcher, Model model, float f) {
		super(entityRenderDispatcher, model, f);
	}

	protected boolean shouldRenderNameTag(T entity) {
		return super.shouldRenderNameTag(entity) && (entity.shouldShowNameTag() || entity.hasCustomName() && entity == this.dispatcher.targetEntity);
	}

	public boolean shouldRender(T entity, Culler view, double cameraX, double cameraY, double cameraZ) {
		if (super.shouldRender(entity, view, cameraX, cameraY, cameraZ)) {
			return true;
		} else if (entity.isLeashed() && entity.getLeashHolder() != null) {
			Entity entity2 = entity.getLeashHolder();
			return view.isVisible(entity2.getShape());
		} else {
			return false;
		}
	}

	public void render(T entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		super.render(entity, dx, dy, dz, yaw, tickDelta);
		this.renderRiders(entity, dx, dy, dz, yaw, tickDelta);
	}

	public void setLightColor(T mob, float tickDelta) {
		int i = mob.getLightLevel(tickDelta);
		int j = i % 65536;
		int k = i / 65536;
		GLX.multiTexCoord2f(GLX.GL_TEXTURE1, j / 1.0F, k / 1.0F);
	}

	private double lerp(double from, double to, double amount) {
		return from + (to - from) * amount;
	}

	protected void renderRiders(T entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		Entity entity2 = entity.getLeashHolder();
		if (entity2 != null) {
			dy -= (1.6 - entity.height) * 0.5;
			Tesselator tesselator = Tesselator.getInstance();
			BufferBuilder bufferBuilder = tesselator.getBuffer();
			double d = this.lerp(entity2.lastYaw, entity2.yaw, tickDelta * 0.5F) * (float) (Math.PI / 180.0);
			double e = this.lerp(entity2.lastPitch, entity2.pitch, tickDelta * 0.5F) * (float) (Math.PI / 180.0);
			double f = Math.cos(d);
			double g = Math.sin(d);
			double h = Math.sin(e);
			if (entity2 instanceof DecorationEntity) {
				f = 0.0;
				g = 0.0;
				h = -1.0;
			}

			double i = Math.cos(e);
			double j = this.lerp(entity2.lastX, entity2.x, tickDelta) - f * 0.7 - g * 0.5 * i;
			double k = this.lerp(entity2.lastY + entity2.getEyeHeight() * 0.7, entity2.y + entity2.getEyeHeight() * 0.7, tickDelta) - h * 0.5 - 0.25;
			double l = this.lerp(entity2.lastZ, entity2.z, tickDelta) - g * 0.7 + f * 0.5 * i;
			double m = this.lerp(entity.lastBodyYaw, entity.bodyYaw, tickDelta) * (float) (Math.PI / 180.0) + (Math.PI / 2);
			f = Math.cos(m) * entity.width * 0.4;
			g = Math.sin(m) * entity.width * 0.4;
			double n = this.lerp(entity.lastX, entity.x, tickDelta) + f;
			double o = this.lerp(entity.lastY, entity.y, tickDelta);
			double p = this.lerp(entity.lastZ, entity.z, tickDelta) + g;
			dx += f;
			dz += g;
			double q = (float)(j - n);
			double r = (float)(k - o);
			double s = (float)(l - p);
			GlStateManager.disableTexture();
			GlStateManager.disableLighting();
			GlStateManager.disableCull();
			int t = 24;
			double u = 0.025;
			bufferBuilder.begin(5, DefaultVertexFormat.POSITION_COLOR);

			for (int v = 0; v <= 24; v++) {
				float w = 0.5F;
				float x = 0.4F;
				float y = 0.3F;
				if (v % 2 == 0) {
					w *= 0.7F;
					x *= 0.7F;
					y *= 0.7F;
				}

				float z = v / 24.0F;
				bufferBuilder.vertex(dx + q * z + 0.0, dy + r * (z * z + z) * 0.5 + ((24.0F - v) / 18.0F + 0.125F), dz + s * z).color(w, x, y, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + q * z + 0.025, dy + r * (z * z + z) * 0.5 + ((24.0F - v) / 18.0F + 0.125F) + 0.025, dz + s * z).color(w, x, y, 1.0F).nextVertex();
			}

			tesselator.end();
			bufferBuilder.begin(5, DefaultVertexFormat.POSITION_COLOR);

			for (int v = 0; v <= 24; v++) {
				float w = 0.5F;
				float x = 0.4F;
				float y = 0.3F;
				if (v % 2 == 0) {
					w *= 0.7F;
					x *= 0.7F;
					y *= 0.7F;
				}

				float z = v / 24.0F;
				bufferBuilder.vertex(dx + q * z + 0.0, dy + r * (z * z + z) * 0.5 + ((24.0F - v) / 18.0F + 0.125F) + 0.025, dz + s * z).color(w, x, y, 1.0F).nextVertex();
				bufferBuilder.vertex(dx + q * z + 0.025, dy + r * (z * z + z) * 0.5 + ((24.0F - v) / 18.0F + 0.125F), dz + s * z + 0.025).color(w, x, y, 1.0F).nextVertex();
			}

			tesselator.end();
			GlStateManager.enableLighting();
			GlStateManager.enableTexture();
			GlStateManager.enableCull();
		}
	}
}

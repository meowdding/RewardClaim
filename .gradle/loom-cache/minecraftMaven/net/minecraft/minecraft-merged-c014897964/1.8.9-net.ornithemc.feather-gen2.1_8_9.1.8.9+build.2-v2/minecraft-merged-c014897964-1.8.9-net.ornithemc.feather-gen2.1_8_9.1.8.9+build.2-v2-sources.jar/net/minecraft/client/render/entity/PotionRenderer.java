package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.projectile.PotionEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

@Environment(EnvType.CLIENT)
public class PotionRenderer extends ItemSpriteRenderer<PotionEntity> {
	public PotionRenderer(EntityRenderDispatcher dispatcher, ItemRenderer itemRenderer) {
		super(dispatcher, Items.POTION, itemRenderer);
	}

	public ItemStack getItem(PotionEntity entity) {
		return new ItemStack(this.item, 1, entity.getPotion());
	}
}

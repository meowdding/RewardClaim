package net.minecraft.block;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.entity.Entity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.LeadItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

public class FenceBlock extends Block {
	public static final BooleanProperty NORTH = BooleanProperty.of("north");
	public static final BooleanProperty EAST = BooleanProperty.of("east");
	public static final BooleanProperty SOUTH = BooleanProperty.of("south");
	public static final BooleanProperty WEST = BooleanProperty.of("west");

	public FenceBlock(Material material) {
		this(material, material.getColor());
	}

	public FenceBlock(Material material, MapColor mapColor) {
		super(material, mapColor);
		this.setDefaultState(this.stateDefinition.any().set(NORTH, false).set(EAST, false).set(SOUTH, false).set(WEST, false));
		this.setCreativeModeTab(CreativeModeTab.DECORATIONS);
	}

	@Override
	public void addCollisions(World world, BlockPos pos, BlockState state, Box shape, List<Box> collisions, Entity entity) {
		boolean bl = this.shouldConnectTo(world, pos.north());
		boolean bl2 = this.shouldConnectTo(world, pos.south());
		boolean bl3 = this.shouldConnectTo(world, pos.west());
		boolean bl4 = this.shouldConnectTo(world, pos.east());
		float f = 0.375F;
		float g = 0.625F;
		float h = 0.375F;
		float i = 0.625F;
		if (bl) {
			h = 0.0F;
		}

		if (bl2) {
			i = 1.0F;
		}

		if (bl || bl2) {
			this.setShape(f, 0.0F, h, g, 1.5F, i);
			super.addCollisions(world, pos, state, shape, collisions, entity);
		}

		h = 0.375F;
		i = 0.625F;
		if (bl3) {
			f = 0.0F;
		}

		if (bl4) {
			g = 1.0F;
		}

		if (bl3 || bl4 || !bl && !bl2) {
			this.setShape(f, 0.0F, h, g, 1.5F, i);
			super.addCollisions(world, pos, state, shape, collisions, entity);
		}

		if (bl) {
			h = 0.0F;
		}

		if (bl2) {
			i = 1.0F;
		}

		this.setShape(f, 0.0F, h, g, 1.0F, i);
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		boolean bl = this.shouldConnectTo(world, pos.north());
		boolean bl2 = this.shouldConnectTo(world, pos.south());
		boolean bl3 = this.shouldConnectTo(world, pos.west());
		boolean bl4 = this.shouldConnectTo(world, pos.east());
		float f = 0.375F;
		float g = 0.625F;
		float h = 0.375F;
		float i = 0.625F;
		if (bl) {
			h = 0.0F;
		}

		if (bl2) {
			i = 1.0F;
		}

		if (bl3) {
			f = 0.0F;
		}

		if (bl4) {
			g = 1.0F;
		}

		this.setShape(f, 0.0F, h, g, 1.0F, i);
	}

	@Override
	public boolean isSolidRender() {
		return false;
	}

	@Override
	public boolean isCube() {
		return false;
	}

	@Override
	public boolean canWalkThrough(WorldView world, BlockPos pos) {
		return false;
	}

	public boolean shouldConnectTo(WorldView world, BlockPos pos) {
		Block block = world.getBlockState(pos).getBlock();
		if (block == Blocks.BARRIER) {
			return false;
		} else if ((!(block instanceof FenceBlock) || block.material != this.material) && !(block instanceof FenceGateBlock)) {
			return block.material.isSolidBlocking() && block.isCube() ? block.material != Material.PUMPKIN : false;
		} else {
			return true;
		}
	}

	@Environment(EnvType.CLIENT)
	@Override
	public boolean shouldRenderFace(WorldView world, BlockPos pos, Direction face) {
		return true;
	}

	@Override
	public boolean use(World world, BlockPos pos, BlockState state, PlayerEntity player, Direction face, float faceX, float faceY, float faceZ) {
		return world.isClient ? true : LeadItem.attachLead(player, world, pos);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		return 0;
	}

	@Override
	public BlockState resolveVirtualProperties(BlockState state, WorldView world, BlockPos pos) {
		return state.set(NORTH, this.shouldConnectTo(world, pos.north()))
			.set(EAST, this.shouldConnectTo(world, pos.east()))
			.set(SOUTH, this.shouldConnectTo(world, pos.south()))
			.set(WEST, this.shouldConnectTo(world, pos.west()));
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, NORTH, EAST, WEST, SOUTH);
	}
}

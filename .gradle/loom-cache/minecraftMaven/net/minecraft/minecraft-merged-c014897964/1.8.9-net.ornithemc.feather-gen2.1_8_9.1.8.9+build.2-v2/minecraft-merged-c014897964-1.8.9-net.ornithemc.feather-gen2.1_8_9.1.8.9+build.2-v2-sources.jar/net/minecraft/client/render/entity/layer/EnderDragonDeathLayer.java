package net.minecraft.client.render.entity.layer;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.living.mob.monster.boss.EnderDragonEntity;

@Environment(EnvType.CLIENT)
public class EnderDragonDeathLayer implements EntityRenderLayer<EnderDragonEntity> {
	public void render(
		EnderDragonEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale
	) {
		if (entity.ticksSinceDeath > 0) {
			Tesselator tesselator = Tesselator.getInstance();
			BufferBuilder bufferBuilder = tesselator.getBuffer();
			Lighting.turnOff();
			float f = (entity.ticksSinceDeath + tickDelta) / 200.0F;
			float g = 0.0F;
			if (f > 0.8F) {
				g = (f - 0.8F) / 0.2F;
			}

			Random random = new Random(432L);
			GlStateManager.disableTexture();
			GlStateManager.shadeModel(7425);
			GlStateManager.enableBlend();
			GlStateManager.blendFunc(770, 1);
			GlStateManager.disableAlphaTest();
			GlStateManager.enableCull();
			GlStateManager.depthMask(false);
			GlStateManager.pushMatrix();
			GlStateManager.translatef(0.0F, -1.0F, -2.0F);

			for (int i = 0; i < (f + f * f) / 2.0F * 60.0F; i++) {
				GlStateManager.rotatef(random.nextFloat() * 360.0F, 1.0F, 0.0F, 0.0F);
				GlStateManager.rotatef(random.nextFloat() * 360.0F, 0.0F, 1.0F, 0.0F);
				GlStateManager.rotatef(random.nextFloat() * 360.0F, 0.0F, 0.0F, 1.0F);
				GlStateManager.rotatef(random.nextFloat() * 360.0F, 1.0F, 0.0F, 0.0F);
				GlStateManager.rotatef(random.nextFloat() * 360.0F, 0.0F, 1.0F, 0.0F);
				GlStateManager.rotatef(random.nextFloat() * 360.0F + f * 90.0F, 0.0F, 0.0F, 1.0F);
				float h = random.nextFloat() * 20.0F + 5.0F + g * 10.0F;
				float j = random.nextFloat() * 2.0F + 1.0F + g * 2.0F;
				bufferBuilder.begin(6, DefaultVertexFormat.POSITION_COLOR);
				bufferBuilder.vertex(0.0, 0.0, 0.0).color(255, 255, 255, (int)(255.0F * (1.0F - g))).nextVertex();
				bufferBuilder.vertex(-0.866 * j, h, -0.5F * j).color(255, 0, 255, 0).nextVertex();
				bufferBuilder.vertex(0.866 * j, h, -0.5F * j).color(255, 0, 255, 0).nextVertex();
				bufferBuilder.vertex(0.0, h, 1.0F * j).color(255, 0, 255, 0).nextVertex();
				bufferBuilder.vertex(-0.866 * j, h, -0.5F * j).color(255, 0, 255, 0).nextVertex();
				tesselator.end();
			}

			GlStateManager.popMatrix();
			GlStateManager.depthMask(true);
			GlStateManager.disableCull();
			GlStateManager.disableBlend();
			GlStateManager.shadeModel(7424);
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			GlStateManager.enableTexture();
			GlStateManager.enableAlphaTest();
			Lighting.turnOn();
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

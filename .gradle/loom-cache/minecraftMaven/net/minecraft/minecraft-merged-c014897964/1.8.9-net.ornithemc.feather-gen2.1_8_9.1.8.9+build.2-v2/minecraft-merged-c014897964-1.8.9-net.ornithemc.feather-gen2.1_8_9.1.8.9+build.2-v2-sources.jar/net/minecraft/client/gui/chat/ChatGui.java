package net.minecraft.client.gui.chat;

import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ChatMessage;
import net.minecraft.client.gui.GuiElement;
import net.minecraft.client.gui.screen.game.ChatScreen;
import net.minecraft.client.render.TextRenderUtils;
import net.minecraft.client.render.Window;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Environment(EnvType.CLIENT)
public class ChatGui extends GuiElement {
	private static final Logger LOGGER = LogManager.getLogger();
	private final Minecraft minecraft;
	/**
	 * Recent messages that show up on screen even if the chat is not in focus.
	 */
	private final List<String> recentMessages = Lists.newArrayList();
	private final List<ChatMessage> messages = Lists.newArrayList();
	/**
	 * A list of chat messages, trimmed to fit on the screen. Note: this means long messages
	 * will have multiple entries; one for each line.
	 */
	private final List<ChatMessage> trimmedMessages = Lists.newArrayList();
	private int scroll;
	private boolean hasNewMessagesSinceScroll;

	public ChatGui(Minecraft minecraft) {
		this.minecraft = minecraft;
	}

	public void render(int ticks) {
		if (this.minecraft.options.chatVisibility != PlayerEntity.ChatVisibility.HIDDEN) {
			int i = this.getVisibleLineCount();
			boolean bl = false;
			int j = 0;
			int k = this.trimmedMessages.size();
			float f = this.minecraft.options.chatOpacity * 0.9F + 0.1F;
			if (k > 0) {
				if (this.isChatFocused()) {
					bl = true;
				}

				float g = this.getChatScale();
				int l = MathHelper.ceil(this.getWidth() / g);
				GlStateManager.pushMatrix();
				GlStateManager.translatef(2.0F, 20.0F, 0.0F);
				GlStateManager.scalef(g, g, 1.0F);

				for (int m = 0; m + this.scroll < this.trimmedMessages.size() && m < i; m++) {
					ChatMessage chatMessage = this.trimmedMessages.get(m + this.scroll);
					if (chatMessage != null) {
						int n = ticks - chatMessage.getTimeOfCreation();
						if (n < 200 || bl) {
							double d = n / 200.0;
							d = 1.0 - d;
							d *= 10.0;
							d = MathHelper.clamp(d, 0.0, 1.0);
							d *= d;
							int o = (int)(255.0 * d);
							if (bl) {
								o = 255;
							}

							o = (int)(o * f);
							j++;
							if (o > 3) {
								int p = 0;
								int q = -m * 9;
								fill(p, q - 9, p + l + 4, q, o / 2 << 24);
								String string = chatMessage.getText().getFormattedString();
								GlStateManager.enableBlend();
								this.minecraft.textRenderer.drawWithShadow(string, p, q - 8, 16777215 + (o << 24));
								GlStateManager.disableAlphaTest();
								GlStateManager.disableBlend();
							}
						}
					}
				}

				if (bl) {
					int m = this.minecraft.textRenderer.fontHeight;
					GlStateManager.translatef(-3.0F, 0.0F, 0.0F);
					int r = k * m + k;
					int n = j * m + j;
					int s = this.scroll * n / k;
					int t = n * n / r;
					if (r != n) {
						int o = s > 0 ? 170 : 96;
						int p = this.hasNewMessagesSinceScroll ? 13382451 : 3355562;
						fill(0, -s, 2, -s - t, p + (o << 24));
						fill(2, -s, 1, -s - t, 13421772 + (o << 24));
					}
				}

				GlStateManager.popMatrix();
			}
		}
	}

	public void clear() {
		this.trimmedMessages.clear();
		this.messages.clear();
		this.recentMessages.clear();
	}

	public void addMessage(Text message) {
		this.addMessage(message, 0);
	}

	public void addMessage(Text message, int id) {
		this.addMessage(message, id, this.minecraft.gui.getTicks(), false);
		LOGGER.info("[CHAT] " + message.getString());
	}

	private void addMessage(Text message, int id, int time, boolean deleted) {
		if (id != 0) {
			this.removeMessage(id);
		}

		int i = MathHelper.floor(this.getWidth() / this.getChatScale());
		List<Text> list = TextRenderUtils.wrapText(message, i, this.minecraft.textRenderer, false, false);
		boolean bl = this.isChatFocused();

		for (Text text : list) {
			if (bl && this.scroll > 0) {
				this.hasNewMessagesSinceScroll = true;
				this.scroll(1);
			}

			this.trimmedMessages.add(0, new ChatMessage(time, text, id));
		}

		while (this.trimmedMessages.size() > 100) {
			this.trimmedMessages.remove(this.trimmedMessages.size() - 1);
		}

		if (!deleted) {
			this.messages.add(0, new ChatMessage(time, message, id));

			while (this.messages.size() > 100) {
				this.messages.remove(this.messages.size() - 1);
			}
		}
	}

	public void reset() {
		this.trimmedMessages.clear();
		this.resetScroll();

		for (int i = this.messages.size() - 1; i >= 0; i--) {
			ChatMessage chatMessage = this.messages.get(i);
			this.addMessage(chatMessage.getText(), chatMessage.getId(), chatMessage.getTimeOfCreation(), true);
		}
	}

	public List<String> getRecentMessages() {
		return this.recentMessages;
	}

	public void addRecentMessage(String message) {
		if (this.recentMessages.isEmpty() || !this.recentMessages.get(this.recentMessages.size() - 1).equals(message)) {
			this.recentMessages.add(message);
		}
	}

	public void resetScroll() {
		this.scroll = 0;
		this.hasNewMessagesSinceScroll = false;
	}

	public void scroll(int lines) {
		this.scroll += lines;
		int i = this.trimmedMessages.size();
		if (this.scroll > i - this.getVisibleLineCount()) {
			this.scroll = i - this.getVisibleLineCount();
		}

		if (this.scroll <= 0) {
			this.scroll = 0;
			this.hasNewMessagesSinceScroll = false;
		}
	}

	public Text getMessageAt(int x, int y) {
		if (!this.isChatFocused()) {
			return null;
		}

		Window window = new Window(this.minecraft);
		int i = window.getScale();
		float f = this.getChatScale();
		int j = x / i - 3;
		int k = y / i - 27;
		j = MathHelper.floor(j / f);
		k = MathHelper.floor(k / f);
		if (j >= 0 && k >= 0) {
			int l = Math.min(this.getVisibleLineCount(), this.trimmedMessages.size());
			if (j <= MathHelper.floor(this.getWidth() / this.getChatScale()) && k < this.minecraft.textRenderer.fontHeight * l + l) {
				int m = k / this.minecraft.textRenderer.fontHeight + this.scroll;
				if (m >= 0 && m < this.trimmedMessages.size()) {
					ChatMessage chatMessage = this.trimmedMessages.get(m);
					int n = 0;

					for (Text text : chatMessage.getText()) {
						if (text instanceof LiteralText) {
							n += this.minecraft.textRenderer.getWidth(TextRenderUtils.prepareText(((LiteralText)text).getRawString(), false));
							if (n > j) {
								return text;
							}
						}
					}
				}

				return null;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public boolean isChatFocused() {
		return this.minecraft.screen instanceof ChatScreen;
	}

	public void removeMessage(int id) {
		Iterator<ChatMessage> iterator = this.trimmedMessages.iterator();

		while (iterator.hasNext()) {
			ChatMessage chatMessage = iterator.next();
			if (chatMessage.getId() == id) {
				iterator.remove();
			}
		}

		iterator = this.messages.iterator();

		while (iterator.hasNext()) {
			ChatMessage chatMessage = iterator.next();
			if (chatMessage.getId() == id) {
				iterator.remove();
				break;
			}
		}
	}

	public int getWidth() {
		return getWidth(this.minecraft.options.chatWidth);
	}

	public int getHeight() {
		return getHeight(this.isChatFocused() ? this.minecraft.options.focusedChatHeight : this.minecraft.options.unfocusedChatHeight);
	}

	public float getChatScale() {
		return this.minecraft.options.chatScale;
	}

	public static int getWidth(float chatWidth) {
		int i = 320;
		int j = 40;
		return MathHelper.floor(chatWidth * (i - j) + j);
	}

	public static int getHeight(float chatHeight) {
		int i = 180;
		int j = 20;
		return MathHelper.floor(chatHeight * (i - j) + j);
	}

	public int getVisibleLineCount() {
		return this.getHeight() / 9;
	}
}

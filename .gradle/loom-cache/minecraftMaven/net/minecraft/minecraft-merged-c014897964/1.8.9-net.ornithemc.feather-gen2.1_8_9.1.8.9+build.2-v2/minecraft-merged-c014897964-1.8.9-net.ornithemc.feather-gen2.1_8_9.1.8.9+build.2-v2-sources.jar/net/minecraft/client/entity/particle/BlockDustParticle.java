package net.minecraft.client.entity.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.state.BlockState;
import net.minecraft.world.World;

@Environment(EnvType.CLIENT)
public class BlockDustParticle extends BlockParticle {
	protected BlockDustParticle(World world, double d, double e, double f, double g, double h, double i, BlockState blockState) {
		super(world, d, e, f, g, h, i, blockState);
		this.velocityX = g;
		this.velocityY = h;
		this.velocityZ = i;
	}

	@Environment(EnvType.CLIENT)
	public static class Factory implements ParticleFactory {
		@Override
		public Particle create(int type, World world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, int... parameters) {
			BlockState blockState = Block.deserialize(parameters[0]);
			return blockState.getBlock().getRenderType() == -1 ? null : new BlockDustParticle(world, x, y, z, velocityX, velocityY, velocityZ, blockState).updateColor();
		}
	}
}

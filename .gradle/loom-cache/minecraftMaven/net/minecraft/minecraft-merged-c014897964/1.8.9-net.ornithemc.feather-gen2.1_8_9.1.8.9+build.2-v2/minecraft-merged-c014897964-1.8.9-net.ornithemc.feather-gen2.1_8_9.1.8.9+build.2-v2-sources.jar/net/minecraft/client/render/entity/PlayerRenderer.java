package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.entity.living.player.ClientPlayerEntity;
import net.minecraft.client.entity.living.player.LocalClientPlayerEntity;
import net.minecraft.client.render.entity.layer.ArmorLayer;
import net.minecraft.client.render.entity.layer.CapeLayer;
import net.minecraft.client.render.entity.layer.Deadmau5Layer;
import net.minecraft.client.render.entity.layer.ItemInHandLayer;
import net.minecraft.client.render.entity.layer.StuckArrowLayer;
import net.minecraft.client.render.entity.layer.WornSkullLayer;
import net.minecraft.client.render.model.PlayerModelPart;
import net.minecraft.client.render.model.entity.PlayerModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.resource.Identifier;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.ScoreboardScore;

@Environment(EnvType.CLIENT)
public class PlayerRenderer extends LivingEntityRenderer<ClientPlayerEntity> {
	private boolean thinArms;

	public PlayerRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		this(entityRenderDispatcher, false);
	}

	public PlayerRenderer(EntityRenderDispatcher dispatcher, boolean thinArms) {
		super(dispatcher, new PlayerModel(0.0F, thinArms), 0.5F);
		this.thinArms = thinArms;
		this.addLayer(new ArmorLayer(this));
		this.addLayer(new ItemInHandLayer(this));
		this.addLayer(new StuckArrowLayer(this));
		this.addLayer(new Deadmau5Layer(this));
		this.addLayer(new CapeLayer(this));
		this.addLayer(new WornSkullLayer(this.getModel().head));
	}

	public PlayerModel getModel() {
		return (PlayerModel)super.getModel();
	}

	public void render(ClientPlayerEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		if (!entity.isLocal() || this.dispatcher.camera == entity) {
			double d = dy;
			if (entity.isSneaking() && !(entity instanceof LocalClientPlayerEntity)) {
				d -= 0.125;
			}

			this.setModelStatus(entity);
			super.render(entity, dx, d, dz, yaw, tickDelta);
		}
	}

	private void setModelStatus(ClientPlayerEntity entity) {
		PlayerModel playerModel = this.getModel();
		if (entity.isSpectator()) {
			playerModel.setVisible(false);
			playerModel.head.visible = true;
			playerModel.hat.visible = true;
		} else {
			ItemStack itemStack = entity.inventory.getSelectedItem();
			playerModel.setVisible(true);
			playerModel.hat.visible = entity.isModelPartVisible(PlayerModelPart.HAT);
			playerModel.jacket.visible = entity.isModelPartVisible(PlayerModelPart.JACKET);
			playerModel.leftPants.visible = entity.isModelPartVisible(PlayerModelPart.LEFT_PANTS_LEG);
			playerModel.rightPants.visible = entity.isModelPartVisible(PlayerModelPart.RIGHT_PANTS_LEG);
			playerModel.leftSleeve.visible = entity.isModelPartVisible(PlayerModelPart.LEFT_SLEEVE);
			playerModel.rightSleeve.visible = entity.isModelPartVisible(PlayerModelPart.RIGHT_SLEEVE);
			playerModel.itemInLeftHand = 0;
			playerModel.aimingBow = false;
			playerModel.sneaking = entity.isSneaking();
			if (itemStack == null) {
				playerModel.itemInRightHand = 0;
			} else {
				playerModel.itemInRightHand = 1;
				if (entity.getItemUseTimer() > 0) {
					UseAction useAction = itemStack.getUseAction();
					if (useAction == UseAction.BLOCK) {
						playerModel.itemInRightHand = 3;
					} else if (useAction == UseAction.BOW) {
						playerModel.aimingBow = true;
					}
				}
			}
		}
	}

	protected Identifier getTextureLocation(ClientPlayerEntity entity) {
		return entity.getSkinTextureLocation();
	}

	@Override
	public void glTranslate() {
		GlStateManager.translatef(0.0F, 0.1875F, 0.0F);
	}

	protected void applyScale(ClientPlayerEntity entity, float scale) {
		float f = 0.9375F;
		GlStateManager.scalef(f, f, f);
	}

	protected void renderNameTag(ClientPlayerEntity entity, double dx, double dy, double dz, String name, float tickDelta, double squaredDistance) {
		if (squaredDistance < 100.0) {
			Scoreboard scoreboard = entity.getScoreboard();
			ScoreboardObjective scoreboardObjective = scoreboard.getDisplayObjective(2);
			if (scoreboardObjective != null) {
				ScoreboardScore scoreboardScore = scoreboard.getScore(entity.getName(), scoreboardObjective);
				this.renderNameTag(entity, scoreboardScore.get() + " " + scoreboardObjective.getDisplayName(), dx, dy, dz, 64);
				dy += this.getTextRenderer().fontHeight * 1.15F * tickDelta;
			}
		}

		super.renderNameTag(entity, dx, dy, dz, name, tickDelta, squaredDistance);
	}

	public void renderRightArm(ClientPlayerEntity player) {
		float f = 1.0F;
		GlStateManager.color3f(f, f, f);
		PlayerModel playerModel = this.getModel();
		this.setModelStatus(player);
		playerModel.attackAnimationProgress = 0.0F;
		playerModel.sneaking = false;
		playerModel.setupAnimation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0625F, player);
		playerModel.renderRightArm();
	}

	public void renderLeftArm(ClientPlayerEntity player) {
		float f = 1.0F;
		GlStateManager.color3f(f, f, f);
		PlayerModel playerModel = this.getModel();
		this.setModelStatus(player);
		playerModel.sneaking = false;
		playerModel.attackAnimationProgress = 0.0F;
		playerModel.setupAnimation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0625F, player);
		playerModel.renderLeftArm();
	}

	protected void applyTranslation(ClientPlayerEntity entity, double dx, double dy, double dz) {
		if (entity.isAlive() && entity.isSleeping()) {
			super.applyTranslation(entity, dx + entity.sleepingCameraOffsetX, dy + entity.sleepingCameraOffsetY, dz + entity.sleepingCameraOffsetZ);
		} else {
			super.applyTranslation(entity, dx, dy, dz);
		}
	}

	protected void applyRotation(ClientPlayerEntity entity, float bob, float bodyYaw, float tickDelta) {
		if (entity.isAlive() && entity.isSleeping()) {
			GlStateManager.rotatef(entity.getSleepingCameraAngle(), 0.0F, 1.0F, 0.0F);
			GlStateManager.rotatef(this.getDeathYaw(entity), 0.0F, 0.0F, 1.0F);
			GlStateManager.rotatef(270.0F, 0.0F, 1.0F, 0.0F);
		} else {
			super.applyRotation(entity, bob, bodyYaw, tickDelta);
		}
	}
}

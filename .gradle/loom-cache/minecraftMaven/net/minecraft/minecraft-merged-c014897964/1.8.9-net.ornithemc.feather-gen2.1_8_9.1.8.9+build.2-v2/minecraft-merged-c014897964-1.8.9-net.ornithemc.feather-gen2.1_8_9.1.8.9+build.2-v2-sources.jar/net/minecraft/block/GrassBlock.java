package net.minecraft.block;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.client.render.block.BlockLayer;
import net.minecraft.client.world.color.BiomeColors;
import net.minecraft.client.world.color.GrassColors;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.ornithemc.feather.constants.SetBlockFlags;

public class GrassBlock extends Block implements Fertilizable {
	public static final BooleanProperty SNOWY = BooleanProperty.of("snowy");

	protected GrassBlock() {
		super(Material.GRASS);
		this.setDefaultState(this.stateDefinition.any().set(SNOWY, false));
		this.setTicksRandomly(true);
		this.setCreativeModeTab(CreativeModeTab.BUILDING_BLOCKS);
	}

	@Override
	public BlockState resolveVirtualProperties(BlockState state, WorldView world, BlockPos pos) {
		Block block = world.getBlockState(pos.up()).getBlock();
		return state.set(SNOWY, block == Blocks.SNOW || block == Blocks.SNOW_LAYER);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public int getColor() {
		return GrassColors.getColor(0.5, 1.0);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public int getColor(BlockState state) {
		return this.getColor();
	}

	@Environment(EnvType.CLIENT)
	@Override
	public int getColorTint(WorldView world, BlockPos pos, int tint) {
		return BiomeColors.getGrassColor(world, pos);
	}

	@Override
	public void tick(World world, BlockPos pos, BlockState state, Random random) {
		if (!world.isClient) {
			if (world.getRawBrightness(pos.up()) < 4 && world.getBlockState(pos.up()).getBlock().getOpacity() > 2) {
				world.setBlockState(pos, Blocks.DIRT.defaultState());
			} else {
				if (world.getRawBrightness(pos.up()) >= 9) {
					for (int i = 0; i < 4; i++) {
						BlockPos blockPos = pos.add(random.nextInt(3) - 1, random.nextInt(5) - 3, random.nextInt(3) - 1);
						Block block = world.getBlockState(blockPos.up()).getBlock();
						BlockState blockState = world.getBlockState(blockPos);
						if (blockState.getBlock() == Blocks.DIRT
							&& blockState.get(DirtBlock.VARIANT) == DirtBlock.Variant.DIRT
							&& world.getRawBrightness(blockPos.up()) >= 4
							&& block.getOpacity() <= 2) {
							world.setBlockState(blockPos, Blocks.GRASS.defaultState());
						}
					}
				}
			}
		}
	}

	@Override
	public Item getDropItem(BlockState state, Random random, int fortuneLevel) {
		return Blocks.DIRT.getDropItem(Blocks.DIRT.defaultState().set(DirtBlock.VARIANT, DirtBlock.Variant.DIRT), random, fortuneLevel);
	}

	@Override
	public boolean canGrow(World world, BlockPos pos, BlockState state, boolean isClient) {
		return true;
	}

	@Override
	public boolean canBeFertilized(World world, Random rand, BlockPos pos, BlockState state) {
		return true;
	}

	@Override
	public void grow(World world, Random rand, BlockPos pos, BlockState state) {
		BlockPos blockPos = pos.up();

		label38:
		for (int i = 0; i < 128; i++) {
			BlockPos blockPos2 = blockPos;

			for (int j = 0; j < i / 16; j++) {
				blockPos2 = blockPos2.add(rand.nextInt(3) - 1, (rand.nextInt(3) - 1) * rand.nextInt(3) / 2, rand.nextInt(3) - 1);
				if (world.getBlockState(blockPos2.down()).getBlock() != Blocks.GRASS || world.getBlockState(blockPos2).getBlock().isSolid()) {
					continue label38;
				}
			}

			if (world.getBlockState(blockPos2).getBlock().material == Material.AIR) {
				if (rand.nextInt(8) == 0) {
					FlowerBlock.Type type = world.getBiome(blockPos2).getRandomFlower(rand, blockPos2);
					FlowerBlock flowerBlock = type.getGroup().getBlock();
					BlockState blockState = flowerBlock.defaultState().set(flowerBlock.getTypeProperty(), type);
					if (flowerBlock.canSurvive(world, blockPos2, blockState)) {
						world.setBlockState(blockPos2, blockState, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
					}
				} else {
					BlockState blockState2 = Blocks.TALLGRASS.defaultState().set(TallPlantBlock.TYPE, TallPlantBlock.Type.GRASS);
					if (Blocks.TALLGRASS.canSurvive(world, blockPos2, blockState2)) {
						world.setBlockState(blockPos2, blockState2, SetBlockFlags.NOTIFY_NEIGHBORS | SetBlockFlags.NOTIFY_LISTENERS);
					}
				}
			}
		}
	}

	@Environment(EnvType.CLIENT)
	@Override
	public BlockLayer getRenderLayer() {
		return BlockLayer.CUTOUT_MIPPED;
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		return 0;
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, SNOWY);
	}
}

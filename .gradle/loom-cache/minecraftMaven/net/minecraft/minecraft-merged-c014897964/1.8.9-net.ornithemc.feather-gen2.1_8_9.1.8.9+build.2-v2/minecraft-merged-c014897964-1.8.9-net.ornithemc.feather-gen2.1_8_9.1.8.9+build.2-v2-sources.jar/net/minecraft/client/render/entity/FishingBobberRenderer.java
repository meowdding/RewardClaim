package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.entity.FishingBobberEntity;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class FishingBobberRenderer extends EntityRenderer<FishingBobberEntity> {
	private static final Identifier PARTICLES_LOCATION = new Identifier("textures/particle/particles.png");

	public FishingBobberRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher);
	}

	public void render(FishingBobberEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		GlStateManager.pushMatrix();
		GlStateManager.translatef((float)dx, (float)dy, (float)dz);
		GlStateManager.enableRescaleNormal();
		GlStateManager.scalef(0.5F, 0.5F, 0.5F);
		this.bindTexture(entity);
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		int i = 1;
		int j = 2;
		float f = 0.0625F;
		float g = 0.125F;
		float h = 0.125F;
		float k = 0.1875F;
		float l = 1.0F;
		float m = 0.5F;
		float n = 0.5F;
		GlStateManager.rotatef(180.0F - this.dispatcher.cameraYaw, 0.0F, 1.0F, 0.0F);
		GlStateManager.rotatef(-this.dispatcher.cameraPitch, 1.0F, 0.0F, 0.0F);
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX_NORMAL);
		bufferBuilder.vertex(-0.5, -0.5, 0.0).texture(0.0625, 0.1875).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(0.5, -0.5, 0.0).texture(0.125, 0.1875).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(0.5, 0.5, 0.0).texture(0.125, 0.125).normal(0.0F, 1.0F, 0.0F).nextVertex();
		bufferBuilder.vertex(-0.5, 0.5, 0.0).texture(0.0625, 0.125).normal(0.0F, 1.0F, 0.0F).nextVertex();
		tesselator.end();
		GlStateManager.disableRescaleNormal();
		GlStateManager.popMatrix();
		if (entity.thrower != null) {
			float o = entity.thrower.getAttackAnimationProgress(tickDelta);
			float p = MathHelper.sin(MathHelper.sqrt(o) * (float) Math.PI);
			Vec3d vec3d = new Vec3d(-0.36, 0.03, 0.35);
			vec3d = vec3d.rotateX(-(entity.thrower.lastPitch + (entity.thrower.pitch - entity.thrower.lastPitch) * tickDelta) * (float) Math.PI / 180.0F);
			vec3d = vec3d.rotateY(-(entity.thrower.lastYaw + (entity.thrower.yaw - entity.thrower.lastYaw) * tickDelta) * (float) Math.PI / 180.0F);
			vec3d = vec3d.rotateY(p * 0.5F);
			vec3d = vec3d.rotateX(-p * 0.7F);
			double d = entity.thrower.lastX + (entity.thrower.x - entity.thrower.lastX) * tickDelta + vec3d.x;
			double e = entity.thrower.lastY + (entity.thrower.y - entity.thrower.lastY) * tickDelta + vec3d.y;
			double q = entity.thrower.lastZ + (entity.thrower.z - entity.thrower.lastZ) * tickDelta + vec3d.z;
			double r = entity.thrower.getEyeHeight();
			if (this.dispatcher.options != null && this.dispatcher.options.perspective > 0 || entity.thrower != Minecraft.getInstance().player) {
				float s = (entity.thrower.lastBodyYaw + (entity.thrower.bodyYaw - entity.thrower.lastBodyYaw) * tickDelta) * (float) Math.PI / 180.0F;
				double t = MathHelper.sin(s);
				double u = MathHelper.cos(s);
				double v = 0.35;
				double w = 0.8;
				d = entity.thrower.lastX + (entity.thrower.x - entity.thrower.lastX) * tickDelta - u * 0.35 - t * 0.8;
				e = entity.thrower.lastY + r + (entity.thrower.y - entity.thrower.lastY) * tickDelta - 0.45;
				q = entity.thrower.lastZ + (entity.thrower.z - entity.thrower.lastZ) * tickDelta - t * 0.35 + u * 0.8;
				r = entity.thrower.isSneaking() ? -0.1875 : 0.0;
			}

			double x = entity.lastX + (entity.x - entity.lastX) * tickDelta;
			double y = entity.lastY + (entity.y - entity.lastY) * tickDelta + 0.25;
			double z = entity.lastZ + (entity.z - entity.lastZ) * tickDelta;
			double aa = (float)(d - x);
			double ab = (float)(e - y) + r;
			double ac = (float)(q - z);
			GlStateManager.disableTexture();
			GlStateManager.disableLighting();
			bufferBuilder.begin(3, DefaultVertexFormat.POSITION_COLOR);
			int ad = 16;

			for (int ae = 0; ae <= 16; ae++) {
				float af = ae / 16.0F;
				bufferBuilder.vertex(dx + aa * af, dy + ab * (af * af + af) * 0.5 + 0.25, dz + ac * af).color(0, 0, 0, 255).nextVertex();
			}

			tesselator.end();
			GlStateManager.enableLighting();
			GlStateManager.enableTexture();
			super.render(entity, dx, dy, dz, yaw, tickDelta);
		}
	}

	protected Identifier getTextureLocation(FishingBobberEntity entity) {
		return PARTICLES_LOCATION;
	}
}

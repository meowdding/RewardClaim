package net.minecraft.client.render.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.BossBar;
import net.minecraft.client.render.entity.layer.WitherChargeLayer;
import net.minecraft.client.render.model.entity.WitherModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.entity.living.mob.monster.boss.WitherEntity;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class WitherRenderer extends MobRenderer<WitherEntity> {
	private static final Identifier WITHER_INVULNERABLE_LOCATION = new Identifier("textures/entity/wither/wither_invulnerable.png");
	private static final Identifier WITHER_LOCATION = new Identifier("textures/entity/wither/wither.png");

	public WitherRenderer(EntityRenderDispatcher entityRenderDispatcher) {
		super(entityRenderDispatcher, new WitherModel(0.0F), 1.0F);
		this.addLayer(new WitherChargeLayer(this));
	}

	public void render(WitherEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		BossBar.update(entity, true);
		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(WitherEntity entity) {
		int i = entity.getInvulnerabilityTimer();
		return i > 0 && (i > 80 || i / 5 % 2 != 1) ? WITHER_INVULNERABLE_LOCATION : WITHER_LOCATION;
	}

	protected void applyScale(WitherEntity entity, float scale) {
		float f = 2.0F;
		int i = entity.getInvulnerabilityTimer();
		if (i > 0) {
			f -= (i - scale) / 220.0F * 0.5F;
		}

		GlStateManager.scalef(f, f, f);
	}
}

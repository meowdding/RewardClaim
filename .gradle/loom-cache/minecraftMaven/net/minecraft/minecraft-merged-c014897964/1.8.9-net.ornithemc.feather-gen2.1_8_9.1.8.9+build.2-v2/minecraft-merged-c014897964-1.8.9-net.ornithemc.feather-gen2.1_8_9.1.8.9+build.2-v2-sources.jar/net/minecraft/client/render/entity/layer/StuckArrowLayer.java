package net.minecraft.client.render.entity.layer;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.model.Box;
import net.minecraft.client.render.model.ModelPart;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class StuckArrowLayer implements EntityRenderLayer<LivingEntity> {
	private final LivingEntityRenderer parent;

	public StuckArrowLayer(LivingEntityRenderer parent) {
		this.parent = parent;
	}

	@Override
	public void render(LivingEntity entity, float walkAnimationProgress, float walkAnimationSpeed, float tickDelta, float bob, float yaw, float pitch, float scale) {
		int i = entity.getStuckArrows();
		if (i > 0) {
			Entity entity2 = new ArrowEntity(entity.world, entity.x, entity.y, entity.z);
			Random random = new Random(entity.getNetworkId());
			Lighting.turnOff();

			for (int j = 0; j < i; j++) {
				GlStateManager.pushMatrix();
				ModelPart modelPart = this.parent.getModel().pickPart(random);
				Box box = modelPart.boxes.get(random.nextInt(modelPart.boxes.size()));
				modelPart.transform(0.0625F);
				float f = random.nextFloat();
				float g = random.nextFloat();
				float h = random.nextFloat();
				float k = (box.minX + (box.maxX - box.minX) * f) / 16.0F;
				float l = (box.minY + (box.maxY - box.minY) * g) / 16.0F;
				float m = (box.minZ + (box.maxZ - box.minZ) * h) / 16.0F;
				GlStateManager.translatef(k, l, m);
				f = f * 2.0F - 1.0F;
				g = g * 2.0F - 1.0F;
				h = h * 2.0F - 1.0F;
				f *= -1.0F;
				g *= -1.0F;
				h *= -1.0F;
				float n = MathHelper.sqrt(f * f + h * h);
				entity2.lastYaw = entity2.yaw = (float)(Math.atan2(f, h) * 180.0 / (float) Math.PI);
				entity2.lastPitch = entity2.pitch = (float)(Math.atan2(g, n) * 180.0 / (float) Math.PI);
				double d = 0.0;
				double e = 0.0;
				double o = 0.0;
				this.parent.getDispatcher().render(entity2, d, e, o, 0.0F, tickDelta);
				GlStateManager.popMatrix();
			}

			Lighting.turnOn();
		}
	}

	@Override
	public boolean colorsWhenDamaged() {
		return false;
	}
}

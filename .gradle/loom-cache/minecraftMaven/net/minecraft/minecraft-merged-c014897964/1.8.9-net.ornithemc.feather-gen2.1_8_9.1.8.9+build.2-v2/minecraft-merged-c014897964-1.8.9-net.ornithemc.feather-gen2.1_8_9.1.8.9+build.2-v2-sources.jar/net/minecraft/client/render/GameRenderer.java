package net.minecraft.client.render;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.nio.Buffer;
import java.nio.FloatBuffer;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleManager;
import net.minecraft.client.entity.living.player.ClientPlayerEntity;
import net.minecraft.client.gui.BossBar;
import net.minecraft.client.render.block.BlockLayer;
import net.minecraft.client.render.platform.GLX;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.render.platform.MemoryTracker;
import net.minecraft.client.render.shaders.ProgramManager;
import net.minecraft.client.render.texture.DynamicTexture;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.client.render.world.WorldRenderer;
import net.minecraft.client.resource.manager.ResourceManager;
import net.minecraft.client.resource.manager.ResourceReloadListener;
import net.minecraft.client.util.SmoothUtil;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityFilter;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.living.LivingEntity;
import net.minecraft.entity.living.effect.StatusEffect;
import net.minecraft.entity.living.mob.monster.CreeperEntity;
import net.minecraft.entity.living.mob.monster.EndermanEntity;
import net.minecraft.entity.living.mob.monster.SpiderEntity;
import net.minecraft.entity.living.mob.passive.animal.AnimalEntity;
import net.minecraft.entity.living.player.PlayerEntity;
import net.minecraft.entity.particle.ParticleType;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.resource.Identifier;
import net.minecraft.util.crash.CrashException;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.HitResult;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.biome.Biome;
import net.ornithemc.feather.constants.Dimensions;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.util.glu.Project;

@Environment(EnvType.CLIENT)
public class GameRenderer implements ResourceReloadListener {
	private static final Logger LOGGER = LogManager.getLogger();
	private static final Identifier RAIN_TEXTURE_LOCATION = new Identifier("textures/environment/rain.png");
	private static final Identifier SNOW_TEXTURE_LOCATION = new Identifier("textures/environment/snow.png");
	public static boolean anaglyphEnabled;
	public static int anaglyphFilter;
	private Minecraft minecraft;
	private final ResourceManager resourceManager;
	private Random random = new Random();
	private float renderDistance;
	public final ItemInHandRenderer itemInHandRenderer;
	private final MapRenderer mapRenderer;
	private int ticks;
	private Entity targetEntity;
	private SmoothUtil smoothUtilMouseX = new SmoothUtil();
	private SmoothUtil smoothUtilMouseY = new SmoothUtil();
	private float oldCamPos = 4.0F;
	private float newCamPos = 4.0F;
	private float totalMouseDX;
	private float totalMouseDY;
	private float smoothMouseDX;
	private float smoothMouseDY;
	private float lastTickDelta;
	private float fov;
	private float lastFov;
	private float skyDarkness;
	private float lastSkyDarkness;
	private boolean thiccFog;
	private boolean newCamPitch = true;
	private boolean renderBlockOutline = true;
	private long lastActiveTime = Minecraft.getTime();
	private long lastWorldRenderTime;
	private final DynamicTexture lightmapTexture;
	private final int[] lightMapPixels;
	private final Identifier lightMapTextureLocation;
	private boolean lightMapDirty;
	private float lightMapFlicker;
	private float lightMapFlickerTotal;
	private int weatherSoundAttempts;
	private float[] rainSizeX = new float[1024];
	private float[] rainSizeZ = new float[1024];
	private FloatBuffer colorBuffer = MemoryTracker.createFloatBuffer(16);
	private float fogRed;
	private float fogGreen;
	private float fogBlue;
	private float lastFogBrightness;
	private float fogBrightness;
	private int hasNausea = 0;
	private boolean debugCamera = false;
	private double zoom = 1.0;
	private double zoomX;
	private double zoomY;
	private PostChain shaderEffect;
	private static final Identifier[] SHADERS = new Identifier[]{
		new Identifier("shaders/post/notch.json"),
		new Identifier("shaders/post/fxaa.json"),
		new Identifier("shaders/post/art.json"),
		new Identifier("shaders/post/bumpy.json"),
		new Identifier("shaders/post/blobs2.json"),
		new Identifier("shaders/post/pencil.json"),
		new Identifier("shaders/post/color_convolve.json"),
		new Identifier("shaders/post/deconverge.json"),
		new Identifier("shaders/post/flip.json"),
		new Identifier("shaders/post/invert.json"),
		new Identifier("shaders/post/ntsc.json"),
		new Identifier("shaders/post/outline.json"),
		new Identifier("shaders/post/phosphor.json"),
		new Identifier("shaders/post/scan_pincushion.json"),
		new Identifier("shaders/post/sobel.json"),
		new Identifier("shaders/post/bits.json"),
		new Identifier("shaders/post/desaturate.json"),
		new Identifier("shaders/post/green.json"),
		new Identifier("shaders/post/blur.json"),
		new Identifier("shaders/post/wobble.json"),
		new Identifier("shaders/post/blobs.json"),
		new Identifier("shaders/post/antialias.json"),
		new Identifier("shaders/post/creeper.json"),
		new Identifier("shaders/post/spider.json")
	};
	public static final int SHADER_NONE = SHADERS.length;
	private int shaderIndex = SHADER_NONE;
	private boolean shadersEnabled = false;
	private int frameId = 0;

	public GameRenderer(Minecraft minecraft, ResourceManager resourceManager) {
		this.minecraft = minecraft;
		this.resourceManager = resourceManager;
		this.itemInHandRenderer = minecraft.getItemInHandRenderer();
		this.mapRenderer = new MapRenderer(minecraft.getTextureManager());
		this.lightmapTexture = new DynamicTexture(16, 16);
		this.lightMapTextureLocation = minecraft.getTextureManager().register("lightMap", this.lightmapTexture);
		this.lightMapPixels = this.lightmapTexture.getPixels();
		this.shaderEffect = null;

		for (int i = 0; i < 32; i++) {
			for (int j = 0; j < 32; j++) {
				float f = j - 16;
				float g = i - 16;
				float h = MathHelper.sqrt(f * f + g * g);
				this.rainSizeX[i << 5 | j] = -g / h;
				this.rainSizeZ[i << 5 | j] = f / h;
			}
		}
	}

	public boolean hasShader() {
		return GLX.usePostProcess && this.shaderEffect != null;
	}

	public void closeShader() {
		if (this.shaderEffect != null) {
			this.shaderEffect.close();
		}

		this.shaderEffect = null;
		this.shaderIndex = SHADER_NONE;
	}

	public void disableShader() {
		this.shadersEnabled = !this.shadersEnabled;
	}

	public void updateShader(Entity camera) {
		if (GLX.usePostProcess) {
			if (this.shaderEffect != null) {
				this.shaderEffect.close();
			}

			this.shaderEffect = null;
			if (camera instanceof CreeperEntity) {
				this.loadShader(new Identifier("shaders/post/creeper.json"));
			} else if (camera instanceof SpiderEntity) {
				this.loadShader(new Identifier("shaders/post/spider.json"));
			} else if (camera instanceof EndermanEntity) {
				this.loadShader(new Identifier("shaders/post/invert.json"));
			}
		}
	}

	public void nextShader() {
		if (GLX.usePostProcess) {
			if (this.minecraft.getCamera() instanceof PlayerEntity) {
				if (this.shaderEffect != null) {
					this.shaderEffect.close();
				}

				this.shaderIndex = (this.shaderIndex + 1) % (SHADERS.length + 1);
				if (this.shaderIndex != SHADER_NONE) {
					this.loadShader(SHADERS[this.shaderIndex]);
				} else {
					this.shaderEffect = null;
				}
			}
		}
	}

	private void loadShader(Identifier location) {
		try {
			this.shaderEffect = new PostChain(this.minecraft.getTextureManager(), this.resourceManager, this.minecraft.getRenderTarget(), location);
			this.shaderEffect.resize(this.minecraft.width, this.minecraft.height);
			this.shadersEnabled = true;
		} catch (IOException iOException) {
			LOGGER.warn("Failed to load shader: " + location, iOException);
			this.shaderIndex = SHADER_NONE;
			this.shadersEnabled = false;
		} catch (JsonSyntaxException jsonSyntaxException) {
			LOGGER.warn("Failed to load shader: " + location, jsonSyntaxException);
			this.shaderIndex = SHADER_NONE;
			this.shadersEnabled = false;
		}
	}

	@Override
	public void reload(ResourceManager resourceManager) {
		if (this.shaderEffect != null) {
			this.shaderEffect.close();
		}

		this.shaderEffect = null;
		if (this.shaderIndex != SHADER_NONE) {
			this.loadShader(SHADERS[this.shaderIndex]);
		} else {
			this.updateShader(this.minecraft.getCamera());
		}
	}

	public void tick() {
		if (GLX.usePostProcess && ProgramManager.getInstance() == null) {
			ProgramManager.createInstance();
		}

		this.tickFov();
		this.tickLightMap();
		this.lastFogBrightness = this.fogBrightness;
		this.newCamPos = this.oldCamPos;
		if (this.minecraft.options.smoothCamera) {
			float f = this.minecraft.options.mouseSensitivity * 0.6F + 0.2F;
			float g = f * f * f * 8.0F;
			this.smoothMouseDX = this.smoothUtilMouseX.smooth(this.totalMouseDX, 0.05F * g);
			this.smoothMouseDY = this.smoothUtilMouseY.smooth(this.totalMouseDY, 0.05F * g);
			this.lastTickDelta = 0.0F;
			this.totalMouseDX = 0.0F;
			this.totalMouseDY = 0.0F;
		} else {
			this.smoothMouseDX = 0.0F;
			this.smoothMouseDY = 0.0F;
			this.smoothUtilMouseX.reset();
			this.smoothUtilMouseY.reset();
		}

		if (this.minecraft.getCamera() == null) {
			this.minecraft.setCamera(this.minecraft.player);
		}

		float f = this.minecraft.world.getBrightness(new BlockPos(this.minecraft.getCamera()));
		float g = this.minecraft.options.viewDistance / 32.0F;
		float h = f * (1.0F - g) + g;
		this.fogBrightness = this.fogBrightness + (h - this.fogBrightness) * 0.1F;
		this.ticks++;
		this.itemInHandRenderer.tick();
		this.tickRain();
		this.lastSkyDarkness = this.skyDarkness;
		if (BossBar.modifiesSkyColor) {
			this.skyDarkness += 0.05F;
			if (this.skyDarkness > 1.0F) {
				this.skyDarkness = 1.0F;
			}

			BossBar.modifiesSkyColor = false;
		} else if (this.skyDarkness > 0.0F) {
			this.skyDarkness -= 0.0125F;
		}
	}

	public PostChain getShader() {
		return this.shaderEffect;
	}

	public void onResolutionChanged(int width, int height) {
		if (GLX.usePostProcess) {
			if (this.shaderEffect != null) {
				this.shaderEffect.resize(width, height);
			}

			this.minecraft.worldRenderer.onResolutionChanged(width, height);
		}
	}

	public void pick(float tickDelta) {
		Entity entity = this.minecraft.getCamera();
		if (entity != null) {
			if (this.minecraft.world != null) {
				this.minecraft.profiler.push("pick");
				this.minecraft.targetEntity = null;
				double d = this.minecraft.interactionManager.getReach();
				this.minecraft.crosshairTarget = entity.rayTrace(d, tickDelta);
				double e = d;
				Vec3d vec3d = entity.getEyePosition(tickDelta);
				boolean bl = false;
				int i = 3;
				if (this.minecraft.interactionManager.hasExtendedReach()) {
					d = 6.0;
					e = 6.0;
				} else {
					if (e > 3.0) {
						bl = true;
					}

					d = e;
				}

				if (this.minecraft.crosshairTarget != null) {
					e = this.minecraft.crosshairTarget.facePos.distanceTo(vec3d);
				}

				Vec3d vec3d2 = entity.getRotationVector(tickDelta);
				Vec3d vec3d3 = vec3d.add(vec3d2.x * d, vec3d2.y * d, vec3d2.z * d);
				this.targetEntity = null;
				Vec3d vec3d4 = null;
				float f = 1.0F;
				List<Entity> list = this.minecraft
					.world
					.getEntities(
						entity,
						entity.getShape().expanded(vec3d2.x * d, vec3d2.y * d, vec3d2.z * d).grown(f, f, f),
						Predicates.and(EntityFilter.NOT_SPECTATOR, new Predicate<Entity>() {
							public boolean apply(Entity entity) {
								return entity.hasCollision();
							}
						})
					);
				double g = e;

				for (int j = 0; j < list.size(); j++) {
					Entity entity2 = list.get(j);
					float h = entity2.getPickRadius();
					Box box = entity2.getShape().grown(h, h, h);
					HitResult hitResult = box.clip(vec3d, vec3d3);
					if (box.contains(vec3d)) {
						if (g >= 0.0) {
							this.targetEntity = entity2;
							vec3d4 = hitResult == null ? vec3d : hitResult.facePos;
							g = 0.0;
						}
					} else if (hitResult != null) {
						double k = vec3d.distanceTo(hitResult.facePos);
						if (k < g || g == 0.0) {
							if (entity2 == entity.vehicle) {
								if (g == 0.0) {
									this.targetEntity = entity2;
									vec3d4 = hitResult.facePos;
								}
							} else {
								this.targetEntity = entity2;
								vec3d4 = hitResult.facePos;
								g = k;
							}
						}
					}
				}

				if (this.targetEntity != null && bl && vec3d.distanceTo(vec3d4) > 3.0) {
					this.targetEntity = null;
					this.minecraft.crosshairTarget = new HitResult(HitResult.Type.MISS, vec3d4, null, new BlockPos(vec3d4));
				}

				if (this.targetEntity != null && (g < e || this.minecraft.crosshairTarget == null)) {
					this.minecraft.crosshairTarget = new HitResult(this.targetEntity, vec3d4);
					if (this.targetEntity instanceof LivingEntity || this.targetEntity instanceof ItemFrameEntity) {
						this.minecraft.targetEntity = this.targetEntity;
					}
				}

				this.minecraft.profiler.pop();
			}
		}
	}

	private void tickFov() {
		float f = 1.0F;
		if (this.minecraft.getCamera() instanceof ClientPlayerEntity) {
			ClientPlayerEntity clientPlayerEntity = (ClientPlayerEntity)this.minecraft.getCamera();
			f = clientPlayerEntity.getFovModifier();
		}

		this.lastFov = this.fov;
		this.fov = this.fov + (f - this.fov) * 0.5F;
		if (this.fov > 1.5F) {
			this.fov = 1.5F;
		}

		if (this.fov < 0.1F) {
			this.fov = 0.1F;
		}
	}

	private float getFov(float tickDelta, boolean fovChanged) {
		if (this.debugCamera) {
			return 90.0F;
		}

		Entity entity = this.minecraft.getCamera();
		float f = 70.0F;
		if (fovChanged) {
			f = this.minecraft.options.fov;
			f *= this.lastFov + (this.fov - this.lastFov) * tickDelta;
		}

		if (entity instanceof LivingEntity && ((LivingEntity)entity).getHealth() <= 0.0F) {
			float g = ((LivingEntity)entity).deathTicks + tickDelta;
			f /= (1.0F - 500.0F / (g + 500.0F)) * 2.0F + 1.0F;
		}

		Block block = Camera.getBlockInside(this.minecraft.world, entity, tickDelta);
		if (block.getMaterial() == Material.WATER) {
			f = f * 60.0F / 70.0F;
		}

		return f;
	}

	private void applyHurtCam(float tickDelta) {
		if (this.minecraft.getCamera() instanceof LivingEntity) {
			LivingEntity livingEntity = (LivingEntity)this.minecraft.getCamera();
			float f = livingEntity.damagedTimer - tickDelta;
			if (livingEntity.getHealth() <= 0.0F) {
				float g = livingEntity.deathTicks + tickDelta;
				GlStateManager.rotatef(40.0F - 8000.0F / (g + 200.0F), 0.0F, 0.0F, 1.0F);
			}

			if (f < 0.0F) {
				return;
			}

			f /= livingEntity.damagedTime;
			f = MathHelper.sin(f * f * f * f * (float) Math.PI);
			float g = livingEntity.damagedSwingDir;
			GlStateManager.rotatef(-g, 0.0F, 1.0F, 0.0F);
			GlStateManager.rotatef(-f * 14.0F, 0.0F, 0.0F, 1.0F);
			GlStateManager.rotatef(g, 0.0F, 1.0F, 0.0F);
		}
	}

	private void applyViewBobbing(float tickDelta) {
		if (this.minecraft.getCamera() instanceof PlayerEntity) {
			PlayerEntity playerEntity = (PlayerEntity)this.minecraft.getCamera();
			float f = playerEntity.walkDistance - playerEntity.lastWalkDistance;
			float g = -(playerEntity.walkDistance + f * tickDelta);
			float h = playerEntity.lastBob + (playerEntity.bob - playerEntity.lastBob) * tickDelta;
			float i = playerEntity.lastTilt + (playerEntity.tilt - playerEntity.lastTilt) * tickDelta;
			GlStateManager.translatef(MathHelper.sin(g * (float) Math.PI) * h * 0.5F, -Math.abs(MathHelper.cos(g * (float) Math.PI) * h), 0.0F);
			GlStateManager.rotatef(MathHelper.sin(g * (float) Math.PI) * h * 3.0F, 0.0F, 0.0F, 1.0F);
			GlStateManager.rotatef(Math.abs(MathHelper.cos(g * (float) Math.PI - 0.2F) * h) * 5.0F, 1.0F, 0.0F, 0.0F);
			GlStateManager.rotatef(i, 1.0F, 0.0F, 0.0F);
		}
	}

	private void transformCamera(float tickDelta) {
		Entity entity = this.minecraft.getCamera();
		float f = entity.getEyeHeight();
		double d = entity.lastX + (entity.x - entity.lastX) * tickDelta;
		double e = entity.lastY + (entity.y - entity.lastY) * tickDelta + f;
		double g = entity.lastZ + (entity.z - entity.lastZ) * tickDelta;
		if (entity instanceof LivingEntity && ((LivingEntity)entity).isSleeping()) {
			f = (float)(f + 1.0);
			GlStateManager.translatef(0.0F, 0.3F, 0.0F);
			if (!this.minecraft.options.debugCamera) {
				BlockPos blockPos = new BlockPos(entity);
				BlockState blockState = this.minecraft.world.getBlockState(blockPos);
				Block block = blockState.getBlock();
				if (block == Blocks.BED) {
					int i = blockState.get(BedBlock.FACING).getIdHorizontal();
					GlStateManager.rotatef(i * 90, 0.0F, 1.0F, 0.0F);
				}

				GlStateManager.rotatef(entity.lastYaw + (entity.yaw - entity.lastYaw) * tickDelta + 180.0F, 0.0F, -1.0F, 0.0F);
				GlStateManager.rotatef(entity.lastPitch + (entity.pitch - entity.lastPitch) * tickDelta, -1.0F, 0.0F, 0.0F);
			}
		} else if (this.minecraft.options.perspective > 0) {
			double h = this.newCamPos + (this.oldCamPos - this.newCamPos) * tickDelta;
			if (this.minecraft.options.debugCamera) {
				GlStateManager.translatef(0.0F, 0.0F, (float)(-h));
			} else {
				float j = entity.yaw;
				float k = entity.pitch;
				if (this.minecraft.options.perspective == 2) {
					k += 180.0F;
				}

				double l = -MathHelper.sin(j / 180.0F * (float) Math.PI) * MathHelper.cos(k / 180.0F * (float) Math.PI) * h;
				double m = MathHelper.cos(j / 180.0F * (float) Math.PI) * MathHelper.cos(k / 180.0F * (float) Math.PI) * h;
				double n = -MathHelper.sin(k / 180.0F * (float) Math.PI) * h;

				for (int o = 0; o < 8; o++) {
					float p = (o & 1) * 2 - 1;
					float q = (o >> 1 & 1) * 2 - 1;
					float r = (o >> 2 & 1) * 2 - 1;
					p *= 0.1F;
					q *= 0.1F;
					r *= 0.1F;
					HitResult hitResult = this.minecraft.world.rayTrace(new Vec3d(d + p, e + q, g + r), new Vec3d(d - l + p + r, e - n + q, g - m + r));
					if (hitResult != null) {
						double s = hitResult.facePos.distanceTo(new Vec3d(d, e, g));
						if (s < h) {
							h = s;
						}
					}
				}

				if (this.minecraft.options.perspective == 2) {
					GlStateManager.rotatef(180.0F, 0.0F, 1.0F, 0.0F);
				}

				GlStateManager.rotatef(entity.pitch - k, 1.0F, 0.0F, 0.0F);
				GlStateManager.rotatef(entity.yaw - j, 0.0F, 1.0F, 0.0F);
				GlStateManager.translatef(0.0F, 0.0F, (float)(-h));
				GlStateManager.rotatef(j - entity.yaw, 0.0F, 1.0F, 0.0F);
				GlStateManager.rotatef(k - entity.pitch, 1.0F, 0.0F, 0.0F);
			}
		} else {
			GlStateManager.translatef(0.0F, 0.0F, -0.1F);
		}

		if (!this.minecraft.options.debugCamera) {
			GlStateManager.rotatef(entity.lastPitch + (entity.pitch - entity.lastPitch) * tickDelta, 1.0F, 0.0F, 0.0F);
			if (entity instanceof AnimalEntity) {
				AnimalEntity animalEntity = (AnimalEntity)entity;
				GlStateManager.rotatef(animalEntity.lastHeadYaw + (animalEntity.headYaw - animalEntity.lastHeadYaw) * tickDelta + 180.0F, 0.0F, 1.0F, 0.0F);
			} else {
				GlStateManager.rotatef(entity.lastYaw + (entity.yaw - entity.lastYaw) * tickDelta + 180.0F, 0.0F, 1.0F, 0.0F);
			}
		}

		GlStateManager.translatef(0.0F, -f, 0.0F);
		d = entity.lastX + (entity.x - entity.lastX) * tickDelta;
		e = entity.lastY + (entity.y - entity.lastY) * tickDelta + f;
		g = entity.lastZ + (entity.z - entity.lastZ) * tickDelta;
		this.thiccFog = this.minecraft.worldRenderer.hasThiccFog(d, e, g, tickDelta);
	}

	private void setupCamera(float tickDelta, int anaglyphRenderPass) {
		this.renderDistance = this.minecraft.options.viewDistance * 16;
		GlStateManager.matrixMode(5889);
		GlStateManager.loadIdentity();
		float f = 0.07F;
		if (this.minecraft.options.anaglyph) {
			GlStateManager.translatef(-(anaglyphRenderPass * 2 - 1) * f, 0.0F, 0.0F);
		}

		if (this.zoom != 1.0) {
			GlStateManager.translatef((float)this.zoomX, (float)(-this.zoomY), 0.0F);
			GlStateManager.scaled(this.zoom, this.zoom, 1.0);
		}

		Project.gluPerspective(this.getFov(tickDelta, true), (float)this.minecraft.width / this.minecraft.height, 0.05F, this.renderDistance * MathHelper.SQRT_TWO);
		GlStateManager.matrixMode(5888);
		GlStateManager.loadIdentity();
		if (this.minecraft.options.anaglyph) {
			GlStateManager.translatef((anaglyphRenderPass * 2 - 1) * 0.1F, 0.0F, 0.0F);
		}

		this.applyHurtCam(tickDelta);
		if (this.minecraft.options.viewBobbing) {
			this.applyViewBobbing(tickDelta);
		}

		float g = this.minecraft.player.lastPortalTime + (this.minecraft.player.portalTime - this.minecraft.player.lastPortalTime) * tickDelta;
		if (g > 0.0F) {
			int i = 20;
			if (this.minecraft.player.hasStatusEffect(StatusEffect.NAUSEA)) {
				i = 7;
			}

			float h = 5.0F / (g * g + 5.0F) - g * 0.04F;
			h *= h;
			GlStateManager.rotatef((this.ticks + tickDelta) * i, 0.0F, 1.0F, 1.0F);
			GlStateManager.scalef(1.0F / h, 1.0F, 1.0F);
			GlStateManager.rotatef(-(this.ticks + tickDelta) * i, 0.0F, 1.0F, 1.0F);
		}

		this.transformCamera(tickDelta);
		if (this.debugCamera) {
			switch (this.hasNausea) {
				case 0:
					GlStateManager.rotatef(90.0F, 0.0F, 1.0F, 0.0F);
					break;
				case 1:
					GlStateManager.rotatef(180.0F, 0.0F, 1.0F, 0.0F);
					break;
				case 2:
					GlStateManager.rotatef(-90.0F, 0.0F, 1.0F, 0.0F);
					break;
				case 3:
					GlStateManager.rotatef(90.0F, 1.0F, 0.0F, 0.0F);
					break;
				case 4:
					GlStateManager.rotatef(-90.0F, 1.0F, 0.0F, 0.0F);
			}
		}
	}

	private void renderItemInHand(float tickDelta, int anaglyphRenderPass) {
		if (!this.debugCamera) {
			GlStateManager.matrixMode(5889);
			GlStateManager.loadIdentity();
			float f = 0.07F;
			if (this.minecraft.options.anaglyph) {
				GlStateManager.translatef(-(anaglyphRenderPass * 2 - 1) * f, 0.0F, 0.0F);
			}

			Project.gluPerspective(this.getFov(tickDelta, false), (float)this.minecraft.width / this.minecraft.height, 0.05F, this.renderDistance * 2.0F);
			GlStateManager.matrixMode(5888);
			GlStateManager.loadIdentity();
			if (this.minecraft.options.anaglyph) {
				GlStateManager.translatef((anaglyphRenderPass * 2 - 1) * 0.1F, 0.0F, 0.0F);
			}

			GlStateManager.pushMatrix();
			this.applyHurtCam(tickDelta);
			if (this.minecraft.options.viewBobbing) {
				this.applyViewBobbing(tickDelta);
			}

			boolean bl = this.minecraft.getCamera() instanceof LivingEntity && ((LivingEntity)this.minecraft.getCamera()).isSleeping();
			if (this.minecraft.options.perspective == 0 && !bl && !this.minecraft.options.hideGui && !this.minecraft.interactionManager.hidesGui()) {
				this.enableLightMap();
				this.itemInHandRenderer.renderInFirstPerson(tickDelta);
				this.disableLightMap();
			}

			GlStateManager.popMatrix();
			if (this.minecraft.options.perspective == 0 && !bl) {
				this.itemInHandRenderer.renderScreenEffects(tickDelta);
				this.applyHurtCam(tickDelta);
			}

			if (this.minecraft.options.viewBobbing) {
				this.applyViewBobbing(tickDelta);
			}
		}
	}

	public void disableLightMap() {
		GlStateManager.activeTexture(GLX.GL_TEXTURE1);
		GlStateManager.disableTexture();
		GlStateManager.activeTexture(GLX.GL_TEXTURE0);
	}

	public void enableLightMap() {
		GlStateManager.activeTexture(GLX.GL_TEXTURE1);
		GlStateManager.matrixMode(5890);
		GlStateManager.loadIdentity();
		float f = 0.00390625F;
		GlStateManager.scalef(f, f, f);
		GlStateManager.translatef(8.0F, 8.0F, 8.0F);
		GlStateManager.matrixMode(5888);
		this.minecraft.getTextureManager().bind(this.lightMapTextureLocation);
		GL11.glTexParameteri(3553, 10241, 9729);
		GL11.glTexParameteri(3553, 10240, 9729);
		GL11.glTexParameteri(3553, 10242, 10496);
		GL11.glTexParameteri(3553, 10243, 10496);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.enableTexture();
		GlStateManager.activeTexture(GLX.GL_TEXTURE0);
	}

	private void tickLightMap() {
		this.lightMapFlickerTotal = (float)(this.lightMapFlickerTotal + (Math.random() - Math.random()) * Math.random() * Math.random());
		this.lightMapFlickerTotal = (float)(this.lightMapFlickerTotal * 0.9);
		this.lightMapFlicker = this.lightMapFlicker + (this.lightMapFlickerTotal - this.lightMapFlicker) * 1.0F;
		this.lightMapDirty = true;
	}

	private void updateLightMap(float tickDelta) {
		if (this.lightMapDirty) {
			this.minecraft.profiler.push("lightTex");
			World world = this.minecraft.world;
			if (world != null) {
				float f = world.calculateAmbientLight(1.0F);
				float g = f * 0.95F + 0.05F;

				for (int i = 0; i < 256; i++) {
					float h = world.dimension.getBrightnessTable()[i / 16] * g;
					float j = world.dimension.getBrightnessTable()[i % 16] * (this.lightMapFlicker * 0.1F + 1.5F);
					if (world.getLightningCooldown() > 0) {
						h = world.dimension.getBrightnessTable()[i / 16];
					}

					float k = h * (f * 0.65F + 0.35F);
					float l = h * (f * 0.65F + 0.35F);
					float m = h;
					float n = j;
					float o = j * ((j * 0.6F + 0.4F) * 0.6F + 0.4F);
					float p = j * (j * j * 0.6F + 0.4F);
					float q = k + n;
					float r = l + o;
					float s = m + p;
					q = q * 0.96F + 0.03F;
					r = r * 0.96F + 0.03F;
					s = s * 0.96F + 0.03F;
					if (this.skyDarkness > 0.0F) {
						float t = this.lastSkyDarkness + (this.skyDarkness - this.lastSkyDarkness) * tickDelta;
						q = q * (1.0F - t) + q * 0.7F * t;
						r = r * (1.0F - t) + r * 0.6F * t;
						s = s * (1.0F - t) + s * 0.6F * t;
					}

					if (world.dimension.getId() == Dimensions.THE_END) {
						q = 0.22F + n * 0.75F;
						r = 0.28F + o * 0.75F;
						s = 0.25F + p * 0.75F;
					}

					if (this.minecraft.player.hasStatusEffect(StatusEffect.NIGHTVISION)) {
						float t = this.getNightVisionScale(this.minecraft.player, tickDelta);
						float u = 1.0F / q;
						if (u > 1.0F / r) {
							u = 1.0F / r;
						}

						if (u > 1.0F / s) {
							u = 1.0F / s;
						}

						q = q * (1.0F - t) + q * u * t;
						r = r * (1.0F - t) + r * u * t;
						s = s * (1.0F - t) + s * u * t;
					}

					if (q > 1.0F) {
						q = 1.0F;
					}

					if (r > 1.0F) {
						r = 1.0F;
					}

					if (s > 1.0F) {
						s = 1.0F;
					}

					float t = this.minecraft.options.gamma;
					float u = 1.0F - q;
					float v = 1.0F - r;
					float w = 1.0F - s;
					u = 1.0F - u * u * u * u;
					v = 1.0F - v * v * v * v;
					w = 1.0F - w * w * w * w;
					q = q * (1.0F - t) + u * t;
					r = r * (1.0F - t) + v * t;
					s = s * (1.0F - t) + w * t;
					q = q * 0.96F + 0.03F;
					r = r * 0.96F + 0.03F;
					s = s * 0.96F + 0.03F;
					if (q > 1.0F) {
						q = 1.0F;
					}

					if (r > 1.0F) {
						r = 1.0F;
					}

					if (s > 1.0F) {
						s = 1.0F;
					}

					if (q < 0.0F) {
						q = 0.0F;
					}

					if (r < 0.0F) {
						r = 0.0F;
					}

					if (s < 0.0F) {
						s = 0.0F;
					}

					int x = 255;
					int y = (int)(q * 255.0F);
					int z = (int)(r * 255.0F);
					int aa = (int)(s * 255.0F);
					this.lightMapPixels[i] = x << 24 | y << 16 | z << 8 | aa;
				}

				this.lightmapTexture.upload();
				this.lightMapDirty = false;
				this.minecraft.profiler.pop();
			}
		}
	}

	private float getNightVisionScale(LivingEntity player, float tickDelta) {
		int i = player.getEffectInstance(StatusEffect.NIGHTVISION).getDuration();
		return i > 200 ? 1.0F : 0.7F + MathHelper.sin((i - tickDelta) * (float) Math.PI * 0.2F) * 0.3F;
	}

	public void render(float tickDelta, long startTime) {
		boolean bl = Display.isActive();
		if (!bl && this.minecraft.options.pauseOnUnfocus && (!this.minecraft.options.touchscreen || !Mouse.isButtonDown(1))) {
			if (Minecraft.getTime() - this.lastActiveTime > 500L) {
				this.minecraft.pauseGame();
			}
		} else {
			this.lastActiveTime = Minecraft.getTime();
		}

		this.minecraft.profiler.push("mouse");
		if (bl && Minecraft.IS_MAC && this.minecraft.focused && !Mouse.isInsideWindow()) {
			Mouse.setGrabbed(false);
			Mouse.setCursorPosition(Display.getWidth() / 2, Display.getHeight() / 2);
			Mouse.setGrabbed(true);
		}

		if (this.minecraft.focused && bl) {
			this.minecraft.mouse.tick();
			float f = this.minecraft.options.mouseSensitivity * 0.6F + 0.2F;
			float g = f * f * f * 8.0F;
			float h = this.minecraft.mouse.x * g;
			float i = this.minecraft.mouse.y * g;
			int j = 1;
			if (this.minecraft.options.invertMouseY) {
				j = -1;
			}

			if (this.minecraft.options.smoothCamera) {
				this.totalMouseDX += h;
				this.totalMouseDY += i;
				float k = tickDelta - this.lastTickDelta;
				this.lastTickDelta = tickDelta;
				h = this.smoothMouseDX * k;
				i = this.smoothMouseDY * k;
				this.minecraft.player.updateLocalPlayerCamera(h, i * j);
			} else {
				this.totalMouseDX = 0.0F;
				this.totalMouseDY = 0.0F;
				this.minecraft.player.updateLocalPlayerCamera(h, i * j);
			}
		}

		this.minecraft.profiler.pop();
		if (!this.minecraft.skipGameRender) {
			anaglyphEnabled = this.minecraft.options.anaglyph;
			final Window window = new Window(this.minecraft);
			int l = window.getWidth();
			int m = window.getHeight();
			final int n = Mouse.getX() * l / this.minecraft.width;
			final int j = m - Mouse.getY() * m / this.minecraft.height - 1;
			int o = this.minecraft.options.fpsLimit;
			if (this.minecraft.world != null) {
				this.minecraft.profiler.push("level");
				int p = Math.min(Minecraft.getCurrentFps(), o);
				p = Math.max(p, 60);
				long q = System.nanoTime() - startTime;
				long r = Math.max(1000000000 / p / 4 - q, 0L);
				this.renderWorld(tickDelta, System.nanoTime() + r);
				if (GLX.usePostProcess) {
					this.minecraft.worldRenderer.renderEntityOutlines();
					if (this.shaderEffect != null && this.shadersEnabled) {
						GlStateManager.matrixMode(5890);
						GlStateManager.pushMatrix();
						GlStateManager.loadIdentity();
						this.shaderEffect.process(tickDelta);
						GlStateManager.popMatrix();
					}

					this.minecraft.getRenderTarget().bindWrite(true);
				}

				this.lastWorldRenderTime = System.nanoTime();
				this.minecraft.profiler.swap("gui");
				if (!this.minecraft.options.hideGui || this.minecraft.screen != null) {
					GlStateManager.alphaFunc(516, 0.1F);
					this.minecraft.gui.render(tickDelta);
				}

				this.minecraft.profiler.pop();
			} else {
				GlStateManager.viewport(0, 0, this.minecraft.width, this.minecraft.height);
				GlStateManager.matrixMode(5889);
				GlStateManager.loadIdentity();
				GlStateManager.matrixMode(5888);
				GlStateManager.loadIdentity();
				this.setupGuiState();
				this.lastWorldRenderTime = System.nanoTime();
			}

			if (this.minecraft.screen != null) {
				GlStateManager.clear(256);

				try {
					this.minecraft.screen.render(n, j, tickDelta);
				} catch (Throwable throwable) {
					CrashReport crashReport = CrashReport.of(throwable, "Rendering screen");
					CrashReportCategory crashReportCategory = crashReport.addCategory("Screen render details");
					crashReportCategory.add("Screen name", new Callable<String>() {
						public String call() throws Exception {
							return GameRenderer.this.minecraft.screen.getClass().getCanonicalName();
						}
					});
					crashReportCategory.add("Mouse location", new Callable<String>() {
						public String call() throws Exception {
							return String.format("Scaled: (%d, %d). Absolute: (%d, %d)", n, j, Mouse.getX(), Mouse.getY());
						}
					});
					crashReportCategory.add(
						"Screen size",
						new Callable<String>() {
							public String call() throws Exception {
								return String.format(
									"Scaled: (%d, %d). Absolute: (%d, %d). Scale factor of %d",
									window.getWidth(),
									window.getHeight(),
									GameRenderer.this.minecraft.width,
									GameRenderer.this.minecraft.height,
									window.getScale()
								);
							}
						}
					);
					throw new CrashException(crashReport);
				}
			}
		}
	}

	public void renderStreamOverlay(float tickDelta) {
		this.setupGuiState();
		this.minecraft.gui.renderStreamOverlay(new Window(this.minecraft));
	}

	private boolean shouldRenderBlockOutline() {
		if (!this.renderBlockOutline) {
			return false;
		}

		Entity entity = this.minecraft.getCamera();
		boolean bl = entity instanceof PlayerEntity && !this.minecraft.options.hideGui;
		if (bl && !((PlayerEntity)entity).abilities.canModifyWorld) {
			ItemStack itemStack = ((PlayerEntity)entity).getItemInHand();
			if (this.minecraft.crosshairTarget != null && this.minecraft.crosshairTarget.type == HitResult.Type.BLOCK) {
				BlockPos blockPos = this.minecraft.crosshairTarget.getPos();
				Block block = this.minecraft.world.getBlockState(blockPos).getBlock();
				if (this.minecraft.interactionManager.getGameMode() == WorldSettings.GameMode.SPECTATOR) {
					bl = block.hasBlockEntity() && this.minecraft.world.getBlockEntity(blockPos) instanceof Inventory;
				} else {
					bl = itemStack != null && (itemStack.hasMineBlockOverride(block) || itemStack.hasPlaceOnBlockOverride(block));
				}
			}
		}

		return bl;
	}

	private void renderAxisIndicators(float tickDelta) {
		if (this.minecraft.options.debugEnabled
			&& !this.minecraft.options.hideGui
			&& !this.minecraft.player.hasReducedDebugInfo()
			&& !this.minecraft.options.reducedDebugInfo) {
			Entity entity = this.minecraft.getCamera();
			GlStateManager.enableBlend();
			GlStateManager.blendFuncSeparate(770, 771, 1, 0);
			GL11.glLineWidth(1.0F);
			GlStateManager.disableTexture();
			GlStateManager.depthMask(false);
			GlStateManager.pushMatrix();
			GlStateManager.matrixMode(5888);
			GlStateManager.loadIdentity();
			this.transformCamera(tickDelta);
			GlStateManager.translatef(0.0F, entity.getEyeHeight(), 0.0F);
			WorldRenderer.renderOutlineShape(new Box(0.0, 0.0, 0.0, 0.005, 1.0E-4, 1.0E-4), 255, 0, 0, 255);
			WorldRenderer.renderOutlineShape(new Box(0.0, 0.0, 0.0, 1.0E-4, 1.0E-4, 0.005), 0, 0, 255, 255);
			WorldRenderer.renderOutlineShape(new Box(0.0, 0.0, 0.0, 1.0E-4, 0.0033, 1.0E-4), 0, 255, 0, 255);
			GlStateManager.popMatrix();
			GlStateManager.depthMask(true);
			GlStateManager.enableTexture();
			GlStateManager.disableBlend();
		}
	}

	public void renderWorld(float tickDelta, long renderTimeLimit) {
		this.updateLightMap(tickDelta);
		if (this.minecraft.getCamera() == null) {
			this.minecraft.setCamera(this.minecraft.player);
		}

		this.pick(tickDelta);
		GlStateManager.enableDepthTest();
		GlStateManager.enableAlphaTest();
		GlStateManager.alphaFunc(516, 0.5F);
		this.minecraft.profiler.push("center");
		if (this.minecraft.options.anaglyph) {
			anaglyphFilter = 0;
			GlStateManager.colorMask(false, true, true, false);
			this.render(0, tickDelta, renderTimeLimit);
			anaglyphFilter = 1;
			GlStateManager.colorMask(true, false, false, false);
			this.render(1, tickDelta, renderTimeLimit);
			GlStateManager.colorMask(true, true, true, false);
		} else {
			this.render(2, tickDelta, renderTimeLimit);
		}

		this.minecraft.profiler.pop();
	}

	private void render(int anaglyphRenderPass, float tickDelta, long renderTimeLimit) {
		WorldRenderer worldRenderer = this.minecraft.worldRenderer;
		ParticleManager particleManager = this.minecraft.particleManager;
		boolean bl = this.shouldRenderBlockOutline();
		GlStateManager.enableCull();
		this.minecraft.profiler.swap("clear");
		GlStateManager.viewport(0, 0, this.minecraft.width, this.minecraft.height);
		this.setupClearColor(tickDelta);
		GlStateManager.clear(16640);
		this.minecraft.profiler.swap("camera");
		this.setupCamera(tickDelta, anaglyphRenderPass);
		Camera.setup(this.minecraft.player, this.minecraft.options.perspective == 2);
		this.minecraft.profiler.swap("frustum");
		Frustum.getInstance();
		this.minecraft.profiler.swap("culling");
		Culler culler = new FrustumCuller();
		Entity entity = this.minecraft.getCamera();
		double d = entity.prevX + (entity.x - entity.prevX) * tickDelta;
		double e = entity.prevY + (entity.y - entity.prevY) * tickDelta;
		double f = entity.prevZ + (entity.z - entity.prevZ) * tickDelta;
		culler.prepare(d, e, f);
		if (this.minecraft.options.viewDistance >= 4) {
			this.setupFog(-1, tickDelta);
			this.minecraft.profiler.swap("sky");
			GlStateManager.matrixMode(5889);
			GlStateManager.loadIdentity();
			Project.gluPerspective(this.getFov(tickDelta, true), (float)this.minecraft.width / this.minecraft.height, 0.05F, this.renderDistance * 2.0F);
			GlStateManager.matrixMode(5888);
			worldRenderer.renderSky(tickDelta, anaglyphRenderPass);
			GlStateManager.matrixMode(5889);
			GlStateManager.loadIdentity();
			Project.gluPerspective(this.getFov(tickDelta, true), (float)this.minecraft.width / this.minecraft.height, 0.05F, this.renderDistance * MathHelper.SQRT_TWO);
			GlStateManager.matrixMode(5888);
		}

		this.setupFog(0, tickDelta);
		GlStateManager.shadeModel(7425);
		if (entity.y + entity.getEyeHeight() < 128.0) {
			this.renderClouds(worldRenderer, tickDelta, anaglyphRenderPass);
		}

		this.minecraft.profiler.swap("prepareterrain");
		this.setupFog(0, tickDelta);
		this.minecraft.getTextureManager().bind(TextureAtlas.BLOCKS_LOCATION);
		Lighting.turnOff();
		this.minecraft.profiler.swap("terrain_setup");
		worldRenderer.setupRender(entity, tickDelta, culler, this.frameId++, this.minecraft.player.isSpectator());
		if (anaglyphRenderPass == 0 || anaglyphRenderPass == 2) {
			this.minecraft.profiler.swap("updatechunks");
			this.minecraft.worldRenderer.compileChunksUntil(renderTimeLimit);
		}

		this.minecraft.profiler.swap("terrain");
		GlStateManager.matrixMode(5888);
		GlStateManager.pushMatrix();
		GlStateManager.disableAlphaTest();
		worldRenderer.render(BlockLayer.SOLID, tickDelta, anaglyphRenderPass, entity);
		GlStateManager.enableAlphaTest();
		worldRenderer.render(BlockLayer.CUTOUT_MIPPED, tickDelta, anaglyphRenderPass, entity);
		this.minecraft.getTextureManager().get(TextureAtlas.BLOCKS_LOCATION).pushFilter(false, false);
		worldRenderer.render(BlockLayer.CUTOUT, tickDelta, anaglyphRenderPass, entity);
		this.minecraft.getTextureManager().get(TextureAtlas.BLOCKS_LOCATION).popFilter();
		GlStateManager.shadeModel(7424);
		GlStateManager.alphaFunc(516, 0.1F);
		if (!this.debugCamera) {
			GlStateManager.matrixMode(5888);
			GlStateManager.popMatrix();
			GlStateManager.pushMatrix();
			Lighting.turnOn();
			this.minecraft.profiler.swap("entities");
			worldRenderer.renderEntities(entity, culler, tickDelta);
			Lighting.turnOff();
			this.disableLightMap();
			GlStateManager.matrixMode(5888);
			GlStateManager.popMatrix();
			GlStateManager.pushMatrix();
			if (this.minecraft.crosshairTarget != null && entity.isSubmergedIn(Material.WATER) && bl) {
				PlayerEntity playerEntity = (PlayerEntity)entity;
				GlStateManager.disableAlphaTest();
				this.minecraft.profiler.swap("outline");
				worldRenderer.renderBlockOutline(playerEntity, this.minecraft.crosshairTarget, 0, tickDelta);
				GlStateManager.enableAlphaTest();
			}
		}

		GlStateManager.matrixMode(5888);
		GlStateManager.popMatrix();
		if (bl && this.minecraft.crosshairTarget != null && !entity.isSubmergedIn(Material.WATER)) {
			PlayerEntity playerEntity = (PlayerEntity)entity;
			GlStateManager.disableAlphaTest();
			this.minecraft.profiler.swap("outline");
			worldRenderer.renderBlockOutline(playerEntity, this.minecraft.crosshairTarget, 0, tickDelta);
			GlStateManager.enableAlphaTest();
		}

		this.minecraft.profiler.swap("destroyProgress");
		GlStateManager.enableBlend();
		GlStateManager.blendFuncSeparate(770, 1, 1, 0);
		this.minecraft.getTextureManager().get(TextureAtlas.BLOCKS_LOCATION).pushFilter(false, false);
		worldRenderer.renderMiningProgress(Tesselator.getInstance(), Tesselator.getInstance().getBuffer(), entity, tickDelta);
		this.minecraft.getTextureManager().get(TextureAtlas.BLOCKS_LOCATION).popFilter();
		GlStateManager.disableBlend();
		if (!this.debugCamera) {
			this.enableLightMap();
			this.minecraft.profiler.swap("litParticles");
			particleManager.renderLit(entity, tickDelta);
			Lighting.turnOff();
			this.setupFog(0, tickDelta);
			this.minecraft.profiler.swap("particles");
			particleManager.render(entity, tickDelta);
			this.disableLightMap();
		}

		GlStateManager.depthMask(false);
		GlStateManager.enableCull();
		this.minecraft.profiler.swap("weather");
		this.renderSnowAndRain(tickDelta);
		GlStateManager.depthMask(true);
		worldRenderer.renderWorldBorder(entity, tickDelta);
		GlStateManager.disableBlend();
		GlStateManager.enableCull();
		GlStateManager.blendFuncSeparate(770, 771, 1, 0);
		GlStateManager.alphaFunc(516, 0.1F);
		this.setupFog(0, tickDelta);
		GlStateManager.enableBlend();
		GlStateManager.depthMask(false);
		this.minecraft.getTextureManager().bind(TextureAtlas.BLOCKS_LOCATION);
		GlStateManager.shadeModel(7425);
		this.minecraft.profiler.swap("translucent");
		worldRenderer.render(BlockLayer.TRANSLUCENT, tickDelta, anaglyphRenderPass, entity);
		GlStateManager.shadeModel(7424);
		GlStateManager.depthMask(true);
		GlStateManager.enableCull();
		GlStateManager.disableBlend();
		GlStateManager.disableFog();
		if (entity.y + entity.getEyeHeight() >= 128.0) {
			this.minecraft.profiler.swap("aboveClouds");
			this.renderClouds(worldRenderer, tickDelta, anaglyphRenderPass);
		}

		this.minecraft.profiler.swap("hand");
		if (this.newCamPitch) {
			GlStateManager.clear(256);
			this.renderItemInHand(tickDelta, anaglyphRenderPass);
			this.renderAxisIndicators(tickDelta);
		}
	}

	private void renderClouds(WorldRenderer worldRenderer, float tickDelta, int anaglyphRenderPass) {
		if (this.minecraft.options.getCloudRenderMode() != 0) {
			this.minecraft.profiler.swap("clouds");
			GlStateManager.matrixMode(5889);
			GlStateManager.loadIdentity();
			Project.gluPerspective(this.getFov(tickDelta, true), (float)this.minecraft.width / this.minecraft.height, 0.05F, this.renderDistance * 4.0F);
			GlStateManager.matrixMode(5888);
			GlStateManager.pushMatrix();
			this.setupFog(0, tickDelta);
			worldRenderer.renderClouds(tickDelta, anaglyphRenderPass);
			GlStateManager.disableFog();
			GlStateManager.popMatrix();
			GlStateManager.matrixMode(5889);
			GlStateManager.loadIdentity();
			Project.gluPerspective(this.getFov(tickDelta, true), (float)this.minecraft.width / this.minecraft.height, 0.05F, this.renderDistance * MathHelper.SQRT_TWO);
			GlStateManager.matrixMode(5888);
		}
	}

	private void tickRain() {
		float f = this.minecraft.world.getRain(1.0F);
		if (!this.minecraft.options.fancyGraphics) {
			f /= 2.0F;
		}

		if (f != 0.0F) {
			this.random.setSeed(this.ticks * 312987231L);
			Entity entity = this.minecraft.getCamera();
			World world = this.minecraft.world;
			BlockPos blockPos = new BlockPos(entity);
			int i = 10;
			double d = 0.0;
			double e = 0.0;
			double g = 0.0;
			int j = 0;
			int k = (int)(100.0F * f * f);
			if (this.minecraft.options.particles == 1) {
				k >>= 1;
			} else if (this.minecraft.options.particles == 2) {
				k = 0;
			}

			for (int l = 0; l < k; l++) {
				BlockPos blockPos2 = world.getPrecipitationHeight(
					blockPos.add(this.random.nextInt(i) - this.random.nextInt(i), 0, this.random.nextInt(i) - this.random.nextInt(i))
				);
				Biome biome = world.getBiome(blockPos2);
				BlockPos blockPos3 = blockPos2.down();
				Block block = world.getBlockState(blockPos3).getBlock();
				if (blockPos2.getY() <= blockPos.getY() + i && blockPos2.getY() >= blockPos.getY() - i && biome.isRainy() && biome.getTemperature(blockPos2) >= 0.15F) {
					double h = this.random.nextDouble();
					double m = this.random.nextDouble();
					if (block.getMaterial() == Material.LAVA) {
						this.minecraft
							.world
							.addParticle(ParticleType.SMOKE_NORMAL, blockPos2.getX() + h, blockPos2.getY() + 0.1F - block.getMinY(), blockPos2.getZ() + m, 0.0, 0.0, 0.0);
					} else if (block.getMaterial() != Material.AIR) {
						block.updateShape(world, blockPos3);
						if (this.random.nextInt(++j) == 0) {
							d = blockPos3.getX() + h;
							e = blockPos3.getY() + 0.1F + block.getMaxY() - 1.0;
							g = blockPos3.getZ() + m;
						}

						this.minecraft
							.world
							.addParticle(ParticleType.WATER_DROP, blockPos3.getX() + h, blockPos3.getY() + 0.1F + block.getMaxY(), blockPos3.getZ() + m, 0.0, 0.0, 0.0);
					}
				}
			}

			if (j > 0 && this.random.nextInt(3) < this.weatherSoundAttempts++) {
				this.weatherSoundAttempts = 0;
				if (e > blockPos.getY() + 1 && world.getPrecipitationHeight(blockPos).getY() > MathHelper.floor(blockPos.getY())) {
					this.minecraft.world.playSound(d, e, g, "ambient.weather.rain", 0.1F, 0.5F, false);
				} else {
					this.minecraft.world.playSound(d, e, g, "ambient.weather.rain", 0.2F, 1.0F, false);
				}
			}
		}
	}

	protected void renderSnowAndRain(float tickDelta) {
		float f = this.minecraft.world.getRain(tickDelta);
		if (!(f <= 0.0F)) {
			this.enableLightMap();
			Entity entity = this.minecraft.getCamera();
			World world = this.minecraft.world;
			int i = MathHelper.floor(entity.x);
			int j = MathHelper.floor(entity.y);
			int k = MathHelper.floor(entity.z);
			Tesselator tesselator = Tesselator.getInstance();
			BufferBuilder bufferBuilder = tesselator.getBuffer();
			GlStateManager.disableCull();
			GL11.glNormal3f(0.0F, 1.0F, 0.0F);
			GlStateManager.enableBlend();
			GlStateManager.blendFuncSeparate(770, 771, 1, 0);
			GlStateManager.alphaFunc(516, 0.1F);
			double d = entity.prevX + (entity.x - entity.prevX) * tickDelta;
			double e = entity.prevY + (entity.y - entity.prevY) * tickDelta;
			double g = entity.prevZ + (entity.z - entity.prevZ) * tickDelta;
			int l = MathHelper.floor(e);
			int m = 5;
			if (this.minecraft.options.fancyGraphics) {
				m = 10;
			}

			int n = -1;
			float h = this.ticks + tickDelta;
			bufferBuilder.offset(-d, -e, -g);
			GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
			BlockPos.Mutable mutable = new BlockPos.Mutable();

			for (int o = k - m; o <= k + m; o++) {
				for (int p = i - m; p <= i + m; p++) {
					int q = (o - k + 16) * 32 + p - i + 16;
					double r = this.rainSizeX[q] * 0.5;
					double s = this.rainSizeZ[q] * 0.5;
					mutable.set(p, 0, o);
					Biome biome = world.getBiome(mutable);
					if (biome.isRainy() || biome.isSnowy()) {
						int t = world.getPrecipitationHeight(mutable).getY();
						int u = j - m;
						int v = j + m;
						if (u < t) {
							u = t;
						}

						if (v < t) {
							v = t;
						}

						int w = t;
						if (w < l) {
							w = l;
						}

						if (u != v) {
							this.random.setSeed(p * p * 3121 + p * 45238971 ^ o * o * 418711 + o * 13761);
							mutable.set(p, u, o);
							float x = biome.getTemperature(mutable);
							if (world.getBiomeSource().adjustTemperatureForHeight(x, t) >= 0.15F) {
								if (n != 0) {
									if (n >= 0) {
										tesselator.end();
									}

									n = 0;
									this.minecraft.getTextureManager().bind(RAIN_TEXTURE_LOCATION);
									bufferBuilder.begin(7, DefaultVertexFormat.PARTICLE);
								}

								double y = ((double)(this.ticks + p * p * 3121 + p * 45238971 + o * o * 418711 + o * 13761 & 31) + tickDelta) / 32.0 * (3.0 + this.random.nextDouble());
								double z = p + 0.5F - entity.x;
								double aa = o + 0.5F - entity.z;
								float ab = MathHelper.sqrt(z * z + aa * aa) / m;
								float ac = ((1.0F - ab * ab) * 0.5F + 0.5F) * f;
								mutable.set(p, w, o);
								int ad = world.getLightColor(mutable, 0);
								int ae = ad >> 16 & 65535;
								int af = ad & 65535;
								bufferBuilder.vertex(p - r + 0.5, u, o - s + 0.5).texture(0.0, u * 0.25 + y).color(1.0F, 1.0F, 1.0F, ac).texture(ae, af).nextVertex();
								bufferBuilder.vertex(p + r + 0.5, u, o + s + 0.5).texture(1.0, u * 0.25 + y).color(1.0F, 1.0F, 1.0F, ac).texture(ae, af).nextVertex();
								bufferBuilder.vertex(p + r + 0.5, v, o + s + 0.5).texture(1.0, v * 0.25 + y).color(1.0F, 1.0F, 1.0F, ac).texture(ae, af).nextVertex();
								bufferBuilder.vertex(p - r + 0.5, v, o - s + 0.5).texture(0.0, v * 0.25 + y).color(1.0F, 1.0F, 1.0F, ac).texture(ae, af).nextVertex();
							} else {
								if (n != 1) {
									if (n >= 0) {
										tesselator.end();
									}

									n = 1;
									this.minecraft.getTextureManager().bind(SNOW_TEXTURE_LOCATION);
									bufferBuilder.begin(7, DefaultVertexFormat.PARTICLE);
								}

								double y = ((this.ticks & 511) + tickDelta) / 512.0F;
								double z = this.random.nextDouble() + h * 0.01 * (float)this.random.nextGaussian();
								double aa = this.random.nextDouble() + h * (float)this.random.nextGaussian() * 0.001;
								double ag = p + 0.5F - entity.x;
								double ah = o + 0.5F - entity.z;
								float ai = MathHelper.sqrt(ag * ag + ah * ah) / m;
								float aj = ((1.0F - ai * ai) * 0.3F + 0.5F) * f;
								mutable.set(p, w, o);
								int ak = (world.getLightColor(mutable, 0) * 3 + 15728880) / 4;
								int al = ak >> 16 & 65535;
								int am = ak & 65535;
								bufferBuilder.vertex(p - r + 0.5, u, o - s + 0.5).texture(0.0 + z, u * 0.25 + y + aa).color(1.0F, 1.0F, 1.0F, aj).texture(al, am).nextVertex();
								bufferBuilder.vertex(p + r + 0.5, u, o + s + 0.5).texture(1.0 + z, u * 0.25 + y + aa).color(1.0F, 1.0F, 1.0F, aj).texture(al, am).nextVertex();
								bufferBuilder.vertex(p + r + 0.5, v, o + s + 0.5).texture(1.0 + z, v * 0.25 + y + aa).color(1.0F, 1.0F, 1.0F, aj).texture(al, am).nextVertex();
								bufferBuilder.vertex(p - r + 0.5, v, o - s + 0.5).texture(0.0 + z, v * 0.25 + y + aa).color(1.0F, 1.0F, 1.0F, aj).texture(al, am).nextVertex();
							}
						}
					}
				}
			}

			if (n >= 0) {
				tesselator.end();
			}

			bufferBuilder.offset(0.0, 0.0, 0.0);
			GlStateManager.enableCull();
			GlStateManager.disableBlend();
			GlStateManager.alphaFunc(516, 0.1F);
			this.disableLightMap();
		}
	}

	public void setupGuiState() {
		Window window = new Window(this.minecraft);
		GlStateManager.clear(256);
		GlStateManager.matrixMode(5889);
		GlStateManager.loadIdentity();
		GlStateManager.ortho(0.0, window.getScaledWidth(), window.getScaledHeight(), 0.0, 1000.0, 3000.0);
		GlStateManager.matrixMode(5888);
		GlStateManager.loadIdentity();
		GlStateManager.translatef(0.0F, 0.0F, -2000.0F);
	}

	private void setupClearColor(float tickDelta) {
		World world = this.minecraft.world;
		Entity entity = this.minecraft.getCamera();
		float f = 0.25F + 0.75F * this.minecraft.options.viewDistance / 32.0F;
		f = 1.0F - (float)Math.pow(f, 0.25);
		Vec3d vec3d = world.getSkyColor(this.minecraft.getCamera(), tickDelta);
		float g = (float)vec3d.x;
		float h = (float)vec3d.y;
		float i = (float)vec3d.z;
		Vec3d vec3d2 = world.getFogColor(tickDelta);
		this.fogRed = (float)vec3d2.x;
		this.fogGreen = (float)vec3d2.y;
		this.fogBlue = (float)vec3d2.z;
		if (this.minecraft.options.viewDistance >= 4) {
			double d = -1.0;
			Vec3d vec3d3 = MathHelper.sin(world.getSunAngle(tickDelta)) > 0.0F ? new Vec3d(d, 0.0, 0.0) : new Vec3d(1.0, 0.0, 0.0);
			float j = (float)entity.getRotationVector(tickDelta).dot(vec3d3);
			if (j < 0.0F) {
				j = 0.0F;
			}

			if (j > 0.0F) {
				float[] fs = world.dimension.getSunriseColor(world.getTimeOfDay(tickDelta), tickDelta);
				if (fs != null) {
					j *= fs[3];
					this.fogRed = this.fogRed * (1.0F - j) + fs[0] * j;
					this.fogGreen = this.fogGreen * (1.0F - j) + fs[1] * j;
					this.fogBlue = this.fogBlue * (1.0F - j) + fs[2] * j;
				}
			}
		}

		this.fogRed = this.fogRed + (g - this.fogRed) * f;
		this.fogGreen = this.fogGreen + (h - this.fogGreen) * f;
		this.fogBlue = this.fogBlue + (i - this.fogBlue) * f;
		float k = world.getRain(tickDelta);
		if (k > 0.0F) {
			float l = 1.0F - k * 0.5F;
			float m = 1.0F - k * 0.4F;
			this.fogRed *= l;
			this.fogGreen *= l;
			this.fogBlue *= m;
		}

		float l = world.getThunder(tickDelta);
		if (l > 0.0F) {
			float m = 1.0F - l * 0.5F;
			this.fogRed *= m;
			this.fogGreen *= m;
			this.fogBlue *= m;
		}

		Block block = Camera.getBlockInside(this.minecraft.world, entity, tickDelta);
		if (this.thiccFog) {
			Vec3d vec3d4 = world.getCloudColor(tickDelta);
			this.fogRed = (float)vec3d4.x;
			this.fogGreen = (float)vec3d4.y;
			this.fogBlue = (float)vec3d4.z;
		} else if (block.getMaterial() == Material.WATER) {
			float j = EnchantmentHelper.getRespirationLevel(entity) * 0.2F;
			if (entity instanceof LivingEntity && ((LivingEntity)entity).hasStatusEffect(StatusEffect.WATER_BREATHING)) {
				j = j * 0.3F + 0.6F;
			}

			this.fogRed = 0.02F + j;
			this.fogGreen = 0.02F + j;
			this.fogBlue = 0.2F + j;
		} else if (block.getMaterial() == Material.LAVA) {
			this.fogRed = 0.6F;
			this.fogGreen = 0.1F;
			this.fogBlue = 0.0F;
		}

		float j = this.lastFogBrightness + (this.fogBrightness - this.lastFogBrightness) * tickDelta;
		this.fogRed *= j;
		this.fogGreen *= j;
		this.fogBlue *= j;
		double e = (entity.prevY + (entity.y - entity.prevY) * tickDelta) * world.dimension.getFogSize();
		if (entity instanceof LivingEntity && ((LivingEntity)entity).hasStatusEffect(StatusEffect.BLINDNESS)) {
			int n = ((LivingEntity)entity).getEffectInstance(StatusEffect.BLINDNESS).getDuration();
			if (n < 20) {
				e *= 1.0F - n / 20.0F;
			} else {
				e = 0.0;
			}
		}

		if (e < 1.0) {
			if (e < 0.0) {
				e = 0.0;
			}

			e *= e;
			this.fogRed = (float)(this.fogRed * e);
			this.fogGreen = (float)(this.fogGreen * e);
			this.fogBlue = (float)(this.fogBlue * e);
		}

		if (this.skyDarkness > 0.0F) {
			float o = this.lastSkyDarkness + (this.skyDarkness - this.lastSkyDarkness) * tickDelta;
			this.fogRed = this.fogRed * (1.0F - o) + this.fogRed * 0.7F * o;
			this.fogGreen = this.fogGreen * (1.0F - o) + this.fogGreen * 0.6F * o;
			this.fogBlue = this.fogBlue * (1.0F - o) + this.fogBlue * 0.6F * o;
		}

		if (entity instanceof LivingEntity && ((LivingEntity)entity).hasStatusEffect(StatusEffect.NIGHTVISION)) {
			float o = this.getNightVisionScale((LivingEntity)entity, tickDelta);
			float p = 1.0F / this.fogRed;
			if (p > 1.0F / this.fogGreen) {
				p = 1.0F / this.fogGreen;
			}

			if (p > 1.0F / this.fogBlue) {
				p = 1.0F / this.fogBlue;
			}

			this.fogRed = this.fogRed * (1.0F - o) + this.fogRed * p * o;
			this.fogGreen = this.fogGreen * (1.0F - o) + this.fogGreen * p * o;
			this.fogBlue = this.fogBlue * (1.0F - o) + this.fogBlue * p * o;
		}

		if (this.minecraft.options.anaglyph) {
			float o = (this.fogRed * 30.0F + this.fogGreen * 59.0F + this.fogBlue * 11.0F) / 100.0F;
			float p = (this.fogRed * 30.0F + this.fogGreen * 70.0F) / 100.0F;
			float q = (this.fogRed * 30.0F + this.fogBlue * 70.0F) / 100.0F;
			this.fogRed = o;
			this.fogGreen = p;
			this.fogBlue = q;
		}

		GlStateManager.clearColor(this.fogRed, this.fogGreen, this.fogBlue, 0.0F);
	}

	private void setupFog(int mode, float tickDelta) {
		Entity entity = this.minecraft.getCamera();
		boolean bl = false;
		if (entity instanceof PlayerEntity) {
			bl = ((PlayerEntity)entity).abilities.creativeMode;
		}

		GL11.glFog(2918, this.updateColorBuffer(this.fogRed, this.fogGreen, this.fogBlue, 1.0F));
		GL11.glNormal3f(0.0F, -1.0F, 0.0F);
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		Block block = Camera.getBlockInside(this.minecraft.world, entity, tickDelta);
		if (entity instanceof LivingEntity && ((LivingEntity)entity).hasStatusEffect(StatusEffect.BLINDNESS)) {
			float f = 5.0F;
			int i = ((LivingEntity)entity).getEffectInstance(StatusEffect.BLINDNESS).getDuration();
			if (i < 20) {
				f = 5.0F + (this.renderDistance - 5.0F) * (1.0F - i / 20.0F);
			}

			GlStateManager.fogMode(9729);
			if (mode == -1) {
				GlStateManager.fogStart(0.0F);
				GlStateManager.fogEnd(f * 0.8F);
			} else {
				GlStateManager.fogStart(f * 0.25F);
				GlStateManager.fogEnd(f);
			}

			if (GLContext.getCapabilities().GL_NV_fog_distance) {
				GL11.glFogi(34138, 34139);
			}
		} else if (this.thiccFog) {
			GlStateManager.fogMode(2048);
			GlStateManager.fogDensity(0.1F);
		} else if (block.getMaterial() == Material.WATER) {
			GlStateManager.fogMode(2048);
			if (entity instanceof LivingEntity && ((LivingEntity)entity).hasStatusEffect(StatusEffect.WATER_BREATHING)) {
				GlStateManager.fogDensity(0.01F);
			} else {
				GlStateManager.fogDensity(0.1F - EnchantmentHelper.getRespirationLevel(entity) * 0.03F);
			}
		} else if (block.getMaterial() == Material.LAVA) {
			GlStateManager.fogMode(2048);
			GlStateManager.fogDensity(2.0F);
		} else {
			float f = this.renderDistance;
			GlStateManager.fogMode(9729);
			if (mode == -1) {
				GlStateManager.fogStart(0.0F);
				GlStateManager.fogEnd(f);
			} else {
				GlStateManager.fogStart(f * 0.75F);
				GlStateManager.fogEnd(f);
			}

			if (GLContext.getCapabilities().GL_NV_fog_distance) {
				GL11.glFogi(34138, 34139);
			}

			if (this.minecraft.world.dimension.isFogThick((int)entity.x, (int)entity.z)) {
				GlStateManager.fogStart(f * 0.05F);
				GlStateManager.fogEnd(Math.min(f, 192.0F) * 0.5F);
			}
		}

		GlStateManager.enableColorMaterial();
		GlStateManager.enableFog();
		GlStateManager.colorMaterial(1028, 4608);
	}

	private FloatBuffer updateColorBuffer(float f1, float f2, float f3, float f4) {
		((Buffer)this.colorBuffer).clear();
		this.colorBuffer.put(f1).put(f2).put(f3).put(f4);
		((Buffer)this.colorBuffer).flip();
		return this.colorBuffer;
	}

	public MapRenderer getMapRenderer() {
		return this.mapRenderer;
	}
}

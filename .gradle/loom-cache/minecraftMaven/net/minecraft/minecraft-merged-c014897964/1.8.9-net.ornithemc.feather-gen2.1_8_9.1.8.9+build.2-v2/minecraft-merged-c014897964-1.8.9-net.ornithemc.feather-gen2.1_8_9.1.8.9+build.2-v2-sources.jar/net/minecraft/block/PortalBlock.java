package net.minecraft.block;

import com.google.common.cache.LoadingCache;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.material.Material;
import net.minecraft.block.pattern.BlockPattern;
import net.minecraft.block.pattern.BlockPointer;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.EnumProperty;
import net.minecraft.client.render.block.BlockLayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.particle.ParticleType;
import net.minecraft.item.Item;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.ornithemc.feather.constants.SetBlockFlags;

public class PortalBlock extends TransparentBlock {
	public static final EnumProperty<Direction.Axis> AXIS = EnumProperty.of("axis", Direction.Axis.class, Direction.Axis.X, Direction.Axis.Z);

	public PortalBlock() {
		super(Material.PORTAL, false);
		this.setDefaultState(this.stateDefinition.any().set(AXIS, Direction.Axis.X));
		this.setTicksRandomly(true);
	}

	@Override
	public void tick(World world, BlockPos pos, BlockState state, Random random) {
		super.tick(world, pos, state, random);
		if (world.dimension.isNatural() && world.getGameRules().getBoolean("doMobSpawning") && random.nextInt(2000) < world.getDifficulty().getId()) {
			int i = pos.getY();
			BlockPos blockPos = pos;

			while (!World.hasSolidTop(world, blockPos) && blockPos.getY() > 0) {
				blockPos = blockPos.down();
			}

			if (i > 0 && !world.getBlockState(blockPos.up()).getBlock().isSolid()) {
				Entity entity = SpawnEggItem.spawnEntity(world, 57, blockPos.getX() + 0.5, blockPos.getY() + 1.1, blockPos.getZ() + 0.5);
				if (entity != null) {
					entity.portalCooldown = entity.getPortalCooldown();
				}
			}
		}
	}

	@Override
	public Box getCollisionShape(World world, BlockPos pos, BlockState state) {
		return null;
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		Direction.Axis axis = world.getBlockState(pos).get(AXIS);
		float f = 0.125F;
		float g = 0.125F;
		if (axis == Direction.Axis.X) {
			f = 0.5F;
		}

		if (axis == Direction.Axis.Z) {
			g = 0.5F;
		}

		this.setShape(0.5F - f, 0.0F, 0.5F - g, 0.5F + f, 1.0F, 0.5F + g);
	}

	public static int getMetadata(Direction.Axis axis) {
		if (axis == Direction.Axis.X) {
			return 1;
		} else {
			return axis == Direction.Axis.Z ? 2 : 0;
		}
	}

	@Override
	public boolean isCube() {
		return false;
	}

	public boolean create(World world, BlockPos pos) {
		PortalBlock.PortalBuilder portalBuilder = new PortalBlock.PortalBuilder(world, pos, Direction.Axis.X);
		if (portalBuilder.isValid() && portalBuilder.foundPortalBlocks == 0) {
			portalBuilder.build();
			return true;
		} else {
			PortalBlock.PortalBuilder portalBuilder2 = new PortalBlock.PortalBuilder(world, pos, Direction.Axis.Z);
			if (portalBuilder2.isValid() && portalBuilder2.foundPortalBlocks == 0) {
				portalBuilder2.build();
				return true;
			} else {
				return false;
			}
		}
	}

	@Override
	public void neighborChanged(World world, BlockPos pos, BlockState state, Block neighborBlock) {
		Direction.Axis axis = state.get(AXIS);
		if (axis == Direction.Axis.X) {
			PortalBlock.PortalBuilder portalBuilder = new PortalBlock.PortalBuilder(world, pos, Direction.Axis.X);
			if (!portalBuilder.isValid() || portalBuilder.foundPortalBlocks < portalBuilder.width * portalBuilder.height) {
				world.setBlockState(pos, Blocks.AIR.defaultState());
			}
		} else if (axis == Direction.Axis.Z) {
			PortalBlock.PortalBuilder portalBuilder = new PortalBlock.PortalBuilder(world, pos, Direction.Axis.Z);
			if (!portalBuilder.isValid() || portalBuilder.foundPortalBlocks < portalBuilder.width * portalBuilder.height) {
				world.setBlockState(pos, Blocks.AIR.defaultState());
			}
		}
	}

	@Environment(EnvType.CLIENT)
	@Override
	public boolean shouldRenderFace(WorldView world, BlockPos pos, Direction face) {
		Direction.Axis axis = null;
		BlockState blockState = world.getBlockState(pos);
		if (world.getBlockState(pos).getBlock() == this) {
			axis = blockState.get(AXIS);
			if (axis == null) {
				return false;
			}

			if (axis == Direction.Axis.Z && face != Direction.EAST && face != Direction.WEST) {
				return false;
			}

			if (axis == Direction.Axis.X && face != Direction.SOUTH && face != Direction.NORTH) {
				return false;
			}
		}

		boolean bl = world.getBlockState(pos.west()).getBlock() == this && world.getBlockState(pos.west(2)).getBlock() != this;
		boolean bl2 = world.getBlockState(pos.east()).getBlock() == this && world.getBlockState(pos.east(2)).getBlock() != this;
		boolean bl3 = world.getBlockState(pos.north()).getBlock() == this && world.getBlockState(pos.north(2)).getBlock() != this;
		boolean bl4 = world.getBlockState(pos.south()).getBlock() == this && world.getBlockState(pos.south(2)).getBlock() != this;
		boolean bl5 = bl || bl2 || axis == Direction.Axis.X;
		boolean bl6 = bl3 || bl4 || axis == Direction.Axis.Z;
		if (bl5 && face == Direction.WEST) {
			return true;
		} else if (bl5 && face == Direction.EAST) {
			return true;
		} else {
			return bl6 && face == Direction.NORTH ? true : bl6 && face == Direction.SOUTH;
		}
	}

	@Override
	public int getBaseDropCount(Random random) {
		return 0;
	}

	@Environment(EnvType.CLIENT)
	@Override
	public BlockLayer getRenderLayer() {
		return BlockLayer.TRANSLUCENT;
	}

	@Override
	public void onEntityCollision(World world, BlockPos pos, BlockState state, Entity entity) {
		if (entity.vehicle == null && entity.rider == null) {
			entity.onPortalCollision(pos);
		}
	}

	@Environment(EnvType.CLIENT)
	@Override
	public void randomDisplayTick(World world, BlockPos pos, BlockState state, Random random) {
		if (random.nextInt(100) == 0) {
			world.playSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, "portal.portal", 0.5F, random.nextFloat() * 0.4F + 0.8F, false);
		}

		for (int i = 0; i < 4; i++) {
			double d = pos.getX() + random.nextFloat();
			double e = pos.getY() + random.nextFloat();
			double f = pos.getZ() + random.nextFloat();
			double g = (random.nextFloat() - 0.5) * 0.5;
			double h = (random.nextFloat() - 0.5) * 0.5;
			double j = (random.nextFloat() - 0.5) * 0.5;
			int k = random.nextInt(2) * 2 - 1;
			if (world.getBlockState(pos.west()).getBlock() != this && world.getBlockState(pos.east()).getBlock() != this) {
				d = pos.getX() + 0.5 + 0.25 * k;
				g = random.nextFloat() * 2.0F * k;
			} else {
				f = pos.getZ() + 0.5 + 0.25 * k;
				j = random.nextFloat() * 2.0F * k;
			}

			world.addParticle(ParticleType.PORTAL, d, e, f, g, h, j);
		}
	}

	@Environment(EnvType.CLIENT)
	@Override
	public Item getPickItem(World world, BlockPos pos) {
		return null;
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		return this.defaultState().set(AXIS, (metadata & 3) == 2 ? Direction.Axis.Z : Direction.Axis.X);
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		return getMetadata(state.get(AXIS));
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, AXIS);
	}

	public BlockPattern.Match findPortalShape(World world, BlockPos pos) {
		Direction.Axis axis = Direction.Axis.Z;
		PortalBlock.PortalBuilder portalBuilder = new PortalBlock.PortalBuilder(world, pos, Direction.Axis.X);
		LoadingCache<BlockPos, BlockPointer> loadingCache = BlockPattern.createBlockCache(world, true);
		if (!portalBuilder.isValid()) {
			axis = Direction.Axis.X;
			portalBuilder = new PortalBlock.PortalBuilder(world, pos, Direction.Axis.Z);
		}

		if (!portalBuilder.isValid()) {
			return new BlockPattern.Match(pos, Direction.NORTH, Direction.UP, loadingCache, 1, 1, 1);
		}

		int[] is = new int[Direction.AxisDirection.values().length];
		Direction direction = portalBuilder.right.counterClockwiseY();
		BlockPos blockPos = portalBuilder.bottomLeft.up(portalBuilder.getHeight() - 1);

		for (Direction.AxisDirection axisDirection : Direction.AxisDirection.values()) {
			BlockPattern.Match match = new BlockPattern.Match(
				direction.getAxisDirection() == axisDirection ? blockPos : blockPos.offset(portalBuilder.right, portalBuilder.getWidth() - 1),
				Direction.of(axisDirection, axis),
				Direction.UP,
				loadingCache,
				portalBuilder.getWidth(),
				portalBuilder.getHeight(),
				1
			);

			for (int k = 0; k < portalBuilder.getWidth(); k++) {
				for (int l = 0; l < portalBuilder.getHeight(); l++) {
					BlockPointer blockPointer = match.getBlock(k, l, 1);
					if (blockPointer.getState() != null && blockPointer.getState().getBlock().getMaterial() != Material.AIR) {
						is[axisDirection.ordinal()]++;
					}
				}
			}
		}

		Direction.AxisDirection axisDirection2 = Direction.AxisDirection.POSITIVE;

		for (Direction.AxisDirection axisDirection3 : Direction.AxisDirection.values()) {
			if (is[axisDirection3.ordinal()] < is[axisDirection2.ordinal()]) {
				axisDirection2 = axisDirection3;
			}
		}

		return new BlockPattern.Match(
			direction.getAxisDirection() == axisDirection2 ? blockPos : blockPos.offset(portalBuilder.right, portalBuilder.getWidth() - 1),
			Direction.of(axisDirection2, axis),
			Direction.UP,
			loadingCache,
			portalBuilder.getWidth(),
			portalBuilder.getHeight(),
			1
		);
	}

	public static class PortalBuilder {
		private final World world;
		private final Direction.Axis axis;
		private final Direction right;
		private final Direction left;
		private int foundPortalBlocks = 0;
		private BlockPos bottomLeft;
		private int height;
		private int width;

		public PortalBuilder(World world, BlockPos pos, Direction.Axis axis) {
			this.world = world;
			this.axis = axis;
			if (axis == Direction.Axis.X) {
				this.left = Direction.EAST;
				this.right = Direction.WEST;
			} else {
				this.left = Direction.NORTH;
				this.right = Direction.SOUTH;
			}

			BlockPos blockPos = pos;

			while (pos.getY() > blockPos.getY() - 21 && pos.getY() > 0 && this.canBeReplacedByPortal(world.getBlockState(pos.down()).getBlock())) {
				pos = pos.down();
			}

			int i = this.findWidth(pos, this.left) - 1;
			if (i >= 0) {
				this.bottomLeft = pos.offset(this.left, i);
				this.width = this.findWidth(this.bottomLeft, this.right);
				if (this.width < 2 || this.width > 21) {
					this.bottomLeft = null;
					this.width = 0;
				}
			}

			if (this.bottomLeft != null) {
				this.height = this.findHeight();
			}
		}

		protected int findWidth(BlockPos pos, Direction dir) {
			int i;
			for (i = 0; i < 22; i++) {
				BlockPos blockPos = pos.offset(dir, i);
				if (!this.canBeReplacedByPortal(this.world.getBlockState(blockPos).getBlock()) || this.world.getBlockState(blockPos.down()).getBlock() != Blocks.OBSIDIAN) {
					break;
				}
			}

			Block block = this.world.getBlockState(pos.offset(dir, i)).getBlock();
			return block == Blocks.OBSIDIAN ? i : 0;
		}

		public int getHeight() {
			return this.height;
		}

		public int getWidth() {
			return this.width;
		}

		protected int findHeight() {
			label56:
			for (this.height = 0; this.height < 21; this.height++) {
				for (int i = 0; i < this.width; i++) {
					BlockPos blockPos = this.bottomLeft.offset(this.right, i).up(this.height);
					Block block = this.world.getBlockState(blockPos).getBlock();
					if (!this.canBeReplacedByPortal(block)) {
						break label56;
					}

					if (block == Blocks.NETHER_PORTAL) {
						this.foundPortalBlocks++;
					}

					if (i == 0) {
						block = this.world.getBlockState(blockPos.offset(this.left)).getBlock();
						if (block != Blocks.OBSIDIAN) {
							break label56;
						}
					} else if (i == this.width - 1) {
						block = this.world.getBlockState(blockPos.offset(this.right)).getBlock();
						if (block != Blocks.OBSIDIAN) {
							break label56;
						}
					}
				}
			}

			for (int i = 0; i < this.width; i++) {
				if (this.world.getBlockState(this.bottomLeft.offset(this.right, i).up(this.height)).getBlock() != Blocks.OBSIDIAN) {
					this.height = 0;
					break;
				}
			}

			if (this.height <= 21 && this.height >= 3) {
				return this.height;
			}

			this.bottomLeft = null;
			this.width = 0;
			this.height = 0;
			return 0;
		}

		protected boolean canBeReplacedByPortal(Block block) {
			return block.material == Material.AIR || block == Blocks.FIRE || block == Blocks.NETHER_PORTAL;
		}

		public boolean isValid() {
			return this.bottomLeft != null && this.width >= 2 && this.width <= 21 && this.height >= 3 && this.height <= 21;
		}

		public void build() {
			for (int i = 0; i < this.width; i++) {
				BlockPos blockPos = this.bottomLeft.offset(this.right, i);

				for (int j = 0; j < this.height; j++) {
					this.world.setBlockState(blockPos.up(j), Blocks.NETHER_PORTAL.defaultState().set(PortalBlock.AXIS, this.axis), SetBlockFlags.NOTIFY_LISTENERS);
				}
			}
		}
	}
}

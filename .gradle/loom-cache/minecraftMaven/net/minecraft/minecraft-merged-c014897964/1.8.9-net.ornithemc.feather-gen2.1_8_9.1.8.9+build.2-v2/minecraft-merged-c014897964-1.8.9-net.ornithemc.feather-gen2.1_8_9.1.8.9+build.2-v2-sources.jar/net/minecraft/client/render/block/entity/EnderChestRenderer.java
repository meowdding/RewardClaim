package net.minecraft.client.render.block.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.client.render.model.block.entity.ChestModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.resource.Identifier;

@Environment(EnvType.CLIENT)
public class EnderChestRenderer extends BlockEntityRenderer<EnderChestBlockEntity> {
	private static final Identifier ENDER_CHEST_LOCATION = new Identifier("textures/entity/chest/ender.png");
	private ChestModel model = new ChestModel();

	public void render(EnderChestBlockEntity blockEntity, double dx, double dy, double dz, float tickDelta, int blockMiningProgress) {
		int i = 0;
		if (blockEntity.hasWorld()) {
			i = blockEntity.getBlockMetadata();
		}

		if (blockMiningProgress >= 0) {
			this.bindTexture(MINING_PROGRESS_LOCATIONS[blockMiningProgress]);
			GlStateManager.matrixMode(5890);
			GlStateManager.pushMatrix();
			GlStateManager.scalef(4.0F, 4.0F, 1.0F);
			GlStateManager.translatef(0.0625F, 0.0625F, 0.0625F);
			GlStateManager.matrixMode(5888);
		} else {
			this.bindTexture(ENDER_CHEST_LOCATION);
		}

		GlStateManager.pushMatrix();
		GlStateManager.enableRescaleNormal();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.translatef((float)dx, (float)dy + 1.0F, (float)dz + 1.0F);
		GlStateManager.scalef(1.0F, -1.0F, -1.0F);
		GlStateManager.translatef(0.5F, 0.5F, 0.5F);
		int j = 0;
		if (i == 2) {
			j = 180;
		}

		if (i == 3) {
			j = 0;
		}

		if (i == 4) {
			j = 90;
		}

		if (i == 5) {
			j = -90;
		}

		GlStateManager.rotatef(j, 0.0F, 1.0F, 0.0F);
		GlStateManager.translatef(-0.5F, -0.5F, -0.5F);
		float f = blockEntity.lastAnimationProgress + (blockEntity.animationProgress - blockEntity.lastAnimationProgress) * tickDelta;
		f = 1.0F - f;
		f = 1.0F - f * f * f;
		this.model.lid.rotationX = -(f * (float) Math.PI / 2.0F);
		this.model.renderParts();
		GlStateManager.disableRescaleNormal();
		GlStateManager.popMatrix();
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		if (blockMiningProgress >= 0) {
			GlStateManager.matrixMode(5890);
			GlStateManager.popMatrix();
			GlStateManager.matrixMode(5888);
		}
	}
}

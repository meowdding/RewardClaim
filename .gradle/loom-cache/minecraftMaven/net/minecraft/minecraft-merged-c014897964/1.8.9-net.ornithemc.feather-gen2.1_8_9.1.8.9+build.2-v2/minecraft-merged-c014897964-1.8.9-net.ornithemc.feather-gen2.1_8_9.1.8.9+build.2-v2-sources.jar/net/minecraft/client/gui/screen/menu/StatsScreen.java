package net.minecraft.client.gui.screen.menu;

import com.google.common.collect.Lists;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ListWidget;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.platform.Lighting;
import net.minecraft.client.render.vertex.BufferBuilder;
import net.minecraft.client.render.vertex.DefaultVertexFormat;
import net.minecraft.client.render.vertex.Tesselator;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.sound.instance.SimpleSoundInstance;
import net.minecraft.entity.Entities;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import net.minecraft.resource.Identifier;
import net.minecraft.stat.ItemStat;
import net.minecraft.stat.PlayerStats;
import net.minecraft.stat.Stat;
import net.minecraft.stat.Stats;
import org.lwjgl.input.Mouse;

@Environment(EnvType.CLIENT)
public class StatsScreen extends Screen implements StatsListener {
	protected Screen parent;
	protected String title = "Select world";
	private StatsScreen.GeneralStatsListWidget generalStats;
	private StatsScreen.ItemStatsListWidget itemStats;
	private StatsScreen.StatsListWidget blockStats;
	private StatsScreen.EntityStatsListWidget mobStats;
	private PlayerStats stats;
	private ListWidget selectedStatsList;
	private boolean downloadingStats = true;

	public StatsScreen(Screen parent, PlayerStats stats) {
		this.parent = parent;
		this.stats = stats;
	}

	@Override
	public void init() {
		this.title = I18n.translate("gui.stats");
		this.downloadingStats = true;
		this.minecraft.getNetworkHandler().sendPacket(new ClientStatusC2SPacket(ClientStatusC2SPacket.Status.REQUEST_STATS));
	}

	@Override
	public void handleMouse() {
		super.handleMouse();
		if (this.selectedStatsList != null) {
			this.selectedStatsList.handleMouse();
		}
	}

	public void createLists() {
		this.generalStats = new StatsScreen.GeneralStatsListWidget(this.minecraft);
		this.generalStats.setScrollButtonIds(1, 1);
		this.itemStats = new StatsScreen.ItemStatsListWidget(this.minecraft);
		this.itemStats.setScrollButtonIds(1, 1);
		this.blockStats = new StatsScreen.StatsListWidget(this.minecraft);
		this.blockStats.setScrollButtonIds(1, 1);
		this.mobStats = new StatsScreen.EntityStatsListWidget(this.minecraft);
		this.mobStats.setScrollButtonIds(1, 1);
	}

	public void createButtons() {
		this.buttons.add(new ButtonWidget(0, this.width / 2 + 4, this.height - 28, 150, 20, I18n.translate("gui.done")));
		this.buttons.add(new ButtonWidget(1, this.width / 2 - 160, this.height - 52, 80, 20, I18n.translate("stat.generalButton")));
		ButtonWidget buttonWidget;
		this.buttons.add(buttonWidget = new ButtonWidget(2, this.width / 2 - 80, this.height - 52, 80, 20, I18n.translate("stat.blocksButton")));
		ButtonWidget buttonWidget2;
		this.buttons.add(buttonWidget2 = new ButtonWidget(3, this.width / 2, this.height - 52, 80, 20, I18n.translate("stat.itemsButton")));
		ButtonWidget buttonWidget3;
		this.buttons.add(buttonWidget3 = new ButtonWidget(4, this.width / 2 + 80, this.height - 52, 80, 20, I18n.translate("stat.mobsButton")));
		if (this.blockStats.size() == 0) {
			buttonWidget.active = false;
		}

		if (this.itemStats.size() == 0) {
			buttonWidget2.active = false;
		}

		if (this.mobStats.size() == 0) {
			buttonWidget3.active = false;
		}
	}

	@Override
	protected void buttonClicked(ButtonWidget button) {
		if (button.active) {
			if (button.id == 0) {
				this.minecraft.openScreen(this.parent);
			} else if (button.id == 1) {
				this.selectedStatsList = this.generalStats;
			} else if (button.id == 3) {
				this.selectedStatsList = this.itemStats;
			} else if (button.id == 2) {
				this.selectedStatsList = this.blockStats;
			} else if (button.id == 4) {
				this.selectedStatsList = this.mobStats;
			} else {
				this.selectedStatsList.buttonClicked(button);
			}
		}
	}

	@Override
	public void render(int mouseX, int mouseY, float tickDelta) {
		if (this.downloadingStats) {
			this.renderBackground();
			this.drawCenteredString(this.textRenderer, I18n.translate("multiplayer.downloadingStats"), this.width / 2, this.height / 2, 16777215);
			this.drawCenteredString(
				this.textRenderer,
				PROGRESS_BAR_STAGES[(int)(Minecraft.getTime() / 150L % PROGRESS_BAR_STAGES.length)],
				this.width / 2,
				this.height / 2 + this.textRenderer.fontHeight * 2,
				16777215
			);
		} else {
			this.selectedStatsList.render(mouseX, mouseY, tickDelta);
			this.drawCenteredString(this.textRenderer, this.title, this.width / 2, 20, 16777215);
			super.render(mouseX, mouseY, tickDelta);
		}
	}

	@Override
	public void onStatsReady() {
		if (this.downloadingStats) {
			this.createLists();
			this.createButtons();
			this.selectedStatsList = this.generalStats;
			this.downloadingStats = false;
		}
	}

	@Override
	public boolean shouldPauseGame() {
		return !this.downloadingStats;
	}

	private void renderStatIcon(int x, int y, Item item) {
		this.renderSlot(x + 1, y + 1);
		GlStateManager.enableRescaleNormal();
		Lighting.turnOnGui();
		this.itemRenderer.renderGuiItemModel(new ItemStack(item, 1, 0), x + 2, y + 2);
		Lighting.turnOff();
		GlStateManager.disableRescaleNormal();
	}

	private void renderSlot(int x, int y) {
		this.renderSlot(x, y, 0, 0);
	}

	private void renderSlot(int x, int y, int u, int v) {
		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.minecraft.getTextureManager().bind(STATS_ICONS_LOCATION);
		float f = 0.0078125F;
		float g = 0.0078125F;
		int i = 18;
		int j = 18;
		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder bufferBuilder = tesselator.getBuffer();
		bufferBuilder.begin(7, DefaultVertexFormat.POSITION_TEX);
		bufferBuilder.vertex(x + 0, y + 18, this.drawOffset).texture((u + 0) * 0.0078125F, (v + 18) * 0.0078125F).nextVertex();
		bufferBuilder.vertex(x + 18, y + 18, this.drawOffset).texture((u + 18) * 0.0078125F, (v + 18) * 0.0078125F).nextVertex();
		bufferBuilder.vertex(x + 18, y + 0, this.drawOffset).texture((u + 18) * 0.0078125F, (v + 0) * 0.0078125F).nextVertex();
		bufferBuilder.vertex(x + 0, y + 0, this.drawOffset).texture((u + 0) * 0.0078125F, (v + 0) * 0.0078125F).nextVertex();
		tesselator.end();
	}

	@Environment(EnvType.CLIENT)
	abstract class AbstractStatsListWidget extends ListWidget {
		protected int clickedIconId = -1;
		protected List<ItemStat> entries;
		protected Comparator<ItemStat> statComparator;
		protected int selectedTab = -1;
		protected int statSortOrder;

		protected AbstractStatsListWidget(Minecraft minecraft) {
			super(minecraft, StatsScreen.this.width, StatsScreen.this.height, 32, StatsScreen.this.height - 64, 20);
			this.setRenderSelectionHighlight(false);
			this.setHeader(true, 20);
		}

		@Override
		protected void entryClicked(int index, boolean doubleClick, int mouseX, int mouseY) {
		}

		@Override
		protected boolean isEntrySelected(int index) {
			return false;
		}

		@Override
		protected void renderBackground() {
			StatsScreen.this.renderBackground();
		}

		@Override
		protected void renderHeader(int x, int y, Tesselator tesselator) {
			if (!Mouse.isButtonDown(0)) {
				this.clickedIconId = -1;
			}

			if (this.clickedIconId == 0) {
				StatsScreen.this.renderSlot(x + 115 - 18, y + 1, 0, 0);
			} else {
				StatsScreen.this.renderSlot(x + 115 - 18, y + 1, 0, 18);
			}

			if (this.clickedIconId == 1) {
				StatsScreen.this.renderSlot(x + 165 - 18, y + 1, 0, 0);
			} else {
				StatsScreen.this.renderSlot(x + 165 - 18, y + 1, 0, 18);
			}

			if (this.clickedIconId == 2) {
				StatsScreen.this.renderSlot(x + 215 - 18, y + 1, 0, 0);
			} else {
				StatsScreen.this.renderSlot(x + 215 - 18, y + 1, 0, 18);
			}

			if (this.selectedTab != -1) {
				int i = 79;
				int j = 18;
				if (this.selectedTab == 1) {
					i = 129;
				} else if (this.selectedTab == 2) {
					i = 179;
				}

				if (this.statSortOrder == 1) {
					j = 36;
				}

				StatsScreen.this.renderSlot(x + i, y + 1, j, 0);
			}
		}

		@Override
		protected void headerClicked(int x, int y) {
			this.clickedIconId = -1;
			if (x >= 79 && x < 115) {
				this.clickedIconId = 0;
			} else if (x >= 129 && x < 165) {
				this.clickedIconId = 1;
			} else if (x >= 179 && x < 215) {
				this.clickedIconId = 2;
			}

			if (this.clickedIconId >= 0) {
				this.click(this.clickedIconId);
				this.minecraft.getSoundManager().play(SimpleSoundInstance.of(new Identifier("gui.button.press"), 1.0F));
			}
		}

		@Override
		protected final int size() {
			return this.entries.size();
		}

		protected final ItemStat getEntry(int index) {
			return this.entries.get(index);
		}

		protected abstract String getColumnHeader(int column);

		protected void renderStat(Stat stat, int x, int y, boolean isRowEven) {
			if (stat != null) {
				String string = stat.format(StatsScreen.this.stats.get(stat));
				StatsScreen.this.drawString(
					StatsScreen.this.textRenderer, string, x - StatsScreen.this.textRenderer.getWidth(string), y + 5, isRowEven ? 16777215 : 9474192
				);
			} else {
				String string = "-";
				StatsScreen.this.drawString(
					StatsScreen.this.textRenderer, string, x - StatsScreen.this.textRenderer.getWidth(string), y + 5, isRowEven ? 16777215 : 9474192
				);
			}
		}

		@Override
		protected void renderDecorations(int mouseX, int mouseY) {
			if (mouseY >= this.minY && mouseY <= this.maxY) {
				int i = this.getEntryAt(mouseX, mouseY);
				int j = this.width / 2 - 92 - 16;
				if (i >= 0) {
					if (mouseX < j + 40 || mouseX > j + 40 + 20) {
						return;
					}

					ItemStat itemStat = this.getEntry(i);
					this.renderStat(itemStat, mouseX, mouseY);
				} else {
					String string = "";
					if (mouseX >= j + 115 - 18 && mouseX <= j + 115) {
						string = this.getColumnHeader(0);
					} else if (mouseX >= j + 165 - 18 && mouseX <= j + 165) {
						string = this.getColumnHeader(1);
					} else {
						if (mouseX < j + 215 - 18 || mouseX > j + 215) {
							return;
						}

						string = this.getColumnHeader(2);
					}

					string = ("" + I18n.translate(string)).trim();
					if (string.length() > 0) {
						int k = mouseX + 12;
						int l = mouseY - 12;
						int m = StatsScreen.this.textRenderer.getWidth(string);
						StatsScreen.this.fillGradient(k - 3, l - 3, k + m + 3, l + 8 + 3, -1073741824, -1073741824);
						StatsScreen.this.textRenderer.drawWithShadow(string, k, l, -1);
					}
				}
			}
		}

		protected void renderStat(ItemStat stat, int x, int z) {
			if (stat != null) {
				Item item = stat.getItem();
				ItemStack itemStack = new ItemStack(item);
				String string = itemStack.getTranslationKey();
				String string2 = ("" + I18n.translate(string + ".name")).trim();
				if (string2.length() > 0) {
					int i = x + 12;
					int j = z - 12;
					int k = StatsScreen.this.textRenderer.getWidth(string2);
					StatsScreen.this.fillGradient(i - 3, j - 3, i + k + 3, j + 8 + 3, -1073741824, -1073741824);
					StatsScreen.this.textRenderer.drawWithShadow(string2, i, j, -1);
				}
			}
		}

		protected void click(int buttonDownTime) {
			if (buttonDownTime != this.selectedTab) {
				this.selectedTab = buttonDownTime;
				this.statSortOrder = -1;
			} else if (this.statSortOrder == -1) {
				this.statSortOrder = 1;
			} else {
				this.selectedTab = -1;
				this.statSortOrder = 0;
			}

			Collections.sort(this.entries, this.statComparator);
		}
	}

	@Environment(EnvType.CLIENT)
	class EntityStatsListWidget extends ListWidget {
		private final List<Entities.SpawnEggData> entries = Lists.newArrayList();

		public EntityStatsListWidget(Minecraft minecraft) {
			super(minecraft, StatsScreen.this.width, StatsScreen.this.height, 32, StatsScreen.this.height - 64, StatsScreen.this.textRenderer.fontHeight * 4);
			this.setRenderSelectionHighlight(false);

			for (Entities.SpawnEggData spawnEggData : Entities.SPAWN_EGG_DATA.values()) {
				if (StatsScreen.this.stats.get(spawnEggData.killEntityStat) > 0 || StatsScreen.this.stats.get(spawnEggData.entityKilledByStat) > 0) {
					this.entries.add(spawnEggData);
				}
			}
		}

		@Override
		protected int size() {
			return this.entries.size();
		}

		@Override
		protected void entryClicked(int index, boolean doubleClick, int mouseX, int mouseY) {
		}

		@Override
		protected boolean isEntrySelected(int index) {
			return false;
		}

		@Override
		protected int getHeight() {
			return this.size() * StatsScreen.this.textRenderer.fontHeight * 4;
		}

		@Override
		protected void renderBackground() {
			StatsScreen.this.renderBackground();
		}

		@Override
		protected void renderEntry(int index, int x, int y, int rowHeight, int mouseX, int mouseY) {
			Entities.SpawnEggData spawnEggData = this.entries.get(index);
			String string = I18n.translate("entity." + Entities.getKey(spawnEggData.id) + ".name");
			int i = StatsScreen.this.stats.get(spawnEggData.killEntityStat);
			int j = StatsScreen.this.stats.get(spawnEggData.entityKilledByStat);
			String string2 = I18n.translate("stat.entityKills", i, string);
			String string3 = I18n.translate("stat.entityKilledBy", string, j);
			if (i == 0) {
				string2 = I18n.translate("stat.entityKills.none", string);
			}

			if (j == 0) {
				string3 = I18n.translate("stat.entityKilledBy.none", string);
			}

			StatsScreen.this.drawString(StatsScreen.this.textRenderer, string, x + 2 - 10, y + 1, 16777215);
			StatsScreen.this.drawString(StatsScreen.this.textRenderer, string2, x + 2, y + 1 + StatsScreen.this.textRenderer.fontHeight, i == 0 ? 6316128 : 9474192);
			StatsScreen.this.drawString(StatsScreen.this.textRenderer, string3, x + 2, y + 1 + StatsScreen.this.textRenderer.fontHeight * 2, j == 0 ? 6316128 : 9474192);
		}
	}

	@Environment(EnvType.CLIENT)
	class GeneralStatsListWidget extends ListWidget {
		public GeneralStatsListWidget(Minecraft minecraft) {
			super(minecraft, StatsScreen.this.width, StatsScreen.this.height, 32, StatsScreen.this.height - 64, 10);
			this.setRenderSelectionHighlight(false);
		}

		@Override
		protected int size() {
			return Stats.GENERAL.size();
		}

		@Override
		protected void entryClicked(int index, boolean doubleClick, int mouseX, int mouseY) {
		}

		@Override
		protected boolean isEntrySelected(int index) {
			return false;
		}

		@Override
		protected int getHeight() {
			return this.size() * 10;
		}

		@Override
		protected void renderBackground() {
			StatsScreen.this.renderBackground();
		}

		@Override
		protected void renderEntry(int index, int x, int y, int rowHeight, int mouseX, int mouseY) {
			Stat stat = Stats.GENERAL.get(index);
			StatsScreen.this.drawString(StatsScreen.this.textRenderer, stat.getDecoratedName().getString(), x + 2, y + 1, index % 2 == 0 ? 16777215 : 9474192);
			String string = stat.format(StatsScreen.this.stats.get(stat));
			StatsScreen.this.drawString(
				StatsScreen.this.textRenderer, string, x + 2 + 213 - StatsScreen.this.textRenderer.getWidth(string), y + 1, index % 2 == 0 ? 16777215 : 9474192
			);
		}
	}

	@Environment(EnvType.CLIENT)
	class ItemStatsListWidget extends StatsScreen.AbstractStatsListWidget {
		public ItemStatsListWidget(Minecraft minecraft) {
			super(minecraft);
			this.entries = Lists.newArrayList();

			for (ItemStat itemStat : Stats.USED) {
				boolean bl = false;
				int i = Item.getId(itemStat.getItem());
				if (StatsScreen.this.stats.get(itemStat) > 0) {
					bl = true;
				} else if (Stats.ITEMS_BROKEN[i] != null && StatsScreen.this.stats.get(Stats.ITEMS_BROKEN[i]) > 0) {
					bl = true;
				} else if (Stats.ITEMS_CRAFTED[i] != null && StatsScreen.this.stats.get(Stats.ITEMS_CRAFTED[i]) > 0) {
					bl = true;
				}

				if (bl) {
					this.entries.add(itemStat);
				}
			}

			this.statComparator = new Comparator<ItemStat>() {
				public int compare(ItemStat itemStat, ItemStat itemStat2) {
					int i = Item.getId(itemStat.getItem());
					int j = Item.getId(itemStat2.getItem());
					Stat stat = null;
					Stat stat2 = null;
					if (ItemStatsListWidget.this.selectedTab == 0) {
						stat = Stats.ITEMS_BROKEN[i];
						stat2 = Stats.ITEMS_BROKEN[j];
					} else if (ItemStatsListWidget.this.selectedTab == 1) {
						stat = Stats.ITEMS_CRAFTED[i];
						stat2 = Stats.ITEMS_CRAFTED[j];
					} else if (ItemStatsListWidget.this.selectedTab == 2) {
						stat = Stats.ITEMS_USED[i];
						stat2 = Stats.ITEMS_USED[j];
					}

					if (stat != null || stat2 != null) {
						if (stat == null) {
							return 1;
						}

						if (stat2 == null) {
							return -1;
						}

						int k = StatsScreen.this.stats.get(stat);
						int l = StatsScreen.this.stats.get(stat2);
						if (k != l) {
							return (k - l) * ItemStatsListWidget.this.statSortOrder;
						}
					}

					return i - j;
				}
			};
		}

		@Override
		protected void renderHeader(int x, int y, Tesselator tesselator) {
			super.renderHeader(x, y, tesselator);
			if (this.clickedIconId == 0) {
				StatsScreen.this.renderSlot(x + 115 - 18 + 1, y + 1 + 1, 72, 18);
			} else {
				StatsScreen.this.renderSlot(x + 115 - 18, y + 1, 72, 18);
			}

			if (this.clickedIconId == 1) {
				StatsScreen.this.renderSlot(x + 165 - 18 + 1, y + 1 + 1, 18, 18);
			} else {
				StatsScreen.this.renderSlot(x + 165 - 18, y + 1, 18, 18);
			}

			if (this.clickedIconId == 2) {
				StatsScreen.this.renderSlot(x + 215 - 18 + 1, y + 1 + 1, 36, 18);
			} else {
				StatsScreen.this.renderSlot(x + 215 - 18, y + 1, 36, 18);
			}
		}

		@Override
		protected void renderEntry(int index, int x, int y, int rowHeight, int mouseX, int mouseY) {
			ItemStat itemStat = this.getEntry(index);
			Item item = itemStat.getItem();
			StatsScreen.this.renderStatIcon(x + 40, y, item);
			int i = Item.getId(item);
			this.renderStat(Stats.ITEMS_BROKEN[i], x + 115, y, index % 2 == 0);
			this.renderStat(Stats.ITEMS_CRAFTED[i], x + 165, y, index % 2 == 0);
			this.renderStat(itemStat, x + 215, y, index % 2 == 0);
		}

		@Override
		protected String getColumnHeader(int column) {
			if (column == 1) {
				return "stat.crafted";
			} else {
				return column == 2 ? "stat.used" : "stat.depleted";
			}
		}
	}

	@Environment(EnvType.CLIENT)
	class StatsListWidget extends StatsScreen.AbstractStatsListWidget {
		public StatsListWidget(Minecraft minecraft) {
			super(minecraft);
			this.entries = Lists.newArrayList();

			for (ItemStat itemStat : Stats.MINED) {
				boolean bl = false;
				int i = Item.getId(itemStat.getItem());
				if (StatsScreen.this.stats.get(itemStat) > 0) {
					bl = true;
				} else if (Stats.ITEMS_USED[i] != null && StatsScreen.this.stats.get(Stats.ITEMS_USED[i]) > 0) {
					bl = true;
				} else if (Stats.ITEMS_CRAFTED[i] != null && StatsScreen.this.stats.get(Stats.ITEMS_CRAFTED[i]) > 0) {
					bl = true;
				}

				if (bl) {
					this.entries.add(itemStat);
				}
			}

			this.statComparator = new Comparator<ItemStat>() {
				public int compare(ItemStat itemStat, ItemStat itemStat2) {
					int i = Item.getId(itemStat.getItem());
					int j = Item.getId(itemStat2.getItem());
					Stat stat = null;
					Stat stat2 = null;
					if (StatsListWidget.this.selectedTab == 2) {
						stat = Stats.BLOCKS_MINED[i];
						stat2 = Stats.BLOCKS_MINED[j];
					} else if (StatsListWidget.this.selectedTab == 0) {
						stat = Stats.ITEMS_CRAFTED[i];
						stat2 = Stats.ITEMS_CRAFTED[j];
					} else if (StatsListWidget.this.selectedTab == 1) {
						stat = Stats.ITEMS_USED[i];
						stat2 = Stats.ITEMS_USED[j];
					}

					if (stat != null || stat2 != null) {
						if (stat == null) {
							return 1;
						}

						if (stat2 == null) {
							return -1;
						}

						int k = StatsScreen.this.stats.get(stat);
						int l = StatsScreen.this.stats.get(stat2);
						if (k != l) {
							return (k - l) * StatsListWidget.this.statSortOrder;
						}
					}

					return i - j;
				}
			};
		}

		@Override
		protected void renderHeader(int x, int y, Tesselator tesselator) {
			super.renderHeader(x, y, tesselator);
			if (this.clickedIconId == 0) {
				StatsScreen.this.renderSlot(x + 115 - 18 + 1, y + 1 + 1, 18, 18);
			} else {
				StatsScreen.this.renderSlot(x + 115 - 18, y + 1, 18, 18);
			}

			if (this.clickedIconId == 1) {
				StatsScreen.this.renderSlot(x + 165 - 18 + 1, y + 1 + 1, 36, 18);
			} else {
				StatsScreen.this.renderSlot(x + 165 - 18, y + 1, 36, 18);
			}

			if (this.clickedIconId == 2) {
				StatsScreen.this.renderSlot(x + 215 - 18 + 1, y + 1 + 1, 54, 18);
			} else {
				StatsScreen.this.renderSlot(x + 215 - 18, y + 1, 54, 18);
			}
		}

		@Override
		protected void renderEntry(int index, int x, int y, int rowHeight, int mouseX, int mouseY) {
			ItemStat itemStat = this.getEntry(index);
			Item item = itemStat.getItem();
			StatsScreen.this.renderStatIcon(x + 40, y, item);
			int i = Item.getId(item);
			this.renderStat(Stats.ITEMS_CRAFTED[i], x + 115, y, index % 2 == 0);
			this.renderStat(Stats.ITEMS_USED[i], x + 165, y, index % 2 == 0);
			this.renderStat(itemStat, x + 215, y, index % 2 == 0);
		}

		@Override
		protected String getColumnHeader(int column) {
			if (column == 0) {
				return "stat.crafted";
			} else {
				return column == 1 ? "stat.used" : "stat.mined";
			}
		}
	}
}

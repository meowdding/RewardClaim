package net.minecraft.block;

import java.util.List;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.EndPortalBlockEntity;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.particle.ParticleType;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

public class EndPortalBlock extends BlockWithBlockEntity {
	protected EndPortalBlock(Material material) {
		super(material);
		this.setLight(1.0F);
	}

	@Override
	public BlockEntity createBlockEntity(World world, int metadata) {
		return new EndPortalBlockEntity();
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		float f = 0.0625F;
		this.setShape(0.0F, 0.0F, 0.0F, 1.0F, f, 1.0F);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public boolean shouldRenderFace(WorldView world, BlockPos pos, Direction face) {
		return face == Direction.DOWN ? super.shouldRenderFace(world, pos, face) : false;
	}

	@Override
	public void addCollisions(World world, BlockPos pos, BlockState state, Box shape, List<Box> collisions, Entity entity) {
	}

	@Override
	public boolean isSolidRender() {
		return false;
	}

	@Override
	public boolean isCube() {
		return false;
	}

	@Override
	public int getBaseDropCount(Random random) {
		return 0;
	}

	@Override
	public void onEntityCollision(World world, BlockPos pos, BlockState state, Entity entity) {
		if (entity.vehicle == null && entity.rider == null && !world.isClient) {
			entity.changeDimension(1);
		}
	}

	@Environment(EnvType.CLIENT)
	@Override
	public void randomDisplayTick(World world, BlockPos pos, BlockState state, Random random) {
		double d = pos.getX() + random.nextFloat();
		double e = pos.getY() + 0.8F;
		double f = pos.getZ() + random.nextFloat();
		double g = 0.0;
		double h = 0.0;
		double i = 0.0;
		world.addParticle(ParticleType.SMOKE_NORMAL, d, e, f, g, h, i);
	}

	@Environment(EnvType.CLIENT)
	@Override
	public Item getPickItem(World world, BlockPos pos) {
		return null;
	}

	@Override
	public MapColor getMapColor(BlockState state) {
		return MapColor.BLACK;
	}
}

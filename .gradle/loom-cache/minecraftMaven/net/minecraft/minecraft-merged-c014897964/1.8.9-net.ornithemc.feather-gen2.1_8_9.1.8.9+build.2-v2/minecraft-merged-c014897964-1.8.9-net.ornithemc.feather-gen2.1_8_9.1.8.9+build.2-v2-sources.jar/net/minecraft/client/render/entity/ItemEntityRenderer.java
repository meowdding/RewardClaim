package net.minecraft.client.render.entity;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.model.block.BakedModel;
import net.minecraft.client.render.platform.GlStateManager;
import net.minecraft.client.render.texture.TextureAtlas;
import net.minecraft.client.resource.model.ModelTransformations;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.resource.Identifier;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class ItemEntityRenderer extends EntityRenderer<ItemEntity> {
	private final ItemRenderer itemRenderer;
	private Random random = new Random();

	public ItemEntityRenderer(EntityRenderDispatcher dispatcher, ItemRenderer itemRenderer) {
		super(dispatcher);
		this.itemRenderer = itemRenderer;
		this.shadowSize = 0.15F;
		this.shadowDarkness = 0.75F;
	}

	private int applyItemBobbing(ItemEntity entity, double dx, double dy, double dz, float tickDelta, BakedModel model) {
		ItemStack itemStack = entity.getItem();
		Item item = itemStack.getItem();
		if (item == null) {
			return 0;
		}

		boolean bl = model.isGui3d();
		int i = this.scaledStackSize(itemStack);
		float f = 0.25F;
		float g = MathHelper.sin((entity.getAge() + tickDelta) / 10.0F + entity.bobOffset) * 0.1F + 0.1F;
		float h = model.getTransformations().get(ModelTransformations.Type.GROUND).scale.y;
		GlStateManager.translatef((float)dx, (float)dy + g + 0.25F * h, (float)dz);
		if (bl || this.dispatcher.options != null) {
			float j = ((entity.getAge() + tickDelta) / 20.0F + entity.bobOffset) * (180.0F / (float)Math.PI);
			GlStateManager.rotatef(j, 0.0F, 1.0F, 0.0F);
		}

		if (!bl) {
			float j = -0.0F * (i - 1) * 0.5F;
			float k = -0.0F * (i - 1) * 0.5F;
			float l = -0.046875F * (i - 1) * 0.5F;
			GlStateManager.translatef(j, k, l);
		}

		GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
		return i;
	}

	private int scaledStackSize(ItemStack item) {
		int i = 1;
		if (item.size > 48) {
			i = 5;
		} else if (item.size > 32) {
			i = 4;
		} else if (item.size > 16) {
			i = 3;
		} else if (item.size > 1) {
			i = 2;
		}

		return i;
	}

	public void render(ItemEntity entity, double dx, double dy, double dz, float yaw, float tickDelta) {
		ItemStack itemStack = entity.getItem();
		this.random.setSeed(187L);
		boolean bl = false;
		if (this.bindTexture(entity)) {
			this.dispatcher.textureManager.get(this.getTextureLocation(entity)).pushFilter(false, false);
			bl = true;
		}

		GlStateManager.enableRescaleNormal();
		GlStateManager.alphaFunc(516, 0.1F);
		GlStateManager.enableBlend();
		GlStateManager.blendFuncSeparate(770, 771, 1, 0);
		GlStateManager.pushMatrix();
		BakedModel bakedModel = this.itemRenderer.getModelShaper().getModel(itemStack);
		int i = this.applyItemBobbing(entity, dx, dy, dz, tickDelta, bakedModel);

		for (int j = 0; j < i; j++) {
			if (bakedModel.isGui3d()) {
				GlStateManager.pushMatrix();
				if (j > 0) {
					float f = (this.random.nextFloat() * 2.0F - 1.0F) * 0.15F;
					float g = (this.random.nextFloat() * 2.0F - 1.0F) * 0.15F;
					float h = (this.random.nextFloat() * 2.0F - 1.0F) * 0.15F;
					GlStateManager.translatef(f, g, h);
				}

				GlStateManager.scalef(0.5F, 0.5F, 0.5F);
				bakedModel.getTransformations().apply(ModelTransformations.Type.GROUND);
				this.itemRenderer.renderItem(itemStack, bakedModel);
				GlStateManager.popMatrix();
			} else {
				GlStateManager.pushMatrix();
				bakedModel.getTransformations().apply(ModelTransformations.Type.GROUND);
				this.itemRenderer.renderItem(itemStack, bakedModel);
				GlStateManager.popMatrix();
				float f = bakedModel.getTransformations().ground.scale.x;
				float g = bakedModel.getTransformations().ground.scale.y;
				float h = bakedModel.getTransformations().ground.scale.z;
				GlStateManager.translatef(0.0F * f, 0.0F * g, 0.046875F * h);
			}
		}

		GlStateManager.popMatrix();
		GlStateManager.disableRescaleNormal();
		GlStateManager.disableBlend();
		this.bindTexture(entity);
		if (bl) {
			this.dispatcher.textureManager.get(this.getTextureLocation(entity)).popFilter();
		}

		super.render(entity, dx, dy, dz, yaw, tickDelta);
	}

	protected Identifier getTextureLocation(ItemEntity entity) {
		return TextureAtlas.BLOCKS_LOCATION;
	}
}

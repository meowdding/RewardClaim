package net.minecraft.client.render.entity.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.model.entity.HumanoidModel;

@Environment(EnvType.CLIENT)
public class ArmorLayer extends AbstractArmorLayer<HumanoidModel> {
	public ArmorLayer(LivingEntityRenderer<?> livingEntityRenderer) {
		super(livingEntityRenderer);
	}

	@Override
	protected void hideAll() {
		this.innerModel = new HumanoidModel(0.5F);
		this.outerModel = new HumanoidModel(1.0F);
	}

	protected void setVisible(HumanoidModel model, int equipmentSlot) {
		this.setInvisible(model);
		switch (equipmentSlot) {
			case 1:
				model.rightLeg.visible = true;
				model.leftLeg.visible = true;
				break;
			case 2:
				model.body.visible = true;
				model.rightLeg.visible = true;
				model.leftLeg.visible = true;
				break;
			case 3:
				model.body.visible = true;
				model.rightArm.visible = true;
				model.leftArm.visible = true;
				break;
			case 4:
				model.head.visible = true;
				model.hat.visible = true;
		}
	}

	protected void setInvisible(HumanoidModel model) {
		model.setVisible(false);
	}
}

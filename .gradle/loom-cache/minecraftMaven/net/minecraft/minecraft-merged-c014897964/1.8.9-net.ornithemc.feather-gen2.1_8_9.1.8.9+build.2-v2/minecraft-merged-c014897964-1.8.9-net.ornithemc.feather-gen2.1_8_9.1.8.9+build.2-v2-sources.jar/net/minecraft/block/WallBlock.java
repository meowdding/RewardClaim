package net.minecraft.block;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.StateDefinition;
import net.minecraft.block.state.property.BooleanProperty;
import net.minecraft.block.state.property.EnumProperty;
import net.minecraft.block.state.property.StringSerializable;
import net.minecraft.item.CreativeModeTab;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.locale.I18n;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

public class WallBlock extends Block {
	public static final BooleanProperty UP = BooleanProperty.of("up");
	public static final BooleanProperty NORTH = BooleanProperty.of("north");
	public static final BooleanProperty EAST = BooleanProperty.of("east");
	public static final BooleanProperty SOUTH = BooleanProperty.of("south");
	public static final BooleanProperty WEST = BooleanProperty.of("west");
	public static final EnumProperty<WallBlock.Variant> VARIANT = EnumProperty.of("variant", WallBlock.Variant.class);

	public WallBlock(Block block) {
		super(block.material);
		this.setDefaultState(
			this.stateDefinition.any().set(UP, false).set(NORTH, false).set(EAST, false).set(SOUTH, false).set(WEST, false).set(VARIANT, WallBlock.Variant.NORMAL)
		);
		this.setStrength(block.miningTime);
		this.setBlastResistance(block.blastResistance / 3.0F);
		this.setSounds(block.sounds);
		this.setCreativeModeTab(CreativeModeTab.BUILDING_BLOCKS);
	}

	@Override
	public String getName() {
		return I18n.translate(this.getTranslationKey() + "." + WallBlock.Variant.NORMAL.getName() + ".name");
	}

	@Override
	public boolean isCube() {
		return false;
	}

	@Override
	public boolean canWalkThrough(WorldView world, BlockPos pos) {
		return false;
	}

	@Override
	public boolean isSolidRender() {
		return false;
	}

	@Override
	public void updateShape(WorldView world, BlockPos pos) {
		boolean bl = this.shouldConnectTo(world, pos.north());
		boolean bl2 = this.shouldConnectTo(world, pos.south());
		boolean bl3 = this.shouldConnectTo(world, pos.west());
		boolean bl4 = this.shouldConnectTo(world, pos.east());
		float f = 0.25F;
		float g = 0.75F;
		float h = 0.25F;
		float i = 0.75F;
		float j = 1.0F;
		if (bl) {
			h = 0.0F;
		}

		if (bl2) {
			i = 1.0F;
		}

		if (bl3) {
			f = 0.0F;
		}

		if (bl4) {
			g = 1.0F;
		}

		if (bl && bl2 && !bl3 && !bl4) {
			j = 0.8125F;
			f = 0.3125F;
			g = 0.6875F;
		} else if (!bl && !bl2 && bl3 && bl4) {
			j = 0.8125F;
			h = 0.3125F;
			i = 0.6875F;
		}

		this.setShape(f, 0.0F, h, g, j, i);
	}

	@Override
	public Box getCollisionShape(World world, BlockPos pos, BlockState state) {
		this.updateShape(world, pos);
		this.maxY = 1.5;
		return super.getCollisionShape(world, pos, state);
	}

	public boolean shouldConnectTo(WorldView world, BlockPos pos) {
		Block block = world.getBlockState(pos).getBlock();
		if (block == Blocks.BARRIER) {
			return false;
		} else if (block == this || block instanceof FenceGateBlock) {
			return true;
		} else {
			return block.material.isSolidBlocking() && block.isCube() ? block.material != Material.PUMPKIN : false;
		}
	}

	@Environment(EnvType.CLIENT)
	@Override
	public void addToCreativeMenu(Item item, CreativeModeTab tab, List<ItemStack> inventory) {
		for (WallBlock.Variant variant : WallBlock.Variant.values()) {
			inventory.add(new ItemStack(item, 1, variant.getId()));
		}
	}

	@Override
	public int getDropItemMetadata(BlockState state) {
		return state.get(VARIANT).getId();
	}

	@Environment(EnvType.CLIENT)
	@Override
	public boolean shouldRenderFace(WorldView world, BlockPos pos, Direction face) {
		return face == Direction.DOWN ? super.shouldRenderFace(world, pos, face) : true;
	}

	@Override
	public BlockState getStateFromMetadata(int metadata) {
		return this.defaultState().set(VARIANT, WallBlock.Variant.byId(metadata));
	}

	@Override
	public int getMetadataFromState(BlockState state) {
		return state.get(VARIANT).getId();
	}

	@Override
	public BlockState resolveVirtualProperties(BlockState state, WorldView world, BlockPos pos) {
		return state.set(UP, !world.isAir(pos.up()))
			.set(NORTH, this.shouldConnectTo(world, pos.north()))
			.set(EAST, this.shouldConnectTo(world, pos.east()))
			.set(SOUTH, this.shouldConnectTo(world, pos.south()))
			.set(WEST, this.shouldConnectTo(world, pos.west()));
	}

	@Override
	protected StateDefinition createStateDefinition() {
		return new StateDefinition(this, UP, NORTH, EAST, WEST, SOUTH, VARIANT);
	}

	public enum Variant implements StringSerializable {
		NORMAL(0, "cobblestone", "normal"),
		MOSSY(1, "mossy_cobblestone", "mossy");

		private static final WallBlock.Variant[] BY_ID = new WallBlock.Variant[values().length];
		private final int id;
		private final String key;
		private String name;

		Variant(int id, String key, String name) {
			this.id = id;
			this.key = key;
			this.name = name;
		}

		public int getId() {
			return this.id;
		}

		@Override
		public String toString() {
			return this.key;
		}

		public static WallBlock.Variant byId(int id) {
			if (id < 0 || id >= BY_ID.length) {
				id = 0;
			}

			return BY_ID[id];
		}

		@Override
		public String getSerializedName() {
			return this.key;
		}

		public String getName() {
			return this.name;
		}

		static {
			for (WallBlock.Variant variant : values()) {
				BY_ID[variant.getId()] = variant;
			}
		}
	}
}
